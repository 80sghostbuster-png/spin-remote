# SPIN REMOTE — concept build (demo mode only)

A spinning reel of four TV remotes (Roku, Fire TV, Google TV, Apple TV).
Swipe the reel to spin and it snaps to a remote. **Tap a remote** and the reel locks on it and
the remote smoothly expands to a full-size, usable remote. **SPIN** (bottom bar), the **‹ SPIN**
chevron (top left) or Esc collapses it and unlocks the reel. While expanded, reel gestures are off
so they never fight the buttons or clickpad. Every expanded remote has a big red **KEYBOARD**
button: native phone keyboard, Backspace, Enter/Search, and a "would send to the TV" demo log.
Same behaviour in the ring layout. A **PAIR / PAIRED ✓** button sits beside the dock (and in the expanded
action bar between SPIN and KEYBOARD): PAIR opens the pairing sheet for the current TV, PAIRED ✓ opens the TV list.
Look: original violet Roku / orange-ring Fire TV / white Google TV / aluminum Apple TV (a NES-palette
experiment was tried and reverted; its screenshots are in shots/nes-theme-discarded/).
Tap the orbit button (top right) to flip between the straight **reel** and the tilted **ring**.

**Status:** front-end concept + demo bridge. It controls NO real TV. A yellow
"DEMO MODE" banner is always shown. The real-TV bridge (Roku ECP, Google TV,
Fire TV ADB, Apple TV pyatv) is NOT built yet.

## Run
    cd bridge
    ../.venv/bin/python run.py --demo --port 8765
Open http://localhost:8765/ — or http://<your-computer-LAN-ip>:8765/ on your phone (same Wi-Fi).
Options: `--host`, `--port`, `--token SECRET` (require a token), `--cert/--key` (https).
If no bridge answers, the page falls back to an in-browser simulation (banner says so).
Static hosting of `web/` also works (simulation only).

## Add to Home Screen
- iPhone: Safari > Share > Add to Home Screen.
- Android: Chrome menu > Install app.
Note: service workers (offline/installable) only register on https or localhost.
Over plain LAN http you can still Add to Home Screen as a bookmark-style app, but
without offline support. For full PWA install use `--cert/--key` or an https tunnel.

## Mixed-content constraint (for the real bridge later)
An https page can't call an http bridge on your LAN (browser blocks it). So the bridge
serves the app itself, same-origin, from your LAN; don't host the UI on https and point
it at a LAN http bridge.

## Demo things to try
- Swipe/fling the reel; tap the bottom dock or ring orbs; arrow keys / mouse wheel work.
- Every button shows what real command it would send (toast + `/api/demo/log`).
- Hold Volume to auto-repeat. Apple remote: swipe/tap the black clickpad.
- Tap a remote to expand it; KEYBOARD button: type text. TV icon in header: your TVs, scan, pair.
- Demo pairing codes: Google TV `A1B2C3`, Apple TV `1234`, Fire TV = confirm.
- Header: sound and haptics toggles. iOS Safari has no `navigator.vibrate` (no haptics on iPhone web).

## Single-file bundle
    cd tools && npm i && node build-pages.mjs   # -> pages/index.html (inline CSS + esbuild JS, no manifest/service worker)
Works opened from disk or any static host (falls back to the in-browser simulation).

## Tests
    cd tools && npm i && node interact.mjs   # scripted touch tests (needs demo server running + Chrome)
    node shots.mjs                            # screenshots into ../shots
(`tools/*.mjs` expect Chrome at the path set inside; adjust if needed.)

## What you'll need to enable on each TV (for the real bridge, later)
- Roku: Settings > System > Advanced system settings > Control by mobile apps > Enabled.
- Fire TV: Settings > My Fire TV > Developer options > ADB debugging ON; accept "Always allow" on first connect.
- Google TV: nothing; enter the 6-character code the TV shows when pairing.
- Apple TV: enter the PIN shown on the TV (Remote app pairing; AirPlay PIN may also be asked).

## Layout
- `web/` PWA (vanilla JS): `app.js`, `wheel.js` (spin physics), `remotes.js`, `style.css`, `sw.js`, `manifest.webmanifest`
- `bridge/` aiohttp server (demo backend, API contract, device store)
- `tools/` headless-Chrome tests and screenshot scripts

## Android app (Capacitor) – `android/`
- Debug APK (sideload): `android/dist/spin-remote-debug.apk` · signed release APK: `android/dist/spin-remote-release-signed.apk` · Play Store bundle: `android/dist/spin-remote-release.aab`
- Keystore + password: `android/spin-remote-release.jks`, `android/KEYSTORE-KEEP-SAFE.txt` (back both up; losing them means you can't update the app).
- Store listing assets: `android/store/` (icon, feature graphic, 5 screenshots 1080x2160, short/full description, privacy policy HTML – add a contact email to it before publishing).
- Rebuild: `node android/scripts/build-www.mjs`, `cap sync android` (Node >= 22), then `./gradlew assembleDebug assembleRelease bundleRelease` in `android/android`.
- Pairing flow (test5, like mainstream remote apps): tap a remote's PAIR pill → "Connect your TV" auto-scans and lists the TVs it found → tap yours. Google TV: type the code shown on the TV. Fire TV / Apple TV: just follow the prompt on the TV ("Look at your Fire TV and press Allow"). Roku needs nothing. A single **Scan** button re-scans; "Can't see it? Enter its address" is the fallback. Errors are plain sentences; the technical text (port check, native error, phone network) is behind a **Details** toggle together with **Copy debug log**.
- Pairing screen (test6, modelled on a reference screenshot): PAIR opens a full-screen dimmed page: X top-left, a TV photo, "Please select the device to connect", then big rounded rows (platform wordmark + device name, a small spinner while connecting). Tapping a row starts pairing. Google TV / Apple TV: a small "Pairing with device / Please enter the PIN code" modal (Google TV accepts hex letters, Apple TV digits) with Cancel / OK. Fire TV: the same modal asks you to Allow on the TV. Roku needs nothing. On failure the modal says what to do in a sentence and hides the technical text behind **Details** (+ Copy debug log). A comparison image is in `android/shots/`.
- Google TV diagnostics (test6): Details lists each step: 1 TCP connect to 6467, 2 TLS handshake (self-signed, client cert), 3 pairing request, 4 code shown on the TV, each OK/FAILED with the reason. Sockets are now bound to the Wi-Fi network individually (`Network.bindSocket`) on top of `bindProcessToNetwork`; a TLS 1.3 handshake failure is retried once with TLS 1.2; the pairing/control ports come from the TV's real mDNS record when available.
- Buttons (test5): every remote button sends on touch-down (a click is a fallback). Only the D-pad arrows and volume repeat while held. The status pill shows each command's real result ("Up ✓" / "Up ✗ HTTP 403"); tap a ✗ pill to see what happened.
- Fire TV (test5): pairing uses ONE ADB connection like `adb connect` (AUTH token → signature → public key → wait for the Allow dialog, reconnecting if the TV drops the socket); key presses are queued per TV so overlapping shell streams can't steal each other's packets.
- Roku ECP: `POST /keypress/<Key>` with `Content-Length: 0` and `Connection: close` (checked on the wire against the Java HTTP client in `android/tests/realdevice.test.mjs`). If Roku Settings → System → Advanced → Control by mobile apps → Network access is "Limited", keypresses return 403 while app launches still work.
- Real-device diagnostics (v test3): in every pairing sheet, **Copy debug log** (tap = copy, press & hold = show text to select) gives the full native-call log; connection failures carry the real error text plus a port check of the TV (6467 pairing / 6466 control / 8009 Cast: open / closed / no answer) and the phone's Wi-Fi state. The app binds itself to the Wi-Fi network (mobile data on does not matter), connects with 9 s timeouts and 2-3 tries, searches only the platform being paired, one NSD search at a time, with a raw-mDNS and a /24 port-sweep fallback.
- Tests: `cd android && node tests/run-all.mjs` (protocol suites vs self-written mock TVs + pyatv/androidtvremote2 oracles), `node tools/android-e2e.mjs`, `node tools/android-e2e-gtv.mjs`, `node tools/android-e2e-taps.mjs`, `node tools/android-e2e-roku403.mjs`, `node tools/perf-compare.mjs <old-index.html>` (pixel diff + main-thread cost old vs new).
- Smoothness work: idle screen no longer redraws (rAF loop only renders while something moves), cached style writes, translate3d + will-change only while moving, 0.25px blur steps, non-inherited `--dim-o`, 15-step accent fade (restyles the tree half as often), cached canvas gradients, paused kbd-glow animation when off-screen, passive pointer listeners, deferred localStorage write, explicit WebView hardware layer + no overscroll. An automatic "lite" mode (backdrop blur, side-remote blur, accent tween off while moving) switches on if real frames run slow.

- test7 (volume, latency, Apple TV, scope): volume up/down/mute audited per platform (Roku sticks say "This Roku can't change volume; use your TV remote", Fire TV falls back to `cmd media_session volume --adj`, Apple TV has no mute and says so); a single tap always sends and only held repeats coalesce; the pill shows an instant optimistic state and then "✓" or the real failure. Latency: Fire TV keeps one ADB connection with a multiplexed persistent shell stream (no per-press handshake, no waiting for command close), Google TV/Apple TV keep their TLS/Companion session open and warm it when a TV is selected, Roku warms capability info. Apple TV: per-step Details (TCP → mDNS port refresh → Pair-Setup/Verify → session). Tests: `tests/volume.test.mjs`, `tests/latency.bench.mjs`. Emulator helpers: `tools/emulator-mocks.mjs`, `tools/emu-lib.mjs` (the stock Android 14 emulator image's WebView 113 crashes under software emulation, so the UI could not be driven there). Next (not implemented): Samsung Tizen (WebSocket 8001/8002, Allow on TV), LG webOS (WebSocket 3000/3001, prompt on TV), Vizio SmartCast (PIN pairing over HTTPS 7345/9000).

## Build 30
Fire TV play/pause, rewind/fast-forward, volume and mute now send exactly the official app's requests (docs/FIRETV-PROTOCOL.md):
request-id header, the official Content-Type, the official scan body for rewind/fast-forward. With an official pairing the volume
buttons are never hidden. Build 21 ADB fallback kept. Tests: android/tests/regress30.test.mjs (strict official-spec mock). Mock-only.

## Build 31
Fire TV paired the official way: every button (arrows, OK, play/pause, rewind/ff, volume, mute) is ONE request in the official form,
the same code path as the arrows — no variants, no skip memory, no volume guard in the remote screen. ADB (build 21) only when that
request errors. Test: android/tests/ui-fire31.test.mjs taps the real remote UI against the real backend and a strict mock. Mock-only.

## Build 32 (2026-11-01)
- Every Fire TV press now logs the TV's full reply (status line + body). On connect the app reads GET /v1/FireTV, /v1/FireTV/status and /v1/FireTV/properties and logs them (including whether the TV says volume is supported).
- Request headers now follow the official app's HTTP stack order/casing (no Content-Type/Length on GET; Connection: Keep-Alive).
- Traced the official volume/play-pause tap path end to end: a short tap sends one POST /v1/FireTV?action=volume_up (empty body, no keyDown/keyUp) over HTTPS :8080 — the same request we send. Details in docs/FIRETV-PROTOCOL.md.

## Build 33 (2026-11-01)
- Fire TV volume up/down/mute rebuilt from scratch in ONE file: `web/native/firetv-volume.js` (the old volume entries in firetv-lightning.js are gone).
- A 200 "OK" from the TV is no longer taken as success. The TV's own reported volume is read before and after each press (GET /v1/FireTV/status, /properties, /v1/FireTV). If it didn't move, the official forms are tried once each (tap → keyDown+keyUp hold → keyDownUp); the one that really moved it is remembered. If the TV doesn't report volume, the official tap is sent once.
- Requests now look like OkHttp 4.12.0's (the official app's version): Content-Length: 0 on an empty POST, Connection: Keep-Alive, Accept-Encoding: gzip (gzip answers are unpacked), User-Agent: okhttp/4.12.0.
