# Fire TV remote protocol (build 30) — interoperability facts only

Read from the official Fire TV phone app (com.amazon.storm.lightning.client.aosp, public APKPure download) for
interoperability: endpoints, action names, methods, headers, JSON bodies, ports. No Amazon code or assets are copied or bundled.

- Wake: POST http://TV:8009/apps/FireTVRemote (DIAL).
- API: https://TV:8080/v1/... (TLS 1.2, TV's own certificate). Every request: POST unless noted, headers
  `x-amzn-request-id: <random UUID v4>`, `x-api-key: 0987654321`, `x-client-token: <token>` (after pairing),
  `Content-Type: application/json; charset=utf-8`; a body-less POST sends an empty body. Timeout 3 s.
- Pairing: /v1/FireTV/pin/display {"friendlyName"}, /v1/FireTV/pin/verify {"pin"} → {"description": token}.
- Buttons (tap): POST /v1/FireTV?action=<a>, no body. a = dpad_up, dpad_down, dpad_left, dpad_right, select, back, home,
  menu, volume_up, volume_down, mute, power, sleep, wakeup, backspace, epg, start, stop.
  Hold: body {"keyActionType":"keyDown"} at start, {"keyActionType":"keyUp"} at release.
- Play/pause (tap): POST /v1/media?action=play, no body. Hold adds {"keyAction":{"keyActionType":"keyDown"|"keyUp"}}.
- Rewind / fast-forward (tap): POST /v1/media?action=scan, body {"direction":"back"|"forward","durationInSeconds":"10","speed":"1"}.
- Volume goes over the same API (no separate channel); the TV turns it into HDMI-CEC, so it needs HDMI-CEC on the TV.
- Other paths seen: /v1/FireTV/text, /v1/FireTV/keyboard, /v1/FireTV/apps, /v1/FireTV/appsV2, /v1/FireTV/properties,
  /v1/FireTV/status (GET), /v1/FireTV/voiceCommand.

## Build 32 trace: official volume / play-pause tap (interoperability facts only)
- Enum RemoteTapCommand (dec.js ~576830): VolumeUp='volume_up', VolumeDown='volume_down', Mute='mute'; KeyActionType keyUp/keyDown/keyDownUp; MediaCommand play/forward/back.
- useLongPress (dec.js 1022767): press-in starts a 300 ms timer; release before it fires → onPress (short tap); after → onLongPressStart at 300 ms and onLongPressEnd on release.
- useCapabilitiesFunctionalityViewModel (dec.js ~1022400): onPress → performCommand(cmd) → new SendCommandRequest(cmd, undefined); onLongPressStart → (cmd, true) = body {"keyActionType":"keyDown"}; onLongPressEnd → (cmd, false) = {"keyActionType":"keyUp"}.
- SendCommandRequest (dec.js 1021697): POST, EndpointType.Turnstile (https://<ip>:8080/v1), path ['FireTV'], query action=<cmd>, timeout 3 s, modifier authorized; body getter returns undefined for a tap → empty body.
- Networking.perform (dec.js ~577590): declareUsage(usageSpace) is local analytics only; then internalPerform → native OkHttp. No websocket or other port for keys (FeniksWebSocket is used for voice only).
- Play/pause tap: MediaCommandRequest(Play) → POST /v1/media?action=play, empty body; long-press rew/ff → scan body.

## Build 33 additions (interoperability facts only)
- Pairing: ShowPinRequest (dec.js 970716) POST /v1/FireTV/pin/display body {"friendlyName": deviceName}; ValidatePinRequest (dec.js 1041103) POST /v1/FireTV/pin/verify {"pin"}. No client-id/device-id header, no capability registration after verify; the only extra requests are status/heartbeat polls (dec.js ~967319–967400) and GET device info.
- Native request (jadx DeviceConnection$processRequest$2.java lines 54–79): Content-Type defaults to application/json; charset=utf-8; a POST without body gets an empty body (OkHttp then sends Content-Length: 0). Headers are only those the JS layer passes. OkHttp version string in classes5.dex: okhttp/4.12.0.
- KeyActionType.KeyDownUp = 'keyDownUp' is defined (dec.js 576864) but not referenced by any button handler.
