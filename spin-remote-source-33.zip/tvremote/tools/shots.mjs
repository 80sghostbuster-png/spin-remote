import puppeteer from 'puppeteer-core';
const URL = process.env.URL || 'http://localhost:8765/';
const out = '/workspace/tvremote/shots/';
const browser = await puppeteer.launch({ executablePath: '/usr/bin/google-chrome', headless: 'new', args: ['--no-sandbox', '--disable-gpu-sandbox'] });
const errors = [];
async function page(q = '') {
  const p = await browser.newPage();
  await p.setViewport({ width: 390, height: 844, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
  p.on('console', (m) => { if (['error', 'warning'].includes(m.type())) errors.push(`[${m.type()}] ${m.text()}`); });
  p.on('pageerror', (e) => errors.push('[pageerror] ' + e.message));
  p.on('requestfailed', (r) => errors.push('[reqfail] ' + r.url()));
  await p.goto(URL + q, { waitUntil: 'networkidle0' });
  await new Promise((r) => setTimeout(r, 900));
  return p;
}
const shot = async (p, n) => { await p.screenshot({ path: out + n + '.png' }); console.log('saved', n); };
const names = ['roku', 'firetv', 'googletv', 'appletv'];
for (let i = 0; i < 4; i++) { const p = await page(`?layout=reel&i=${i}`); await shot(p, `reel-${i + 1}-${names[i]}`); await p.close(); }
for (let i = 0; i < 4; i += 3) { const p = await page(`?layout=ring&i=${i}`); await shot(p, `ring-${i + 1}-${names[i]}`); await p.close(); }
console.log('ERRORS', JSON.stringify(errors, null, 1));
await browser.close();
