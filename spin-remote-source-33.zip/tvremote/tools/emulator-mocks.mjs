// Mock Roku / Fire TV / Google TV / Apple TV on the host, for the Android emulator (reachable there as 10.0.2.2; start the emulator with -ports 5700,5701 so host port 5555 is free).
// Every event the "TV" receives is logged with a host timestamp (Date.now) to /tmp/emu-events.jsonl; control + state on http://127.0.0.1:9999
import fs from 'node:fs'; import http from 'node:http';
import { startRokuMock } from '../android/mocks/roku-mock.mjs';
import { startAndroidTvMock } from '../android/mocks/androidtv-mock.mjs';
import { startAppleTvMock } from '../android/mocks/appletv-mock.mjs';
import { startAdbMock } from '../android/mocks/adb-mock.mjs';
const LOG = '/tmp/emu-events.jsonl'; fs.writeFileSync(LOG, '');
const ev = (tv, what) => fs.appendFileSync(LOG, JSON.stringify({ t: Date.now(), tv, what }) + '\n');
const tap = (arr, tv, f = (x) => x) => { const p = arr.push.bind(arr); arr.push = (...a) => { for (const x of a) ev(tv, f(x)); return p(...a); }; };
const kind = process.env.ROKU_KIND || 'box';
const roku = await startRokuMock({ port: 8060, ssdpPort: 11900, host: '0.0.0.0', kind });
const fire = await startAdbMock({ port: 5555, host: '0.0.0.0', autoAllow: false, inputMs: Number(process.env.INPUT_MS || 0) });
const gtv = await startAndroidTvMock({ pairPort: 6467, remotePort: 6466, host: '0.0.0.0' });
const atv = await startAppleTvMock({ port: 49153, host: '0.0.0.0' });
tap(roku.st.log, 'roku'); tap(fire.st.cmds, 'firetv'); tap(gtv.st.keys, 'googletv', (k) => `key ${k.code}`); tap(atv.st.hid, 'appletv', (h) => `hid ${h.code}/${h.state}`);
const state = () => ({ roku: { kind }, gtvCode: gtv.st.code, gtvPaired: gtv.st.paired.size, atvPin: atv.st.pin, atvPairLog: atv.st.pairLog, fireOffered: fire.st.offered.length, fireTrusted: fire.st.trusted.length });
http.createServer((q, s) => { if (q.url === '/allow') fire.allow(); if (q.url === '/reset-log') fs.writeFileSync(LOG, ''); s.end(JSON.stringify(state())); }).listen(9999, '127.0.0.1');
console.log('mocks up', JSON.stringify(state()));
