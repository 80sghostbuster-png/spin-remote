// Renders the Android launcher icons (adaptive + legacy + round), splash images and the 512px Play icon from web/icons/icon.svg.
import puppeteer from 'puppeteer-core'; import fs from 'node:fs'; import path from 'node:path';
const root = '/workspace/tvremote/', res = root + 'android/android/app/src/main/res/', store = root + 'android/store/';
fs.mkdirSync(store, { recursive: true });
const svg = fs.readFileSync(root + 'web/icons/icon.svg', 'utf8');
const art = svg.replace(/<defs>[\s\S]*?<\/defs>\s*<rect[^>]*\/>/, '');                      // artwork only (no background tile)
const inner = art.replace(/^<svg[^>]*>/, '').replace(/<\/svg>\s*$/, '');
const BG = '#0b0914';
const b = await puppeteer.launch({ executablePath: '/usr/bin/google-chrome', headless: 'new', args: ['--no-sandbox'] });
async function render(html, size, out, transparent = true, w = size, h = size) {
  const p = await b.newPage(); await p.setViewport({ width: w, height: h });
  await p.setContent(`<body style="margin:0;background:${transparent ? 'transparent' : BG}">${html}</body>`);
  await p.screenshot({ path: out, omitBackground: transparent }); await p.close();
}
const full = (rx, size) => svg.replace('<svg ', `<svg width="${size}" height="${size}" `).replace('rx="112"', `rx="${rx}"`);
const fg = (size) => `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 108 108"><g transform="translate(54 54) scale(0.1) translate(-256 -256)">${inner}</g></svg>`;   // art spans ~±200 → ±20dp… scaled to the 66dp safe zone below
const dens = { mdpi: 1, hdpi: 1.5, xhdpi: 2, xxhdpi: 3, xxxhdpi: 4 };
for (const [d, k] of Object.entries(dens)) {
  const dir = res + `mipmap-${d}/`;
  const fgSvg = `<svg xmlns="http://www.w3.org/2000/svg" width="${108 * k}" height="${108 * k}" viewBox="0 0 108 108"><g transform="translate(54 54) scale(0.165) translate(-256 -256)">${inner}</g></svg>`;
  await render(fgSvg, 108 * k, dir + 'ic_launcher_foreground.png');
  await render(full(112, 48 * k), 48 * k, dir + 'ic_launcher.png');
  await render(`<div style="width:${48 * k}px;height:${48 * k}px;border-radius:50%;overflow:hidden">${full(0, 48 * k)}</div>`, 48 * k, dir + 'ic_launcher_round.png');
}
void fg;
fs.writeFileSync(res + 'values/ic_launcher_background.xml', `<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">${BG}</color>\n</resources>\n`);
fs.writeFileSync(res + 'drawable/ic_launcher_background.xml', `<?xml version="1.0" encoding="utf-8"?>\n<shape xmlns:android="http://schemas.android.com/apk/res/android" android:shape="rectangle"><solid android:color="${BG}"/></shape>\n`);
// splash (pre-Android-12 launch screen): dark with the icon in the middle
for (const dir of fs.readdirSync(res).filter((x) => /^drawable(-(land|port))?/.test(x) && fs.existsSync(res + x + '/splash.png'))) {
  const land = dir.includes('land'), dpi = ({ mdpi: 1, hdpi: 1.5, xhdpi: 2, xxhdpi: 3, xxxhdpi: 4 })[dir.split('-').pop()] || 1;
  const w = Math.round((land ? 480 : 320) * dpi), h = Math.round((land ? 320 : 480) * dpi), s = Math.round(120 * dpi);
  await render(`<div style="width:${w}px;height:${h}px;background:${BG};display:flex;align-items:center;justify-content:center">${full(26 * 0, s).replace('rx="0"', 'rx="112"')}</div>`, 0, res + dir + '/splash.png', false, w, h);
}
// Play Store icon: 512x512, full-bleed square (Google applies the mask)
await render(full(0, 512), 512, store + 'icon-512.png', false);
await b.close();
console.log('icons done');
