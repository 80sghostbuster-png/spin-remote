import puppeteer from 'puppeteer-core'; import fs from 'fs';
const b = await puppeteer.launch({ executablePath: '/usr/bin/google-chrome', headless: 'new', args: ['--no-sandbox'] });
for (const [src, size, name] of [['icon.svg', 192, 'icon-192'], ['icon.svg', 512, 'icon-512'], ['icon-maskable.svg', 512, 'icon-maskable-512']]) {
  const p = await b.newPage(); await p.setViewport({ width: size, height: size });
  const svg = fs.readFileSync('/workspace/tvremote/web/icons/' + src, 'utf8');
  await p.setContent(`<body style="margin:0;background:transparent">${svg.replace('<svg ', `<svg width="${size}" height="${size}" `)}</body>`);
  await p.screenshot({ path: `/workspace/tvremote/web/icons/${name}.png`, omitBackground: true }); await p.close();
}
await b.close();
