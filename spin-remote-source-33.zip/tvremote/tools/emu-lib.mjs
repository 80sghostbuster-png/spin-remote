// Helpers for driving the app inside the Android emulator: real touches via `adb shell input`, state read through the WebView's DevTools socket
// (read-only: DOM text, element rectangles; the taps themselves are real touchscreen events from adb).
import { execFileSync } from 'node:child_process'; import fs from 'node:fs';
export const SERIAL = process.env.ANDROID_SERIAL || 'emulator-5700';
const ADB = process.env.HOME + '/sdk/android/platform-tools/adb';
export const adb = (...a) => execFileSync(ADB, ['-s', SERIAL, ...a], { maxBuffer: 1 << 26 }).toString();
export const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
export const shot = (name) => { const b = execFileSync(ADB, ['-s', SERIAL, 'exec-out', 'screencap', '-p'], { maxBuffer: 1 << 26 }); fs.mkdirSync('/workspace/tvremote/android/shots/emulator', { recursive: true }); fs.writeFileSync(`/workspace/tvremote/android/shots/emulator/${name}.png`, b); };
export async function connect() {
  const pid = adb('shell', 'cat /proc/net/unix').match(/webview_devtools_remote_(\d+)/)[1];
  try { execFileSync(ADB, ['-s', SERIAL, 'forward', 'tcp:9333', `localabstract:webview_devtools_remote_${pid}`]); } catch (e) { /* ignore */ }
  const list = await (await fetch('http://localhost:9333/json')).json(); const ws = new WebSocket(list.find((x) => x.type === 'page').webSocketDebuggerUrl);
  await new Promise((r, j) => { ws.onopen = r; ws.onerror = j; }); let id = 0; const wait = new Map();
  ws.onmessage = (m) => { const d = JSON.parse(m.data); if (d.id && wait.has(d.id)) { wait.get(d.id)(d); wait.delete(d.id); } };
  const send = (method, params = {}) => new Promise((res) => { const i = ++id; wait.set(i, res); ws.send(JSON.stringify({ id: i, method, params })); });
  const ev = async (expr) => { const r = await send('Runtime.evaluate', { expression: expr, returnByValue: true, awaitPromise: true }); if (r.result.exceptionDetails) throw new Error(JSON.stringify(r.result.exceptionDetails).slice(0, 300)); return r.result.result.value; };
  return { ev, close: () => ws.close() };
}
/** Real touchscreen tap on a CSS selector (centre of the element). Returns the host time just before the tap was issued. */
export async function tap(page, sel, { text } = {}) {
  const r = await page.ev(`(() => { const els = [...document.querySelectorAll(${JSON.stringify(sel)})]; const e = ${text ? `els.find((x) => x.textContent.includes(${JSON.stringify(text)}))` : 'els.find((x) => x.getBoundingClientRect().width)'}; if (!e) return null; const b = e.getBoundingClientRect(); return { x: (b.x + b.width / 2) * devicePixelRatio, y: (b.y + b.height / 2) * devicePixelRatio, top: window.screenY }; })()`);
  if (!r) throw new Error('no element ' + sel);
  const t0 = Date.now(); adb('shell', 'input', 'tap', String(Math.round(r.x)), String(Math.round(r.y + OFFSET))); return t0;
}
export let OFFSET = Number(process.env.WEBVIEW_TOP || 136);
export const events = () => fs.readFileSync('/tmp/emu-events.jsonl', 'utf8').trim().split('\n').filter(Boolean).map((l) => JSON.parse(l));
export const state = async () => (await fetch('http://127.0.0.1:9999/state')).json();
