// Old vs new bundle: pixel diff of resting states + main-thread cost while spinning/idle (headless Chrome, software raster: relative numbers only).
import puppeteer from 'puppeteer-core'; import http from 'node:http'; import fs from 'node:fs'; const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const files = { old: process.argv[2] || '/tmp/old-index.html', new: '/workspace/tvremote/android/www/index.html' };
const html = {}; for (const k in files) html[k] = fs.readFileSync(files[k]);
const srv = http.createServer((q, r) => { r.setHeader('content-type', 'text/html'); r.end(html[q.url.split('/')[1]]); }).listen(8798);
const b = await puppeteer.launch({ executablePath: '/usr/bin/google-chrome', headless: 'new', args: ['--no-sandbox'] });
const LITE = process.env.LITE === '1'; const shots = {}, cost = {};
for (const v of (process.env.VARIANTS || 'old,new').split(',')) {
  for (const [q, name] of [['?layout=reel&i=0', 'reel'], ['?layout=reel&i=2', 'reel2'], ['?layout=reel&i=0&locked=1', 'exp']]) {
    const p = await b.newPage(); await p.setViewport({ width: 390, height: 844, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
    await p.goto(`http://localhost:8798/${v}/${q}`, { waitUntil: 'networkidle0' }); await sleep(1500);
    shots[v + name] = await p.screenshot(); await p.close();
  }
  const p = await b.newPage(); await p.setViewport({ width: 390, height: 844, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
  const cdp = await p.createCDPSession(); await cdp.send('Performance.enable');
  await p.goto(`http://localhost:8798/${v}/?layout=reel&i=0`, { waitUntil: 'networkidle0' }); await sleep(1500);
  const m = async () => Object.fromEntries((await cdp.send('Performance.getMetrics')).metrics.map((x) => [x.name, x.value]));
  const diff = (a, c) => ({ script: +((c.ScriptDuration - a.ScriptDuration) * 1000).toFixed(0), style: +((c.RecalcStyleDuration - a.RecalcStyleDuration) * 1000).toFixed(0), layout: +((c.LayoutDuration - a.LayoutDuration) * 1000).toFixed(0), task: +((c.TaskDuration - a.TaskDuration) * 1000).toFixed(0) });
  if (LITE) await p.evaluate(() => document.body.classList.add('lite'));
  let a = await m(); await sleep(3000); cost[v + '-idle-3s(ms)'] = diff(a, await m());
  // spin: fling left/right repeatedly for ~4 s
  a = await m(); const t0 = Date.now(); let dir = 1;
  while (Date.now() - t0 < 4000) { await p.mouse.move(195, 400); await p.mouse.down(); for (let i = 1; i <= 6; i++) { await p.mouse.move(195 + dir * i * 28, 400); await sleep(12); } await p.mouse.up(); dir = -dir; await sleep(250); }
  cost[v + '-spin-4s(ms)'] = diff(a, await m()); await p.close();
}
for (const k in shots) fs.writeFileSync(`/tmp/pc-${k}.png`, shots[k]);
console.table(cost); await b.close(); srv.close();
