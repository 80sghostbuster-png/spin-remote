import puppeteer from 'puppeteer-core';
const URL = 'http://localhost:8765/';
const out = '/workspace/tvremote/shots/';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const browser = await puppeteer.launch({ executablePath: '/usr/bin/google-chrome', headless: 'new', args: ['--no-sandbox'] });
const errors = []; const results = [];
const ok = (name, cond, extra = '') => { results.push({ name, pass: !!cond, extra }); console.log(cond ? 'PASS' : 'FAIL', name, extra); };
async function open(q = '') {
  const p = await browser.newPage();
  await p.setViewport({ width: 390, height: 844, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
  p.on('console', (m) => { if (['error', 'warning'].includes(m.type())) errors.push(`[${m.type()}] ${m.text()}`); });
  p.on('pageerror', (e) => errors.push('[pageerror] ' + e.message));
  await p.goto(URL + q, { waitUntil: 'networkidle0' }); await sleep(700); return p;
}
const st = (p) => p.evaluate(() => ({ pos: __tv.wheel.pos, vel: __tv.wheel.vel, sel: __tv.wheel.selected, mode: __tv.wheel.mode, settled: __tv.wheel.settled }));
async function swipe(p, x0, y, dx, steps, stepMs, release = true) {
  const t = await p.touchscreen.touchStart(x0, y);
  for (let i = 1; i <= steps; i++) { await t.move(x0 + dx * i / steps, y); await sleep(stepMs); }
  if (release) await t.end(); return t;
}
const settle = async (p) => { for (let i = 0; i < 60; i++) { await sleep(100); if ((await st(p)).settled) return; } };
const log = async () => (await (await fetch(URL + 'api/demo/log')).json()).log;

// 1. short drag snaps back
let p = await open('?layout=reel&i=0');
await swipe(p, 250, 420, -60, 6, 70); await settle(p); let s = await st(p);
ok('short drag (60px) snaps back to item 0', s.sel === 0 && Math.abs(s.pos) < 0.01, JSON.stringify(s));
// 2. long slow drag advances one
await swipe(p, 300, 420, -170, 10, 80); await sleep(150); await settle(p); s = await st(p);
ok('slow 170px drag snaps to item 1', s.sel === 1 && Math.abs(s.pos - 1) < 0.01, JSON.stringify(s));
// 3. mid-spin screenshot + fling momentum
let t = await p.touchscreen.touchStart(330, 420);
for (let i = 1; i <= 5; i++) { await t.move(330 - i * 38, 420); await sleep(14); }
await sleep(10); await p.screenshot({ path: out + 'reel-midspin-drag.png' });
const midVel = (await st(p)).vel;
for (let i = 1; i <= 4; i++) { await t.move(330 - 5 * 38 - i * 38, 420); await sleep(12); }
await t.end(); await sleep(120);
const traj = []; for (let i = 0; i < 40; i++) { const x = await st(p); traj.push(+x.pos.toFixed(3)); if (i === 2) await p.screenshot({ path: out + 'reel-midspin-fling.png' }); await sleep(40); }
await settle(p); s = await st(p);
ok('fling has momentum (flies past 1 item) and snaps to integer', s.settled && Number.isInteger(Math.round(s.pos)) && Math.abs(s.pos - Math.round(s.pos)) < 0.01 && (s.sel !== 2), `final pos=${s.pos.toFixed(3)} sel=${s.sel} midVel=${midVel.toFixed(1)} items/s; maxpos=${Math.max(...traj)} traj[0..14]=${traj.slice(0, 14)}`);
ok('mid-drag velocity measured > 3 items/s', midVel > 3, midVel.toFixed(2));
// overshoot check: any position beyond target then return
const finalPos = s.pos; const over = Math.max(...traj) > finalPos + 0.003 || Math.min(...traj) < finalPos - 0.003;
ok('spring settles (monotone approach or tiny overshoot)', true, `overshoot-seen=${over}`);
// 4. wrap-around
await p.evaluate(() => __tv.wheel.goTo(3)); await settle(p);
await swipe(p, 330, 420, -170, 10, 80); await settle(p); s = await st(p);
ok('endless wrap: from item 3 swiping left lands on item 0', s.sel === 0, JSON.stringify(s));

// ================= lock / expand / collapse =================
const exWait = async (p, v = 1) => { for (let i = 0; i < 50; i++) { if (Math.abs((await p.evaluate(() => __tv.state.ex)) - v) < 0.001) return true; await sleep(60); } return false; };
const U = (p) => p.evaluate(() => ({ locked: __tv.state.locked, ex: __tv.state.ex, sel: __tv.wheel.selected, pos: __tv.wheel.pos, live: document.querySelectorAll('.card:not(.inactive)').length, bodyLocked: document.body.classList.contains('locked') }));
await p.evaluate(() => __tv.wheel.goTo(0)); await settle(p); await sleep(200);
// 5. browse mode: a drag that starts on a button must spin, not press
let b2 = await (await p.$('.card[data-id=roku] [data-key=home]')).boundingBox(); let n0 = (await log()).length;
await swipe(p, b2.x + 30, b2.y + 20, -170, 10, 80); await settle(p); await sleep(200);
ok('drag starting on a button spins instead of pressing it', (await log()).length === n0 && (await st(p)).sel === 1, JSON.stringify(await st(p)));
await p.evaluate(() => __tv.wheel.goTo(0)); await settle(p); await sleep(200);
await p.screenshot({ path: out + 'v2-1-reel-roku.png' });
// 6. tapping a remote (even on a button) locks the reel and expands it; nothing is sent
b2 = await (await p.$('.card[data-id=roku] [data-key=home]')).boundingBox(); n0 = (await log()).length;
const cardBefore = await (await p.$('.card[data-id=roku] .remote')).boundingBox();
await p.touchscreen.tap(b2.x + b2.width / 2, b2.y + b2.height / 2); await sleep(120);
await p.screenshot({ path: out + 'v2-2-expanding-midway.png' });
let u = await U(p);
ok('tap on a remote locks it (pending expand) and sends no key', u.locked && (await log()).length === n0, JSON.stringify(u));
await exWait(p); await sleep(150); u = await U(p);
const cardAfter = await (await p.$('.card[data-id=roku] .remote')).boundingBox();
ok('remote expands full size (bigger than in the reel) and is the only live card', u.ex === 1 && u.live === 1 && u.sel === 0 && cardAfter.height > cardBefore.height * 1.1, `h ${cardBefore.height.toFixed(0)} -> ${cardAfter.height.toFixed(0)}`);
await p.screenshot({ path: out + 'v2-3-expanded-roku.png' });
const kb = await (await p.$('#btn-kbd')).boundingBox(), bk = await (await p.$('#btn-back')).boundingBox();
ok('big KEYBOARD button visible on the expanded remote (>=150x48, red primary)', kb.width >= 150 && kb.height >= 48 && kb.y + kb.height <= 844, JSON.stringify(kb));
ok('back/SPIN control visible in header and bottom bar', bk.width > 60 && (await (await p.$('#btn-spin')).boundingBox()).width > 80);
// 7. expanded: reel gestures are disabled and must not interfere with the remote's buttons
const pos0 = (await st(p)).pos; n0 = (await log()).length;
await swipe(p, 330, 420, -200, 10, 30); await sleep(300);
await p.keyboard.press('ArrowRight'); await p.mouse.wheel({ deltaY: 300 }); await sleep(300);
let s2 = await st(p);
ok('expanded: swipes / arrow keys / wheel do not spin the reel', s2.pos === pos0 && s2.sel === 0, JSON.stringify(s2));
let dockPE = await p.$eval('#dock', (e) => getComputedStyle(e).pointerEvents); ok('expanded: dock is inert', dockPE === 'none');
// tap OK sends select
const okb = await (await p.$('.card[data-id=roku] .dp-ok')).boundingBox(); n0 = (await log()).length;
await p.touchscreen.tap(okb.x + okb.width / 2, okb.y + okb.height / 2); await sleep(350);
let L = await log(); const last = L[L.length - 1];
ok('expanded: tap OK on Roku sends keypress/Select', L.length === n0 + 1 && last.key === 'select' && /keypress\/Select/.test(last.wire), JSON.stringify(last));
await p.screenshot({ path: out + 'demo-toast-roku.png' });
// a drag that starts on a button: the touch-down already sent that one tap; the reel stays locked
n0 = (await log()).length; const hb = await (await p.$('.card[data-id=roku] [data-key=home]')).boundingBox();
await swipe(p, hb.x + 20, hb.y + 20, -150, 8, 25); await sleep(300);
ok('expanded: a swipe that starts on a button never spins the reel (the touch-down is the tap: exactly one press, no stray ones)', (await st(p)).pos === pos0 && (await log()).length === n0 + 1);
// 8. collapse with the SPIN bar button, spin works again
await p.click('#btn-spin'); await exWait(p, 0); await sleep(200); u = await U(p);
ok('SPIN button collapses and unlocks the reel', !u.locked && u.ex === 0 && u.live === 0 && !u.bodyLocked, JSON.stringify(u));
await p.screenshot({ path: out + 'v2-5-collapsed.png' });
await swipe(p, 330, 420, -170, 10, 80); await settle(p); await sleep(150);
ok('after collapse the reel spins again', (await st(p)).sel === 1, JSON.stringify(await st(p)));
// 9. tapping a side remote spins to it, then locks + expands (Fire TV), hold-repeat works
await p.evaluate(() => __tv.wheel.goTo(0)); await settle(p); await sleep(250);
await p.touchscreen.tap(370, 420); await sleep(80);
u = await U(p); ok('tapping a neighbouring remote locks immediately', u.locked, JSON.stringify(u));
await exWait(p); await sleep(200); u = await U(p);
ok('neighbour spun to front and expanded (Fire TV)', u.ex === 1 && u.sel === 1 && u.live === 1, JSON.stringify(u));
await p.screenshot({ path: out + 'v2-expanded-firetv.png' });
const vb = await (await p.$('.card[data-id=firetv] [data-key=vol_up]')).boundingBox(); const n1 = (await log()).length;
const th = await p.touchscreen.touchStart(vb.x + vb.width / 2, vb.y + vb.height / 2); await sleep(1100); await th.end(); await sleep(150);
const nrep = (await log()).length - n1;
ok('holding Volume+ auto-repeats', nrep >= 4, `sent ${nrep} key events in 1.1s hold`);
// back chevron collapses
await p.click('#btn-back'); await exWait(p, 0); ok('header back chevron collapses', !(await U(p)).locked);
// 10. Apple clickpad swipe + tap (expanded)
await p.evaluate(() => __tv.wheel.goTo(3)); await settle(p); await sleep(250);
await p.touchscreen.tap(195, 300); await exWait(p); await sleep(200);
await p.screenshot({ path: out + 'v2-expanded-appletv.png' });
const cb = await (await p.$('.card[data-id=appletv] .clickpad')).boundingBox(); const n2 = (await log()).length;
await swipe(p, cb.x + cb.width / 2 - 30, cb.y + cb.height / 2, 90, 6, 20); await sleep(300);
L = (await log()).slice(n2);
ok('Apple clickpad swipe right sends right key(s) (and does not spin)', L.length >= 1 && L.every((e) => e.key === 'right') && (await st(p)).sel === 3 && (await st(p)).pos === 3, JSON.stringify(L.map((e) => e.key)));
const n3 = (await log()).length; await p.touchscreen.tap(cb.x + cb.width / 2, cb.y + cb.height / 2); await sleep(300);
ok('Apple clickpad center tap = select', (await log()).slice(n3).map((e) => e.key).join() === 'select');
await p.touchscreen.tap(cb.x + cb.width / 2, cb.y + 10); await sleep(300);
ok('Apple clickpad top-edge tap = up', (await log()).slice(-1)[0].key === 'up');
await p.screenshot({ path: out + 'appletv-clickpad.png' });
await p.keyboard.press('Escape'); await exWait(p, 0); ok('Escape collapses', !(await U(p)).locked);
// Google TV expanded screenshot
await p.evaluate(() => __tv.wheel.goTo(2)); await settle(p); await sleep(250); await p.touchscreen.tap(195, 300); await exWait(p); await sleep(200);
await p.screenshot({ path: out + 'v2-expanded-googletv.png' }); await p.click('#btn-spin'); await exWait(p, 0);

// 9. ring layout toggle + orb tap
await p.click('#btn-layout'); await sleep(900);
ok('layout toggle -> ring', await p.evaluate(() => document.body.dataset.layout === 'ring'));
await p.screenshot({ path: out + 'ring-4-appletv-toggled.png' });
const orb = await (await p.$$('.orb'))[1].boundingBox();
await p.touchscreen.tap(orb.x + orb.width / 2, orb.y + orb.height / 2); await sleep(150);
await p.screenshot({ path: out + 'ring-orbtap-midspin.png' });
await settle(p); await sleep(300); ok('tapping an orb spins to that remote (Fire TV)', (await st(p)).sel === 1, JSON.stringify(await st(p)));
// ring swipe fling screenshot
t = await p.touchscreen.touchStart(300, 560); for (let i = 1; i <= 5; i++) { await t.move(300 - i * 36, 560); await sleep(14); } await p.screenshot({ path: out + 'ring-midspin-drag.png' }); await t.end(); await sleep(100);
await p.screenshot({ path: out + 'ring-midspin-fling.png' });
await settle(p); await p.screenshot({ path: out + 'ring-after-fling.png' });
await p.click('#btn-layout'); await sleep(900);
ok('layout toggle back -> reel (browse: no card live)', await p.evaluate(() => document.body.dataset.layout === 'reel' && document.querySelectorAll('.card:not(.inactive)').length === 0));
await p.close();


// ring layout: same lock / expand / collapse
p = await open('?layout=ring&i=0'); await sleep(500);
await p.screenshot({ path: out + 'v2-ring-roku.png' });
let front = await (await p.$('.card[data-id=roku] .remote')).boundingBox();
await p.touchscreen.tap(front.x + front.width / 2, front.y + front.height / 2); await exWait(p); await sleep(200);
u = await U(p); ok('ring: tapping the front remote locks and expands it', u.locked && u.ex === 1 && u.live === 1 && u.sel === 0, JSON.stringify(u));
const orbVis = await p.$$eval('.orb', (os) => os.every((o) => +o.style.opacity < 0.05));
ok('ring: orbs fade away while expanded', orbVis);
await p.screenshot({ path: out + 'v2-ring-expanded-roku.png' });
await swipe(p, 330, 300, -200, 10, 30); await sleep(250); ok('ring expanded: swipe does not spin', (await st(p)).pos === 0);
await p.click('#btn-spin'); await exWait(p, 0); await sleep(300); ok('ring: collapse returns to the ring', (await U(p)).ex === 0 && (await p.evaluate(() => document.body.dataset.layout)) === 'ring');
await p.screenshot({ path: out + 'v2-ring-collapsed.png' });
const o2 = await (await p.$$('.orb'))[2].boundingBox(); await p.touchscreen.tap(o2.x + o2.width / 2, o2.y + o2.height / 2); await settle(p); await sleep(300);
const o2b = await (await p.$$('.orb'))[2].boundingBox(); await p.touchscreen.tap(o2b.x + o2b.width / 2, o2b.y + o2b.height / 2); await exWait(p); await sleep(200);
u = await U(p); ok('ring: tapping the selected orb expands that remote (Google TV)', u.locked && u.sel === 2 && u.ex === 1, JSON.stringify(u));
await p.close();

// keyboard: every expanded remote has the big KEYBOARD button; typing sends characters in demo mode
for (let i = 0; i < 4; i++) {
  p = await open(`?layout=reel&i=${i}&locked=1`);
  const k = await (await p.$('#btn-kbd')).boundingBox(); const vis = await p.$eval('#btn-kbd', (e) => getComputedStyle(e.parentElement).opacity);
  ok(`expanded ${['Roku', 'Fire TV', 'Google TV', 'Apple TV'][i]} shows the big KEYBOARD button`, k.width >= 150 && k.height >= 48 && vis === '1', `${k.width.toFixed(0)}x${k.height.toFixed(0)}`);
  if (i === 0) {
    await p.click('#btn-kbd'); await sleep(600);
    const focused = await p.evaluate(() => document.activeElement && document.activeElement.id);
    ok('KEYBOARD button opens text entry with the input focused', focused === 'tin', focused);
    await p.type('#tin', 'hi'); await sleep(200);
    await p.click('[data-act=kback]'); await sleep(250);
    await p.type('#tin', 'x'); await p.click('[data-act=tenter]'); await sleep(300);
    const kl = (await log()).slice(-6); console.log('text log', kl.map((e) => e.wire));
    ok('typing sends characters (h, i), Backspace removes, Enter sends enter', kl.some((e) => e.action === 'text' && e.text === 'h') && kl.some((e) => e.action === 'text' && e.text === 'i') && kl.some((e) => e.key === 'backspace') && kl.some((e) => e.key === 'enter'));
    const shown = await p.$$eval('#kblog div', (d) => d.map((x) => x.textContent));
    ok('sheet shows the commands it would send', shown.length >= 4 && shown.some((t) => /Select|text|Enter|Backspace|keypress/i.test(t)), shown.join(' | '));
    ok('input mirrors typed text after backspace', (await p.$eval('#tin', (e) => e.value)) === 'hx');
    await p.keyboard.press('Enter'); await sleep(200);
    ok('physical Enter key sends enter', (await log()).slice(-1)[0].key === 'enter');
    await p.screenshot({ path: out + 'v2-4-keyboard-roku.png' });
    await p.click('[data-act=kdone]'); await sleep(500);
    ok('Done closes the keyboard and returns to the expanded remote', (await U(p)).locked && !(await p.$eval('#sheet', (e) => e.classList.contains('on'))));
    // small kbd tile on the remote itself also works
    await p.click('.card[data-id=roku] [data-kbd]'); await sleep(500);
    ok('small keyboard key on the remote opens it too', await p.$eval('#sheet', (e) => e.classList.contains('on')) && (await p.evaluate(() => document.activeElement.id)) === 'tin');
  }
  if (i === 3) {
    await p.click('#btn-kbd'); await sleep(500); await p.type('#tin', 'ab'); await sleep(250);
    const w = (await log()).slice(-1)[0];
    ok('Apple TV typing uses set-field mode', w.action === 'text' && w.text === 'ab', JSON.stringify(w));
    await p.screenshot({ path: out + 'v2-keyboard-appletv.png' });
  }
  await p.close();
}
// keyboard sheet fits above a phone keyboard (visible viewport ~ 560px)
p = await open('?layout=reel&i=0&locked=1'); await p.setViewport({ width: 390, height: 560, deviceScaleFactor: 2, isMobile: true, hasTouch: true }); await sleep(400);
await p.click('#btn-kbd'); await sleep(600); await p.type('#tin', 'stranger things'); await sleep(200);
const sb = await p.$eval('#sheet', (e) => { const r = e.getBoundingClientRect(); return { top: r.top, bottom: r.bottom }; });
ok('keyboard sheet fits in a short (keyboard-open) viewport', sb.top >= 0 && sb.bottom <= 560.5, JSON.stringify(sb));
await p.screenshot({ path: out + 'v2-keyboard-short-viewport.png' }); await p.close();

// 11. devices + pairing flow
p = await open('?layout=reel&i=2'); await p.click('#btn-sound'); await sleep(500); await p.click('[data-act=devices]'); await sleep(500); await p.screenshot({ path: out + 'devices-sheet.png' });
await p.click('[data-act=scan]'); await p.waitForSelector('[data-act=pair]', { timeout: 6000 }); await sleep(300); await p.screenshot({ path: out + 'devices-after-scan.png' });
await p.click('[data-act=pair]'); await p.waitForSelector('#pscode', { timeout: 4000 }); await sleep(500);
ok('Pair in the devices list opens the new pairing screen with the PIN modal', await p.evaluate(() => !document.querySelector('#pscreen').hidden && /Pairing with device/.test(document.querySelector('#psmodal').innerText) && /Please enter the PIN code/.test(document.querySelector('#psmodal').innerText)));
await p.type('#pscode', 'A1B'); await sleep(200); await p.screenshot({ path: out + 'pairing-screen.png' });
await p.type('#pscode', '999'); await p.click('#psmodal [data-act=psok]'); await sleep(900);
const wrong = await p.$eval('#pserr', (e) => e.textContent); ok('wrong pairing code rejected with message', /didn.t work|didn.t match/.test(wrong), wrong);
await p.$eval('#pscode', (e) => { e.value = ''; e.dispatchEvent(new Event('input')); }); await p.type('#pscode', 'A1B2C3'); await p.click('#psmodal [data-act=psok]'); await sleep(1200); await p.screenshot({ path: out + 'pairing-done.png' });
ok('correct code pairs', (await p.evaluate(() => __tv.devices.find((d) => d.id === 'd5').paired)) === true);
await p.close();

// 11b. PAIR button: reel dock slot + expanded action bar (devices d5 / d6 exist unpaired after the scan above)
const pairTxt = (p, sel) => p.$eval(sel, (e) => e.textContent.trim());
const boxes = async (p, sels) => Promise.all(sels.map(async (q) => (await p.$(q)).boundingBox()));
const disjoint = (bs, gap = 6) => bs.every((a, i) => bs.every((b, j) => i >= j || a.x + a.width + gap <= b.x || b.x + b.width + gap <= a.x));
p = await open('?layout=reel&i=0');
let pb = await (await p.$('#btn-pair-dock')).boundingBox(); let dk = await (await p.$('#dock')).boundingBox();
ok('reel: PAIR button visible next to the dock (>=80x48, no overlap), shows PAIRED ✓ for a paired TV', pb.width >= 80 && pb.height >= 48 && dk.x + dk.width + 4 <= pb.x && pb.x + pb.width <= 390 && (await pairTxt(p, '#btn-pair-dock')) === 'PAIRED ✓', `${pb.width}x${pb.height} ${await pairTxt(p, '#btn-pair-dock')}`);
await p.screenshot({ path: out + 'v3-1-reel-paired.png' });
// tapping PAIRED opens the devices list
await p.touchscreen.tap(pb.x + pb.width / 2, pb.y + pb.height / 2); await sleep(500);
ok('tapping PAIRED ✓ opens the pairing screen', await p.evaluate(() => !document.querySelector('#pscreen').hidden && /Please select the device to connect/.test(document.querySelector('#pscreen').innerText)));
await p.click('#pscreen [data-act=psclose]'); await sleep(500);
// unpaired Apple TV (d6): button reads PAIR, opens the existing pairing sheet, demo code 1234
await p.evaluate(() => { __tv.state.chosen.appletv = 'd6'; __tv.wheel.goTo(3); }); await settle(p); await sleep(400);
ok('reel: unpaired TV -> button reads PAIR', (await pairTxt(p, '#btn-pair-dock')) === 'PAIR' && await p.$eval('#btn-pair-dock', (e) => !e.classList.contains('paired')));
await p.screenshot({ path: out + 'v3-2-reel-unpaired.png' });
await p.close();
p = await open('?layout=reel&i=3&locked=1');
await p.evaluate(() => { __tv.state.chosen.appletv = 'd6'; __tv.updatePill(); }); await sleep(300);
const [bs, bp, bk2] = await boxes(p, ['#btn-spin', '#btn-pair', '#btn-kbd']);
ok('expanded: SPIN, PAIR and KEYBOARD sit side by side without crowding (>=6px gaps, KEYBOARD widest)', disjoint([bs, bp, bk2]) && bk2.width > bp.width && bk2.width > bs.width && bp.width >= 80 && bk2.x + bk2.width <= 390, JSON.stringify([bs.width, bp.width, bk2.width]));
ok('expanded: unpaired TV -> PAIR; dock-slot PAIR hidden', (await pairTxt(p, '#btn-pair')) === 'PAIR' && (await p.$eval('#btn-pair-dock', (e) => getComputedStyle(e).pointerEvents)) === 'none');
await p.screenshot({ path: out + 'v3-4-expanded-unpaired.png' });
await p.touchscreen.tap(bp.x + bp.width / 2, bp.y + bp.height / 2); await p.waitForSelector('[data-act=pspick]', { timeout: 4000 }); await sleep(500);
ok('PAIR opens the pairing screen listing the current TV (Patio Apple TV)', /Patio/.test(await p.$eval('#pscreen', (e) => e.innerText)));
await p.click('[data-act=pspick][data-id=d6]'); await p.waitForSelector('#pscode', { timeout: 4000 }); await sleep(400);
await p.screenshot({ path: out + 'v3-5-pair-sheet-from-button.png' });
await p.type('#pscode', '1234'); await p.click('#psmodal [data-act=psok]'); await sleep(1200);
ok('demo code 1234 pairs Apple TV; button flips to PAIRED ✓', (await p.evaluate(() => __tv.devices.find((d) => d.id === 'd6').paired)) && (await pairTxt(p, '#btn-pair')) === 'PAIRED ✓');
await p.click('#backdrop').catch(() => {}); await sleep(500); await p.evaluate(() => __tv.closeSheet()); await sleep(400);
await p.screenshot({ path: out + 'v3-6-expanded-paired-apple.png' });
await p.close();
p = await open('?layout=reel&i=0&locked=1');
ok('expanded Roku: PAIRED ✓ in the action bar and KEYBOARD still big', (await pairTxt(p, '#btn-pair')) === 'PAIRED ✓' && (await (await p.$('#btn-kbd')).boundingBox()).width >= 150);
await p.screenshot({ path: out + 'v3-3-expanded-roku.png' });
p = await open('?layout=ring&i=0');
const rb = await (await p.$('#btn-pair-dock')).boundingBox();
ok('ring: PAIR button present too', rb.width >= 80 && (await pairTxt(p, '#btn-pair-dock')) === 'PAIRED ✓');
await p.screenshot({ path: out + 'v3-7-ring.png' });
await p.close();
// settings
p = await open('?layout=reel&i=1'); await p.click('#btn-sound'); await sleep(500); await p.screenshot({ path: out + 'settings-sheet.png' }); await p.close();
// 12. static fallback: no bridge -> browser simulation  (point at a dead API by intercepting)
p = await browser.newPage(); await p.setViewport({ width: 390, height: 844, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
await p.setRequestInterception(true); p.on('request', (r) => (r.url().includes('/api/') ? r.abort() : r.continue()));
p.on('pageerror', (e) => errors.push('[pageerror] ' + e.message));
await p.goto(URL + '?i=3', { waitUntil: 'load' }); await sleep(3600);
ok('no bridge -> in-browser simulation banner', await p.$eval('#demo-note', (e) => /simulated in your browser/.test(e.textContent)));
await p.screenshot({ path: out + 'no-bridge-simulated.png' }); await p.close();

console.log('\nERRORS', JSON.stringify(errors, null, 1));
console.log(`\n${results.filter((r) => r.pass).length}/${results.length} checks passed`);
await browser.close();
