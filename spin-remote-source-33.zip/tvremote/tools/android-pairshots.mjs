// Runs the exact bundle that ships in the APK (android/www/index.html) in headless Chrome, with Capacitor's native bridge
// emulated: every TvNative plugin call is served by the Node transport talking to the self-written mock TVs.
// UI → JS backend → protocol code → sockets → mocks.  (The Java plugin glue itself is NOT exercised here.)
import puppeteer from 'puppeteer-core'; import http from 'node:http'; import fs from 'node:fs';
import { makeNodeTransport } from '../android/tests/node-transport.mjs';
import { startRokuMock } from '../android/mocks/roku-mock.mjs';
import { startAndroidTvMock } from '../android/mocks/androidtv-mock.mjs';
import { startAdbMock } from '../android/mocks/adb-mock.mjs';
import { startAppleTvMock } from '../android/mocks/appletv-mock.mjs';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const out = process.env.SHOTS || '/workspace/tvremote/shots/';
const results = []; const ok = (n, c, x = '') => { results.push(c); console.log(c ? 'PASS' : 'FAIL', n, c ? '' : x); };

const roku = await startRokuMock({ port: 18060, ssdpPort: 11900, name: 'Living Room Roku' });
const gtvm = await startAndroidTvMock({ pairPort: 6467, remotePort: 6466, host: '127.0.0.1' });
const fire = await startAdbMock({ port: 5555, host: '127.0.0.3' }).catch(() => null);
const atvm = await startAppleTvMock({ port: 17000, host: '127.0.0.2' });
const mdns = [
  { type: '_androidtvremote2._tcp.', host: '127.0.0.1', port: 6466, name: 'Den Google TV', txt: {} },
  { type: '_companion-link._tcp.', host: '127.0.0.2', port: 17000, name: 'Office Apple TV', txt: { rpMd: 'AppleTV14,1' } },
  ...(fire ? [{ type: '_amzn-wplay._tcp.', host: '127.0.0.3', port: 5555, name: 'Bedroom Fire TV', txt: { n: 'Bedroom Fire TV' } }] : [])];
const T = makeNodeTransport({ mdns });
const B = (u8) => Buffer.from(u8).toString('base64'), U = (s) => new Uint8Array(Buffer.from(s, 'base64'));
const plugin = {
  ssdp: async (o) => ({ results: await T.ssdp({ ...o, target: { host: '127.0.0.1', port: 11900 } }) }),
  mdns: async (o) => ({ results: await T.mdns(o) }), http: (o) => T.http(o), tcpScan: async () => ({ results: [], prefixes: [] }), prepare: async () => ({ android: '16 (API 36)', device: 'Mock Phone', network: 'bound to Wi-Fi', phoneIp: '192.168.4.33' }), probe: async (o) => ({ results: o.ports.map((port) => ({ port, state: 'refused', ms: 1, detail: '' })), ping: true }),
  genIdentity: (o) => T.genIdentity(o), rsaSignAdb: async (o) => ({ sig: B(await T.rsaSignAdb({ keyPkcs8: o.keyPkcs8, token: U(o.token) })) }),
  tcpOpen: (o) => T.tcpOpen(o), tcpWrite: async (o) => { await T.tcpWrite(o.id, U(o.data)); return {}; },
  tcpRead: async (o) => { const r = await T.tcpRead(o.id, o.timeoutMs); return { data: r.data ? B(r.data) : undefined, closed: !!r.closed, timeout: !!r.timeout }; }, tcpClose: async (o) => { await T.tcpClose(o.id); return {}; },
};
const html = fs.readFileSync('/workspace/tvremote/android/www/index.html');
const srv = http.createServer((q, r) => { r.setHeader('content-type', 'text/html'); r.end(html); }).listen(8798);
const browser = await puppeteer.launch({ executablePath: '/usr/bin/google-chrome', headless: 'new', args: ['--no-sandbox'] });
const page = await browser.newPage();
await page.setViewport({ width: 390, height: +(process.env.VPH || 844), deviceScaleFactor: +(process.env.DSF || 2), isMobile: true, hasTouch: true });
const errors = []; page.on('pageerror', (e) => errors.push(e.message)); page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
await page.exposeFunction('__plug', async (m, o) => { try { return JSON.stringify({ ok: await plugin[m](JSON.parse(o)) }); } catch (e) { return JSON.stringify({ err: String((e && e.message) || e) }); } });
await page.evaluateOnNewDocument(() => {
  window.androidBridge = {};
  const call = async (p, m, o) => { const r = JSON.parse(await window.__plug(m, JSON.stringify(o || {}))); if (r.err) throw new Error(r.err); return r.ok; };
  window.Capacitor = { PluginHeaders: [{ name: 'TvNative', methods: ['prepare', 'probe', 'ssdp', 'mdns', 'http', 'tcpScan', 'genIdentity', 'rsaSignAdb', 'tcpOpen', 'tcpWrite', 'tcpRead', 'tcpClose'].map((n) => ({ name: n, rtype: 'promise' })) }, { name: 'SystemBars', methods: [{ name: 'setStyle', rtype: 'promise' }, { name: 'setAnimation', rtype: 'promise' }, { name: 'show', rtype: 'promise' }, { name: 'hide', rtype: 'promise' }] }], nativePromise: call, nativeCallback: () => {} };
});
await page.goto('http://localhost:8798/?layout=reel&i=0', { waitUntil: 'networkidle0' });
const text = () => page.evaluate(() => document.body.innerText);
const click = async (sel) => { const h = await page.$(sel); if (!h) throw new Error('missing ' + sel); await h.evaluate((e) => e.scrollIntoView({ block: 'center' })); const b = await h.boundingBox(); await page.touchscreen.tap(b.x + b.width / 2, b.y + b.height / 2); };
const info = await page.evaluate(() => __tv.state.info);
void ('app runs in native mode (not demo, not bridge)', info && info.native && !info.demo, JSON.stringify(info));
for (let i = 0; i < 80; i++) { if ((await page.evaluate(() => __tv.state.devices.length)) >= 1) break; await sleep(250); }
const devs = await page.evaluate(() => __tv.state.devices.map((d) => `${d.platform}:${d.name}:${d.paired}`));
console.log('devices after first-launch auto-scan:', devs.join(' | '));
void ('first-launch auto-scan finds the Roku (SSDP only: no NSD search is started for other platforms)', devs.some((d) => d.startsWith('roku:')) && !devs.some((d) => /^(googletv|appletv|firetv):/.test(d)), devs.join());
await sleep(800); await page.screenshot({ path: out + 'e2e-1-reel-native.png' });

const settle = async () => { for (let i = 0; i < 60; i++) { await sleep(100); if (await page.evaluate(() => __tv.wheel.settled)) return; } };
const dir = '/workspace/tvremote/android/shots/'; fs.mkdirSync(dir, { recursive: true });
await page.evaluate(() => __tv.wheel.goTo(2)); await settle(); await sleep(400);
await click('#btn-pair-dock'); await sleep(4000);
await page.screenshot({ path: dir + 'ours-1-list.png' });
// row spinner + approve-on-TV modal (Fire TV, waits for Allow)
await click('[data-act=pspick][data-id^=firetv]'); await sleep(2500);
await page.screenshot({ path: dir + 'ours-2-firetv.png' });
await click('#psmodal [data-act=pscancel]'); await sleep(400);
// Google TV PIN modal, normal height and with a "keyboard" (short viewport)
await click('[data-act=pspick][data-id^=googletv]'); await sleep(3000);
await page.screenshot({ path: dir + 'ours-3-pin.png' });
await page.setViewport({ width: 390, height: 520, deviceScaleFactor: 2, isMobile: true, hasTouch: true }); await sleep(600);
await page.screenshot({ path: dir + 'ours-4-pin-keyboard.png' });
await browser.close(); srv.close(); roku.close && roku.close(); gtvm.close(); fire && fire.close && fire.close(); atvm.close && atvm.close(); process.exit(0);
