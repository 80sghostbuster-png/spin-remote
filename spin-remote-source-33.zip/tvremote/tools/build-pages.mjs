// Bundle web/ into ONE self-contained html file (inline CSS + bundled JS, no manifest / service worker / external files).
import { build } from 'esbuild';
import fs from 'node:fs';
const root = new URL('../', import.meta.url).pathname;
const js = (await build({ entryPoints: [root + 'web/app.js'], bundle: true, minify: true, format: 'iife', target: 'es2020', write: false, define: { __BUNDLE__: 'true', __NATIVE__: 'false' } })).outputFiles[0].text.replace(/<\/script/gi, '<\\/script');
const css = fs.readFileSync(root + 'web/style.css', 'utf8').replace('/icons/pair-tv.jpg', 'data:image/jpeg;base64,' + fs.readFileSync(root + 'web/icons/pair-tv.jpg').toString('base64'));
const icon = 'data:image/svg+xml,' + encodeURIComponent(fs.readFileSync(root + 'web/icons/icon.svg', 'utf8'));
let html = fs.readFileSync(root + 'web/index.html', 'utf8')
  .replace(/<link rel="manifest"[^>]*>\n?/, '')
  .replace(/<link rel="icon"[^>]*>/, `<link rel="icon" href="${icon}">`)
  .replace(/<link rel="apple-touch-icon"[^>]*>\n?/, '')
  .replace(/<link rel="stylesheet"[^>]*>/, () => `<style>${css}</style>`)
  .replace(/<script type="module"[^>]*><\/script>/, () => `<script>${js}</script>`);
fs.mkdirSync(root + 'pages', { recursive: true });
fs.writeFileSync(root + 'pages/index.html', html);
console.log('pages/index.html', (html.length / 1024).toFixed(1) + ' KB', 'manifest:', /manifest/.test(html.replace(/mobile-web-app/g, '')), 'sw:', /serviceWorker/.test(html), 'extern refs:', (html.match(/(src|href)="\/[^"]*"/g) || []));
