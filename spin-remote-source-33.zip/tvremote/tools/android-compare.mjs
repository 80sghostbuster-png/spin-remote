// Renders android/www/index.html (the exact file bundled into the APK) at 390x844@2x in headless Chrome and diffs against the web reference shots.
import puppeteer from 'puppeteer-core'; import http from 'node:http'; import fs from 'node:fs';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const html = fs.readFileSync('/workspace/tvremote/android/www/index.html');
const srv = http.createServer((q, r) => { r.setHeader('content-type', 'text/html'); r.end(html); }).listen(8799);
const b = await puppeteer.launch({ executablePath: '/usr/bin/google-chrome', headless: 'new', args: ['--no-sandbox'] });
for (const [q, name] of [['?layout=reel&i=0', 'and-1-reel'], ['?layout=reel&i=0&locked=1', 'and-3-expanded-roku']]) {
  const p = await b.newPage(); await p.setViewport({ width: 390, height: 844, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
  p.on('pageerror', (e) => console.log('pageerror', e.message));
  await p.goto('http://localhost:8799/' + q, { waitUntil: 'networkidle0' }); await sleep(1500);
  await p.screenshot({ path: `/workspace/tvremote/shots/${name}-www.png` }); await p.close();
}
await b.close(); srv.close();
