// Every remote button must be a plain immediate tap: it sends on pointerdown (no waiting for the finger to lift), only the D-pad arrows and volume repeat while held. Runs the exact bundle that ships in the APK (android/www/index.html) in headless Chrome, with Capacitor's native bridge
// emulated: every TvNative plugin call is served by the Node transport talking to the self-written mock TVs.
// UI → JS backend → protocol code → sockets → mocks.  (The Java plugin glue itself is NOT exercised here.)
import puppeteer from 'puppeteer-core'; import http from 'node:http'; import fs from 'node:fs';
import { makeNodeTransport } from '../android/tests/node-transport.mjs';
import { startRokuMock } from '../android/mocks/roku-mock.mjs';
import { startAndroidTvMock } from '../android/mocks/androidtv-mock.mjs';
import { startAdbMock } from '../android/mocks/adb-mock.mjs';
import { startAppleTvMock } from '../android/mocks/appletv-mock.mjs';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const out = process.env.SHOTS || '/workspace/tvremote/shots/';
const results = []; const ok = (n, c, x = '') => { results.push(c); console.log(c ? 'PASS' : 'FAIL', n, c ? '' : x); };

const roku = { close() {} };
const gtvm = { close() {}, st: {} };
const fire = null;
const atvm = { close() {} };
const mdns = [].concat([
  { type: '_androidtvremote2._tcp.', host: '127.0.0.1', port: 6466, name: 'Den Google TV', txt: {} },
  { type: '_companion-link._tcp.', host: '127.0.0.2', port: 17000, name: 'Office Apple TV', txt: { rpMd: 'AppleTV14,1' } },
  ]).filter(() => false);
const T = makeNodeTransport({ mdns });
const B = (u8) => Buffer.from(u8).toString('base64'), U = (s) => new Uint8Array(Buffer.from(s, 'base64'));
const queried = [];
const plugin = {
  ssdp: async () => ({ results: [] }),
  // MDNS_FAIL=1: NSD broken (error 7) and the sweep sees nothing.  MDNS_FAIL=sweep: NSD broken, but the port sweep finds the TV.
  mdns: async (o) => { queried.push(o.type); if (process.env.MDNS_FAIL) throw new Error(`Android NSD failed (NSD failed to start for ${o.type} (error 7, code 7)); direct mDNS got no answer`); return { results: await T.mdns(o), log: ['mock'] }; }, http: (o) => T.http(o),
  tcpScan: async () => ({ results: process.env.MDNS_FAIL === 'sweep' ? [{ host: '127.0.0.1', port: 6467 }, { host: '127.0.0.1', port: 6466 }] : [], prefixes: ['192.168.4.x'] }),
  prepare: async () => ({ android: '16 (API 36)', device: 'Mock Phone', network: 'this app is bound to the Wi-Fi network', phoneIp: '192.168.4.33', nearbyPermission: 'granted', localNetworkPermission: 'not needed' }),
  probe: async (o) => ({ results: o.ports.map((port) => ({ port, state: o.host === '127.0.0.1' && port === 6467 ? 'open' : 'refused', ms: 3, detail: '' })), ping: true }),
  genIdentity: (o) => T.genIdentity(o), rsaSignAdb: async (o) => ({ sig: B(await T.rsaSignAdb({ keyPkcs8: o.keyPkcs8, token: U(o.token) })) }),
  tcpOpen: (o) => T.tcpOpen(o), tcpWrite: async (o) => { await T.tcpWrite(o.id, U(o.data)); return {}; },
  tcpRead: async (o) => { const r = await T.tcpRead(o.id, o.timeoutMs); return { data: r.data ? B(r.data) : undefined, closed: !!r.closed, timeout: !!r.timeout }; }, tcpClose: async (o) => { await T.tcpClose(o.id); return {}; },
};
const hits = [];
const rokuSrv = http.createServer((q, r) => { hits.push(q.method + ' ' + q.url); if (q.url === '/query/device-info') return r.end('<device-info><user-device-name>Limited Roku</user-device-name></device-info>'); if (q.url.startsWith('/launch/')) return r.end(); if (q.url === '/query/apps') return r.end('<apps><app id="12">Netflix</app></apps>'); r.end(); }).listen(8060, '127.0.0.1');
const html = fs.readFileSync('/workspace/tvremote/android/www/index.html');
const srv = http.createServer((q, r) => { r.setHeader('content-type', 'text/html'); r.end(html); }).listen(8799);
const browser = await puppeteer.launch({ executablePath: '/usr/bin/google-chrome', headless: 'new', args: ['--no-sandbox'] });
await browser.defaultBrowserContext().overridePermissions('http://localhost:8799', ['clipboard-read', 'clipboard-write']);
const page = await browser.newPage();
await page.setViewport({ width: 390, height: 844, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
await page.exposeFunction('__plug', async (m, o) => { try { return JSON.stringify({ ok: await plugin[m](JSON.parse(o)) }); } catch (e) { return JSON.stringify({ err: String((e && e.message) || e) }); } });
await page.evaluateOnNewDocument(() => {
  localStorage.setItem('spin.devices', JSON.stringify([{ id: 'roku-127.0.0.1', platform: 'roku', host: '127.0.0.1', name: 'Limited Roku', paired: true }]));
  window.androidBridge = {};
  const call = async (p, m, o) => { const r = JSON.parse(await window.__plug(m, JSON.stringify(o || {}))); if (r.err) throw new Error(r.err); return r.ok; };
  window.Capacitor = { PluginHeaders: [{ name: 'TvNative', methods: ['prepare', 'probe', 'ssdp', 'mdns', 'http', 'tcpScan', 'genIdentity', 'rsaSignAdb', 'tcpOpen', 'tcpWrite', 'tcpRead', 'tcpClose'].map((n) => ({ name: n, rtype: 'promise' })) }, { name: 'SystemBars', methods: [{ name: 'setStyle', rtype: 'promise' }, { name: 'setAnimation', rtype: 'promise' }, { name: 'show', rtype: 'promise' }, { name: 'hide', rtype: 'promise' }] }], nativePromise: call, nativeCallback: () => {} };
});
const errors = []; page.on('pageerror', (e) => errors.push(e.message));
await page.goto('http://localhost:8799/?layout=reel&i=0', { waitUntil: 'networkidle0' });
const text = () => page.evaluate(() => document.body.innerText.replace(/\s+/g, ' '));
const click = async (sel) => { const h = await page.$(sel); if (!h) throw new Error('missing ' + sel); await h.evaluate((e) => e.scrollIntoView({ block: 'center' })); const b = await h.boundingBox(); await page.touchscreen.tap(b.x + b.width / 2, b.y + b.height / 2); };
await sleep(3000);
await click('.card[data-id=roku] [data-key=home]'); await sleep(1200);          // first tap opens the remote (locks the reel)
const keys = () => hits.filter((h) => h.startsWith('POST /keypress/')).map((h) => h.slice(15));
const down = (sel) => page.evaluate((sel) => { const e = document.querySelector(sel); const r = e.getBoundingClientRect(); e.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, pointerId: 7, pointerType: 'touch', isPrimary: true, clientX: r.x + r.width / 2, clientY: r.y + r.height / 2 })); }, sel);
const up = () => page.evaluate(() => window.dispatchEvent(new PointerEvent('pointerup', { bubbles: true, pointerId: 7, pointerType: 'touch', isPrimary: true })));
const ALL = await page.$$eval('.card[data-id=roku] [data-key]', (els) => els.map((e) => [e.dataset.key, e.hasAttribute('data-repeat'), e.hasAttribute('data-kbd')]));
console.log('buttons on the Roku remote:', ALL.map((a) => a[0]).join(' '));
for (const [k, rep, kbd] of ALL) {
  if (kbd) continue;
  hits.length = 0; await down(`.card[data-id=roku] [data-key=${k}]`); await sleep(250);
  const n1 = keys().length;
  ok(`"${k}" sends the moment the finger goes down (finger still down)`, n1 === 1, JSON.stringify(hits));
  await sleep(1100); const n2 = keys().length; await up(); await sleep(150); const n3 = keys().length;
  if (rep) ok(`"${k}" repeats while held`, n2 >= 4, `after 1.35s: ${n2}`); else ok(`"${k}" is a single tap even if held`, n2 === 1 && n3 === 1, `after 1.35s: ${n2}/${n3}`);
  await sleep(120);
}
const REPEATERS = ALL.filter((a) => a[1]).map((a) => a[0]).sort().join(',');
ok('only the D-pad arrows and the volume keys repeat', REPEATERS === 'down,left,right,up,vol_down,vol_up', REPEATERS);
// a plain click (accessibility / keyboard / synthetic) with no pointerdown still sends once
hits.length = 0; await page.evaluate(() => document.querySelector('.card[data-id=roku] [data-key=back]').click()); await sleep(300);
ok('a bare click sends once', keys().join() === 'Back', JSON.stringify(hits));
// real touchscreen taps, with the pill showing the result
hits.length = 0; { const h = await page.$('.card[data-id=roku] [data-key=up]'); const b = await h.boundingBox(); await page.touchscreen.tap(b.x + b.width / 2, b.y + 45); } await sleep(500);   // the wedge is clipped: tap where the arrow is drawn
ok('real tap on Up → POST /keypress/Up with an empty body, pill "Up ✓"', hits.join() === 'POST /keypress/Up' && /Up ✓/.test(await page.$eval('#pill-text', (e) => e.textContent)), JSON.stringify(hits) + await page.$eval('#pill-text', (e) => e.textContent));
await click('.card[data-id=roku] [data-launch=netflix]'); await sleep(600);
ok('launch uses the same tap path', hits.some((h) => h === 'POST /launch/12'), JSON.stringify(hits));
await browser.close(); srv.close(); rokuSrv.close();
console.log('errors:', errors.slice(0, 5)); const bad = results.filter((x) => !x).length; console.log(bad ? `${bad} FAILED` : 'ALL CHECKS PASSED'); process.exit(bad ? 1 : 0);
