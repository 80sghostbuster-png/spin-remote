// Roku with "Control by mobile apps" = Limited (keypress 403, launch OK): the real UI must show it. Runs the exact bundle that ships in the APK (android/www/index.html) in headless Chrome, with Capacitor's native bridge
// emulated: every TvNative plugin call is served by the Node transport talking to the self-written mock TVs.
// UI → JS backend → protocol code → sockets → mocks.  (The Java plugin glue itself is NOT exercised here.)
import puppeteer from 'puppeteer-core'; import http from 'node:http'; import fs from 'node:fs';
import { makeNodeTransport } from '../android/tests/node-transport.mjs';
import { startRokuMock } from '../android/mocks/roku-mock.mjs';
import { startAndroidTvMock } from '../android/mocks/androidtv-mock.mjs';
import { startAdbMock } from '../android/mocks/adb-mock.mjs';
import { startAppleTvMock } from '../android/mocks/appletv-mock.mjs';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const out = process.env.SHOTS || '/workspace/tvremote/shots/';
const results = []; const ok = (n, c, x = '') => { results.push(c); console.log(c ? 'PASS' : 'FAIL', n, c ? '' : x); };

const roku = { close() {} };
const gtvm = { close() {}, st: {} };
const fire = null;
const atvm = { close() {} };
const mdns = [].concat([
  { type: '_androidtvremote2._tcp.', host: '127.0.0.1', port: 6466, name: 'Den Google TV', txt: {} },
  { type: '_companion-link._tcp.', host: '127.0.0.2', port: 17000, name: 'Office Apple TV', txt: { rpMd: 'AppleTV14,1' } },
  ]).filter(() => false);
const T = makeNodeTransport({ mdns });
const B = (u8) => Buffer.from(u8).toString('base64'), U = (s) => new Uint8Array(Buffer.from(s, 'base64'));
const queried = [];
const plugin = {
  ssdp: async () => ({ results: [] }),
  // MDNS_FAIL=1: NSD broken (error 7) and the sweep sees nothing.  MDNS_FAIL=sweep: NSD broken, but the port sweep finds the TV.
  mdns: async (o) => { queried.push(o.type); if (process.env.MDNS_FAIL) throw new Error(`Android NSD failed (NSD failed to start for ${o.type} (error 7, code 7)); direct mDNS got no answer`); return { results: await T.mdns(o), log: ['mock'] }; }, http: (o) => T.http(o),
  tcpScan: async () => ({ results: process.env.MDNS_FAIL === 'sweep' ? [{ host: '127.0.0.1', port: 6467 }, { host: '127.0.0.1', port: 6466 }] : [], prefixes: ['192.168.4.x'] }),
  prepare: async () => ({ android: '16 (API 36)', device: 'Mock Phone', network: 'this app is bound to the Wi-Fi network', phoneIp: '192.168.4.33', nearbyPermission: 'granted', localNetworkPermission: 'not needed' }),
  probe: async (o) => ({ results: o.ports.map((port) => ({ port, state: o.host === '127.0.0.1' && port === 6467 ? 'open' : 'refused', ms: 3, detail: '' })), ping: true }),
  genIdentity: (o) => T.genIdentity(o), rsaSignAdb: async (o) => ({ sig: B(await T.rsaSignAdb({ keyPkcs8: o.keyPkcs8, token: U(o.token) })) }),
  tcpOpen: (o) => T.tcpOpen(o), tcpWrite: async (o) => { await T.tcpWrite(o.id, U(o.data)); return {}; },
  tcpRead: async (o) => { const r = await T.tcpRead(o.id, o.timeoutMs); return { data: r.data ? B(r.data) : undefined, closed: !!r.closed, timeout: !!r.timeout }; }, tcpClose: async (o) => { await T.tcpClose(o.id); return {}; },
};
const hits = [];
const rokuSrv = http.createServer((q, r) => { hits.push(q.method + ' ' + q.url); if (q.url === '/query/device-info') return r.end('<device-info><user-device-name>Limited Roku</user-device-name></device-info>'); if (q.url.startsWith('/launch/')) return r.end(); if (q.url === '/query/apps') { r.statusCode = 403; return r.end(); } r.statusCode = 403; r.end('Forbidden'); }).listen(8060, '127.0.0.1');
const html = fs.readFileSync('/workspace/tvremote/android/www/index.html');
const srv = http.createServer((q, r) => { r.setHeader('content-type', 'text/html'); r.end(html); }).listen(8799);
const browser = await puppeteer.launch({ executablePath: '/usr/bin/google-chrome', headless: 'new', args: ['--no-sandbox'] });
await browser.defaultBrowserContext().overridePermissions('http://localhost:8799', ['clipboard-read', 'clipboard-write']);
const page = await browser.newPage();
await page.setViewport({ width: 390, height: 844, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
await page.exposeFunction('__plug', async (m, o) => { try { return JSON.stringify({ ok: await plugin[m](JSON.parse(o)) }); } catch (e) { return JSON.stringify({ err: String((e && e.message) || e) }); } });
await page.evaluateOnNewDocument(() => {
  localStorage.setItem('spin.devices', JSON.stringify([{ id: 'roku-127.0.0.1', platform: 'roku', host: '127.0.0.1', name: 'Limited Roku', paired: true }]));
  window.androidBridge = {};
  const call = async (p, m, o) => { const r = JSON.parse(await window.__plug(m, JSON.stringify(o || {}))); if (r.err) throw new Error(r.err); return r.ok; };
  window.Capacitor = { PluginHeaders: [{ name: 'TvNative', methods: ['prepare', 'probe', 'ssdp', 'mdns', 'http', 'tcpScan', 'genIdentity', 'rsaSignAdb', 'tcpOpen', 'tcpWrite', 'tcpRead', 'tcpClose'].map((n) => ({ name: n, rtype: 'promise' })) }, { name: 'SystemBars', methods: [{ name: 'setStyle', rtype: 'promise' }, { name: 'setAnimation', rtype: 'promise' }, { name: 'show', rtype: 'promise' }, { name: 'hide', rtype: 'promise' }] }], nativePromise: call, nativeCallback: () => {} };
});
const errors = []; page.on('pageerror', (e) => errors.push(e.message));
await page.goto('http://localhost:8799/?layout=reel&i=0', { waitUntil: 'networkidle0' });
const text = () => page.evaluate(() => document.body.innerText.replace(/\s+/g, ' '));
const click = async (sel) => { const h = await page.$(sel); if (!h) throw new Error('missing ' + sel); await h.evaluate((e) => e.scrollIntoView({ block: 'center' })); const b = await h.boundingBox(); await page.touchscreen.tap(b.x + b.width / 2, b.y + b.height / 2); };
await sleep(3000);
await click('.card[data-id=roku] [data-key=home]'); await sleep(900);    // first tap on the card expands it (locks the reel)
await click('.card[data-id=roku] [data-key=home]'); await sleep(1500);
const pill = await page.$eval('#pill-text', (e) => e.textContent), toastTxt = await page.$eval('#toast', (e) => e.textContent);
console.log('PILL:', pill, '\nTOAST:', toastTxt);
await page.screenshot({ path: out + 'e2e-roku-403.png' });
ok('keypress reached the Roku as POST /keypress/Home', hits.includes('POST /keypress/Home'), JSON.stringify(hits));
ok('the toast says it in plain words with the Roku setting to change', /blocking remote control/.test(toastTxt) && /Network access/.test(toastTxt) && !/POST|keypress/.test(toastTxt), toastTxt);
ok('the status pill shows "Home ✗ HTTP 403"', /Home ✗ HTTP 403/.test(pill), pill);
await click('#pill'); await sleep(400);
ok('tapping the pill explains it, with Details and the raw reason behind a toggle', /What happened/.test(await text()) && !/keypress\/Home/.test(await text()), (await text()).slice(0, 300));
await page.evaluate(() => document.querySelector('[data-act=det]').click()); await sleep(200);
ok('Details shows the real HTTP reason', /403 Forbidden to \/keypress\/Home/.test(await text()), (await text()).slice(0, 500));
await page.evaluate(() => document.querySelector('#backdrop').click()); await sleep(500);
await click('.card[data-id=roku] [data-launch=netflix]'); await sleep(1200);
ok('app launch still works (POST /launch/12 → 200 in pill)', /Netflix ✓/.test(await page.$eval('#pill-text', (e) => e.textContent)) && hits.includes('POST /launch/12'), JSON.stringify(hits));
await click('#btn-sound'); await sleep(500);
ok('Settings has "Copy debug log"', !!(await page.$('[data-act=dbgcopy]')));
await click('[data-act=dbgcopy]'); await sleep(400);
const clip = await page.evaluate(() => navigator.clipboard.readText());
ok('log shows the UI press, the HTTP status and the launch', /ui: fire home/.test(clip) && /ECP POST \/keypress\/Home → HTTP 403/.test(clip) && /ECP POST \/launch\/12 → HTTP 200/.test(clip), clip.split('\n').filter((l) => /ui:|ECP/.test(l)).join('\n'));
await browser.close(); srv.close(); rokuSrv.close();
console.log('errors:', errors.slice(0, 5)); const bad = results.filter((x) => !x).length; console.log(bad ? `${bad} FAILED` : 'ALL CHECKS PASSED'); process.exit(bad ? 1 : 0);
