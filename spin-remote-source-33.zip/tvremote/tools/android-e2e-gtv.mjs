// Runs the exact bundle that ships in the APK (android/www/index.html) in headless Chrome, with Capacitor's native bridge
// emulated: every TvNative plugin call is served by the Node transport talking to the self-written mock TVs.
// UI → JS backend → protocol code → sockets → mocks.  (The Java plugin glue itself is NOT exercised here.)
import puppeteer from 'puppeteer-core'; import http from 'node:http'; import fs from 'node:fs';
import { makeNodeTransport } from '../android/tests/node-transport.mjs';
import { startRokuMock } from '../android/mocks/roku-mock.mjs';
import { startAndroidTvMock } from '../android/mocks/androidtv-mock.mjs';
import { startAdbMock } from '../android/mocks/adb-mock.mjs';
import { startAppleTvMock } from '../android/mocks/appletv-mock.mjs';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const out = process.env.SHOTS || '/workspace/tvremote/shots/';
const results = []; const ok = (n, c, x = '') => { results.push(c); console.log(c ? 'PASS' : 'FAIL', n, c ? '' : x); };

const roku = { close() {} };
const gtvm = await startAndroidTvMock({ pairPort: 6467, remotePort: 6466, host: '127.0.0.1' });
const fire = null;
const atvm = { close() {} };
const mdns = [].concat([
  { type: '_androidtvremote2._tcp.', host: '127.0.0.1', port: 6466, name: 'Den Google TV', txt: {} },
  { type: '_companion-link._tcp.', host: '127.0.0.2', port: 17000, name: 'Office Apple TV', txt: { rpMd: 'AppleTV14,1' } },
  ]).filter(() => false);
const T = makeNodeTransport({ mdns });
const B = (u8) => Buffer.from(u8).toString('base64'), U = (s) => new Uint8Array(Buffer.from(s, 'base64'));
const queried = [];
const plugin = {
  ssdp: async () => ({ results: [] }),
  // MDNS_FAIL=1: NSD broken (error 7) and the sweep sees nothing.  MDNS_FAIL=sweep: NSD broken, but the port sweep finds the TV.
  mdns: async (o) => { queried.push(o.type); if (process.env.MDNS_FAIL) throw new Error(`Android NSD failed (NSD failed to start for ${o.type} (error 7, code 7)); direct mDNS got no answer`); return { results: await T.mdns(o), log: ['mock'] }; }, http: (o) => T.http(o),
  tcpScan: async () => ({ results: process.env.MDNS_FAIL === 'sweep' ? [{ host: '127.0.0.1', port: 6467 }, { host: '127.0.0.1', port: 6466 }] : [], prefixes: ['192.168.4.x'] }),
  prepare: async () => ({ android: '16 (API 36)', device: 'Mock Phone', network: 'this app is bound to the Wi-Fi network', phoneIp: '192.168.4.33', nearbyPermission: 'granted', localNetworkPermission: 'not needed' }),
  probe: async (o) => ({ results: o.ports.map((port) => ({ port, state: o.host === '127.0.0.1' && port === 6467 ? 'open' : 'refused', ms: 3, detail: '' })), ping: true }),
  genIdentity: (o) => T.genIdentity(o), rsaSignAdb: async (o) => ({ sig: B(await T.rsaSignAdb({ keyPkcs8: o.keyPkcs8, token: U(o.token) })) }),
  tcpOpen: (o) => T.tcpOpen(o), tcpWrite: async (o) => { await T.tcpWrite(o.id, U(o.data)); return {}; },
  tcpRead: async (o) => { const r = await T.tcpRead(o.id, o.timeoutMs); return { data: r.data ? B(r.data) : undefined, closed: !!r.closed, timeout: !!r.timeout }; }, tcpClose: async (o) => { await T.tcpClose(o.id); return {}; },
};
const html = fs.readFileSync('/workspace/tvremote/android/www/index.html');
const srv = http.createServer((q, r) => { r.setHeader('content-type', 'text/html'); r.end(html); }).listen(8799);
const browser = await puppeteer.launch({ executablePath: '/usr/bin/google-chrome', headless: 'new', args: ['--no-sandbox'] });
await browser.defaultBrowserContext().overridePermissions('http://localhost:8799', ['clipboard-read', 'clipboard-write']);
const page = await browser.newPage();
await page.setViewport({ width: 390, height: +(process.env.VPH || 844), deviceScaleFactor: +(process.env.DSF || 2), isMobile: true, hasTouch: true });
const errors = []; page.on('pageerror', (e) => errors.push(e.message)); page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
await page.exposeFunction('__plug', async (m, o) => { try { return JSON.stringify({ ok: await plugin[m](JSON.parse(o)) }); } catch (e) { return JSON.stringify({ err: String((e && e.message) || e) }); } });
await page.evaluateOnNewDocument(() => {
  window.androidBridge = {};
  const call = async (p, m, o) => { const r = JSON.parse(await window.__plug(m, JSON.stringify(o || {}))); if (r.err) throw new Error(r.err); return r.ok; };
  window.Capacitor = { PluginHeaders: [{ name: 'TvNative', methods: ['prepare', 'probe', 'ssdp', 'mdns', 'http', 'tcpScan', 'genIdentity', 'rsaSignAdb', 'tcpOpen', 'tcpWrite', 'tcpRead', 'tcpClose'].map((n) => ({ name: n, rtype: 'promise' })) }, { name: 'SystemBars', methods: [{ name: 'setStyle', rtype: 'promise' }, { name: 'setAnimation', rtype: 'promise' }, { name: 'show', rtype: 'promise' }, { name: 'hide', rtype: 'promise' }] }], nativePromise: call, nativeCallback: () => {} };
});
await page.goto('http://localhost:8799/?layout=reel&i=0', { waitUntil: 'networkidle0' });


const text = () => page.evaluate(() => document.body.innerText.replace(/\s+/g, ' '));
const click = async (sel) => { const h = await page.$(sel); if (!h) throw new Error('missing ' + sel + ' in: ' + (await text()).slice(0, 300)); await h.evaluate((e) => e.scrollIntoView({ block: 'center' })); const b = await h.boundingBox(); await page.touchscreen.tap(b.x + b.width / 2, b.y + b.height / 2); };
await sleep(3000);
const settle = async () => { for (let i = 0; i < 60; i++) { await sleep(100); if (await page.evaluate(() => __tv.wheel.settled)) return; } };
const MDNS_OK = (t) => !process.env.MDNS_FAIL || (/error 7/.test(t) && /Scanned 192\.168\.4\.x for [\d\/]+: nothing answered/.test(t));
const detail = async (n = -1) => { await page.evaluate((n) => { const bs = [...document.querySelectorAll('[data-act=det]')]; const b = bs.at(n); b && b.click(); }, n); await sleep(250); };
await page.evaluate(() => __tv.wheel.goTo(2)); await settle(); await sleep(400);
const ps = () => page.evaluate(() => (document.querySelector('#pscreen') || {}).innerText || '').then((x) => x.replace(/\s+/g, ' '));
const modal = () => page.evaluate(() => { const m = document.querySelector('#psmodal'); return m && !m.hidden ? m.innerText.replace(/\s+/g, ' ') : ''; });
const psdetail = async () => { await page.evaluate(() => { const b = document.querySelector('#pscreen [data-act=det]'); b && b.click(); }); await sleep(250); };
const TECH = /NSD|error 7|_androidtvremote2|Scanned 192|protobuf|TLS|socket/i;
await click('#btn-pair-dock'); await sleep(3500);
let t = await ps(); console.log('PAIR SCREEN:', t.slice(0, 300));
await page.screenshot({ path: out + 'e2e-gtv-1-not-found.png' });
ok('pairing screen opened with the caption', /Please select the device to connect/.test(t), t);
if (process.env.MDNS_FAIL === 'sweep') {
  ok('NSD error 7 → the port sweep still lists the TV (no technical text on screen)', !!(await page.$('[data-act=pspick][data-id^=googletv]')) && !TECH.test(t), t.slice(0, 300));
  await click('[data-act=pspick][data-id^=googletv]'); await sleep(3500); t = await modal();
  ok('tapping the row → "Pairing with device / Please enter the PIN code" modal with Cancel and OK', /Pairing with device/.test(t) && /Please enter the PIN code/.test(t) && /Cancel/.test(t) && /OK/.test(t) && !!gtvm.st.code, t);
  ok('only the Google TV service type was searched? (scan asks every platform, Google TV included)', queried.includes('_androidtvremote2._tcp.'), JSON.stringify(queried));
  await page.screenshot({ path: out + 'e2e-gtv-3-pairing.png' });
  await page.type('#pscode', gtvm.st.code); await click('[data-act=psok]'); await sleep(3000);
  ok('correct code → paired, pairing screen closes', await page.evaluate(() => document.querySelector('#pscreen').hidden) && /paired/i.test(await text()), (await text()).slice(0, 200));
  await browser.close(); srv.close(); gtvm.close();
  console.log('errors:', errors.slice(0, 5)); const bad2 = results.filter((x) => !x).length; console.log(bad2 ? `${bad2} FAILED` : 'ALL CHECKS PASSED'); process.exit(bad2 ? 1 : 0);
}
ok('no TV found → "No devices found", Scan again + Enter IP, and no technical text by default', /No devices found/.test(t) && /Scan again/.test(t) && /Enter IP address/.test(t) && !TECH.test(t), t.slice(0, 400));
await psdetail(); t = await page.evaluate(() => document.querySelector('#pscreen .detbox').innerText); ok('"Details" toggle reveals the technical reason', MDNS_OK(t), t.slice(0, 600));
ok('the Google TV service type was searched', queried.includes('_androidtvremote2._tcp.'), JSON.stringify(queried));
ok('"Copy debug log" button is inside Details', !!(await page.$('#pscreen [data-act=dbgcopy]')));
await click('#pscreen [data-act=dbgcopy]'); await sleep(400);
const clip = await page.evaluate(() => navigator.clipboard.readText());
ok('tap copies the debug log to the clipboard', /Spin Remote debug log/.test(clip) && /native\.mdns\(_androidtvremote2/.test(clip) && /Mock Phone/.test(clip) && /192\.168\.4\.33/.test(clip), clip.slice(0, 300));
await page.evaluate(() => { const b = document.querySelector('#pscreen [data-act=dbgcopy]'); b.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true })); }); await sleep(800);
ok('long-press shows the log in a selectable box', await page.evaluate(() => { const t = document.querySelector('#dbgbox'); return t && t.style.display === 'block' && /debug log/.test(t.value); }));
await page.evaluate(() => { const b = document.querySelector('#pscreen [data-act=dbgcopy]'); b.dispatchEvent(new PointerEvent('pointerup', { bubbles: true })); });
await click('#pscreen [data-act=psip]'); await sleep(300); t = await modal();
ok('Enter IP address → small modal with one input and Cancel / Connect', /Enter TV address/.test(t) && /Cancel/.test(t) && /Connect/.test(t), t);
await page.type('#pscode', '127.0.0.9'); await click('[data-act=psipgo]'); await sleep(2500);
for (let k = 0; k < 20 && !/Couldn’t connect/.test(await modal()); k++) await sleep(500);
t = await modal(); ok('wrong IP → "Couldn’t connect" with a friendly line (no technical text)', /Couldn’t connect/.test(t) && /Couldn’t reach your Google TV/.test(t) && !TECH.test(t.replace(/Details/g, '')), t.slice(0, 500));
await page.screenshot({ path: out + 'e2e-gtv-2-bad-ip.png' });
await psdetail(); const det = await page.evaluate(() => document.querySelector('#psmodal .detbox').innerText); console.log('BAD IP DETAILS:', det.slice(0, 900));
ok('Details: "Couldn’t reach a Google TV at 127.0.0.9" + the port check + the phone line', /Couldn’t reach a Google TV at 127\.0\.0\.9/.test(det) && /Port check 127\.0\.0\.9: 6467 pairing closed.*6466 control closed.*8009 Cast closed/.test(det) && /Phone: 192\.168\.4\.33/.test(det), det.slice(0, 700));
ok('Details: per-step result — TCP connect to 6467 FAILED', /TCP connect.*6467.*FAILED/is.test(det), det.slice(0, 700));
await click('#psmodal [data-act=pscancel]'); await sleep(300);
await click('#pscreen [data-act=psip]'); await sleep(300); await page.type('#pscode', '127.0.0.1'); await click('[data-act=psipgo]'); await sleep(4500);
t = await modal(); console.log('AFTER GOOD IP:', t.slice(0, 300));
ok('right IP → PIN modal', /Pairing with device/.test(t) && /Please enter the PIN code/.test(t) && !!gtvm.st.code, t.slice(0, 300));
await page.screenshot({ path: out + 'e2e-gtv-3-pairing.png' });
const okDis = () => page.evaluate(() => document.querySelector('#psmodal [data-act=psok]').disabled);
await page.type('#pscode', 'ZZZZZZ'); await sleep(200);
ok('only hex characters are accepted (Z is dropped), OK stays disabled until 6', (await page.$eval('#pscode', (e) => e.value)) === '' && (await okDis()));
const wrong = ((parseInt(gtvm.st.code.slice(0, 2), 16) ^ 1).toString(16).padStart(2, '0') + gtvm.st.code.slice(2)).toUpperCase();
await page.type('#pscode', wrong.slice(0, 5)); ok('OK disabled with 5 characters', await okDis());
await page.type('#pscode', wrong.slice(5)); ok('OK enabled with 6', !(await okDis()));
await click('#psmodal [data-act=psok]'); await sleep(2000); t = await modal();
ok('wrong code → friendly error in the same modal', /didn’t work/.test(t) && /PIN code/.test(t), t.slice(0, 300)); await page.screenshot({ path: out + 'e2e-gtv-4-wrong-code.png' });
await page.type('#pscode', gtvm.st.code.toLowerCase()); await click('#psmodal [data-act=psok]'); await sleep(3500);
ok('correct code (typed lowercase) → paired, pairing screen closes', await page.evaluate(() => document.querySelector('#pscreen').hidden) && /paired/i.test(await text()), (await text()).slice(0, 200));
await sleep(600); await click('.card[data-id=googletv] [data-key=home]'); await sleep(600); await click('.card[data-id=googletv] [data-key=home]'); await sleep(900);
ok('key reaches the mock TV (HOME)', gtvm.st.keys.some((k) => k.code === 3), JSON.stringify(gtvm.st.keys));
await browser.close(); srv.close(); gtvm.close();
console.log('errors:', errors.slice(0, 5)); const bad = results.filter((x) => !x).length; console.log(bad ? `${bad} FAILED` : 'ALL CHECKS PASSED'); process.exit(bad ? 1 : 0);
