// Runs the exact bundle that ships in the APK (android/www/index.html) in headless Chrome, with Capacitor's native bridge
// emulated: every TvNative plugin call is served by the Node transport talking to the self-written mock TVs.
// UI → JS backend → protocol code → sockets → mocks.  (The Java plugin glue itself is NOT exercised here.)
import puppeteer from 'puppeteer-core'; import http from 'node:http'; import fs from 'node:fs';
import { makeNodeTransport } from '../android/tests/node-transport.mjs';
import { startRokuMock } from '../android/mocks/roku-mock.mjs';
import { startAndroidTvMock } from '../android/mocks/androidtv-mock.mjs';
import { startAdbMock } from '../android/mocks/adb-mock.mjs';
import { startAppleTvMock } from '../android/mocks/appletv-mock.mjs';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const out = process.env.SHOTS || '/workspace/tvremote/shots/';
const results = []; const ok = (n, c, x = '') => { results.push(c); console.log(c ? 'PASS' : 'FAIL', n, c ? '' : x); };

const roku = await startRokuMock({ port: 18060, ssdpPort: 11900, name: 'Living Room Roku' });
const gtvm = await startAndroidTvMock({ pairPort: 6467, remotePort: 6466, host: '127.0.0.1' });
const fire = await startAdbMock({ port: 5555, host: '127.0.0.3' }).catch(() => null);
const atvm = await startAppleTvMock({ port: 17000, host: '127.0.0.2' });
const mdns = [
  { type: '_androidtvremote2._tcp.', host: '127.0.0.1', port: 6466, name: 'Den Google TV', txt: {} },
  { type: '_companion-link._tcp.', host: '127.0.0.2', port: 17000, name: 'Office Apple TV', txt: { rpMd: 'AppleTV14,1' } },
  ...(fire ? [{ type: '_amzn-wplay._tcp.', host: '127.0.0.3', port: 5555, name: 'Bedroom Fire TV', txt: { n: 'Bedroom Fire TV' } }] : [])];
const T = makeNodeTransport({ mdns });
const B = (u8) => Buffer.from(u8).toString('base64'), U = (s) => new Uint8Array(Buffer.from(s, 'base64'));
const plugin = {
  ssdp: async (o) => ({ results: await T.ssdp({ ...o, target: { host: '127.0.0.1', port: 11900 } }) }),
  mdns: async (o) => ({ results: await T.mdns(o) }), http: (o) => T.http(o), tcpScan: async () => ({ results: [], prefixes: [] }), prepare: async () => ({ android: '16 (API 36)', device: 'Mock Phone', network: 'bound to Wi-Fi', phoneIp: '192.168.4.33' }), probe: async (o) => ({ results: o.ports.map((port) => ({ port, state: 'refused', ms: 1, detail: '' })), ping: true }),
  genIdentity: (o) => T.genIdentity(o), rsaSignAdb: async (o) => ({ sig: B(await T.rsaSignAdb({ keyPkcs8: o.keyPkcs8, token: U(o.token) })) }),
  tcpOpen: (o) => T.tcpOpen(o), tcpWrite: async (o) => { await T.tcpWrite(o.id, U(o.data)); return {}; },
  tcpRead: async (o) => { const r = await T.tcpRead(o.id, o.timeoutMs); return { data: r.data ? B(r.data) : undefined, closed: !!r.closed, timeout: !!r.timeout }; }, tcpClose: async (o) => { await T.tcpClose(o.id); return {}; },
};
const html = fs.readFileSync('/workspace/tvremote/android/www/index.html');
const srv = http.createServer((q, r) => { r.setHeader('content-type', 'text/html'); r.end(html); }).listen(8799);
const browser = await puppeteer.launch({ executablePath: '/usr/bin/google-chrome', headless: 'new', args: ['--no-sandbox'] });
const page = await browser.newPage();
await page.setViewport({ width: 390, height: +(process.env.VPH || 844), deviceScaleFactor: +(process.env.DSF || 2), isMobile: true, hasTouch: true });
const errors = []; page.on('pageerror', (e) => errors.push(e.message)); page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
await page.exposeFunction('__plug', async (m, o) => { try { return JSON.stringify({ ok: await plugin[m](JSON.parse(o)) }); } catch (e) { return JSON.stringify({ err: String((e && e.message) || e) }); } });
await page.evaluateOnNewDocument(() => {
  window.androidBridge = {};
  const call = async (p, m, o) => { const r = JSON.parse(await window.__plug(m, JSON.stringify(o || {}))); if (r.err) throw new Error(r.err); return r.ok; };
  window.Capacitor = { PluginHeaders: [{ name: 'TvNative', methods: ['prepare', 'probe', 'ssdp', 'mdns', 'http', 'tcpScan', 'genIdentity', 'rsaSignAdb', 'tcpOpen', 'tcpWrite', 'tcpRead', 'tcpClose'].map((n) => ({ name: n, rtype: 'promise' })) }, { name: 'SystemBars', methods: [{ name: 'setStyle', rtype: 'promise' }, { name: 'setAnimation', rtype: 'promise' }, { name: 'show', rtype: 'promise' }, { name: 'hide', rtype: 'promise' }] }], nativePromise: call, nativeCallback: () => {} };
});
await page.goto('http://localhost:8799/?layout=reel&i=0', { waitUntil: 'networkidle0' });
const text = () => page.evaluate(() => document.body.innerText);
const click = async (sel) => { const h = await page.$(sel); if (!h) throw new Error('missing ' + sel); await h.evaluate((e) => e.scrollIntoView({ block: 'center' })); const b = await h.boundingBox(); await page.touchscreen.tap(b.x + b.width / 2, b.y + b.height / 2); };
const info = await page.evaluate(() => __tv.state.info);
ok('app runs in native mode (not demo, not bridge)', info && info.native && !info.demo, JSON.stringify(info));
for (let i = 0; i < 80; i++) { if ((await page.evaluate(() => __tv.state.devices.length)) >= 1) break; await sleep(250); }
const devs = await page.evaluate(() => __tv.state.devices.map((d) => `${d.platform}:${d.name}:${d.paired}`));
console.log('devices after first-launch auto-scan:', devs.join(' | '));
ok('first-launch auto-scan finds the Roku (SSDP only: no NSD search is started for other platforms)', devs.some((d) => d.startsWith('roku:')) && !devs.some((d) => /^(googletv|appletv|firetv):/.test(d)), devs.join());
await sleep(800); await page.screenshot({ path: out + 'e2e-1-reel-native.png' });
const settle = async () => { for (let i = 0; i < 60; i++) { await sleep(100); if (await page.evaluate(() => __tv.wheel.settled)) return; } };
const goTo = async (i) => { await page.evaluate((i) => __tv.wheel.goTo(i), i); await settle(); await sleep(300); };
// ---- Roku: real HTTP to the mock
await goTo(0); await click('.card[data-id=roku] [data-key=home]'); await sleep(500); await page.screenshot({ path: out + 'e2e-2-expanded-roku.png' });
await click('.card[data-id=roku] [data-key=select]'); await sleep(500);
ok('Roku: tapping buttons sends ECP keypresses to the mock', roku.st.log.some((l) => l.startsWith('POST /keypress/Select')), JSON.stringify(roku.st.log));
await page.screenshot({ path: out + 'e2e-2b-expanded-roku.png' });
// ---- helper: leave expanded view, go to platform i, press PAIR, return the sheet text
const back = async () => { await page.evaluate(() => { const b = document.querySelector('#btn-back, .backbtn, [data-act=back]'); b && b.click(); }); await sleep(500); };
const PF = ['roku', 'firetv', 'googletv', 'appletv'];
const pscreenText = () => page.evaluate(() => (document.querySelector('#pscreen') || {}).innerText || '');
const pairUi = async (i, label, getCode, pre) => {
  await page.evaluate(() => { const c = document.querySelector('[data-act=close],[data-act=psclose]'); c && c.click(); }); await sleep(300);
  await page.evaluate(() => __tv.collapse()); await sleep(900); await goTo(i); await click('#btn-pair-dock'); await sleep(3500);
  await page.screenshot({ path: out + `e2e-pairscreen-list-${label}.png` });
  await click(`[data-act=pspick][data-id^=${PF[i]}]`); await sleep(2500);       // tap the TV in the list
  if (pre) await pre();
  const t = (await pscreenText()).replace(/\s+/g, ' '); console.log(label, 'screen:', t.slice(0, 420));
  return t;
};
const screenGone = async () => page.evaluate(() => document.querySelector('#pscreen').hidden);
// ---- Google TV
let t = await pairUi(2, 'googletv');
await page.screenshot({ path: out + 'e2e-4-pair-googletv.png' });
ok('Google TV: "Pairing with device" dialog asks for the PIN code', /Pairing with device/.test(t) && /Please enter the PIN code/.test(t) && /Cancel/.test(t) && /OK/.test(t) && gtvm.st.code, t.slice(0, 200));
ok('Google TV code field accepts hex letters', await page.$eval('#pscode', (e) => e.getAttribute('inputmode') === 'text' && e.maxLength === 6));
await page.type('#pscode', gtvm.st.code); await sleep(300); await click('[data-act=psok]'); await sleep(2500);
ok('Google TV paired through the UI (screen closes, remote is live)', await screenGone() && /paired/i.test(await page.$eval('#toast', (e) => e.textContent)), await page.$eval('#toast', (e) => e.textContent));
await page.screenshot({ path: out + 'e2e-5-paired-googletv.png' });
await click('.card[data-id=googletv] [data-key=home]'); await sleep(500);   // first tap expands
await click('.card[data-id=googletv] [data-key=home]'); await sleep(900);
ok('Google TV: a button tap reaches the mock as a key event (HOME=3)', gtvm.st.keys.some((k) => k.code === 3), JSON.stringify(gtvm.st.keys));
await page.screenshot({ path: out + 'e2e-6-expanded-googletv.png' });
// ---- Apple TV
await page.evaluate(() => { const b = document.querySelector('[data-act=back],#btn-back'); });

t = await pairUi(3, 'appletv');
await page.screenshot({ path: out + 'e2e-7-pair-appletv.png' });
ok('Apple TV: PIN dialog, numeric keypad, and the mock TV shows a code', /Please enter the PIN code/.test(t) && /^\d{4}$/.test(atvm.st.pin) && await page.$eval('#pscode', (e) => e.getAttribute('inputmode') === 'numeric'), t.slice(0, 200));
await page.type('#pscode', atvm.st.pin); await sleep(300); await click('[data-act=psok]'); await sleep(8000);
ok('Apple TV paired through the UI (SRP + Ed25519 in the page)', await screenGone(), (await pscreenText()).slice(0, 200));
await click('.card[data-id=appletv] [data-key=tv]'); await sleep(500); await page.screenshot({ path: out + 'e2e-8-expanded-appletv.png' });
await click('.card[data-id=appletv] [data-key=tv]'); await sleep(6000);
ok('Apple TV: button taps arrive as HID commands over the encrypted session', atvm.st.hid.length >= 2, JSON.stringify(atvm.st.hid) + atvm.st.pairLog.join('|'));
// ---- Fire TV
if (fire) {
  
  t = await pairUi(1, 'firetv', null, async () => { fire.allow(); });
  await page.screenshot({ path: out + 'e2e-9-pair-firetv.png' });
  ok('Fire TV: approve-on-TV dialog shows no technical text', /Pairing with device/.test(t) && /select Allow/.test(t) && !/ADB|port|socket|HTTP/i.test(t), t.slice(0, 200));
  await sleep(2500); ok('Fire TV: the dialog waits for Allow and the screen closes by itself', await screenGone(), (await pscreenText()).slice(0, 200));
  await page.screenshot({ path: out + 'e2e-10-firetv-confirmed.png' });
}
await page.evaluate(() => __tv.collapse()); await sleep(800); await goTo(0); await page.evaluate(() => __tv.openDevices()); await sleep(900); await page.screenshot({ path: out + 'e2e-12-devices.png' });
await page.evaluate(() => __tv.closeSheet()); await sleep(500); await goTo(0); await click('.card[data-id=roku] [data-key=home]'); await sleep(700); await page.evaluate(() => __tv.openKeyboard()); await sleep(800);
await page.type('#tin', 'stranger things'); await sleep(700); await page.screenshot({ path: out + 'e2e-13-keyboard-roku.png' }); ok('Roku keyboard sheet: typed text reached the mock', roku.st.text === 'stranger things', roku.st.text);
await page.screenshot({ path: out + 'e2e-11-final.png' });
await browser.close(); srv.close(); roku.close(); gtvm.close(); fire && fire.close(); atvm.close();
console.log('errors:', errors.slice(0, 5)); const bad = results.filter((x) => !x).length; console.log(bad ? `${bad} FAILED` : 'ALL E2E CHECKS PASSED'); process.exit(bad ? 1 : 0);
