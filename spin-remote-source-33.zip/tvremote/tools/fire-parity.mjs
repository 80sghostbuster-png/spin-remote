// Build 24: Fire TV connect + keys, byte-for-byte against build 21. Runs the SHIPPED bundle of each build (index.html from the APK) in headless
// Chrome with the native bridge emulated, against the same self-written ADB mock Fire TV, and records every byte the app writes to the TV.
// Usage: node fire-parity.mjs <old.apk|index.html> <new index.html>
import puppeteer from 'puppeteer-core'; import http from 'node:http'; import fs from 'node:fs'; import { execFileSync } from 'node:child_process';
import { makeNodeTransport } from '../android/tests/node-transport.mjs';
import { startAdbMock } from '../android/mocks/adb-mock.mjs';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const load = (f) => f.endsWith('.apk') ? execFileSync('unzip', ['-p', f, 'assets/public/index.html']) : fs.readFileSync(f);
const B = (u8) => Buffer.from(u8).toString('base64'), U = (s) => new Uint8Array(Buffer.from(s, 'base64'));
let ident = null;
async function run(label, html, port) {
  const fire = await startAdbMock({ port: 5555, host: '127.0.0.3', autoAllow: true, helper: true });
  const T = makeNodeTransport({ mdns: [{ type: '_amzn-wplay._tcp.', host: '127.0.0.3', port: 5555, name: 'x', txt: { n: 'Ben’s Fire TV' } }] });
  const wire = [], attempts = []; const ids = new Map();
  const plugin = {
    ssdp: async () => ({ results: [] }), mdns: async (o) => ({ results: await T.mdns(o) }), http: (o) => T.http(o), tcpScan: async () => ({ results: [], prefixes: [] }),
    prepare: async () => ({ android: '16 (API 36)', device: 'Mock Phone', network: 'bound to Wi-Fi', phoneIp: '192.168.4.33' }),
    probe: async (o) => ({ results: await T.probe(o), ping: true }),
    genIdentity: async (o) => { if (!ident) ident = await T.genIdentity(o); return ident; },
    rsaSignAdb: async (o) => ({ sig: B(await T.rsaSignAdb({ keyPkcs8: o.keyPkcs8, token: U(o.token) })) }),
    tcpOpen: async (o) => { attempts.push(`${o.host}:${o.port}`); const r = await T.tcpOpen(o); ids.set(r.id, wire.length); wire.push({ open: `${o.host}:${o.port}${o.tls ? ' tls' : ''}`, w: [] }); return r; },
    tcpWrite: async (o) => { const c = wire[ids.get(o.id)]; if (c) c.w.push(Buffer.from(U(o.data))); await T.tcpWrite(o.id, U(o.data)); return {}; },
    tcpRead: async (o) => { const r = await T.tcpRead(o.id, o.timeoutMs); return { data: r.data ? B(r.data) : undefined, closed: !!r.closed, timeout: !!r.timeout }; },
    tcpClose: async (o) => { await T.tcpClose(o.id); return {}; },
  };
  const srv = http.createServer((q, r) => { r.setHeader('content-type', 'text/html'); r.end(html); }).listen(port);
  const browser = await puppeteer.launch({ executablePath: '/usr/bin/google-chrome', headless: 'new', args: ['--no-sandbox'] });
  const page = await browser.newPage(); const errors = [];
  await page.setViewport({ width: 390, height: 844, deviceScaleFactor: 1, isMobile: true, hasTouch: true });
  page.on('pageerror', (e) => errors.push(e.message));
  await page.exposeFunction('__plug', async (m, o) => { try { return JSON.stringify({ ok: await plugin[m](JSON.parse(o)) }); } catch (e) { return JSON.stringify({ err: String((e && e.message) || e) }); } });
  await page.evaluateOnNewDocument((SAVEDFLAG) => {
    if (!localStorage.getItem('spin.devices')) localStorage.setItem('spin.devices', JSON.stringify([{ id: 'firetv-127.0.0.3', platform: 'firetv', host: '127.0.0.3', name: 'Ben’s Fire TV', paired: false }]));
    window.androidBridge = {};
    const call = async (p, m, o) => { const r = JSON.parse(await window.__plug(m, JSON.stringify(o || {}))); if (r.err) throw new Error(r.err); return r.ok; };
    window.Capacitor = { PluginHeaders: [{ name: 'TvNative', methods: ['prepare', 'probe', 'ssdp', 'mdns', 'http', 'tcpScan', 'genIdentity', 'rsaSignAdb', 'tcpOpen', 'tcpWrite', 'tcpRead', 'tcpClose'].map((n) => ({ name: n, rtype: 'promise' })) }, { name: 'SystemBars', methods: ['setStyle', 'setAnimation', 'show', 'hide'].map((n) => ({ name: n, rtype: 'promise' })) }], nativePromise: call, nativeCallback: () => {} };
  }, !!process.env.SAVED);
  await page.goto(`http://localhost:${port}/?layout=reel&i=1`, { waitUntil: 'networkidle0' }); await sleep(1500);
  // connect exactly as the app does when the Fire TV is tapped
  await page.evaluate(() => __tv.openPair(__tv.state.devices.find((d) => d.platform === 'firetv')));
  let paired = false; for (let i = 0; i < 60 && !paired; i++) { await sleep(250); paired = await page.evaluate(() => !!(__tv.state.devices.find((d) => d.platform === 'firetv') || {}).paired); }
  const ui = await page.evaluate(() => document.body.innerText.replace(/\s+/g, ' ').slice(0, 300));
  const session = async () => {
  attempts.push('--buttons--');
  await page.evaluate(() => { const c = document.querySelector('[data-act=close],[data-act=psclose]'); c && c.click(); }); await sleep(400);
  await page.evaluate(() => { for (const e of document.querySelectorAll('button,[role=button]')) if (/close ad/i.test(e.textContent + ' ' + (e.getAttribute('aria-label') || '')) && e.offsetParent) e.click(); }); await sleep(600);
  await page.evaluate(() => __tv.expand(1)); await sleep(1500);
  const press = async (k) => { await page.evaluate((k) => { const el = [...document.querySelectorAll(`[data-key=${k}]`)].find((e) => e.offsetParent && !e.closest('.inactive')); const o = { bubbles: true, pointerId: 1, isPrimary: true }; el.dispatchEvent(new PointerEvent('pointerdown', o)); el.dispatchEvent(new PointerEvent('pointerup', o)); el.click && 0; }, k); await sleep(700); };
  for (const k of ['up', 'down', 'select', 'back', 'home', 'vol_up']) { try { await press(k); } catch (e) { errors.push('press ' + k + ': ' + e.message); } }
  await sleep(1500);
  };
  await session();
  if (process.env.SAVED) { await page.reload({ waitUntil: 'networkidle0' }); await sleep(2500); await session(); }   // app restarted: saved Fire TV reconnects by itself
  const st = { keys: fire.st.keys.map((k) => `${k.k} via ${k.via}`), cmds: fire.st.cmds.map(String), helperStarts: fire.st.helperStarts, helperKeys: fire.st.helperKeys, opens: fire.st.opens, settingsPuts: fire.st.settingsPuts };
  await browser.close(); srv.close(); fire.close();
  return { label, paired, ui, wire, st, errors, attempts };
}
// ADB packets: 24-byte header (cmd, arg0, arg1, len, crc, magic) + payload. AUTH payloads (signature / public key) are normalized.
function adbNorm(bufs) {
  const all = Buffer.concat(bufs), out = []; let i = 0;
  while (i + 24 <= all.length) { const cmd = all.toString('latin1', i, i + 4), a0 = all.readUInt32LE(i + 4), a1 = all.readUInt32LE(i + 8), n = all.readUInt32LE(i + 12);
    const pl = all.subarray(i + 24, i + 24 + n); out.push(`${cmd} ${a0} ${a1} ${cmd === 'AUTH' ? `<auth type ${a0}, ${n} bytes>` : JSON.stringify(pl.toString('latin1').replace(/DONE[\s\S]{4}/g, 'DONE<mtime>'))}`); i += 24 + n; }
  if (i < all.length) out.push(`<${all.length - i} trailing bytes>`); return out;
}
const [a, b] = await Promise.all([0].map(async () => null)).then(async () => [await run('build 21', load(process.argv[2] || '/workspace/tvremote/android/dist/spin-remote-test21-debug.apk'), 8811), await run('new', load(process.argv[3] || '/workspace/tvremote/android/www/index.html'), 8812)]);
const flat = (r) => r.wire.filter((c) => /:5555/.test(c.open)).map((c) => [`OPEN ${c.open}`, ...adbNorm(c.w)]).flat();
const fa = flat(a), fb = flat(b);
let same = fa.length === fb.length && fa.every((x, i) => x === fb[i]);
const res = { b21: { paired: a.paired, conns: a.wire.length, packets: fa.length, st: a.st, errors: a.errors, ui: a.ui }, now: { paired: b.paired, conns: b.wire.length, packets: fb.length, st: b.st, errors: b.errors, ui: b.ui },
  sameBytes: same, attempts: { b21: a.attempts, now: b.attempts } };
if (!same) { const n = Math.max(fa.length, fb.length); for (let i = 0; i < n; i++) if (fa[i] !== fb[i]) { res.firstDiff = { i, b21: fa[i], now: fb[i] }; break; } }
fs.writeFileSync('/tmp/fire-parity.json', JSON.stringify({ ...res, wireB21: fa, wireNow: fb }, null, 1));
console.log(JSON.stringify(res, null, 1));
// Build 25: the pairing-only code step may knock on the Fire TV code ports (8080/8009) while pairing. That is allowed ONLY before the
// buttons are used; button presses must never touch them. Everything else (ADB) must match build 21 exactly.
const CODE = /:(8080|8009|8443|60000)$/, codeOnly = (l) => l.filter((x) => !CODE.test(x));
const afterButtons = (l) => l.slice(l.indexOf('--buttons--')).filter((x) => CODE.test(x));
res.codeStepAttempts = b.attempts.filter((x) => CODE.test(x)); res.codePortsDuringButtons = afterButtons(b.attempts);
const okAttempts = JSON.stringify(codeOnly(a.attempts)) === JSON.stringify(codeOnly(b.attempts)) && res.codePortsDuringButtons.length === 0;
console.log('code-step attempts (pairing only):', JSON.stringify(res.codeStepAttempts), '| during buttons:', JSON.stringify(res.codePortsDuringButtons));
const okAll = okAttempts && same && a.paired && b.paired && JSON.stringify(a.st.keys) === JSON.stringify(b.st.keys) && JSON.stringify(a.st.cmds) === JSON.stringify(b.st.cmds) && a.st.keys.length >= 6;
console.log(okAll ? 'PARITY PASS' : 'PARITY FAIL'); process.exit(okAll ? 0 : 1);
