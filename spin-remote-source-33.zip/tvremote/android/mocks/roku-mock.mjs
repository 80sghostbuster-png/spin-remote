// SELF-WRITTEN Roku ECP mock (HTTP + SSDP responder). Not a real Roku: it implements the documented ECP endpoints the app uses.
import http from 'node:http';
import dgram from 'node:dgram';

export async function startRokuMock({ port = 18060, ssdpPort = 11900, name = 'Mock Living Room Roku', restricted = false, noPower = false, kind = 'box', delayMs = 0, host = '127.0.0.1' } = {}) {
  // kind: 'tv' (Roku TV: is-tv true, volume works), 'stick' (is-stick true: ECP volume keys do nothing), 'box' (Ultra / Streambar: neither flag)
  const st = { log: [], keys: [], text: '', launched: null, name, conns: 0, search: null };
  const apps = [['12', 'Netflix'], ['837', 'YouTube'], ['13', 'Prime Video'], ['291097', 'Disney+'], ['2285', 'Hulu'], ['151908', 'The Roku Channel']];
  const server = http.createServer((req, res0) => {
    const res = delayMs ? { writeHead: (...a) => res0.writeHead(...a), end: (b) => setTimeout(() => res0.end(b), delayMs) } : res0;
    const u = decodeURIComponent(req.url);
    if (restricted) { res.writeHead(403); return res.end('Forbidden'); }
    st.log.push(`${req.method} ${req.url}`);
    if (req.method === 'GET' && u === '/query/device-info') { res.writeHead(200, { 'content-type': 'text/xml' }); return res.end(`<?xml version="1.0" encoding="UTF-8" ?><device-info><udn>mock-1</udn><serial-number>MOCK123</serial-number><device-id>MOCK-DEV</device-id><model-name>Roku Ultra</model-name><friendly-model-name>Roku Ultra</friendly-model-name><user-device-name>${name}</user-device-name><is-tv>${kind === 'tv'}</is-tv><is-stick>${kind === 'stick'}</is-stick><power-mode>PowerOn</power-mode></device-info>`); }
    if (req.method === 'GET' && u === '/query/apps') { res.writeHead(200, { 'content-type': 'text/xml' }); return res.end(`<apps>${apps.map(([i, n]) => `<app id="${i}" type="appl" version="1.0">${n.replace(/&/g, '&amp;')}</app>`).join('')}</apps>`); }
    if (req.method === 'POST' && req.url.startsWith('/search/browse')) { /* old form keyword=<words> or the Roku OS 12.5+ form ?<words>= */ { const sp = new URL(req.url, 'http://x').searchParams; st.search = sp.get('keyword') != null ? sp.get('keyword') : ([...sp.keys()][0] ?? null); } res.writeHead(200); return res.end(); }
    if (req.method === 'POST' && u.startsWith('/keypress/')) {
      const k = u.slice('/keypress/'.length); st.keys.push({ k, t: Date.now() });
      if (k === 'Power' && noPower) { res.writeHead(400); return res.end(); }
      if (k.startsWith('Lit_')) st.text += k.slice(4); else if (k === 'Backspace') st.text = st.text.slice(0, -1);
      res.writeHead(200); return res.end();
    }
    if (req.method === 'POST' && u.startsWith('/launch/')) { st.launched = u.slice(8); res.writeHead(200); return res.end(); }
    res.writeHead(404); res.end();
  });
  server.on('connection', () => { st.conns++; });
  await new Promise((r) => server.listen(port, host, r));
  const udp = dgram.createSocket('udp4');
  udp.on('message', (m, r) => { if (/ST:\s*roku:ecp/i.test(m.toString())) udp.send(Buffer.from(`HTTP/1.1 200 OK\r\nCache-Control: max-age=3600\r\nST: roku:ecp\r\nUSN: uuid:roku:ecp:MOCK123\r\nLocation: http://127.0.0.1:${port}/\r\nServer: Roku/9.0 UPnP/1.0 Roku/9.0\r\n\r\n`), r.port, r.address); });
  await new Promise((r) => udp.bind(ssdpPort, '127.0.0.1', r));
  return { st, port, ssdpPort, close: () => { server.close(); server.closeAllConnections(); udp.close(); } };
}
if (process.argv[1] && process.argv[1].endsWith('roku-mock.mjs')) { const m = await startRokuMock({ port: 8060, ssdpPort: 1900 }); console.log('roku mock on :8060'); void m; }
