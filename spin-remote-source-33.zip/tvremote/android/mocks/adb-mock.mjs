// SELF-WRITTEN ADB-over-network mock (CNXN / AUTH token+signature+pubkey / OPEN shell:). Not a real Fire TV.
import net from 'node:net';
import crypto from 'node:crypto';
import { A, packet } from '../../web/native/firetv.js';

const SHA1_PREFIX = Buffer.from('3021300906052b0e03021a05000414', 'hex');
const rd32 = (b, o) => b.readUInt32LE(o);

function keyFromAdbBlob(b64txt) {
  const raw = Buffer.from(b64txt.split(' ')[0], 'base64');
  if (raw.length !== 524 || raw.readUInt32LE(0) !== 64) throw new Error('bad adb pubkey blob');
  const nLE = raw.subarray(8, 264), eNum = raw.readUInt32LE(520);
  const n = Buffer.from(nLE).reverse();
  const e = Buffer.alloc(4); e.writeUInt32BE(eNum);
  // check the n0inv & rr fields independently (extended Euclid / modpow), as Android's adbd would rely on them
  const N = BigInt('0x' + n.toString('hex')), M = 1n << 32n;
  const egcd = (a, b) => (b === 0n ? [a, 1n, 0n] : (([g, x, y]) => [g, y, x - (a / b) * y])(egcd(b, a % b)));
  const inv = ((egcd(N % M, M)[1] % M) + M) % M, n0inv = Number((M - inv) % M);
  if (raw.readUInt32LE(4) !== n0inv) throw new Error('bad n0inv');
  let rr = 1n; for (let i = 0; i < 4096; i++) rr = (rr * 2n) % N;
  if (BigInt('0x' + Buffer.from(raw.subarray(264, 520)).reverse().toString('hex')) !== rr) throw new Error('bad rr');
  return { key: crypto.createPublicKey({ key: { kty: 'RSA', n: n.toString('base64url'), e: Buffer.from(e.toString('hex').replace(/^(00)+/, ''), 'hex').toString('base64url') }, format: 'jwk' }), raw, n };
}

// delayMs  = one-way network delay applied to every packet the TV sends (models Wi-Fi), inputMs = time `input keyevent` takes on the TV (the JVM start of /system/bin/input),
// failInput = regex: commands matching it print an error like a missing/rejected key (to test fallbacks), interactive = false makes `shell:` (no command) unavailable.
const CODE_NAMES = { 19: 'KEYCODE_DPAD_UP', 20: 'KEYCODE_DPAD_DOWN', 21: 'KEYCODE_DPAD_LEFT', 22: 'KEYCODE_DPAD_RIGHT', 23: 'KEYCODE_DPAD_CENTER', 4: 'KEYCODE_BACK', 3: 'KEYCODE_HOME', 82: 'KEYCODE_MENU', 85: 'KEYCODE_MEDIA_PLAY_PAUSE', 89: 'KEYCODE_MEDIA_REWIND', 90: 'KEYCODE_MEDIA_FAST_FORWARD', 24: 'KEYCODE_VOLUME_UP', 25: 'KEYCODE_VOLUME_DOWN', 164: 'KEYCODE_VOLUME_MUTE', 26: 'KEYCODE_POWER', 67: 'KEYCODE_DEL', 66: 'KEYCODE_ENTER', 84: 'KEYCODE_SEARCH', 126: 'KEYCODE_MEDIA_PLAY', 127: 'KEYCODE_MEDIA_PAUSE', 88: 'KEYCODE_MEDIA_PREVIOUS', 87: 'KEYCODE_MEDIA_NEXT' };
export async function startAdbMock({ port = 15555, autoAllow = false, host = '127.0.0.1', dropOnOffer = false, delayMs = 0, inputMs = 0, failInput = null, interactive = true, cmdInput = false, cmdMs = 0, globalSearch = false, fixedVolume = false, helper = false, cecEnabled = '1', cecVolume = '0', settingsRefused = false, helperStartMs = 300, helperMs = 0, noBase64 = false, noSync = false, helperNoise = '' } = {}) {
  const st = { cmds: [], keys: [], lines: 0, settings: { hdmi_control_enabled: cecEnabled, hdmi_control_volume_control_enabled: cecVolume }, settingsPuts: [], searchOpen: 0, files: new Map(), setup: [], helperStarts: 0, helperKeys: 0, trusted: [], offered: [], badSig: 0, pendingAllow: null, opens: 0, interactiveOpens: 0, vol: [] };
  const socks = new Set();
  const server = net.createServer((sock) => { sock.setNoDelay(true);
    socks.add(sock); sock.on('close', () => socks.delete(sock)); sock.on('error', () => {});
    let buf = Buffer.alloc(0), token = null, nextRemote = 100;
    const send = (c, a0, a1, d) => { const p = packet(c, a0, a1, d ? new Uint8Array(d) : undefined); if (delayMs) setTimeout(() => { if (!sock.destroyed) sock.write(p); }, delayMs); else sock.write(p); };
    const streams = new Map();                       // our remote id -> { local, line, q: Promise (commands run one at a time inside one shell) }
    // Runs one shell command line the way sh would: `a; b` runs both. Returns the text it prints.
    const runLine = async (line, onKey) => {
      let out = '';
      const parts = []; { let cur = '', q = false, esc = false; for (const ch of line) { if (esc) { esc = false; cur += ch; continue; } if (ch === '\\' && !q) { esc = true; cur += ch; continue; } if (ch === "'") q = !q; if (ch === ';' && !q) { parts.push(cur); cur = ''; } else cur += ch; } parts.push(cur); }   // split on ; outside '…'
      { const L = line.replace(/; echo __K''\d+__\s*$/, '').trim(); let m;            // fast-key-helper setup: kept out of st.cmds / st.lines
        if ((m = /^\[ -[fs] (\S+) \] && echo HAVE''__DEX$/.exec(L))) { st.setup.push(L); return (st.files.has(m[1]) ? 'HAVE__DEX\n' : '') + (line.includes('__K') ? line.match(/__K''(\d+)__/)[0].replace("''", '') + '\n' : ''); }
        if (/^(settings put global hdmi_control_\w+ \d; )*echo CEC=\$\(settings get global hdmi_control_enabled\) VOL=\$\(settings get global hdmi_control_volume_control_enabled\)$/.test(L)) {
          st.setup.push('cec'); for (const pm of L.matchAll(/settings put global (hdmi_control_\w+) (\d)/g)) { st.settingsPuts.push(pm[1] + '=' + pm[2]); if (!settingsRefused) st.settings[pm[1]] = pm[2]; }
          const k = line.match(/__K''(\d+)__/)[0].replace("''", ''); return `CEC=${st.settings.hdmi_control_enabled} VOL=${st.settings.hdmi_control_volume_control_enabled}\n${k}\n`;
        }
        if ((m = /^rm -f (\S+)$/.exec(L))) { st.setup.push(L); st.files.delete(m[1]); return line.match(/__K''(\d+)__/)[0].replace("''", '') + '\n'; }
        if ((m = /^echo -n '([A-Za-z0-9+\/=]*)' >> (\S+)$/.exec(L))) { st.setup.push('chunk'); st.files.set(m[2], (st.files.get(m[2]) || '') + m[1]); return line.match(/__K''(\d+)__/)[0].replace("''", '') + '\n'; }
        if ((m = /^base64 -d (\S+) > \S+\.part && mv \S+ (\S+) && rm -f \S+ && echo DEX''__OK$/.exec(L))) { st.setup.push('decode'); const k = line.match(/__K''(\d+)__/)[0].replace("''", ''); if (noBase64) return `/system/bin/sh: base64: inaccessible or not found\n${k}\n`; st.files.set(m[2], Buffer.from(st.files.get(m[1]) || '', 'base64')); st.files.delete(m[1]); return `DEX__OK\n${k}\n`; }
      }
      if (!/^echo (__K''\d+__|ready)$/.test(line.trim())) st.lines++;
      for (const c0 of parts.map((x) => x.trim()).filter(Boolean)) {
        let c = c0.replace(/\s+2>&1(\s*\|\s*head -\d+)?$/, '');
        if (/^cmd input\b/.test(c)) {                                // Android 11+/Fire OS 8 style: the input service's own shell command (no JVM start)
          if (!cmdInput) { st.cmds.push('shell:' + c); out += 'No shell command implementation.\n'; continue; }
          if (c === 'cmd input') { st.cmds.push('shell:' + c); out += 'Usage: input [<source>] [-d DISPLAY_ID] <command> [<arg>...]\n  text <string>\n  keyevent [--longpress|--doubletap] <key code number or name> ...\n'; continue; }
          if (cmdMs) await new Promise((r) => setTimeout(r, cmdMs));
          c = c.replace(/^cmd input/, 'input'); st.via = (st.via || []); st.via.push('cmd');
          const mm = /^input keyevent (.+)$/.exec(c); if (mm && !(failInput && failInput.test(c))) { st.cmds.push('shell:cmd ' + c); for (const k of mm[1].split(/\s+/)) st.keys.push({ k, t: Date.now(), via: 'cmd' }); continue; }
          const mt = /^input text (.+)$/.exec(c); if (mt && !(failInput && failInput.test(c))) { st.cmds.push('shell:cmd ' + c); (st.texts = st.texts || []).push(mt[1]); continue; }
          if (failInput && failInput.test(c)) { st.cmds.push('shell:cmd ' + c); out += `Exception occurred while executing 'input':\njava.lang.IllegalArgumentException: bad key\n`; continue; }
        }
        if (/^dumpsys audio/.test(c)) { st.cmds.push('shell:dumpsys audio'); out += fixedVolume ? '  mUseFixedVolume=true\n  mHdmiCecVolumeControlEnabled=false\n' : '  mUseFixedVolume=false\n  mHdmiCecVolumeControlEnabled=true\n'; continue; }
        if (/^am start -a android\.search\.action\.GLOBAL_SEARCH/.test(c)) { st.cmds.push('shell:' + c); if (globalSearch) { st.searchOpen++; out += 'Starting: Intent { act=android.search.action.GLOBAL_SEARCH }\n'; } else out += 'Starting: Intent { act=android.search.action.GLOBAL_SEARCH }\nError: Activity not started, unable to resolve Intent { act=android.search.action.GLOBAL_SEARCH flg=0x10000000 }\n'; continue; }
        if (/^echo (__K''\d+__|ready)$/.test(c)) st.markers = (st.markers || 0) + 1; else st.cmds.push('shell:' + c);
        let m;
        if (failInput && failInput.test(c)) { out += `Exception occurred while executing '${c.split(' ')[0]}':\njava.lang.IllegalArgumentException: bad key\n`; continue; }
        if ((m = /^input keyevent (.+)$/.exec(c))) { if (inputMs) await new Promise((r) => setTimeout(r, inputMs)); for (const k of m[1].split(/\s+/)) { st.keys.push({ k, t: Date.now() }); } }
        else if ((m = /^input text (.+)$/.exec(c))) { (st.texts = st.texts || []).push(m[1]); }
        else if ((m = /^cmd media_session volume .*--adj (\w+)/.exec(c))) { st.vol.push({ adj: m[1], t: Date.now() }); }
        else if ((m = /^echo (.*)$/.exec(c))) out += m[1].replace(/''/g, '') + '\n';
      }
      return out;
    };
    const newToken = () => { token = crypto.randomBytes(20); send(A.AUTH, 1, 0, token); };
    const onPkt = (cmd, a0, a1, data) => {
      if (cmd === A.CNXN) newToken();
      else if (cmd === A.AUTH && a0 === 2) {
        const ok = st.trusted.some((k) => { try { return Buffer.compare(crypto.publicDecrypt(k.key, data), Buffer.concat([SHA1_PREFIX, token])) === 0; } catch { return false; } });
        if (ok) send(A.CNXN, 0x01000001, 256 * 1024, Buffer.from('device::ro.product.name=mock_firetv;features=cmd\0')); else { st.badSig++; newToken(); }
      } else if (cmd === A.AUTH && a0 === 3) {
        const k = keyFromAdbBlob(Buffer.from(data).toString().replace(/\0.*$/, '')); st.offered.push(k);
        if (dropOnOffer) { st.trusted.push(k); setTimeout(() => sock.destroy(), 150); return; }   // TV hangs up when the dialog appears (key is trusted by the time we reconnect)
        const allow = () => { st.trusted.push(k); send(A.CNXN, 0x01000001, 256 * 1024, Buffer.from('device::ro.product.name=mock_firetv;features=cmd\0')); };
        if (autoAllow) setTimeout(allow, 200); else st.pendingAllow = allow;
      } else if (cmd === A.OPEN) {
        const dest = Buffer.from(data).toString().replace(/\0$/, ''); st.opens++;
        const r = nextRemote++;
        if (/^shell:CLASSPATH=(\S+) exec app_process \/ com\.spinremote\.keys\.Main( 2>&1)?$/.test(dest)) {      // the fast key helper (build 20)
          const file = /CLASSPATH=(\S+)/.exec(dest)[1]; send(A.OKAY, r, a0); st.helperStarts++;
          const H = { local: a0, line: '', helper: true, q: Promise.resolve() }; streams.set(r, H);
          if (!helper || !st.files.has(file)) { setTimeout(() => { send(A.WRTE, r, a0, Buffer.from('SPINKEYS FAIL java.lang.ClassNotFoundException: com.spinremote.keys.Main\n')); send(A.CLSE, r, a0); streams.delete(r); }, 50); return; }
          setTimeout(() => send(A.WRTE, r, a0, Buffer.from(helperNoise + 'SPINKEYS READY\n')), helperStartMs);
          return;
        }
        if (dest === 'sync:') {                                     // adb push (SEND path,mode / DATA / DONE → OKAY)
          if (noSync) { send(A.CLSE, 0, a0); return; }
          send(A.OKAY, r, a0); streams.set(r, { local: a0, sync: true, buf: Buffer.alloc(0), path: null, data: [] }); return;
        }
        if (dest === 'shell:') {                                    // interactive shell on a pty: echoes what is typed, prints a prompt
          if (!interactive) { send(A.CLSE, 0, a0); return; }
          st.interactiveOpens++; const S = { local: a0, line: '', q: Promise.resolve() }; streams.set(r, S);
          send(A.OKAY, r, a0); send(A.WRTE, r, a0, Buffer.from('shell@mock:/ $ '));
          return;
        }
        send(A.OKAY, r, a0);
        const cmdline = dest.replace(/^shell:/, '');
        runLine(cmdline).then((out) => { if (out) send(A.WRTE, r, a0, Buffer.from(out)); send(A.CLSE, r, a0); });
      } else if (cmd === A.WRTE) {
        const S = streams.get(a1); if (!S) return;                  // a1 = our remote id
        send(A.OKAY, a1, a0);
        if (S.sync) {
          S.buf = Buffer.concat([S.buf, Buffer.from(data)]);
          while (S.buf.length >= 8) {
            const id = S.buf.slice(0, 4).toString(), n = S.buf.readUInt32LE(4);
            if (id === 'DONE') { S.buf = S.buf.slice(8); st.files.set(S.path, Buffer.concat(S.data)); st.setup.push('sync'); send(A.WRTE, a1, S.local, Buffer.concat([Buffer.from('OKAY'), Buffer.alloc(4)])); continue; }
            if (id === 'QUIT') { S.buf = S.buf.slice(8); continue; }
            if (S.buf.length < 8 + n) break;
            const body = S.buf.slice(8, 8 + n); S.buf = S.buf.slice(8 + n);
            if (id === 'SEND') { S.path = body.toString().split(',')[0]; S.data = []; } else if (id === 'DATA') S.data.push(body);
          }
          return;
        }
        if (S.helper) {
          S.line += Buffer.from(data).toString(); let j;
          while ((j = S.line.indexOf('\n')) >= 0) {
            const ln = S.line.slice(0, j); S.line = S.line.slice(j + 1);
            S.q = S.q.then(async () => {
              const [c, id, ...rest] = ln.split(' '); const arg = rest.join(' ');
              if (helperMs) await new Promise((r) => setTimeout(r, helperMs));
              let res = 'ok';
              if (c === 'k') { const name = CODE_NAMES[+arg] || String(arg); if (failInput && failInput.test('input keyevent ' + name)) res = 'err refused'; else { st.keys.push({ k: name, t: Date.now(), via: 'helper' }); st.helperKeys++; } }
              else if (c === 't') { if (failInput && failInput.test('input text x')) res = 'err refused'; else (st.texts = st.texts || []).push(arg); }
              send(A.WRTE, a1, S.local, Buffer.from(`A${id} ${res}\n`));
            });
          }
          return;
        }
        const text = Buffer.from(data).toString(); send(A.WRTE, a1, S.local, Buffer.from(text.replace(/\n/g, '\r\n')));   // pty echo
        S.line += text;
        let i; while ((i = S.line.indexOf('\n')) >= 0) {
          const line = S.line.slice(0, i); S.line = S.line.slice(i + 1);
          S.q = S.q.then(async () => { const out = await runLine(line); send(A.WRTE, a1, S.local, Buffer.from(out.replace(/\n/g, '\r\n') + 'shell@mock:/ $ ')); });
        }
      } else if (cmd === A.OKAY) { /* ack of our WRTE */ }
      else if (cmd === A.CLSE) { streams.delete(a1); send(A.CLSE, a1, a0); }
    };
    sock.on('data', (d) => {
      buf = Buffer.concat([buf, d]);
      while (buf.length >= 24) {
        const len = rd32(buf, 12); if (buf.length < 24 + len) break;
        const cmd = rd32(buf, 0); if (((cmd ^ 0xffffffff) >>> 0) !== rd32(buf, 20)) { sock.destroy(); return; }
        let sum = 0; for (const x of buf.subarray(24, 24 + len)) sum = (sum + x) >>> 0; if (sum !== rd32(buf, 16)) { sock.destroy(); return; }
        const pkt = [cmd, rd32(buf, 4), rd32(buf, 8), buf.subarray(24, 24 + len)]; buf = buf.subarray(24 + len); onPkt(...pkt);
      }
    });
  });
  await new Promise((r) => server.listen(port, host, r));
  return { st, port, allow: () => st.pendingAllow && st.pendingAllow(), close: () => { server.close(); socks.forEach((x) => x.destroy()); } };
}
