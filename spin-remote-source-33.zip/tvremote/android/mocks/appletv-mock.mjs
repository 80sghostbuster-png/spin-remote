// SELF-WRITTEN Apple TV "Companion" mock (server side), written from pyatv's public source. Not a real Apple TV.
// Implements HAP Pair-Setup (SRP-3072, PIN), Pair-Verify (X25519/Ed25519), ChaCha20-Poly1305 framing and a handful of OPACK requests.
import net from 'node:net';
import crypto from 'node:crypto';
import { ed25519, x25519 } from '@noble/curves/ed25519.js';
import { chacha20poly1305 } from '@noble/ciphers/chacha.js';
import { hkdf } from '@noble/hashes/hkdf.js';
import { sha512 } from '@noble/hashes/sha2.js';
import { cat, te, hex } from '../../web/native/bytes.js';
import * as opack from '../../web/native/opack.js';
import * as bplist from '../../web/native/bplist.js';
import { srpServer } from '../../web/native/srp.js';
import { tlvRead, tlvWrite, TLV, FT } from '../../web/native/appletv.js';

const rnd = (n) => new Uint8Array(crypto.randomBytes(n));
const hk = (salt, info, secret) => hkdf(sha512, secret, te.encode(salt), te.encode(info), 32);
const nonce8 = (l) => cat(new Uint8Array(4), te.encode(l));
const nonce12 = (n) => { const o = new Uint8Array(12); let v = BigInt(n); for (let i = 0; i < 12; i++) { o[i] = Number(v & 255n); v >>= 8n; } return o; };
const U = bplist.UID, cls = (n) => ({ $classname: n, $classes: [n, 'NSObject'] });

export async function startAppleTvMock({ port = 17000, host = '127.0.0.1', pin = null } = {}) {
  const atvSk = rnd(32), atvPk = ed25519.getPublicKey(atvSk), atvId = te.encode('AA:BB:CC:11:22:33');
  const st = { pin: pin || String(1000 + crypto.randomInt(9000)), clients: new Map(), hid: [], apps: [], texts: [], field: '', mcc: [], pairLog: [], sessions: 0, state: 3, tiSession: null, wrongPins: 0, info: [] };
  const sockets = new Set();
  const server = net.createServer((sock) => {
    sockets.add(sock); sock.on('close', () => sockets.delete(sock)); sock.on('error', () => {});
    let buf = new Uint8Array(0), inKey = null, outKey = null, inN = 0, outN = 0, ps = null, pv = null;
    const send = (type, payload) => {
      let len = payload.length, body = payload; if (outKey && len) len += 16;
      const header = Uint8Array.of(type, (len >> 16) & 255, (len >> 8) & 255, len & 255);
      if (outKey && payload.length) body = chacha20poly1305(outKey, nonce12(outN++), header).encrypt(payload);
      sock.write(Buffer.from(cat(header, body)));
    };
    const reply = (type, req, dict) => send(type, opack.pack({ ...dict, _x: req._x, _t: 3 }));
    sock.on('data', (d) => {
      buf = cat(buf, new Uint8Array(d));
      for (;;) {
        if (buf.length < 4) return; const n = (buf[1] << 16) | (buf[2] << 8) | buf[3]; if (buf.length < 4 + n) return;
        const header = buf.slice(0, 4), type = buf[0]; let payload = buf.slice(4, 4 + n); buf = buf.slice(4 + n);
        try { if (inKey && payload.length) payload = chacha20poly1305(inKey, nonce12(inN++), header).decrypt(payload); } catch (e) { st.pairLog.push('bad frame mac'); if (process.env.ATV_DEBUG) console.log('MOCK bad frame mac'); sock.destroy(); return; }
        const [m] = opack.unpack(payload);
        try { handle(type, m); } catch (e) { st.pairLog.push('handler error: ' + e.message); if (process.env.ATV_DEBUG) console.log('MOCK handler error', e.stack); sock.destroy(); }
      }
    });
    function handle(type, m) {
      if (type === FT.PS_Start) {
        const t = tlvRead(m._pd); if (t[TLV.SeqNo][0] !== 1) throw new Error('bad seq');
        const salt = rnd(16); let srv; do { srv = srpServer('Pair-Setup', st.pin, salt, rnd(32)); } while (srv.publicKey.length !== 384 && false);
        ps = { srv, salt }; st.pairLog.push('PS M1 (pin shown on TV: ' + st.pin + ')');
        return send(FT.PS_Next, opack.pack({ _pd: tlvWrite([[TLV.SeqNo, Uint8Array.of(2)], [TLV.PublicKey, srv.publicKey], [TLV.Salt, salt]]), _x: m._x, _t: 3 }));
      }
      if (type === FT.PS_Next) {
        const t = tlvRead(m._pd), seq = t[TLV.SeqNo][0];
        if (seq === 3) {
          const r = ps.srv.process(t[TLV.PublicKey]); ps.key = r.key;
          if (Buffer.compare(Buffer.from(r.expectedClientProof), Buffer.from(t[TLV.Proof])) !== 0) { st.wrongPins++; st.pairLog.push('PS M3 BAD PROOF'); return send(FT.PS_Next, opack.pack({ _pd: tlvWrite([[TLV.SeqNo, Uint8Array.of(4)], [TLV.Error, Uint8Array.of(2)]]), _x: m._x, _t: 3 })); }
          st.pairLog.push('PS M3 proof ok');
          return send(FT.PS_Next, opack.pack({ _pd: tlvWrite([[TLV.SeqNo, Uint8Array.of(4)], [TLV.Proof, r.serverProof(t[TLV.Proof])]]), _x: m._x, _t: 3 }));
        }
        if (seq === 5) {
          const encKey = hk('Pair-Setup-Encrypt-Salt', 'Pair-Setup-Encrypt-Info', ps.key);
          const dec = tlvRead(chacha20poly1305(encKey, nonce8('PS-Msg05')).decrypt(t[TLV.EncryptedData]));
          const x = hk('Pair-Setup-Controller-Sign-Salt', 'Pair-Setup-Controller-Sign-Info', ps.key);
          if (!ed25519.verify(dec[TLV.Signature], cat(x, dec[TLV.Identifier], dec[TLV.PublicKey]), dec[TLV.PublicKey])) throw new Error('client signature invalid');
          const [nm] = dec[TLV.Name] ? opack.unpack(dec[TLV.Name]) : [{}];
          st.clients.set(new TextDecoder().decode(dec[TLV.Identifier]), { ltpk: dec[TLV.PublicKey], name: nm.name }); st.pairLog.push('PS M5 ok, client name ' + nm.name);
          const ax = hk('Pair-Setup-Accessory-Sign-Salt', 'Pair-Setup-Accessory-Sign-Info', ps.key);
          const inner = tlvWrite([[TLV.Identifier, atvId], [TLV.PublicKey, atvPk], [TLV.Signature, ed25519.sign(cat(ax, atvId, atvPk), atvSk)]]);
          return send(FT.PS_Next, opack.pack({ _pd: tlvWrite([[TLV.SeqNo, Uint8Array.of(6)], [TLV.EncryptedData, chacha20poly1305(encKey, nonce8('PS-Msg06')).encrypt(inner)]]), _x: m._x, _t: 3 }));
        }
      }
      if (type === FT.PV_Start) {
        const t = tlvRead(m._pd), cPub = t[TLV.PublicKey], ek = rnd(32), ePub = x25519.getPublicKey(ek), shared = x25519.getSharedSecret(ek, cPub);
        const vKey = hk('Pair-Verify-Encrypt-Salt', 'Pair-Verify-Encrypt-Info', shared);
        pv = { cPub, ePub, shared, vKey };
        const inner = tlvWrite([[TLV.Identifier, atvId], [TLV.Signature, ed25519.sign(cat(ePub, atvId, cPub), atvSk)]]);
        return send(FT.PV_Next, opack.pack({ _pd: tlvWrite([[TLV.SeqNo, Uint8Array.of(2)], [TLV.PublicKey, ePub], [TLV.EncryptedData, chacha20poly1305(vKey, nonce8('PV-Msg02')).encrypt(inner)]]), _x: m._x, _t: 3 }));
      }
      if (type === FT.PV_Next) {
        const t = tlvRead(m._pd);
        const bad = () => { st.pairLog.push('PV rejected'); send(FT.PV_Next, opack.pack({ _pd: tlvWrite([[TLV.SeqNo, Uint8Array.of(4)], [TLV.Error, Uint8Array.of(2)]]), _x: m._x, _t: 3 })); };
        let dec; try { dec = tlvRead(chacha20poly1305(pv.vKey, nonce8('PV-Msg03')).decrypt(t[TLV.EncryptedData])); } catch (e) { return bad(); }
        const c = st.clients.get(new TextDecoder().decode(dec[TLV.Identifier] || new Uint8Array()));
        if (!c || !ed25519.verify(dec[TLV.Signature], cat(pv.cPub, dec[TLV.Identifier], pv.ePub), c.ltpk)) return bad();
        st.pairLog.push('PV ok'); send(FT.PV_Next, opack.pack({ _pd: tlvWrite([[TLV.SeqNo, Uint8Array.of(4)]]), _x: m._x, _t: 3 }));
        outKey = hk('', 'ServerEncrypt-main', pv.shared); inKey = hk('', 'ClientEncrypt-main', pv.shared); inN = 0; outN = 0; return;
      }
      if (type === FT.E_OPACK) {
        if (!inKey) throw new Error('unencrypted OPACK');
        const i = m._i, c = m._c || {};
        if (m._t === 1) {                                           // events
          if (i === '_tiC') {
            const arc = bplist.read(c._tiD), ops = bplist.archiveProp(arc, ['textOperations']);
            const ko = ops && arc.$objects[ops.keyboardOutput.uid];
            if (ko && ko.insertionText) { const t = arc.$objects[ko.insertionText.uid]; st.field += t; st.texts.push(t); } else { st.field = ''; st.texts.push('<clear>'); }
          }
          return;
        }
        if (i === '_sessionStart') { st.sessions++; return reply(FT.E_OPACK, m, { _c: { _sid: 77 } }); }
        if (i === '_hidC') { st.hid.push({ code: c._hidC, state: c._hBtS, t: Date.now() }); return reply(FT.E_OPACK, m, { _c: {} }); }
        if (i === '_launchApp') { st.apps.push(c._bundleID || c._urlS); return reply(FT.E_OPACK, m, { _c: {} }); }
        if (i === '_mcc') { st.mcc.push(c); return reply(FT.E_OPACK, m, { _c: {} }); }
        if (i === 'FetchAttentionState') return reply(FT.E_OPACK, m, { _c: { state: st.state } });
        if (i === '_tiStart' && st.noField) return reply(FT.E_OPACK, m, { _c: {} });          // no text field is focused on the TV
        if (i === '_tiStart') {
          st.tiSession = rnd(16);
          const arc = bplist.write({ $version: 100000, $archiver: 'RTIKeyedArchiver', $top: { sessionUUID: U(1), documentState: U(2) }, $objects: ['$null', st.tiSession, { docSt: U(3), $class: U(5) }, { contextBeforeInput: U(4), $class: U(5) }, st.field, cls('RTIDocumentState')] });
          return reply(FT.E_OPACK, m, { _c: { _tiD: arc } });
        }
        if (i === '_tiStop') { st.tiSession = null; return reply(FT.E_OPACK, m, { _c: {} }); }
        if (i === '_systemInfo') st.info.push(c.name);
        if (i === 'TVRCSessionStart') return reply(FT.E_OPACK, m, { _c: {} });
        return reply(FT.E_OPACK, m, { _c: {} });
      }
    }
  });
  await new Promise((r) => server.listen(port, host, r));
  return { st, port, sockets: () => sockets, unpairAll: () => st.clients.clear(), close: () => { for (const s of sockets) s.destroy(); server.close(); }, atvId: hex(atvId) };
}
