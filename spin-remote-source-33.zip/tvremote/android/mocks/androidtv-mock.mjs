// SELF-WRITTEN Android TV remote v2 mock (TLS + protobuf), written from the public protocol description (polo.proto / remotemessage.proto).
// Not a real TV. It verifies the pairing secret exactly as the real TV is documented to, and only talks to paired client certificates.
import tls from 'node:tls';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import * as pb from '../../web/native/pb.js';
import { cat } from '../../web/native/bytes.js';

const strip = (b) => { let i = 0; while (i < b.length - 1 && b[i] === 0) i++; return b.subarray(i); };
const rsaOf = (der) => { const j = new crypto.X509Certificate(der).publicKey.export({ format: 'jwk' }); return { n: strip(Buffer.from(j.n, 'base64url')), e: strip(Buffer.from(j.e, 'base64url')) }; };
const padEven = (b) => b; // modulus/exponent are already whole bytes

export async function startAndroidTvMock({ pairPort = 16467, remotePort = 16466, requireCode = true, host = '127.0.0.1' } = {}) {
  const d = fs.mkdtempSync(path.join(os.tmpdir(), 'atv-'));
  execFileSync('openssl', ['req', '-x509', '-newkey', 'rsa:2048', '-nodes', '-keyout', d + '/k.pem', '-out', d + '/c.pem', '-subj', '/CN=mock-androidtv', '-days', '30'], { stdio: 'ignore' });
  const key = fs.readFileSync(d + '/k.pem'), cert = fs.readFileSync(d + '/c.pem');
  const serverDer = new crypto.X509Certificate(cert).raw;
  const st = { code: null, paired: new Set(), keys: [], texts: [], apps: [], pairLog: [], started: 0, pings: 0, lastIme: null };
  const fp = (raw) => crypto.createHash('sha256').update(raw).digest('hex');
  const outer = (inner, status = 200) => pb.frame(cat(pb.fVarint(1, 2), pb.fVarint(2, status), inner));

  const framer = (sock, onMsg) => { let buf = new Uint8Array(0); sock.on('data', (d2) => { buf = cat(buf, new Uint8Array(d2)); const [fr, rest] = pb.unframe(buf); buf = rest; fr.forEach(onMsg); }); };

  const pairing = tls.createServer({ key, cert, requestCert: true, rejectUnauthorized: false }, (sock) => {
    const clientRaw = sock.getPeerCertificate(true).raw;
    if (!clientRaw) return sock.destroy();
    let expect = null;
    sock.on('error', () => {});
    framer(sock, (raw) => {
      const m = pb.decode(raw);
      if (pb.field(m, 10)) { const r = pb.decode(pb.field(m, 10).v); st.pairLog.push('pairing_request ' + new TextDecoder().decode(pb.field(r, 1).v) + ' / ' + new TextDecoder().decode(pb.field(r, 2).v)); sock.write(outer(pb.fMsg(11, pb.fString(1, 'Mock TV')))); }
      else if (pb.field(m, 20)) { st.pairLog.push('options'); sock.write(outer(pb.fMsg(20, cat(pb.fMsg(1, cat(pb.fVarint(1, 3), pb.fVarint(2, 6))), pb.fVarint(3, 2))))); }
      else if (pb.field(m, 30)) {
        st.pairLog.push('configuration');
        // choose the code the way a real TV must: first byte of the hash == first two hex digits of the code
        const c = rsaOf(clientRaw), s = rsaOf(serverDer), tail = crypto.randomBytes(2);
        const h = crypto.createHash('sha256').update(c.n).update(c.e.length % 2 ? c.e : c.e).update(s.n).update(s.e).update(tail).digest();
        st.code = (h.subarray(0, 1).toString('hex') + tail.toString('hex')).toUpperCase(); expect = h;
        sock.write(outer(pb.fMsg(31, new Uint8Array(0))));
      } else if (pb.field(m, 40)) {
        const sec = Buffer.from(pb.field(pb.decode(pb.field(m, 40).v), 1).v);
        if (expect && Buffer.compare(sec, expect) === 0) { st.paired.add(fp(clientRaw)); st.pairLog.push('secret ok'); sock.write(outer(pb.fMsg(41, pb.fBytes(1, sec)))); }
        else { st.pairLog.push('secret BAD'); sock.write(outer(new Uint8Array(0), 402)); sock.end(); }
      }
    });
  });

  const remote = tls.createServer({ key, cert, requestCert: true, rejectUnauthorized: false }, (sock) => {
    const raw = sock.getPeerCertificate(true).raw;
    sock.on('error', () => {});
    if (!raw || !st.paired.has(fp(raw))) { setTimeout(() => sock.destroy(), 60); return; }          // unknown client certificate -> hang up
    const send = (inner) => sock.write(pb.frame(inner));
    send(pb.fMsg(1, cat(pb.fVarint(1, 1 | 2 | 4 | 32 | 64 | 512 | 8), pb.fMsg(2, cat(pb.fString(1, 'MockTV'), pb.fString(2, 'Spin Mock'), pb.fVarint(3, 1), pb.fString(4, '1'), pb.fString(5, 'mock.tv'), pb.fString(6, '1.0'))))));
    framer(sock, (frm) => {
      const m = pb.decode(frm), f = m[0]; if (!f) return;
      if (f.f === 1) { st.cfg = pb.field(pb.decode(f.v), 1).v; send(pb.fMsg(2, pb.fVarint(1, 622))); }
      else if (f.f === 2) { st.started++; send(pb.fMsg(40, pb.fVarint(1, 1))); send(pb.fMsg(21, cat(pb.fVarint(1, 7), pb.fVarint(2, 9)))); send(pb.fMsg(8, pb.fVarint(1, 1))); }
      else if (f.f === 9) st.pings++;
      else if (f.f === 10) { const k = pb.decode(f.v); st.keys.push({ code: pb.field(k, 1).v, dir: pb.field(k, 2).v, t: Date.now() }); if (pb.field(k, 1).v === 84 && st.searchBox !== false) setTimeout(() => send(pb.fMsg(22, pb.fVarint(1, 1))), 30); }   // the search key opens a text field on the TV: it tells the phone (remote_ime_show_request)
      else if (f.f === 21) { const b = pb.decode(f.v); const info = pb.decode(pb.field(b, 3).v); const obj = pb.decode(pb.field(info, 2).v); const text = new TextDecoder().decode(pb.field(obj, 3).v); st.texts.push(text); st.lastIme = { ime: pb.field(b, 1).v, field: pb.field(b, 2).v, start: (pb.field(obj, 1) || { v: 0 }).v, end: (pb.field(obj, 2) || { v: 0 }).v, insert: pb.field(info, 1).v }; }
      else if (f.f === 90) { const l = new TextDecoder().decode(pb.field(pb.decode(f.v), 1).v); st.apps.push(l); if (/GLOBAL_SEARCH/.test(l) && st.linkSearch) setTimeout(() => send(pb.fMsg(22, pb.fVarint(1, 1))), 30); }
    });
  });
  await new Promise((r) => pairing.listen(pairPort, host, r));
  await new Promise((r) => remote.listen(remotePort, host, r));
  void padEven; void requireCode;
  return { st, pairPort, remotePort, unpairAll: () => st.paired.clear(), close: () => { pairing.close(); remote.close(); pairing.closeAllConnections?.(); remote.closeAllConnections?.(); fs.rmSync(d, { recursive: true, force: true }); } };
}
