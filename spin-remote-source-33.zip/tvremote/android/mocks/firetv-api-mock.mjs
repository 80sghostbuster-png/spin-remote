import zlib from 'node:zlib';
// Mock of a real Fire TV's own remote service (what Amazon's Fire TV phone app talks to), modelled on public findings
// (hms-firetv README/LightningClient.cpp/DiscoveryService.cpp, debloat-fire-stick tools/firetv.py, FireTVRest, HA forum, uc-intg-firetv):
//  - DIAL: POST /apps/FireTVRemote on the dial port (8009) starts the service → 201 Created. GET → 200 app status. Answers while asleep.
//  - DIAL description: GET /dd.xml on 60000 → 200 with "Application-URL: http://<ip>:<dial>/apps/" header and a <UDN>. Answers while asleep.
//  - The HTTPS API (8080, self-signed) is CLOSED until woken and opens `startMs` later (real sticks ~1–4 s).
//  - X-Api-Key: 0987654321 required (401). pin/display {"friendlyName"} → PIN on screen; pin/verify {"pin"} → {"description": token}.
//  - Keys: POST /v1/FireTV?action=… and /v1/media?action=… need X-Client-Token (401), and must have NO body (a body → 500 NullPointerException).
//  - keep-alive connections are honoured. `noLength` = answers without Content-Length (read until close).
import http from 'node:http';
import https from 'node:https';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { execFileSync } from 'node:child_process';

export async function startFireApiMock({ host = '127.0.0.1', dialPort = 18009, apiPort = 18080, ddPort = 0, appUrlPort = 0, startMs = 2000, pin = '4821', awake = false, noLength = false, displayHang = false, verifyHang = false, verifyStatus = 0, displayStatus = 200, noDial = false, refuse = [], noSearchApp = false, mediaBody = 'none', errorBody200 = [], strict = false, volumeSupported = true, volume = null, gzip = false } = {}) {
  // build 33: volume = { level, muted, needs: 'tap'|'hold'|'downup'|'none', report: true|false, where: 'status'|'properties' } — a TV whose
  //          volume only really moves for one press form (and that may or may not report its volume). gzip = answer gzip when asked.
  // build 30: strict = behave exactly like the spec read from the official app (docs/FIRETV-PROTOCOL.md): every request needs an
  //          x-amzn-request-id, and scan only takes the {"direction","durationInSeconds","speed"} body (the query form is refused).
  // build 29: mediaBody 'none' = media actions must be body-less (like the nav keys); 'required' = this model only accepts the {"keyAction":…} body form.
  //          errorBody200 = action names this TV answers with HTTP 200 + an error description (not a real success).
  // build 28: `refuse` = action/endpoint names this TV model answers with 500 (e.g. ['mute'], ['volume_up','volume_down','mute','volume_mute'], ['text'])
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ftvapi-'));
  execFileSync('openssl', ['req', '-x509', '-newkey', 'rsa:2048', '-nodes', '-keyout', dir + '/k.pem', '-out', dir + '/c.pem', '-subj', '/CN=FireTV', '-days', '30'], { stdio: 'ignore' });
  const st = { vol: volume ? { level: volume.level ?? 10, muted: !!volume.muted } : null, volReqs: [], hdrs: [], rids: [], ctypes: [], texts: [], launched: [], wakes: 0, wakeVia: [], reqs: [], keys: [], uas: new Set(), shown: null, token: null, apiUp: false, conns: 0, ddReads: 0 };
  const send = (s, code, obj) => { const b = obj == null ? '' : JSON.stringify(obj);
    if (gzip && /gzip/.test(s.req.headers['accept-encoding'] || '')) { const z = zlib.gzipSync(b); s.writeHead(code, { 'Content-Type': 'application/json', 'Content-Encoding': 'gzip', 'Content-Length': z.length }); return s.end(z); }
    if (noLength) { const so = s.socket; so.write(`HTTP/1.1 ${code} X\r\nContent-Type: application/json\r\nConnection: close\r\n\r\n${b}`); so.end(); return; }
    s.writeHead(code, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(b) }); s.end(b); };
  const api = https.createServer({ key: fs.readFileSync(dir + '/k.pem'), cert: fs.readFileSync(dir + '/c.pem'), keepAliveTimeout: 30000 }, (q, s) => {
    let body = ''; q.on('data', (d) => (body += d)); q.on('end', () => {
      st.reqs.push(`${q.method} ${q.url}`); st.hdrs.push({ url: q.url, raw: q.rawHeaders.slice() }); if (q.headers['user-agent']) st.uas.add(q.headers['user-agent']);
      if (q.headers['x-api-key'] !== '0987654321') return send(s, 401, { description: 'bad key' });
      st.rids.push(q.headers['x-amzn-request-id'] || null); st.ctypes.push(q.headers['content-type'] || null);
      if (strict && !/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/.test(q.headers['x-amzn-request-id'] || '')) return send(s, 400, { description: 'missing request id' });
      if (q.method === 'GET' && q.url === '/v1/FireTV' && st.token && q.headers['x-client-token'] === st.token) return send(s, 200, { isVolumeControlsSupported: volumeSupported, volumeCapabilityLevelOfSupport: volumeSupported ? 'FULL' : 'NONE', powerCapabilityLevelOfSupport: 'FULL' });   // build 32: device info
      if (q.method === 'GET' && (q.url === '/' || q.url === '/v1/FireTV')) return send(s, 404, { description: 'not found' });
      if (q.url === '/v1/FireTV/pin/display') { if (displayHang) return; let j = {}; try { j = JSON.parse(body); } catch (e) { /* */ } if (!j.friendlyName) return send(s, 400, { description: 'friendlyName' }); if (displayStatus !== 200) return send(s, displayStatus, { description: 'error' }); st.shown = pin; return send(s, 200, { description: 'OK' }); }
      if (q.url === '/v1/FireTV/pin/verify') { if (verifyHang) return; if (verifyStatus) return send(s, verifyStatus, { description: 'error' }); let j = {}; try { j = JSON.parse(body); } catch (e) { /* */ } if (st.shown && j.pin === st.shown) { st.token = 'Wj9PP8I'; return send(s, 200, { description: st.token }); } return send(s, 400, { description: '' }); }
      const authed = st.token && q.headers['x-client-token'] === st.token;
      if (volume && q.method === 'GET' && (q.url === '/v1/FireTV/status' || q.url === '/v1/FireTV/properties')) {
        if (!authed) return send(s, 401, { description: 'not paired' });
        const mine = (volume.where || 'status') === q.url.split('/').pop();
        return send(s, 200, volume.report !== false && mine ? { turnstileVersion: '1', osVersion: '8', volumeLevel: st.vol.level, isMuted: st.vol.muted } : { turnstileVersion: '1', osVersion: '8' });
      }
      if (volume && q.method === 'POST' && /^\/v1\/FireTV\?action=(volume_up|volume_down|mute)$/.test(q.url)) {
        if (!authed) return send(s, 401, { description: 'not paired' });
        const name = q.url.split('action=')[1]; let jb = null; try { jb = body.length ? JSON.parse(body) : null; } catch (e) { return send(s, 400, { description: 'json' }); }
        const kind = !jb ? 'tap' : jb.keyActionType === 'keyDown' ? 'hold' : jb.keyActionType === 'keyDownUp' ? 'downup' : jb.keyActionType === 'keyUp' ? 'up' : 'bad';
        if (kind === 'bad') return send(s, 400, { description: 'keyActionType' });
        st.volReqs.push(`${name} ${kind}`);
        if (kind === volume.needs) { if (name === 'mute') st.vol.muted = !st.vol.muted; else st.vol.level = Math.max(0, Math.min(100, st.vol.level + (name === 'volume_up' ? 1 : -1))); }
        return send(s, 200, { description: 'OK' });   // like the real TV: always "OK", whether or not anything happened
      }
      if (q.url.startsWith('/v1/FireTV?action=') || q.url.startsWith('/v1/media?action=')) {
        if (!authed) return send(s, 401, { description: 'not paired' });
        const a = q.url.split('action=')[1], name = a.split('&')[0], media = q.url.startsWith('/v1/media');
        let jb = null; try { jb = body.length ? JSON.parse(body) : null; } catch (e) { /* */ }
        if (media && mediaBody === 'required' && !(jb && jb.keyAction)) return send(s, 500, { description: 'java.lang.NullPointerException' });
        const scanBody = media && name === 'scan' && jb && /^(back|forward)$/.test(jb.direction) && jb.durationInSeconds === '10' && jb.speed === '1';
        if (strict && name === 'scan' && !scanBody) return send(s, 400, { description: 'scan needs direction/durationInSeconds/speed' });
        if (body.length && !(media && jb && (jb.keyAction || scanBody))) return send(s, 500, { description: 'java.lang.NullPointerException' });
        if (errorBody200.includes(name)) return send(s, 200, { description: 'Error: no media session' });
        const label = jb && jb.direction ? `${a}&direction=${jb.direction}` : a;
        if (refuse.includes(name)) return send(s, 500, { description: 'unsupported' });
        if (name === 'scan' && !/&direction=(forward|back)$/.test(label)) return send(s, 400, { description: 'direction' });
        st.keys.push(label + (jb && jb.keyAction ? ' +body' : '')); return send(s, 200, { description: 'OK' });
      }
      if (q.method === 'POST' && (q.url === '/v1/FireTV/text' || q.url === '/v1/FireTV/keyboard')) {
        if (!authed) return send(s, 401, { description: 'not paired' });
        const ep = q.url.split('/').pop(); if (refuse.includes(ep)) return send(s, 500, { description: 'unsupported' });
        let j = {}; try { j = JSON.parse(body); } catch (e) { /* */ } if (typeof j.text !== 'string') return send(s, 400, { description: 'text' });
        st.texts.push({ ep, text: j.text, screen: st.launched[st.launched.length - 1] || null }); return send(s, 200, { description: 'OK' });
      }
      if (q.method === 'GET' && q.url === '/v1/FireTV/appsV2') {
        if (!authed) return send(s, 401, { description: 'not paired' });
        const apps = [{ appId: 'com.netflix.ninja', name: 'Netflix' }, { appId: 'com.amazon.firebat', name: 'Prime Video' }];
        if (!noSearchApp) apps.push({ appId: 'com.amazon.tv.searchapp', name: 'Search' });
        return send(s, 200, apps);
      }
      if (q.method === 'POST' && q.url.startsWith('/v1/FireTV/app/')) {
        if (!authed) return send(s, 401, { description: 'not paired' });
        st.launched.push(q.url.slice('/v1/FireTV/app/'.length)); return send(s, 200, { description: 'OK' });
      }
      send(s, 404, { description: 'not found' });
    });
  });
  api.on('secureConnection', () => st.conns++);
  const bringUp = () => new Promise((r) => { if (st.apiUp) return r(); st.apiUp = true; api.listen(apiPort, host, r); });
  if (awake) await bringUp();
  const wakeHandler = (q, s, via) => { q.resume(); q.on('end', () => {
    if (q.method === 'POST' && /\/apps\/FireTVRemote$/.test(q.url)) { st.wakes++; st.wakeVia.push(via); setTimeout(bringUp, startMs); s.writeHead(201, { LOCATION: `http://${host}:${via}/apps/FireTVRemote/run`, 'Content-Length': 0 }); return s.end(); }
    if (q.method === 'GET' && /\/apps\/FireTVRemote$/.test(q.url)) { const b = '<service xmlns="urn:dial-multiscreen-org:schemas:dial"><name>FireTVRemote</name><state>stopped</state></service>'; s.writeHead(200, { 'Content-Length': b.length }); return s.end(b); }
    s.writeHead(404, { 'Content-Length': 0 }); s.end(); }); };
  const servers = [];
  if (!noDial) { const d = http.createServer((q, s) => wakeHandler(q, s, dialPort)); await new Promise((r) => d.listen(dialPort, host, r)); servers.push(d); }
  if (appUrlPort) { const d = http.createServer((q, s) => wakeHandler(q, s, appUrlPort)); await new Promise((r) => d.listen(appUrlPort, host, r)); servers.push(d); }
  if (ddPort) { const d = http.createServer((q, s) => { q.resume(); st.ddReads++; const b = '<root><device><UDN>uuid:fire-mock</UDN><friendlyName>Fire TV</friendlyName></device></root>'; s.writeHead(200, { 'Application-URL': `http://${host}:${appUrlPort || dialPort}/apps/`, 'Content-Type': 'text/xml', 'Content-Length': b.length }); s.end(b); }); await new Promise((r) => d.listen(ddPort, host, r)); servers.push(d); }
  return { st, close() { for (const d of servers) { try { d.close(); d.closeAllConnections && d.closeAllConnections(); } catch (e) { /* */ } } try { api.close(); api.closeAllConnections && api.closeAllConnections(); } catch (e) { /* */ } } };
}
