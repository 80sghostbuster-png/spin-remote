// SELF-WRITTEN strict Roku ECP server on a raw socket. It checks the request the way a picky HTTP server would, so a malformed request is *refused* here instead of being forgiven by Node's lenient parser:
//   request line "METHOD /path HTTP/1.1" · a Host header holding an IP[:port] · a POST must carry Content-Length: 0 (no body) · no pipelining (a 2nd request before the reply to the 1st is refused) · header lines "Name: value".
// Modes: limited (Settings → Control by mobile apps → Limited: /keypress answers 403, queries are fine) · forbiddenAll (everything 403).
import net from 'node:net';
import crypto from 'node:crypto';
const WS_KEY = 'F3A278B8-1C6F-44A9-9D89-F1979CA4C6F1';
export async function startStrictRoku({ port = 18400, host = '127.0.0.1', kind = 'tv', limited = false, forbiddenAll = false, volumeOk = false, ws = true, version = '12.5.5', searchStyle = 'both', wsRawLit = false, wsNoLit = false, searchBlocked = null, keyStatus = 0 } = {}) {
  const st = { raw: [], bad: [], keys: [], searches: [], searchRaw: [], conns: 0, kind, wsKeys: [], wsBad: [], wsAuth: 0, wsOpen: 0 };
  const info = `<?xml version="1.0" encoding="UTF-8" ?><device-info><udn>strict-1</udn><user-device-name>Strict Roku</user-device-name><model-name>Mock</model-name><serial-number>S1</serial-number><device-id>D1</device-id><is-tv>${kind === 'tv'}</is-tv><is-stick>${kind === 'stick'}</is-stick><power-mode>PowerOn</power-mode><software-version>${version}</software-version>${limited ? "<ecp-setting-mode>limited</ecp-setting-mode>" : "<ecp-setting-mode>enabled</ecp-setting-mode>"}</device-info>`;
  const server = net.createServer((s) => {
    st.conns++; let buf = Buffer.alloc(0), busy = false;
    const reply = (code, text, body = '', extra = '') => { s.write(`HTTP/1.1 ${code} ${text}\r\nContent-Length: ${Buffer.byteLength(body)}\r\nServer: Roku/12.5.0 UPnP/1.0\r\n${extra}\r\n${body}`); busy = false; };
    s.on('error', () => {});
    s.on('data', (d) => {
      buf = Buffer.concat([buf, d]);
      for (;;) {
        const i = buf.indexOf('\r\n\r\n'); if (i < 0) return;
        const head = buf.subarray(0, i).toString('latin1'); const lines = head.split('\r\n'); const raw = head; st.raw.push(raw);
        const m = /^(GET|POST) (\/\S*) HTTP\/1\.1$/.exec(lines[0]);
        const H = {}; let hdrOk = true; for (const l of lines.slice(1)) { const k = /^([A-Za-z0-9-]+):[ \t]*(.*)$/.exec(l); if (!k) { hdrOk = false; break; } H[k[1].toLowerCase()] = k[2]; }
        const cl = H['content-length'] != null ? +H['content-length'] : 0; let bodyLen = cl; if (buf.length < i + 4 + bodyLen) return;
        const why = !m ? 'bad request line' : !hdrOk ? 'bad header line' : !H.host || !/^\d{1,3}(\.\d{1,3}){3}(:\d+)?$/.test(H.host) ? 'missing/odd Host header' : (m[1] === 'POST' && (H['content-length'] == null || cl !== 0)) ? 'POST without Content-Length: 0' : busy ? 'pipelined request' : /transfer-encoding/i.test(head) ? 'chunked request' : '';
        buf = buf.subarray(i + 4 + bodyLen); busy = true;
        if (why) { st.bad.push(why + ' :: ' + lines[0]); reply(400, 'Bad Request', '', 'Connection: close\r\n'); s.end(); return; }
        if (ws && m && m[1] === 'GET' && m[2] === '/ecp-session' && /upgrade/i.test(H.connection || '') && /websocket/i.test(H.upgrade || '')) {   // the Roku phone-app channel
          if (H['sec-websocket-protocol'] !== 'ecp-2' || !H['sec-websocket-key'] || H['sec-websocket-version'] !== '13') { st.wsBad.push('bad upgrade headers'); reply(400, 'Bad Request', '', 'Connection: close\r\n'); s.end(); return; }
          st.wsOpen++;
          const acc = crypto.createHash('sha1').update(H['sec-websocket-key'] + '258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64');
          s.write(`HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ${acc}\r\nSec-WebSocket-Protocol: ecp-2\r\n\r\n`);
          const send = (o) => { const b = Buffer.from(JSON.stringify(o)); const h = b.length < 126 ? Buffer.from([0x81, b.length]) : Buffer.from([0x81, 126, b.length >> 8, b.length & 255]); s.write(Buffer.concat([h, b])); };
          const challenge = crypto.randomBytes(16).toString('base64'); let authed = false, wbuf = buf; buf = Buffer.alloc(0);
          send({ notify: 'authenticate', 'param-challenge': challenge, timestamp: '1.0' });
          const pump = () => {
            for (;;) {
              if (wbuf.length < 2) return; const op = wbuf[0] & 15; let len = wbuf[1] & 127, i = 2, masked = !!(wbuf[1] & 128);
              if (len === 126) { if (wbuf.length < 4) return; len = wbuf.readUInt16BE(2); i = 4; }
              if (!masked) { st.wsBad.push('unmasked client frame'); s.end(); return; }
              if (wbuf.length < i + 4 + len) return; const mk = wbuf.subarray(i, i + 4), pl = Buffer.from(wbuf.subarray(i + 4, i + 4 + len)); for (let k = 0; k < len; k++) pl[k] ^= mk[k & 3]; wbuf = wbuf.subarray(i + 4 + len);
              if (op === 8) { s.end(); return; } if (op === 9) { s.write(Buffer.concat([Buffer.from([0x8a, pl.length]), pl])); continue; } if (op !== 1) continue;
              let j; try { j = JSON.parse(pl.toString()); } catch { st.wsBad.push('not json'); continue; }
              if (j.request === 'authenticate') { const want = crypto.createHash('sha1').update(challenge + WS_KEY).digest('base64'); if (j['param-response'] === want) { authed = true; st.wsAuth++; send({ response: 'authenticate', 'response-id': j['request-id'], status: '200', 'status-msg': 'OK' }); } else send({ response: 'authenticate', 'response-id': j['request-id'], status: '401', 'status-msg': 'Unauthorized' }); }
              else if (!authed) send({ response: j.request, 'response-id': j['request-id'], status: '401', 'status-msg': 'Unauthorized' });
              else if (j.request === 'key-press' && /^Lit_/.test(j['param-key']) && (wsNoLit || (wsRawLit && /%/.test(j['param-key'])))) { st.wsBad.push('lit refused: ' + j['param-key']); send({ response: 'key-press', 'response-id': j['request-id'], status: '400', 'status-msg': 'Bad request' }); }
              else if (j.request === 'key-press') { send({ notify: 'noise', timestamp: '2.0' }); st.wsKeys.push(j['param-key']); send({ response: 'key-press', 'response-id': j['request-id'], status: '200', 'status-msg': 'OK' }); }
              else send({ response: j.request, 'response-id': j['request-id'], status: '400', 'status-msg': 'Bad request' });
            }
          };
          s.removeAllListeners('data'); s.on('data', (d) => { wbuf = Buffer.concat([wbuf, d]); pump(); }); pump(); return;
        }
        const close = /^close$/i.test(H.connection || '');
        const path = decodeURIComponent(m[2]);
        if (forbiddenAll) reply(403, 'Forbidden', '', close ? 'Connection: close\r\n' : '');
        else if (m[1] === 'GET' && path === '/query/device-info') reply(200, 'OK', info, 'Content-Type: text/xml; charset="UTF-8"\r\n' + (close ? 'Connection: close\r\n' : ''));
        else if (m[1] === 'GET' && path === '/query/apps') reply(200, 'OK', '<apps></apps>', close ? 'Connection: close\r\n' : '');
        else if (m[1] === 'POST' && path.startsWith('/keypress/')) { if (limited && !(volumeOk && /^Volume/.test(path.slice(10)))) reply(403, 'Forbidden', '', close ? 'Connection: close\r\n' : ''); else if (keyStatus) reply(keyStatus, 'Error', '', close ? 'Connection: close\r\n' : ''); else { st.keys.push(path.slice(10)); reply(200, 'OK', '', close ? 'Connection: close\r\n' : ''); } }
        else if (m[1] === 'POST' && m[2].startsWith('/search/browse')) {
          st.searchRaw.push(m[2]); const qs = m[2].split('?')[1] || '', first = qs.split('&')[0], eq = first.indexOf('='), name = decodeURIComponent(eq < 0 ? first : first.slice(0, eq)), val = eq < 0 ? '' : decodeURIComponent(first.slice(eq + 1));
          const legacy = name === 'keyword' && val !== '', title = name === 'title' && val !== '', style = legacy ? 'legacy' : title ? 'title' : 'modern';
          if (searchBlocked != null ? searchBlocked : limited) reply(403, 'Forbidden', '', close ? 'Connection: close\r\n' : '');
          else if (eq < 0) reply(404, 'Not Found', '', close ? 'Connection: close\r\n' : '');
          else if (searchStyle === 'none') reply(404, 'Not Found', '', close ? 'Connection: close\r\n' : '');
          else if (searchStyle === 'title' && style !== 'title') reply(404, 'Not Found', '', close ? 'Connection: close\r\n' : '');
          else if (searchStyle === 'legacy' && style !== 'legacy') reply(404, 'Not Found', '', close ? 'Connection: close\r\n' : '');
          else if (searchStyle === 'modern' && style === 'legacy') { st.searches.push({ style, q: 'keyword', literalKeyword: true }); reply(200, 'OK', '', close ? 'Connection: close\r\n' : ''); }   // what a Roku OS 12.5+ does with the old form: searches for the literal word "keyword"
          else { st.searches.push({ style, q: legacy || title ? val : name }); reply(200, 'OK', '', close ? 'Connection: close\r\n' : ''); }
        }
        else if (m[1] === 'POST' && (path.startsWith('/keydown/') || path.startsWith('/keyup/'))) reply(limited ? 403 : 200, limited ? 'Forbidden' : 'OK', '', close ? 'Connection: close\r\n' : '');
        else reply(404, 'Not Found', '', close ? 'Connection: close\r\n' : '');
        if (close) { s.end(); return; }
      }
    });
  });
  await new Promise((r) => server.listen(port, host, r));
  return { st, close: () => new Promise((r) => { server.close(r); server.closeAllConnections && server.closeAllConnections(); }) };
}
