package com.spinremote.app;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.math.BigInteger;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.Signature;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicInteger;
import javax.net.ssl.KeyManager;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509KeyManager;
import javax.net.ssl.X509TrustManager;

/**
 * Platform-independent networking primitives used by the TvNative Capacitor plugin (and by the JVM test bridge).
 * No Android classes in here on purpose, so the exact same code is exercised on the build box against the mock TVs.
 * All TV protocol logic lives in JavaScript; this is only sockets, TLS with a client certificate, HTTP, SSDP and key handling.
 */
public final class NetCore {
    private NetCore() {}

    public static final class Conn {
        final Socket sock; final InputStream in; byte[] peerCert; volatile boolean closed;
        Conn(Socket s) throws java.io.IOException { sock = s; in = s.getInputStream(); }
    }
    public static final class ReadResult { public byte[] data; public boolean closed, timeout; }
    public static final class HttpResult { public int status; public String body, statusLine; }
    public static final class SsdpHit { public String ip; public Map<String, String> headers = new LinkedHashMap<>(); }
    public static final class Identity { public String keyPkcs8, certDer, modulusHex, exponentHex; }

    private static final Map<Integer, Conn> CONNS = new ConcurrentHashMap<>();
    private static final AtomicInteger IDS = new AtomicInteger(1);
    private static final byte[] SHA1_PREFIX = hex("3021300906052b0e03021a05000414");

    static byte[] hex(String h) { byte[] o = new byte[h.length() / 2]; for (int i = 0; i < o.length; i++) o[i] = (byte) Integer.parseInt(h.substring(2 * i, 2 * i + 2), 16); return o; }
    static String toHex(byte[] b) { StringBuilder s = new StringBuilder(); for (byte x : b) s.append(String.format("%02x", x & 255)); return s.toString(); }
    static byte[] stripSign(byte[] b) { int i = 0; while (i < b.length - 1 && b[i] == 0) i++; return java.util.Arrays.copyOfRange(b, i, b.length); }

    /** Full, honest exception text for the UI / debug log: class, message and the chain of causes. */
    public static String describe(Throwable e) {
        StringBuilder b = new StringBuilder(); int n = 0;
        for (Throwable t = e; t != null && n < 4; t = t.getCause(), n++) {
            if (n > 0) b.append(" ← ");
            b.append(t.getClass().getName()); if (t.getMessage() != null) b.append(": ").append(t.getMessage());
        }
        return b.toString();
    }

    // ------------------------------------------------------------------ identity / signing
    public static Identity genIdentity(boolean withCert) throws Exception {
        KeyPairGenerator g = KeyPairGenerator.getInstance("RSA");
        g.initialize(2048);
        KeyPair kp = g.generateKeyPair();
        RSAPublicKey pub = (RSAPublicKey) kp.getPublic();
        Identity id = new Identity();
        id.keyPkcs8 = Base64.getEncoder().encodeToString(kp.getPrivate().getEncoded());
        id.modulusHex = toHex(stripSign(pub.getModulus().toByteArray()));
        String e = pub.getPublicExponent().toString(16); id.exponentHex = e;
        if (withCert) id.certDer = Base64.getEncoder().encodeToString(CertGen.selfSigned(kp, "atvremote"));
        return id;
    }

    private static PrivateKey privateKey(String pkcs8B64) throws Exception {
        return KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(Base64.getDecoder().decode(pkcs8B64)));
    }

    /** ADB AUTH: RSA-sign the 20-byte token as if it were already a SHA-1 digest (PKCS#1 v1.5 + SHA-1 DigestInfo). */
    public static byte[] rsaSignAdb(String pkcs8B64, byte[] token) throws Exception {
        byte[] data = new byte[SHA1_PREFIX.length + token.length];
        System.arraycopy(SHA1_PREFIX, 0, data, 0, SHA1_PREFIX.length);
        System.arraycopy(token, 0, data, SHA1_PREFIX.length, token.length);
        Signature s = Signature.getInstance("NONEwithRSA");
        s.initSign(privateKey(pkcs8B64));
        s.update(data);
        return s.sign();
    }

    // ------------------------------------------------------------------ TCP / TLS
    private static final class FixedKeyManager implements X509KeyManager {
        final PrivateKey key; final X509Certificate[] chain;
        FixedKeyManager(PrivateKey k, X509Certificate c) { key = k; chain = new X509Certificate[] {c}; }
        public String[] getClientAliases(String t, java.security.Principal[] i) { return new String[] {"c"}; }
        public String chooseClientAlias(String[] t, java.security.Principal[] i, Socket s) { return "c"; }
        public String[] getServerAliases(String t, java.security.Principal[] i) { return null; }
        public String chooseServerAlias(String t, java.security.Principal[] i, Socket s) { return null; }
        public X509Certificate[] getCertificateChain(String a) { return chain; }
        public PrivateKey getPrivateKey(String a) { return key; }
    }
    /** TVs present self-signed certificates, so the chain is not validated (pairing code / on-screen prompt is what authenticates the TV). */
    private static final class TrustAll implements X509TrustManager {
        public void checkClientTrusted(X509Certificate[] c, String a) {}
        public void checkServerTrusted(X509Certificate[] c, String a) {}
        public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
    }

    /** The Wi-Fi network, when known: sockets are bound to it explicitly (belt and braces on top of bindProcessToNetwork). */
    public interface SocketBinder { void bind(Socket s) throws Exception; }
    public static volatile SocketBinder binder;
    /** Called once after a connect timeout on a Wi-Fi-pinned socket: lets the plugin stop pinning (plain Android default routing, like any other app) so the connect can be retried. Returns true if it changed anything. */
    public static volatile java.util.function.BooleanSupplier unpin;
    public static volatile boolean unpinned;
    static final class SocketBinderInfo { static boolean bound() { return binder != null && !unpinned; } }
    public static Socket newSocket() {
        Socket s = new Socket();
        try { SocketBinder b = binder; if (b != null) b.bind(s); } catch (Throwable ignored) { }
        return s;
    }

    /** Build 22: force TLS 1.2 from the first try (a TV that accepts a TLS 1.3 handshake but then silently ignores the client certificate). */
    public static Map<String, String> open(String host, int port, boolean tls, String certDerB64, String keyPkcs8B64, int timeoutMs, boolean tls12) throws Exception {
        if (tls && tls12) return openOnce(host, port, tls, certDerB64, keyPkcs8B64, timeoutMs, true);
        return open(host, port, tls, certDerB64, keyPkcs8B64, timeoutMs);
    }
    public static Map<String, String> open(String host, int port, boolean tls, String certDerB64, String keyPkcs8B64, int timeoutMs) throws Exception {
        // Some TV TLS stacks only like TLS 1.2: if the first handshake fails (not a timeout), retry once with a fresh TCP connection pinned to 1.2.
        try { return openOnce(host, port, tls, certDerB64, keyPkcs8B64, timeoutMs, false); }
        catch (Exception e) {
            if (!tls || !String.valueOf(e.getMessage()).startsWith("TLS handshake failed")) throw e;
            try { return openOnce(host, port, tls, certDerB64, keyPkcs8B64, timeoutMs, true); }
            catch (Exception e2) { throw new Exception(e.getMessage() + " | retry with TLS 1.2 only: " + e2.getMessage()); }
        }
    }

    private static Map<String, String> openOnce(String host, int port, boolean tls, String certDerB64, String keyPkcs8B64, int timeoutMs, boolean tls12Only) throws Exception {
        Socket raw = newSocket(); boolean viaDefault = unpinned; final long tStart = System.currentTimeMillis(); long tTcp;
        try {
            try { raw.connect(new InetSocketAddress(host, port), timeoutMs); }
            catch (SocketTimeoutException te) {                // pinned to Wi-Fi and nothing answered: retry exactly like a plain app would (no pinning at all)
                try { raw.close(); } catch (Exception ignored) {}
                java.util.function.BooleanSupplier u = unpin;
                if (binder == null || u == null || !u.getAsBoolean()) throw te;
                raw = newSocket(); viaDefault = true;
                try { raw.connect(new InetSocketAddress(host, port), Math.min(timeoutMs, 5000)); }
                catch (SocketTimeoutException te2) { throw new SocketTimeoutException("no answer from the Wi-Fi-pinned socket nor from Android's default route"); }
            }
        } catch (java.net.ConnectException e) {
            try { raw.close(); } catch (Exception ignored) {}
            throw new Exception("TCP connect failed: refused / unreachable on " + host + ":" + port + " (" + describe(e) + ")");
        } catch (SocketTimeoutException e) {
            try { raw.close(); } catch (Exception ignored) {}
            throw new Exception("TCP connect failed: timed out connecting to " + host + ":" + port + " after " + timeoutMs + " ms" + (e.getMessage() != null && e.getMessage().startsWith("no answer from") ? " (" + e.getMessage() + ")" : ""));
        } catch (java.net.NoRouteToHostException | java.net.UnknownHostException e) {
            try { raw.close(); } catch (Exception ignored) {}
            throw new Exception("TCP connect failed: no route to " + host + ":" + port + " (" + describe(e) + ")");
        }
        tTcp = System.currentTimeMillis() - tStart;
        raw.setTcpNoDelay(true);
        raw.setKeepAlive(true);
        raw.setSoTimeout(timeoutMs);
        Conn c; byte[] peer = null; String tlsInfo = null;
        if (tls) {
            SSLSocket ssl = null;
            try {
                SSLContext ctx = SSLContext.getInstance(tls12Only ? "TLSv1.2" : "TLS");
                KeyManager[] km = null;
                if (certDerB64 != null && keyPkcs8B64 != null) {
                    X509Certificate cert = (X509Certificate) CertificateFactory.getInstance("X.509").generateCertificate(new java.io.ByteArrayInputStream(Base64.getDecoder().decode(certDerB64)));
                    km = new KeyManager[] {new FixedKeyManager(privateKey(keyPkcs8B64), cert)};
                }
                ctx.init(km, new TrustManager[] {new TrustAll()}, new java.security.SecureRandom());
                ssl = (SSLSocket) ctx.getSocketFactory().createSocket(raw, host, port, true);
                if (tls12Only) ssl.setEnabledProtocols(new String[] {"TLSv1.2"});
                ssl.startHandshake();
                Certificate[] pc = ssl.getSession().getPeerCertificates();
                peer = pc[0].getEncoded();
                tlsInfo = (viaDefault ? "[default route] " : "") + ssl.getSession().getProtocol() + " " + ssl.getSession().getCipherSuite() + (km != null ? " (client cert sent)" : " (no client cert)") + " [TCP " + tTcp + " ms, TLS " + (System.currentTimeMillis() - tStart - tTcp) + " ms" + (SocketBinderInfo.bound() ? ", Wi-Fi-bound" : ", default route") + "]";
            } catch (Exception e) {
                try { raw.close(); } catch (Exception ignored) {}
                if (e instanceof SocketTimeoutException) throw new Exception("TLS handshake timed out with " + host + ":" + port + " after " + timeoutMs + " ms (TCP connected fine)");
                throw new Exception("TLS handshake failed with " + host + ":" + port + " (TCP connected fine)" + (tls12Only ? " [TLS 1.2 only]" : "") + ": " + describe(e));
            }
            c = new Conn(ssl);
        } else c = new Conn(raw);
        c.peerCert = peer;
        int id = IDS.getAndIncrement();
        CONNS.put(id, c);
        Map<String, String> r = new HashMap<>();
        r.put("id", String.valueOf(id));
        if (peer != null) r.put("peerCert", Base64.getEncoder().encodeToString(peer));
        if (tlsInfo != null) r.put("tls", tlsInfo);
        return r;
    }

    private static Conn conn(int id) { Conn c = CONNS.get(id); if (c == null) throw new IllegalStateException("closed"); return c; }

    public static void write(int id, byte[] data) throws Exception {
        Conn c = conn(id);
        synchronized (c) { c.sock.getOutputStream().write(data); c.sock.getOutputStream().flush(); }
    }

    public static ReadResult read(int id, int timeoutMs) {
        ReadResult r = new ReadResult();
        Conn c = CONNS.get(id);
        if (c == null) { r.closed = true; return r; }
        try {
            c.sock.setSoTimeout(timeoutMs <= 0 ? 0 : timeoutMs);   // 0 = block until data or close (no read timeouts on a live TLS session)
            byte[] buf = new byte[16384];
            int n = c.in.read(buf);
            if (n < 0) { r.closed = true; close(id); }
            else r.data = java.util.Arrays.copyOf(buf, n);
        } catch (SocketTimeoutException e) { r.timeout = true; }
        catch (Exception e) { r.closed = true; close(id); }
        return r;
    }

    public static void close(int id) { Conn c = CONNS.remove(id); if (c != null) { c.closed = true; try { c.sock.close(); } catch (Exception ignored) {} } }
    public static void closeAll() { for (Integer id : new ArrayList<>(CONNS.keySet())) close(id); }

    // ------------------------------------------------------------------ HTTP
    public static HttpResult http(String method, String url, String body, int timeoutMs) throws Exception {
        HttpURLConnection h = (HttpURLConnection) new URL(url).openConnection();
        h.setConnectTimeout(timeoutMs); h.setReadTimeout(timeoutMs);
        h.setRequestMethod(method);
        h.setUseCaches(false);
        h.setRequestProperty("Connection", "close");        // TV web servers are tiny: never reuse a pooled connection the TV may already have dropped
        if (!"GET".equals(method)) {
            h.setDoOutput(true);
            byte[] b = body == null ? new byte[0] : body.getBytes(StandardCharsets.UTF_8);
            h.setFixedLengthStreamingMode(b.length);
            h.getOutputStream().write(b);
        }
        HttpResult r = new HttpResult();
        r.status = h.getResponseCode(); r.statusLine = h.getHeaderField(null);
        InputStream in = r.status >= 400 ? h.getErrorStream() : h.getInputStream();
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        if (in != null) { byte[] buf = new byte[8192]; int n; while ((n = in.read(buf)) > 0) o.write(buf, 0, n); in.close(); }
        r.body = new String(o.toByteArray(), StandardCharsets.UTF_8);
        h.disconnect();
        return r;
    }

    // ------------------------------------------------------------------ diagnostics
    /** Per port: "open", "refused" (the TV answered: port closed) or "timeout" (nothing came back: blocked / wrong network). Run in parallel. */
    public static List<String[]> probe(String host, int[] ports, int timeoutMs) throws Exception {
        ExecutorService ex = Executors.newFixedThreadPool(Math.max(1, ports.length));
        List<Future<String[]>> fs = new ArrayList<>();
        for (int port : ports) fs.add(ex.submit(() -> {
            long t0 = System.currentTimeMillis();
            try (Socket s = newSocket()) { s.connect(new InetSocketAddress(host, port), timeoutMs); return new String[] {String.valueOf(port), "open", String.valueOf(System.currentTimeMillis() - t0), ""}; }
            catch (SocketTimeoutException e) { return new String[] {String.valueOf(port), "timeout", String.valueOf(System.currentTimeMillis() - t0), "no answer in " + timeoutMs + " ms"}; }
            catch (java.net.ConnectException e) {
                String m = String.valueOf(e.getMessage()); boolean refused = m.contains("refused") || m.contains("ECONNREFUSED");
                return new String[] {String.valueOf(port), refused ? "refused" : "error", String.valueOf(System.currentTimeMillis() - t0), m};
            }
            catch (Exception e) { return new String[] {String.valueOf(port), "error", String.valueOf(System.currentTimeMillis() - t0), describe(e)}; }
        }));
        List<String[]> out = new ArrayList<>();
        for (Future<String[]> f : fs) out.add(f.get());
        ex.shutdownNow();
        return out;
    }

    /** ICMP/echo reachability as far as Java can tell (may be false on phones that forbid raw ping even though the host is up). */
    public static boolean ping(String host) { try { return InetAddress.getByName(host).isReachable(1500); } catch (Exception e) { return false; } }

    // ------------------------------------------------------------------ SSDP
    public static List<SsdpHit> ssdp(String st, int timeoutMs, String host, int port) throws Exception {
        String msg = "M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\nMAN: \"ssdp:discover\"\r\nMX: 2\r\nST: " + st + "\r\n\r\n";
        byte[] out = msg.getBytes(StandardCharsets.US_ASCII);
        InetAddress dest = InetAddress.getByName(host == null ? "239.255.255.250" : host);
        int dport = host == null ? 1900 : port;
        List<SsdpHit> hits = new ArrayList<>();
        try (DatagramSocket s = new DatagramSocket()) {
            long end = System.currentTimeMillis() + timeoutMs, nextSend = 0;
            byte[] buf = new byte[4096];
            while (System.currentTimeMillis() < end) {
                if (System.currentTimeMillis() >= nextSend) { s.send(new DatagramPacket(out, out.length, dest, dport)); nextSend = System.currentTimeMillis() + 400; }
                s.setSoTimeout((int) Math.max(1, Math.min(300, end - System.currentTimeMillis())));
                try {
                    DatagramPacket p = new DatagramPacket(buf, buf.length);
                    s.receive(p);
                    SsdpHit h = new SsdpHit(); h.ip = p.getAddress().getHostAddress();
                    String[] lines = new String(p.getData(), 0, p.getLength(), StandardCharsets.UTF_8).split("\r\n");
                    for (int i = 1; i < lines.length; i++) { int k = lines[i].indexOf(':'); if (k > 0) h.headers.put(lines[i].substring(0, k).trim().toLowerCase(), lines[i].substring(k + 1).trim()); }
                    hits.add(h);
                } catch (SocketTimeoutException ignored) {}
            }
        }
        return hits;
    }

    // ------------------------------------------------------------------ raw mDNS (works when Android's NsdManager refuses to run)
    public static final class MdnsHit { public String name, host, type; public int port; public Map<String, String> txt = new LinkedHashMap<>(); }

    private static byte[] dnsQuery(String name, int qtype) {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        o.write(0); o.write(0); o.write(0); o.write(0); o.write(0); o.write(1); o.write(0); o.write(0); o.write(0); o.write(0); o.write(0); o.write(0);   // id 0, flags 0, QD=1
        for (String l : name.split("\\.")) { if (l.isEmpty()) continue; byte[] b = l.getBytes(StandardCharsets.UTF_8); o.write(b.length); o.write(b, 0, b.length); }
        o.write(0); o.write(qtype >> 8); o.write(qtype & 255); o.write(0x80); o.write(1);   // class IN with the "unicast response" bit: answers come straight back to our port
        return o.toByteArray();
    }
    private static int u16(byte[] b, int p) { return ((b[p] & 255) << 8) | (b[p + 1] & 255); }
    private static String dnsName(byte[] m, int[] pos) {
        StringBuilder sb = new StringBuilder(); int p = pos[0]; boolean jumped = false; int guard = 0;
        while (guard++ < 64) {
            int l = m[p] & 255;
            if (l == 0) { p++; break; }
            if ((l & 0xC0) == 0xC0) { int ptr = ((l & 0x3F) << 8) | (m[p + 1] & 255); if (!jumped) pos[0] = p + 2; jumped = true; p = ptr; continue; }
            p++; sb.append(new String(m, p, l, StandardCharsets.UTF_8)).append('.'); p += l;
        }
        if (!jumped) pos[0] = p;
        return sb.toString();
    }

    /** One-shot mDNS browse for a service type like "_androidtvremote2._tcp." - PTR → SRV/TXT → A. host/port override the multicast group (tests). */
    public static List<MdnsHit> mdnsQuery(String type, int timeoutMs, String host, int port) throws Exception {
        String svc = type.endsWith(".") ? type + "local" : type + ".local";
        InetAddress dest = InetAddress.getByName(host == null ? "224.0.0.251" : host);
        int dport = host == null ? 5353 : port;
        Map<String, String> inst = new LinkedHashMap<>();            // instance FQDN → (unused)
        Map<String, Object[]> srv = new HashMap<>();                 // instance → {targetHost, port}
        Map<String, Map<String, String>> txts = new HashMap<>();
        Map<String, String> addr = new HashMap<>();                  // host → ipv4
        try (DatagramSocket s = new DatagramSocket()) {
            long end = System.currentTimeMillis() + timeoutMs, next = 0; byte[] buf = new byte[9000];
            while (System.currentTimeMillis() < end) {
                if (System.currentTimeMillis() >= next) {
                    List<byte[]> qs = new ArrayList<>(); qs.add(dnsQuery(svc, 12));
                    for (String i : inst.keySet()) if (!srv.containsKey(i)) { qs.add(dnsQuery(i, 33)); qs.add(dnsQuery(i, 16)); }
                    for (Object[] sv : srv.values()) if (!addr.containsKey(((String) sv[0]).toLowerCase())) qs.add(dnsQuery((String) sv[0], 1));
                    for (byte[] q : qs) s.send(new DatagramPacket(q, q.length, dest, dport));
                    next = System.currentTimeMillis() + 400;
                }
                s.setSoTimeout((int) Math.max(1, Math.min(250, end - System.currentTimeMillis())));
                try {
                    DatagramPacket p = new DatagramPacket(buf, buf.length); s.receive(p);
                    byte[] m = java.util.Arrays.copyOf(p.getData(), p.getLength());
                    try { parseMdns(m, svc, inst, srv, txts, addr); } catch (RuntimeException bad) { /* ignore malformed packet */ }
                } catch (SocketTimeoutException ignored) {}
                boolean complete = !inst.isEmpty(); for (String i : inst.keySet()) { Object[] sv = srv.get(i); if (sv == null || !addr.containsKey(((String) sv[0]).toLowerCase())) complete = false; }
                if (complete && System.currentTimeMillis() > end - timeoutMs + 350) break;
            }
        }
        List<MdnsHit> out = new ArrayList<>();
        for (String i : inst.keySet()) {
            Object[] sv = srv.get(i); if (sv == null) continue; String ip = addr.get(((String) sv[0]).toLowerCase()); if (ip == null) continue;
            MdnsHit h = new MdnsHit(); h.type = type; h.host = ip; h.port = (Integer) sv[1];
            h.name = i.endsWith("." + svc + ".") ? i.substring(0, i.length() - svc.length() - 2) : i;
            if (txts.containsKey(i)) h.txt.putAll(txts.get(i));
            out.add(h);
        }
        return out;
    }

    private static void parseMdns(byte[] m, String svc, Map<String, String> inst, Map<String, Object[]> srv, Map<String, Map<String, String>> txts, Map<String, String> addr) {
        int qd = u16(m, 4), an = u16(m, 6) + u16(m, 8) + u16(m, 10); int[] pos = {12};
        for (int i = 0; i < qd; i++) { dnsName(m, pos); pos[0] += 4; }
        for (int i = 0; i < an; i++) {
            String name = dnsName(m, pos); int type = u16(m, pos[0]), len = u16(m, pos[0] + 8), rd = pos[0] + 10; pos[0] = rd + len;
            String lname = name.toLowerCase();
            if (type == 12 && lname.equals(svc.toLowerCase() + ".")) { int[] q = {rd}; String t = dnsName(m, q); inst.put(t, ""); }
            else if (type == 33) { int[] q = {rd + 6}; String t = dnsName(m, q); srv.put(name, new Object[] {t, u16(m, rd + 4)}); }
            else if (type == 16) {
                Map<String, String> t = new LinkedHashMap<>(); int q = rd;
                while (q < rd + len) { int l = m[q] & 255; q++; if (l > 0) { String kv = new String(m, q, Math.min(l, rd + len - q), StandardCharsets.UTF_8); int e = kv.indexOf('='); if (e > 0) t.put(kv.substring(0, e), kv.substring(e + 1)); else t.put(kv, ""); } q += l; }
                txts.put(name, t);
            }
            else if (type == 1 && len == 4) addr.put(lname, (m[rd] & 255) + "." + (m[rd + 1] & 255) + "." + (m[rd + 2] & 255) + "." + (m[rd + 3] & 255));
        }
    }

    // ------------------------------------------------------------------ /24 sweep (fallback when multicast is blocked)
    /** Returns the /24 prefixes (e.g. "192.168.1.") of this phone's IPv4 addresses on non-loopback interfaces. */
    public static List<String> localPrefixes() throws Exception {
        List<String> out = new ArrayList<>();
        for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
            if (!ni.isUp() || ni.isLoopback() || ni.isVirtual()) continue;
            for (java.net.InterfaceAddress ia : ni.getInterfaceAddresses()) {
                InetAddress a = ia.getAddress();
                if (a instanceof java.net.Inet4Address && a.isSiteLocalAddress()) { String s = a.getHostAddress(); out.add(s.substring(0, s.lastIndexOf('.') + 1)); }
            }
        }
        return out;
    }

    /** Which hosts on the local /24 accept TCP on any of these ports? (explicitHosts, if given, replaces the sweep - used by tests). */
    public static List<String[]> tcpScan(int[] ports, int timeoutMs, List<String> explicitHosts) throws Exception { return tcpScan(ports, timeoutMs, explicitHosts, null); }

    /** prefixes (e.g. "192.168.1.") replace the interface lookup; explicitHosts replace both (tests). */
    public static List<String[]> tcpScan(int[] ports, int timeoutMs, List<String> explicitHosts, List<String> prefixes) throws Exception {
        List<String> hosts = new ArrayList<>();
        if (explicitHosts != null) hosts.addAll(explicitHosts);
        else for (String p : (prefixes != null && !prefixes.isEmpty() ? prefixes : localPrefixes())) for (int i = 1; i < 255; i++) hosts.add(p + i);
        ExecutorService ex = Executors.newFixedThreadPool(64);
        List<Future<String[]>> fs = new ArrayList<>();
        for (String h : hosts) for (int port : ports) fs.add(ex.submit(() -> {
            try (Socket s = newSocket()) { s.connect(new InetSocketAddress(h, port), timeoutMs); return new String[] {h, String.valueOf(port)}; }
            catch (Exception e) { return null; }
        }));
        List<String[]> out = new ArrayList<>();
        for (Future<String[]> f : fs) { String[] r = f.get(); if (r != null) out.add(r); }
        ex.shutdownNow();
        return out;
    }
}
