package com.spinremote.app;

import android.Manifest;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.LinkAddress;
import android.net.LinkProperties;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.os.Build;
import android.os.Bundle;
import android.content.Intent;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.util.Log;
import com.getcapacitor.PermissionState;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;
import java.util.concurrent.Semaphore;
import android.net.nsd.NsdManager;
import android.net.nsd.NsdServiceInfo;
import android.net.wifi.WifiManager;
import android.util.Base64;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * Thin native layer: sockets / TLS / HTTP / SSDP / mDNS. All TV protocol logic is JavaScript (web/native/*.js).
 * Heavy lifting lives in NetCore (platform independent, exercised on the build box); this class only adapts it to Capacitor
 * and adds the Android-only bits (MulticastLock, NsdManager).
 */
@CapacitorPlugin(name = "TvNative", permissions = {
    @Permission(alias = "nearby", strings = {"android.permission.NEARBY_WIFI_DEVICES"}),
    @Permission(alias = "localnet", strings = {"android.permission.ACCESS_LOCAL_NETWORK"}),
    @Permission(alias = "mic", strings = {"android.permission.RECORD_AUDIO"})
})
public class TvNativePlugin extends Plugin {
    private final ExecutorService pool = Executors.newCachedThreadPool();

    private interface Job { JSObject run() throws Exception; }

    // ---- network binding / permissions -------------------------------------------------------------------
    private volatile String bindInfo = "not bound yet";
    private volatile Network wifiNet;

    @Override
    public void load() {
        bindWifi();
        try {
            ConnectivityManager cm = (ConnectivityManager) getContext().getSystemService(Context.CONNECTIVITY_SERVICE);
            cm.registerNetworkCallback(new NetworkRequest.Builder().addTransportType(NetworkCapabilities.TRANSPORT_WIFI).build(), new ConnectivityManager.NetworkCallback() {
                @Override public void onAvailable(Network n) { bindWifi(); }
                @Override public void onLost(Network n) { bindWifi(); }
            });
        } catch (Throwable ignored) { }
    }

    /** TVs are on the Wi-Fi. With mobile data on, a socket must not be routed over the cellular network (or a VPN), so bind this process to the Wi-Fi network. */
    private volatile long pinOffUntil = 0;
    /** Stop pinning sockets/process to Wi-Fi (plain Android routing, like any ordinary app) for a few minutes. */
    private boolean unpinWifi() {
        try {
            ConnectivityManager cm = (ConnectivityManager) getContext().getSystemService(Context.CONNECTIVITY_SERVICE);
            pinOffUntil = System.currentTimeMillis() + 10 * 60_000L; cm.bindProcessToNetwork(null); NetCore.binder = null; NetCore.unpinned = true; wifiNet = null;
            bindInfo = "Wi-Fi pinning switched off after a timeout (plain Android routing)"; return true;
        } catch (Throwable t) { return false; }
    }

    private void bindWifi() {
        if (System.currentTimeMillis() < pinOffUntil) return;
        NetCore.unpinned = false; NetCore.unpin = this::unpinWifi;
        try {
            ConnectivityManager cm = (ConnectivityManager) getContext().getSystemService(Context.CONNECTIVITY_SERVICE);
            Network pick = null;
            for (Network n : cm.getAllNetworks()) {
                NetworkCapabilities c = cm.getNetworkCapabilities(n);
                if (c != null && (c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) || c.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) && !c.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) { pick = n; break; }
            }
            if (pick != null) { boolean ok = cm.bindProcessToNetwork(pick); wifiNet = pick; final Network pn = pick; NetCore.binder = (sk) -> pn.bindSocket(sk); bindInfo = ok ? "this app is bound to the Wi-Fi network" : "Android refused to bind the app to Wi-Fi"; }
            else { cm.bindProcessToNetwork(null); wifiNet = null; NetCore.binder = null; bindInfo = "no Wi-Fi network found (is Wi-Fi on?)"; }
        } catch (Throwable t) { bindInfo = "couldn’t bind to Wi-Fi: " + NetCore.describe(t); }
    }

    private String phoneIp(boolean prefix) {
        try {
            Network n = wifiNet; if (n == null) return null;
            LinkProperties lp = ((ConnectivityManager) getContext().getSystemService(Context.CONNECTIVITY_SERVICE)).getLinkProperties(n);
            if (lp == null) return null;
            for (LinkAddress la : lp.getLinkAddresses()) if (la.getAddress() instanceof java.net.Inet4Address) { String a = la.getAddress().getHostAddress(); return prefix ? a.substring(0, a.lastIndexOf('.') + 1) : a; }
        } catch (Throwable ignored) { }
        return null;
    }

    private String permState(String alias) { try { return getPermissionState(alias) == PermissionState.GRANTED ? "granted" : "not granted"; } catch (Throwable t) { return "unknown"; } }

    private JSObject prepInfo() {
        JSObject r = new JSObject();
        r.put("android", Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")"); r.put("device", Build.MANUFACTURER + " " + Build.MODEL);
        r.put("network", bindInfo); r.put("phoneIp", phoneIp(false));
        r.put("nearbyPermission", Build.VERSION.SDK_INT >= 33 ? permState("nearby") : "not needed");
        r.put("localNetworkPermission", Build.VERSION.SDK_INT >= 37 ? permState("localnet") : "not needed");
        return r;
    }

    /** Called by the JS before discovery / pairing: binds to Wi-Fi, asks for the nearby-devices / local-network permission where this Android version has one, and reports the state. */
    @PluginMethod
    public void prepare(PluginCall call) {
        bindWifi();
        java.util.List<String> need = new java.util.ArrayList<>();
        try {
            if (Build.VERSION.SDK_INT >= 33 && getPermissionState("nearby") != PermissionState.GRANTED) need.add("nearby");
            if (Build.VERSION.SDK_INT >= 37 && getPermissionState("localnet") != PermissionState.GRANTED) need.add("localnet");
        } catch (Throwable ignored) { }
        if (!need.isEmpty() && getActivity() != null && !call.getBoolean("noPrompt", false)) requestPermissionForAliases(need.toArray(new String[0]), call, "prepareDone");
        else call.resolve(prepInfo());
    }

    @PermissionCallback
    private void prepareDone(PluginCall call) { bindWifi(); call.resolve(prepInfo()); }

    @PluginMethod
    public void probe(PluginCall call) {
        final String host = call.getString("host"); final JSArray ports = call.getArray("ports"); final int ms = call.getInt("timeoutMs", 2500);
        async(call, () -> {
            int[] p = new int[ports.length()]; for (int i = 0; i < p.length; i++) p[i] = ports.getInt(i);
            JSArray arr = new JSArray();
            for (String[] r : NetCore.probe(host, p, ms)) { JSObject o = new JSObject(); o.put("port", Integer.parseInt(r[0])); o.put("state", r[1]); o.put("ms", Integer.parseInt(r[2])); o.put("detail", r[3]); arr.put(o); }
            JSObject r = new JSObject(); r.put("results", arr); r.put("ping", NetCore.ping(host)); return r;
        });
    }

    private void async(PluginCall call, Job job) {
        pool.execute(() -> {
            try { call.resolve(job.run()); }
            catch (Throwable e) { call.reject(e instanceof java.io.IOException || (e.getMessage() != null && e.getCause() == null) ? (e.getMessage() == null ? NetCore.describe(e) : e.getMessage()) : NetCore.describe(e)); }
        });
    }

    private static byte[] b64(String s) { return Base64.decode(s, Base64.NO_WRAP); }
    private static String b64(byte[] b) { return Base64.encodeToString(b, Base64.NO_WRAP); }

    @PluginMethod
    public void ssdp(PluginCall call) {
        final String st = call.getString("st", "ssdp:all");
        final int ms = call.getInt("timeoutMs", 2500);
        final JSObject target = call.getObject("target");
        async(call, () -> {
            WifiManager wm = (WifiManager) getContext().getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            WifiManager.MulticastLock lock = wm.createMulticastLock("spinremote-ssdp");
            lock.setReferenceCounted(false);
            lock.acquire();
            try {
                List<NetCore.SsdpHit> hits = NetCore.ssdp(st, ms, target == null ? null : target.getString("host"), target == null ? 0 : target.getInteger("port", 1900));
                JSArray arr = new JSArray();
                for (NetCore.SsdpHit h : hits) {
                    JSObject o = new JSObject(); o.put("ip", h.ip);
                    JSObject hh = new JSObject(); for (Map.Entry<String, String> e : h.headers.entrySet()) hh.put(e.getKey(), e.getValue());
                    o.put("headers", hh); arr.put(o);
                }
                JSObject r = new JSObject(); r.put("results", arr); return r;
            } finally { lock.release(); }
        });
    }

    private final Semaphore nsdLock = new Semaphore(1);   // Android allows only a few NSD operations at once: run exactly one at a time, always stop it

    private static String nsdErr(int c) {
        switch (c) { case 0: return "internal error"; case 3: return "already active"; case 4: return "too many requests (max limit)"; case 5: return "operation not running"; case 6: return "bad parameters"; default: return "code " + c; }
    }

    @PluginMethod
    public void mdns(PluginCall call) {
        final String type = call.getString("type");
        final int ms = call.getInt("timeoutMs", 3000);
        async(call, () -> {
            JSArray log = new JSArray();
            // Build 23: ask the network directly FIRST. It needs no NSD slot, so several service types run at the same time, and it stops as soon
            // as every TV that answered is complete (well under a second on a normal Wi-Fi). Android NSD is only the fallback.
            {
                WifiManager wm0 = (WifiManager) getContext().getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                WifiManager.MulticastLock l0 = wm0.createMulticastLock("spinremote-mdns-" + type); l0.setReferenceCounted(false); l0.acquire();
                try {
                    JSArray arr = new JSArray();
                    for (NetCore.MdnsHit h : NetCore.mdnsQuery(type, Math.min(ms, 1500), null, 0)) {
                        JSObject o = new JSObject(); o.put("type", type); o.put("name", h.name); o.put("host", h.host); o.put("port", h.port);
                        JSObject txt = new JSObject(); for (Map.Entry<String, String> e : h.txt.entrySet()) txt.put(e.getKey(), e.getValue()); o.put("txt", txt); arr.put(o);
                    }
                    log.put("direct mDNS query for " + type + ": " + arr.length() + " answer(s)");
                    if (arr.length() > 0) { JSObject r = new JSObject(); r.put("results", arr); r.put("log", log); r.put("via", "raw"); return r; }
                } catch (Exception e) { log.put("direct mDNS query failed: " + NetCore.describe(e)); }
                finally { l0.release(); }
            }
            if (!nsdLock.tryAcquire(15, TimeUnit.SECONDS)) throw new Exception("another network search is still running");
            WifiManager wm = (WifiManager) getContext().getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            WifiManager.MulticastLock lock = wm.createMulticastLock("spinremote-mdns"); lock.setReferenceCounted(false); lock.acquire();
            try {
                JSArray arr = new JSArray(); String nsdFail = null; String via = "nsd";
                try { nsdDiscover(type, Math.min(ms, 1500), arr, log); } catch (Exception e) { nsdFail = e.getMessage(); log.put("Android NSD: " + nsdFail); }
                if (arr.length() == 0) {                   // NSD found nothing (or refused to run): ask the network directly
                    String rawFail = null;
                    try {
                        for (NetCore.MdnsHit h : NetCore.mdnsQuery(type, Math.min(ms, 2500), null, 0)) {
                            JSObject o = new JSObject(); o.put("type", type); o.put("name", h.name); o.put("host", h.host); o.put("port", h.port);
                            JSObject txt = new JSObject(); for (Map.Entry<String, String> e : h.txt.entrySet()) txt.put(e.getKey(), e.getValue()); o.put("txt", txt); arr.put(o);
                        }
                        log.put("direct mDNS query for " + type + ": " + arr.length() + " answer(s)"); via = "raw";
                    } catch (Exception e) { rawFail = NetCore.describe(e); log.put("direct mDNS query failed: " + rawFail); }
                    if (arr.length() == 0 && nsdFail != null) throw new Exception("Android NSD failed (" + nsdFail + ")" + (rawFail != null ? "; direct mDNS failed (" + rawFail + ")" : "; direct mDNS got no answer"));
                }
                JSObject r = new JSObject(); r.put("results", arr); r.put("log", log); r.put("via", via); return r;
            } finally { lock.release(); nsdLock.release(); }
        });
    }

    /** One NSD browse: start (retry once), wait, STOP and wait for the stop, then resolve results one by one. */
    private void nsdDiscover(String type, int ms, JSArray out, JSArray log) throws Exception {
        NsdManager nsd = (NsdManager) getContext().getSystemService(Context.NSD_SERVICE);
        final List<NsdServiceInfo> found = Collections.synchronizedList(new ArrayList<>());
        int lastErr = -1;
        for (int attempt = 0; attempt < 2; attempt++) {
            final CountDownLatch started = new CountDownLatch(1), stopped = new CountDownLatch(1);
            final java.util.concurrent.atomic.AtomicInteger startErr = new java.util.concurrent.atomic.AtomicInteger(-1);
            NsdManager.DiscoveryListener l = new NsdManager.DiscoveryListener() {
                public void onStartDiscoveryFailed(String t, int c) { startErr.set(c); started.countDown(); stopped.countDown(); }
                public void onStopDiscoveryFailed(String t, int c) { stopped.countDown(); }
                public void onDiscoveryStarted(String t) { started.countDown(); }
                public void onDiscoveryStopped(String t) { stopped.countDown(); }
                public void onServiceFound(NsdServiceInfo i) { found.add(i); }
                public void onServiceLost(NsdServiceInfo i) {}
            };
            try { nsd.discoverServices(type, NsdManager.PROTOCOL_DNS_SD, l); }
            catch (Exception e) { throw new Exception("discoverServices threw " + NetCore.describe(e)); }
            started.await(3, TimeUnit.SECONDS);
            if (startErr.get() >= 0) { lastErr = startErr.get(); log.put("NSD start failed for " + type + ": error " + lastErr + " (" + nsdErr(lastErr) + ")" + (attempt == 0 ? " – retrying" : "")); Thread.sleep(400); continue; }
            try { Thread.sleep(ms); } catch (InterruptedException ignored) {}
            try { nsd.stopServiceDiscovery(l); stopped.await(2, TimeUnit.SECONDS); } catch (Exception ignored) {}
            lastErr = -1; break;
        }
        if (lastErr >= 0) throw new Exception("NSD failed to start for " + type + " (error " + lastErr + ", " + nsdErr(lastErr) + ")");
        List<NsdServiceInfo> copy; synchronized (found) { copy = new ArrayList<>(found); }
        log.put("NSD found " + copy.size() + " service(s) of " + type);
        for (NsdServiceInfo f : copy) {              // resolve one at a time (NsdManager allows a single active resolve)
            NsdServiceInfo got = null;
            for (int tries = 0; tries < 3 && got == null; tries++) {
                final CountDownLatch done = new CountDownLatch(1); final NsdServiceInfo[] res = new NsdServiceInfo[1]; final int[] rerr = {-1};
                try {
                    nsd.resolveService(f, new NsdManager.ResolveListener() {
                        public void onResolveFailed(NsdServiceInfo i, int c) { rerr[0] = c; done.countDown(); }
                        public void onServiceResolved(NsdServiceInfo i) { res[0] = i; done.countDown(); }
                    });
                } catch (Exception e) { log.put("NSD resolve threw " + NetCore.describe(e)); break; }
                done.await(2500, TimeUnit.MILLISECONDS);
                got = res[0];
                if (got == null) { if (rerr[0] >= 0) log.put("NSD resolve of " + f.getServiceName() + " failed: error " + rerr[0] + " (" + nsdErr(rerr[0]) + ")"); Thread.sleep(250); }
            }
            if (got == null || got.getHost() == null) continue;
            String host = got.getHost().getHostAddress(); int pct = host.indexOf('%'); if (pct > 0) host = host.substring(0, pct);
            if (host.contains(":") && Build.VERSION.SDK_INT >= 34) {       // API 34+: the service can list several addresses: take its IPv4 one
                try { for (java.net.InetAddress ia : got.getHostAddresses()) if (ia instanceof java.net.Inet4Address) { host = ia.getHostAddress(); break; } } catch (Throwable ignored) { }
            }
            if (host.contains(":")) continue;        // IPv6 only → not usable by the protocols here
            JSArray hosts = new JSArray(); hosts.put(host);  // build 21: every IPv4 address the service advertises (a TV on two interfaces / mesh)
            if (Build.VERSION.SDK_INT >= 34) { try { for (java.net.InetAddress ia : got.getHostAddresses()) if (ia instanceof java.net.Inet4Address && !ia.getHostAddress().equals(host)) hosts.put(ia.getHostAddress()); for (java.net.InetAddress ia : got.getHostAddresses()) if (ia instanceof java.net.Inet6Address) hosts.put(ia.getHostAddress()); } catch (Throwable ignored) { } }   // IPv4 first, then IPv6 (with its %interface)
            JSObject o = new JSObject(); o.put("type", type); o.put("name", got.getServiceName()); o.put("host", host); o.put("hosts", hosts); o.put("port", got.getPort());
            JSObject txt = new JSObject();
            for (Map.Entry<String, byte[]> e : got.getAttributes().entrySet()) txt.put(e.getKey(), e.getValue() == null ? "" : new String(e.getValue(), java.nio.charset.StandardCharsets.UTF_8));
            o.put("txt", txt); out.put(o);
        }
    }

    @PluginMethod
    public void tcpScan(PluginCall call) {
        final JSArray ports = call.getArray("ports");
        final int ms = call.getInt("timeoutMs", 500);
        async(call, () -> {
            int[] p = new int[ports.length()]; for (int i = 0; i < p.length; i++) p[i] = ports.getInt(i);
            List<String> pre = new ArrayList<>(); String wp = phoneIp(true); if (wp != null) pre.add(wp); else pre.addAll(NetCore.localPrefixes());
            JSArray arr = new JSArray();
            for (String[] h : NetCore.tcpScan(p, ms, null, pre)) { JSObject o = new JSObject(); o.put("host", h[0]); o.put("port", Integer.parseInt(h[1])); arr.put(o); }
            JSArray pa = new JSArray(); for (String x : pre) pa.put(x + "x");
            JSObject r = new JSObject(); r.put("results", arr); r.put("prefixes", pa); return r;
        });
    }

    @PluginMethod
    public void http(PluginCall call) {
        final String method = call.getString("method", "GET"), url = call.getString("url"), body = call.getString("body", "");
        final int ms = call.getInt("timeoutMs", 4000);
        async(call, () -> {
            NetCore.HttpResult h = NetCore.http(method, url, body, ms);
            JSObject r = new JSObject(); r.put("status", h.status); r.put("body", h.body); r.put("statusLine", h.statusLine == null ? "" : h.statusLine); return r;
        });
    }

    @PluginMethod
    public void genIdentity(PluginCall call) {
        final boolean cert = call.getBoolean("cert", true);
        async(call, () -> {
            NetCore.Identity id = NetCore.genIdentity(cert);
            JSObject r = new JSObject(); r.put("keyPkcs8", id.keyPkcs8); r.put("modulusHex", id.modulusHex); r.put("exponentHex", id.exponentHex);
            if (id.certDer != null) r.put("certDer", id.certDer);
            return r;
        });
    }

    @PluginMethod
    public void rsaSignAdb(PluginCall call) {
        final String key = call.getString("keyPkcs8"), token = call.getString("token");
        async(call, () -> { JSObject r = new JSObject(); r.put("sig", b64(NetCore.rsaSignAdb(key, b64(token)))); return r; });
    }

    @PluginMethod
    public void tcpOpen(PluginCall call) {
        final String host = call.getString("host"); final int port = call.getInt("port", 0); final boolean tls = call.getBoolean("tls", false);
        final int ms = call.getInt("timeoutMs", 4000); final JSObject ident = call.getObject("identity"); final boolean tls12 = call.getBoolean("tls12", false);
        async(call, () -> {
            Map<String, String> m = NetCore.open(host, port, tls, ident == null ? null : ident.getString("certDer"), ident == null ? null : ident.getString("keyPkcs8"), ms, tls12);
            JSObject r = new JSObject(); r.put("id", Integer.parseInt(m.get("id"))); if (m.get("peerCert") != null) r.put("peerCert", m.get("peerCert")); if (m.get("tls") != null) r.put("tls", m.get("tls")); return r;
        });
    }

    @PluginMethod
    public void tcpWrite(PluginCall call) {
        final int id = call.getInt("id", 0); final String data = call.getString("data", "");
        async(call, () -> { NetCore.write(id, b64(data)); return new JSObject(); });
    }

    @PluginMethod
    public void tcpRead(PluginCall call) {
        final int id = call.getInt("id", 0); final int ms = call.getInt("timeoutMs", 20000);
        async(call, () -> {
            NetCore.ReadResult rr = NetCore.read(id, ms);
            JSObject r = new JSObject(); if (rr.data != null) r.put("data", b64(rr.data)); r.put("closed", rr.closed); r.put("timeout", rr.timeout); return r;
        });
    }

    @PluginMethod
    public void tcpClose(PluginCall call) {
        NetCore.close(call.getInt("id", 0));
        call.resolve();
    }


    // ---- perf log line -> logcat ------------------------------------------------------------------------------------
    /** Dev timing lines from web/native/perf.js (pressed → queued → transmitted → ack). `adb logcat -s SpinPerf`. */
    @PluginMethod
    public void perfLog(PluginCall call) { Log.i("SpinPerf", String.valueOf(call.getString("line", ""))); call.resolve(); }

    // ---- low-latency Wi-Fi while the app is on screen ---------------------------------------------------------------
    /** A phone's Wi-Fi radio sleeps between packets (power-save), which can add 100-300 ms to the first packet after a pause. While the app is in the foreground this keeps the radio awake. */
    private WifiManager.WifiLock wifiLock;
    private static final boolean LOW_LATENCY_WIFI_LOCK = false;      // OFF: not proven on real phones (a Wi-Fi mode change is a risk to every TV's connection); flip to true only after testing on a device
    private void holdWifi(boolean on) {
        if (!LOW_LATENCY_WIFI_LOCK) return;
        try {
            if (on) {
                if (wifiLock == null) {
                    WifiManager wm = (WifiManager) getContext().getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                    wifiLock = wm.createWifiLock(Build.VERSION.SDK_INT >= 29 ? WifiManager.WIFI_MODE_FULL_LOW_LATENCY : WifiManager.WIFI_MODE_FULL_HIGH_PERF, "spinremote-lowlatency");
                    wifiLock.setReferenceCounted(false);
                }
                if (!wifiLock.isHeld()) wifiLock.acquire();
            } else if (wifiLock != null && wifiLock.isHeld()) wifiLock.release();
        } catch (Throwable t) { Log.w("SpinPerf", "wifi lock: " + t); }
    }
    @Override protected void handleOnResume() { holdWifi(true); }
    @Override protected void handleOnPause() { holdWifi(false); if (recognizer != null) voiceCancelNow("background"); }

    // ---- voice search: Android SpeechRecognizer ---------------------------------------------------------------------
    // RECORD_AUDIO is asked for only when the voice button is pressed. Events go to JS as the "voice" listener:
    //   {state: listening | speaking | partial | final | error | stopped, text?, code?}
    private SpeechRecognizer recognizer;
    private volatile boolean voiceLive = false;
    private volatile int voiceGen = 0, voiceWant = 0;                         // Cancel bumps voiceGen: a start still waiting on the permission dialog is then dropped (never an invisible open microphone)

    private JSObject voiceInfo() {
        JSObject r = new JSObject(); String perm = "prompt";
        try { perm = permState("mic"); } catch (Throwable ignored) { }
        r.put("permission", perm);
        boolean avail = false; try { avail = SpeechRecognizer.isRecognitionAvailable(getContext()); } catch (Throwable ignored) { }
        r.put("available", avail);
        return r;
    }
    @PluginMethod
    public void voiceStatus(PluginCall call) { call.resolve(voiceInfo()); }

    @PluginMethod
    public void voiceStart(PluginCall call) {
        boolean avail = false; try { avail = SpeechRecognizer.isRecognitionAvailable(getContext()); } catch (Throwable ignored) { }
        if (!avail) { JSObject r = new JSObject(); r.put("state", "unavailable"); call.resolve(r); return; }
        voiceWant = voiceGen;
        if (getPermissionState("mic") != PermissionState.GRANTED) {
            if (getActivity() == null) { JSObject r = new JSObject(); r.put("state", "denied"); call.resolve(r); return; }
            requestPermissionForAlias("mic", call, "voicePermDone"); return;
        }
        beginListening(call);
    }
    @PermissionCallback
    private void voicePermDone(PluginCall call) {
        if (voiceWant != voiceGen) { JSObject r = new JSObject(); r.put("state", "stopped"); call.resolve(r); return; }
        if (getPermissionState("mic") == PermissionState.GRANTED) beginListening(call);
        else { JSObject r = new JSObject(); r.put("state", "denied"); call.resolve(r); }
    }
    private void beginListening(PluginCall call) {
        if (getActivity() == null) { call.reject("no activity"); return; }
        getActivity().runOnUiThread(() -> {
            if (voiceWant != voiceGen) { JSObject r = new JSObject(); r.put("state", "stopped"); call.resolve(r); return; }
            try {
                destroyRecognizer();
                recognizer = SpeechRecognizer.createSpeechRecognizer(getContext());
                recognizer.setRecognitionListener(new RecognitionListener() {
                    private void ev(String state, String text, String code) { JSObject o = new JSObject(); o.put("state", state); if (text != null) o.put("text", text); if (code != null) o.put("code", code); notifyListeners("voice", o); }
                    private String first(Bundle b) { java.util.ArrayList<String> l = b == null ? null : b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION); return l == null || l.isEmpty() ? "" : l.get(0); }
                    @Override public void onReadyForSpeech(Bundle p) { ev("listening", null, null); }
                    @Override public void onBeginningOfSpeech() { ev("speaking", null, null); }
                    @Override public void onRmsChanged(float v) { }
                    @Override public void onBufferReceived(byte[] b) { }
                    @Override public void onEndOfSpeech() { }
                    @Override public void onPartialResults(Bundle b) { String t = first(b); if (!t.isEmpty()) ev("partial", t, null); }
                    @Override public void onResults(Bundle b) { voiceLive = false; ev("final", first(b), null); destroyRecognizer(); }
                    @Override public void onError(int e) {
                        voiceLive = false;
                        String c = e == SpeechRecognizer.ERROR_NO_MATCH ? "no_match" : e == SpeechRecognizer.ERROR_SPEECH_TIMEOUT ? "no_speech"
                            : (e == SpeechRecognizer.ERROR_NETWORK || e == SpeechRecognizer.ERROR_NETWORK_TIMEOUT || e == SpeechRecognizer.ERROR_SERVER) ? "network"
                            : e == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ? "denied" : e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY ? "busy"
                            : e == SpeechRecognizer.ERROR_AUDIO ? "audio" : "unavailable";
                        ev("error", null, c); destroyRecognizer();
                    }
                    @Override public void onEvent(int t, Bundle b) { }
                });
                Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
                i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
                i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getContext().getPackageName());
                voiceLive = true;
                recognizer.startListening(i);
                JSObject r = new JSObject(); r.put("state", "started"); call.resolve(r);
            } catch (Throwable t) {
                voiceLive = false; destroyRecognizer();
                JSObject r = new JSObject(); r.put("state", "unavailable"); call.resolve(r);
            }
        });
    }
    /** "Done speaking": the recognizer returns what it has as a final result. */
    @PluginMethod
    public void voiceStop(PluginCall call) {
        if (getActivity() != null) getActivity().runOnUiThread(() -> { try { if (recognizer != null) recognizer.stopListening(); } catch (Throwable ignored) { } });
        call.resolve();
    }
    /** Cancel / back / backgrounded: the microphone is released immediately and no result is delivered. */
    @PluginMethod
    public void voiceCancel(PluginCall call) { voiceCancelNow("cancel"); call.resolve(); }
    private void voiceCancelNow(String why) {
        voiceGen++;
        if (recognizer == null) return;
        if (getActivity() != null) getActivity().runOnUiThread(this::destroyRecognizer); else destroyRecognizer();
        if (voiceLive) { voiceLive = false; JSObject o = new JSObject(); o.put("state", "stopped"); o.put("code", why); notifyListeners("voice", o); }
    }
    private void destroyRecognizer() {
        try { if (recognizer != null) { recognizer.setRecognitionListener(null); recognizer.cancel(); recognizer.destroy(); } } catch (Throwable ignored) { }
        recognizer = null;
    }

    @Override
    protected void handleOnDestroy() { holdWifi(false); destroyRecognizer(); NetCore.closeAll(); pool.shutdownNow(); }
}
