package com.spinremote.app;

import java.io.ByteArrayOutputStream;
import java.math.BigInteger;
import java.security.KeyPair;
import java.security.Signature;
import java.util.Date;

/** Minimal self-signed X.509 v3 certificate writer (RSA / SHA-256) - no external crypto library needed. */
final class CertGen {
    private CertGen() {}

    private static byte[] tlv(int tag, byte[]... parts) {
        ByteArrayOutputStream body = new ByteArrayOutputStream();
        for (byte[] p : parts) body.write(p, 0, p.length);
        byte[] b = body.toByteArray();
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        o.write(tag);
        if (b.length < 128) o.write(b.length);
        else if (b.length < 256) { o.write(0x81); o.write(b.length); }
        else if (b.length < 65536) { o.write(0x82); o.write(b.length >> 8); o.write(b.length & 255); }
        else { o.write(0x83); o.write(b.length >> 16); o.write((b.length >> 8) & 255); o.write(b.length & 255); }
        o.write(b, 0, b.length);
        return o.toByteArray();
    }

    private static byte[] oid(int... c) {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        o.write(c[0] * 40 + c[1]);
        for (int i = 2; i < c.length; i++) {
            int v = c[i];
            if (v < 128) { o.write(v); continue; }
            byte[] tmp = new byte[5]; int n = 0;
            while (v > 0) { tmp[n++] = (byte) (v & 0x7f); v >>= 7; }
            for (int k = n - 1; k >= 0; k--) o.write(tmp[k] | (k > 0 ? 0x80 : 0));
        }
        byte[] b = o.toByteArray();
        return tlv(0x06, b);
    }

    private static byte[] utc(Date d) {
        java.text.SimpleDateFormat f = new java.text.SimpleDateFormat("yyMMddHHmmss'Z'");
        f.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));
        return tlv(0x17, f.format(d).getBytes(java.nio.charset.StandardCharsets.US_ASCII));
    }

    private static byte[] name(String cn) {
        return tlv(0x30, tlv(0x31, tlv(0x30, oid(2, 5, 4, 3), tlv(0x0c, cn.getBytes(java.nio.charset.StandardCharsets.UTF_8)))));
    }

    static byte[] selfSigned(KeyPair kp, String cn) throws Exception {
        byte[] sigAlg = tlv(0x30, oid(1, 2, 840, 113549, 1, 1, 11), tlv(0x05));
        Date from = new Date(System.currentTimeMillis() - 24L * 3600 * 1000), to = new Date(System.currentTimeMillis() + 3650L * 24 * 3600 * 1000);
        byte[] serial = tlv(0x02, new BigInteger(63, new java.security.SecureRandom()).add(BigInteger.ONE).toByteArray());
        byte[] tbs = tlv(0x30,
                tlv(0xa0, tlv(0x02, new byte[] {2})),   // version v3
                serial, sigAlg, name(cn), tlv(0x30, utc(from), utc(to)), name(cn), kp.getPublic().getEncoded(),
                // same extensions as androidtvremote2's generator: BasicConstraints CA:TRUE pathlen 0, SAN DNS:<cn>
                tlv(0xa3, tlv(0x30,
                        tlv(0x30, oid(2, 5, 29, 19), tlv(0x04, tlv(0x30, new byte[] {1, 1, (byte) 0xff}, new byte[] {2, 1, 0}))),
                        tlv(0x30, oid(2, 5, 29, 17), tlv(0x04, tlv(0x30, tlv(0x82, cn.getBytes(java.nio.charset.StandardCharsets.US_ASCII))))))));
        Signature s = Signature.getInstance("SHA256withRSA");
        s.initSign(kp.getPrivate());
        s.update(tbs);
        byte[] sig = s.sign();
        byte[] bits = new byte[sig.length + 1];
        System.arraycopy(sig, 0, bits, 1, sig.length);
        return tlv(0x30, tbs, sigAlg, tlv(0x03, bits));
    }
}
