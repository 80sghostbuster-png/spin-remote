package com.spinremote.app;

import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(TvNativePlugin.class);
        super.onCreate(savedInstanceState);
        // Smoothness: make sure the WebView composites on the GPU, has no overscroll glow/stretch, and doesn't pay for text autosizing.
        try {
            WebView wv = getBridge().getWebView();
            wv.setLayerType(View.LAYER_TYPE_HARDWARE, null);
            wv.setOverScrollMode(View.OVER_SCROLL_NEVER);
            wv.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
            wv.setVerticalScrollBarEnabled(false);
            wv.setHorizontalScrollBarEnabled(false);
            WebSettings ws = wv.getSettings();
            ws.setTextZoom(100);
            ws.setMediaPlaybackRequiresUserGesture(false);
            ws.setOffscreenPreRaster(true);
        } catch (Throwable ignored) { }
    }
}
