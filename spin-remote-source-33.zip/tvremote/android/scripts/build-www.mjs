// Builds android/www/index.html from the SAME web sources as pages/index.html (one inline file) with the native TV backend switched on.
import { build } from 'esbuild';
import fs from 'node:fs';
import path from 'node:path';
const here = new URL('../', import.meta.url).pathname, root = path.resolve(here, '..') + '/';
const js = (await build({
  entryPoints: [root + 'web/app.js'], bundle: true, minify: true, format: 'iife', target: 'es2020', write: false,
  define: { __BUNDLE__: 'true', __NATIVE__: 'true' },
  alias: { '@capacitor/core': here + 'node_modules/@capacitor/core' },
})).outputFiles[0].text.replace(/<\/script/gi, '<\\/script');
const css = fs.readFileSync(root + 'web/style.css', 'utf8');
const icon = 'data:image/svg+xml,' + encodeURIComponent(fs.readFileSync(root + 'web/icons/icon.svg', 'utf8'));
const html = fs.readFileSync(root + 'web/index.html', 'utf8')
  .replace(/<link rel="manifest"[^>]*>\n?/, '')
  .replace(/<link rel="icon"[^>]*>/, `<link rel="icon" href="${icon}">`)
  .replace(/<link rel="apple-touch-icon"[^>]*>\n?/, '')
  .replace(/<link rel="stylesheet"[^>]*>/, () => `<style>${css}</style>`)
  .replace(/<script type="module"[^>]*><\/script>/, () => `<script>${js}</script>`);
fs.mkdirSync(here + 'www', { recursive: true });
fs.writeFileSync(here + 'www/index.html', html);
console.log('android/www/index.html', (html.length / 1024).toFixed(1) + ' KB');
