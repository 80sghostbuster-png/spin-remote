// Build 28: volume, rewind/fast-forward, typing and voice search through the official Fire TV remote API (what Amazon's app sends),
// with the build 21 ADB path as the silent fallback. SELF-WRITTEN mocks — not a real Fire TV.
import { makeTransport, stopJvm } from './transports.mjs';
import { makeStore } from '../../web/native/backend.js';
import { fire } from '../../web/native/firetv-official.js';
import { adb } from '../../web/native/firetv.js';
import { ok, eq, section, summary } from './lib.mjs';

globalThis.__tvTransport = makeTransport();
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const { startAdbMock } = await import('../mocks/adb-mock.mjs');
const { startFireApiMock } = await import('../mocks/firetv-api-mock.mjs');
const adbTv = await startAdbMock({ port: 19375, autoAllow: true, globalSearch: true });
let n = 0, pd = 19700; const NOADB = 19398;
const tv = async (o = {}, adbPort = NOADB) => { pd += 10; const m = await startFireApiMock({ dialPort: pd, apiPort: pd + 1, awake: true, ...o });
  const d = { id: 'firetv-v' + (++n), host: '127.0.0.1', platform: 'firetv', name: 'Fire', ports: { adb: adbPort, dial: pd, lightning: pd + 1, dialdd: pd + 2 } };
  const st = makeStore(); if (adbPort !== NOADB) { const r = await adb.pairStart(d, st); if (r.status === 'confirm') await adb.pairFinish(d, st); }
  const r = await fire.pairStart(d, st); if (r.status === 'code') await fire.pairFinish(d, st, '4821'); return [m, d, st]; };

section('1. official path, ADB debugging OFF (like Ben’s Fire TV): volume, mute, rewind, fast-forward');
let [m, d, st] = await tv();
for (const k of ['vol_up', 'vol_down', 'mute', 'rew', 'ff']) await fire.key(d, k, st);
eq(m.st.keys, ['volume_up', 'volume_down', 'mute', 'scan&direction=back', 'scan&direction=forward'], 'each press sent the official request');

section('2. voice search with ADB OFF: words land in the Fire TV search');
const o = { settleMs: 50 }; await fire.search(d, 'stranger things', st, o);
eq(m.st.launched, ['com.amazon.tv.searchapp'], 'search screen opened via the app list'); eq(m.st.texts, [{ ep: 'text', text: 'stranger things', screen: 'com.amazon.tv.searchapp' }], 'words typed into the search screen'); eq(o.how, 'typed', 'reported as typed');
await fire.text(d, 'abc', st); eq(m.st.texts[1].text, 'abc', 'keyboard typing official'); m.close(); fire.closeAll();

section('3. /text refused → /keyboard (build 31: buttons have no variants any more)');
[m, d, st] = await tv({ refuse: ['text'] });
await fire.search(d, 'news', st, { settleMs: 20 }); eq(m.st.texts.map((t) => t.ep + ':' + t.text), ['keyboard:news'], 'typed via /v1/FireTV/keyboard'); m.close(); fire.closeAll();

section('4. official refuses volume/rewind → ADB fallback (KEYCODE_VOLUME_*, MEDIA_REWIND/FAST_FORWARD)');
[m, d, st] = await tv({ refuse: ['volume_up', 'volume_down', 'mute', 'volume_mute', 'scan'] }, 19375);
let k0 = adbTv.st.keys.length; for (const k of ['vol_up', 'vol_down', 'mute', 'rew', 'ff']) await fire.key(d, k, st); await sleep(400);
const got = adbTv.st.keys.slice(k0).map((x) => x.k).join(' ');
for (const want of ['VOLUME_UP', 'VOLUME_DOWN', 'VOLUME_MUTE', 'MEDIA_REWIND', 'MEDIA_FAST_FORWARD']) ok(got.includes(want), `${want} over ADB`);
eq(m.st.keys, [], 'nothing accepted by the official API (refused)'); m.close(); fire.closeAll();

section('5. no search app in the list → ADB voice search');
[m, d, st] = await tv({ noSearchApp: true }, 19375); const s0 = adbTv.st.searchOpen; const o2 = { settleMs: 50 };
await fire.search(d, 'cooking', st, o2); await sleep(300); ok(adbTv.st.searchOpen > s0, 'ADB opened the search screen'); ok((adbTv.st.texts || []).some((t) => /cooking/.test(t)), 'words typed over ADB'); eq(o2.how, 'typed', 'reported as typed'); m.close(); fire.closeAll();

section('6. token present → ADB connects quietly in the background (warm)');
[m, d, st] = await tv({}, 19375); fire.closeAll(); adb.closeAll(); const op = adbTv.st.opens; await fire.warm(d, st); await sleep(800); ok(adbTv.st.opens > op, 'ADB connection opened in the background'); m.close();

fire.closeAll(); adbTv.close(); stopJvm();
const s = summary(); console.log(`\n${s.pass} passed, ${s.fail} failed`); process.exit(s.fail ? 1 : 0);
