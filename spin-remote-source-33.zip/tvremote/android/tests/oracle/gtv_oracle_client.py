"""INDEPENDENT oracle: the published `androidtvremote2` Python library (used by Home Assistant against real Google TVs)
drives our self-written mock TV. If this passes, the mock (and therefore our JS client, which is tested against the same
mock) speaks the same wire protocol that library speaks to real TVs. Usage: gtv_oracle_client.py <host> <pair_port> <api_port> <workdir>"""
import asyncio, sys, json
from androidtvremote2 import AndroidTVRemote
host, pp, ap, wd = sys.argv[1], int(sys.argv[2]), int(sys.argv[3]), sys.argv[4]

async def main():
    r = AndroidTVRemote("oracle-client", wd + "/cert.pem", wd + "/key.pem", host, api_port=ap, pair_port=pp)
    await r.async_generate_cert_if_missing()
    await r.async_start_pairing()
    print("NEED_CODE", flush=True)
    code = (await asyncio.get_event_loop().run_in_executor(None, sys.stdin.readline)).strip()
    await r.async_finish_pairing(code)
    print("PAIRED", flush=True)
    await r.async_connect()
    r.send_key_command("DPAD_UP"); await asyncio.sleep(0.15)
    r.send_key_command("HOME"); await asyncio.sleep(0.15)
    r.send_launch_app_command("https://www.youtube.com"); await asyncio.sleep(0.15)
    r.send_text("hi"); await asyncio.sleep(0.4)
    print("DONE", json.dumps({"is_on": r.is_on, "info": str(r.device_info)}), flush=True)
    r.disconnect()
asyncio.run(main())
