// Runs the Python androidtvremote2 library against our mock Android TV (see gtv_oracle_client.py)
import { spawn } from 'node:child_process'; import fs from 'node:fs'; import os from 'node:os'; import path from 'node:path';
import { startAndroidTvMock } from '../../mocks/androidtv-mock.mjs';
import { section, ok, eq, summary } from '../lib.mjs';
const check = (n, c, x = '') => ok(c, n + (c ? '' : '  ' + x));
const py = process.env.PYORACLE || '/tmp/pyvenv/bin/python';
section('ORACLE: androidtvremote2 (Home Assistant\'s Python library) → our mock Android TV');
if (!fs.existsSync(py)) { console.log('  (skipped: no python oracle venv at ' + py + ')'); process.exit(0); }
const atv = await startAndroidTvMock({ pairPort: 16467, remotePort: 16466 });
const wd = fs.mkdtempSync(path.join(os.tmpdir(), 'oracle-'));
const child = spawn(py, [new URL('./gtv_oracle_client.py', import.meta.url).pathname, '127.0.0.1', '16467', '16466', wd]);
let out = '', err = ''; child.stdout.on('data', (d) => { out += d; if (/NEED_CODE/.test(out) && !child.sent) { const t = setInterval(() => { if (atv.st.code) { child.sent = true; clearInterval(t); child.stdin.write(atv.st.code + '\n'); } }, 50); child.sent = 'wait'; } }); child.stderr.on('data', (d) => { err += d; });
await new Promise((r) => child.on('close', r));
check('python library completed pairing and session', /PAIRED/.test(out) && /DONE/.test(out), out + err.slice(-600));
check('TV saw the pairing handshake in order', atv.st.pairLog.join(',').includes('pairing_request') && atv.st.pairLog.includes('secret ok'), atv.st.pairLog.join(' | '));
check('python library: key presses arrive (DPAD_UP=19, HOME=3, SHORT)', JSON.stringify(atv.st.keys.map(({ code, dir }) => ({ code, dir }))) === JSON.stringify([{ code: 19, dir: 3 }, { code: 3, dir: 3 }]), JSON.stringify(atv.st.keys));
check('python library: app link arrives', atv.st.apps.join() === 'https://www.youtube.com', atv.st.apps.join());
check('python library: text arrives via ime_batch_edit', atv.st.texts.join().includes('hi'), JSON.stringify(atv.st.texts));
atv.close(); const s = summary(); console.log(`\n${s.pass} passed, ${s.fail} failed`); process.exit(s.fail ? 1 : 0);
