// Runs the Python pyatv library against our mock Apple TV (see appletv_oracle_client.py)
import { spawn } from 'node:child_process'; import fs from 'node:fs';
import { startAppleTvMock } from '../../mocks/appletv-mock.mjs';
import { section, ok, summary } from '../lib.mjs';
const check = (n, c, x = '') => ok(c, n + (c ? '' : '  ' + x));
const py = process.env.PYORACLE || '/tmp/pyvenv/bin/python';
section('ORACLE: pyatv (Companion protocol library) → our mock Apple TV');
if (!fs.existsSync(py)) { console.log('  (skipped: no python oracle venv at ' + py + ')'); process.exit(0); }
const atv = await startAppleTvMock({ port: 17010 });
const child = spawn(py, [new URL('./appletv_oracle_client.py', import.meta.url).pathname, '127.0.0.1', '17010']);
let out = '', err = '', sent = false; child.stdout.on('data', (d) => { out += d; if (/NEED_PIN/.test(out) && !sent) { sent = true; child.stdin.write(atv.st.pin + '\n'); } }); child.stderr.on('data', (d) => { err += d; });
await new Promise((r) => child.on('close', r));
const diag = out + err.slice(-900) + atv.st.pairLog.join(' | ');
check('pyatv completed Pair-Setup with the 4-digit PIN', /PAIRED True/.test(out) && atv.st.pairLog.some((l) => l.startsWith('PS M5 ok')), diag);
check('pyatv completed Pair-Verify and an encrypted session', atv.st.pairLog.includes('PV ok') && atv.st.sessions >= 1, diag);
check('pyatv: button presses arrive (UP=1, HOME=7)', JSON.stringify(atv.st.hid.map((h) => h.code)).includes('1') && atv.st.hid.some((h) => h.code === 7), JSON.stringify(atv.st.hid));
check('pyatv: app launch arrives', atv.st.apps.includes('com.netflix.Netflix'), JSON.stringify(atv.st.apps));
check('pyatv: text input arrives (this checks our mock\'s text-input archive format against pyatv\'s parser)', atv.st.field === 'oracle text' || atv.st.texts.includes('oracle text'), JSON.stringify(atv.st.texts) + diag);
atv.close(); const s = summary(); console.log(`\n${s.pass} passed, ${s.fail} failed`); process.exit(s.fail ? 1 : 0);
