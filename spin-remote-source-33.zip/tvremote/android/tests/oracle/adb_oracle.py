"""Independent oracle for ADB auth: adb-shell's public-key encoding and RSA signing (PKCS#1 v1.5 over the pre-hashed token)."""
import sys, json, base64
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.primitives.asymmetric import padding, utils
from adb_shell.auth.keygen import encode_pubkey
key = serialization.load_der_private_key(base64.b64decode(sys.argv[1]), None)
token = base64.b64decode(sys.argv[2])
blob = encode_pubkey_blob = None
import adb_shell.auth.keygen as kg
pub = kg.get_user_info() if False else None
# encode_pubkey wants a path to a private key: write it as PEM
import tempfile, os
pem = key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.TraditionalOpenSSL, serialization.NoEncryption())
f = tempfile.NamedTemporaryFile(delete=False, suffix='.key'); f.write(pem); f.close()
pubkey = kg.decode_pubkey_file if False else None
print(json.dumps({'pub': base64.b64encode(kg.encode_pubkey(f.name)).decode(), 'sig': base64.b64encode(key.sign(token, padding.PKCS1v15(), utils.Prehashed(hashes.SHA1()))).decode()}))
os.unlink(f.name)
