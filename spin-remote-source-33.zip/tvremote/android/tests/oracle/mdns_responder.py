"""Independent mDNS responder for testing NetCore.mdnsQuery: the DNS packet is encoded by the `zeroconf` library (not by our code).
Listens on a UDP port on 127.0.0.1 and answers every query with PTR + SRV + TXT + A for one service."""
import socket, sys
from zeroconf import DNSOutgoing, DNSPointer, DNSService, DNSText, DNSAddress, const
svc, inst, host, ip, port = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4], int(sys.argv[5])
full = f"{inst}.{svc}"
out = DNSOutgoing(const._FLAGS_QR_RESPONSE | const._FLAGS_AA, multicast=False)
out.add_answer_at_time(DNSPointer(svc, const._TYPE_PTR, const._CLASS_IN, 120, full), 0)
out.add_answer_at_time(DNSService(full, const._TYPE_SRV, const._CLASS_IN | const._CLASS_UNIQUE, 120, 0, 0, port, host), 0)
out.add_answer_at_time(DNSText(full, const._TYPE_TXT, const._CLASS_IN | const._CLASS_UNIQUE, 120, b"\x08bt=AA:BB\x06fn=Den"), 0)
out.add_answer_at_time(DNSAddress(host, const._TYPE_A, const._CLASS_IN | const._CLASS_UNIQUE, 120, socket.inet_aton(ip)), 0)
data = out.packets()[0]
s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); s.bind(("127.0.0.1", 0)); print(s.getsockname()[1], flush=True)
while True:
    _, addr = s.recvfrom(9000); s.sendto(data, addr)
