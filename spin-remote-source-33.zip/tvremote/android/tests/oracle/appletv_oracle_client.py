"""INDEPENDENT oracle: the published `pyatv` library (Companion protocol, used against real Apple TVs) pairs with and
controls our self-written mock. Usage: appletv_oracle_client.py <host> <port>"""
import asyncio, sys, json
import pyatv
from pyatv import conf
from pyatv.const import Protocol
host, port = sys.argv[1], int(sys.argv[2])

async def main():
    loop = asyncio.get_event_loop()
    cfg = conf.AppleTV(host, "Mock Apple TV")
    cfg.add_service(conf.ManualService("mock", Protocol.Companion, port, {}))
    p = await pyatv.pair(cfg, Protocol.Companion, loop, name="oracle")
    await p.begin()
    print("NEED_PIN", flush=True)
    pin = (await loop.run_in_executor(None, sys.stdin.readline)).strip()
    p.pin(int(pin))
    await p.finish()
    print("PAIRED", p.has_paired, flush=True)
    await p.close()
    atv = await pyatv.connect(cfg, loop)
    await atv.remote_control.up(); await asyncio.sleep(0.1)
    await atv.remote_control.home(); await asyncio.sleep(0.1)
    await atv.apps.launch_app("com.netflix.Netflix"); await asyncio.sleep(0.1)
    await atv.keyboard.text_set("oracle text"); await asyncio.sleep(0.3)
    print("DONE", flush=True)
    atv.close()
    await asyncio.sleep(0.2)
asyncio.run(main())
