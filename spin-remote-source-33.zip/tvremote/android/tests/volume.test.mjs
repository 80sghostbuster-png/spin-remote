// Volume / mute on every platform, plus the honest-failure paths (Roku stick, Fire TV rejecting the key, Apple TV mute) and Apple TV Details.
import { makeTransport as makeNodeTransport, stopJvm } from './transports.mjs';
import { makeStore, createBackend } from '../../web/native/backend.js';
import { startRokuMock } from '../mocks/roku-mock.mjs';
import { startAndroidTvMock } from '../mocks/androidtv-mock.mjs';
import { startAppleTvMock } from '../mocks/appletv-mock.mjs';
import { startAdbMock } from '../mocks/adb-mock.mjs';
import { ok, eq, rejects, section, summary } from './lib.mjs';
import { sleep } from '../../web/native/bytes.js';

const stub = () => async (p) => ({ stub: p, demo: true });
const mk = (ports) => createBackend({ makeSim: stub, store: makeStore(null), transport: makeNodeTransport(), ports });
const call = (b, path, method = 'GET', body) => b.handler(path, { method, body: body ? JSON.stringify(body) : undefined });
const key = (b, d, k) => call(b, '/api/send', 'POST', { device: d.id, action: 'key', key: k });
const VOL = ['vol_up', 'vol_down', 'mute'];

section('Roku: volume on a Roku TV / box works; on a stick it fails with a clear message and sends nothing');
for (const [kind, port] of [['tv', 18160], ['box', 18161], ['stick', 18162]]) {
  const r = await startRokuMock({ port, ssdpPort: 11960 + port % 10, kind }); const b = mk({ roku: { http: port } });
  const d = await call(b, '/api/devices', 'POST', { platform: 'roku', host: '127.0.0.1' });
  if (kind !== 'stick') {
    for (const [k, w] of [['vol_up', 'VolumeUp'], ['vol_down', 'VolumeDown'], ['mute', 'VolumeMute']]) { r.st.log.length = 0; const s = await key(b, d, k); ok(s.ok && r.st.log[0] === `POST /keypress/${w}`, `${kind}: ${k} → /keypress/${w}`); }
  } else {
    await call(b, '/api/warm', 'POST', { device: d.id });      // the app warms the connection when a TV is selected, which also reads is-stick
    for (const k of VOL) { r.st.log.length = 0; const e = await rejects(key(b, d, k), 'no_volume', `stick: ${k} → no_volume`); ok(/can.t change volume; use your TV remote/.test(e.message), 'stick: message tells the user to use the TV remote'); ok(!r.st.log.some((l) => /Volume/.test(l)), 'stick: no volume key was sent'); }
    r.st.log.length = 0; ok((await key(b, d, 'up')).ok, 'stick: D-pad still works');
  }
  b.closeAll(); r.close();
}

section('Google TV: volume keys 24 / 25 / 164 over remote v2');
{
  const atv = await startAndroidTvMock({ pairPort: 16567, remotePort: 16566 }); const b = mk({ googletv: { pair: 16567, remote: 16566 } });
  const d = await call(b, '/api/devices', 'POST', { platform: 'googletv', host: '127.0.0.1' }); await call(b, '/api/pair/start', 'POST', { device: d.id }); await call(b, '/api/pair/finish', 'POST', { device: d.id, code: atv.st.code });
  for (const k of VOL) ok((await key(b, d, k)).ok, `${k} ok`);
  await sleep(150); eq(atv.st.keys.map((k) => k.code), [24, 25, 164], 'TV received VOLUME_UP 24, VOLUME_DOWN 25, MUTE 164'); ok(atv.st.keys.every((k) => k.dir === 3), 'direction SHORT');
  b.closeAll(); atv.close();
}

section('Fire TV: volume keys 24 / 25 / 164, and the fallback when the TV rejects the key event');
{
  const m = await startAdbMock({ port: 15655, autoAllow: true }); const b = mk({ firetv: { adb: 15655 } });
  const d = await call(b, '/api/devices', 'POST', { platform: 'firetv', host: '127.0.0.1' }); await call(b, '/api/pair/start', 'POST', { device: d.id }); await call(b, '/api/pair/finish', 'POST', { device: d.id });
  for (const k of VOL) ok((await key(b, d, k)).ok, `${k} ok`);
  eq(m.st.cmds.slice(-3), ['VOLUME_UP', 'VOLUME_DOWN', 'VOLUME_MUTE'].map((n) => `shell:input keyevent KEYCODE_${n}`), 'input keyevent VOLUME_UP / VOLUME_DOWN / VOLUME_MUTE');
  b.closeAll(); m.close();
  const m2 = await startAdbMock({ port: 15656, autoAllow: true, failInput: /KEYCODE_VOLUME/ }); const b2 = mk({ firetv: { adb: 15656 } });
  const d2 = await call(b2, '/api/devices', 'POST', { platform: 'firetv', host: '127.0.0.1' }); await call(b2, '/api/pair/start', 'POST', { device: d2.id }); await call(b2, '/api/pair/finish', 'POST', { device: d2.id });
  const s = await key(b2, d2, 'vol_up'); ok(s.ok, 'rejected key event → fallback accepted');
  ok(m2.st.cmds.some((c) => /cmd media_session volume .*--adj raise/.test(c)), 'fell back to cmd media_session volume --adj raise');
  m2.st.cmds.length = 0; await key(b2, d2, 'vol_down'); ok(m2.st.cmds.some((c) => /--adj lower/.test(c)), 'vol_down fallback lowers');
  b2.closeAll(); m2.close();
}

section('Apple TV: HID volume up (8) / down (9); mute is honestly refused; failures list per-step Details');
{
  const m = await startAppleTvMock({ port: 17100 }); const b = mk({ appletv: { companion: 17100 } });
  const d = await call(b, '/api/devices', 'POST', { platform: 'appletv', host: '127.0.0.1' }); await call(b, '/api/pair/start', 'POST', { device: d.id }); await call(b, '/api/pair/finish', 'POST', { device: d.id, code: m.st.pin });
  await key(b, d, 'vol_up'); await key(b, d, 'vol_down');
  eq(m.st.hid.filter((h) => h.state === 1).map((h) => h.code), [8, 9], 'HID VOLUME_UP 8, VOLUME_DOWN 9');
  const e = await rejects(key(b, d, 'mute'), 'bad_key', 'mute → clear refusal'); ok(/no mute/i.test(e.message), 'message says Apple TV has no mute');
  b.closeAll(); m.close();
  const m2 = await startAppleTvMock({ port: 17101, host: '127.0.0.2' }); const b2 = mk({ appletv: { companion: 17101 } });
  const d2 = await call(b2, '/api/devices', 'POST', { platform: 'appletv', host: '127.0.0.2' }); await call(b2, '/api/pair/start', 'POST', { device: d2.id }); await call(b2, '/api/pair/finish', 'POST', { device: d2.id, code: m2.st.pin });
  b2.closeAll(); m2.close(); await sleep(100);                                                  // the TV goes to sleep / leaves the network
  const e2 = await rejects(key(b2, d2, 'vol_up'), null, 'volume press to a TV that is gone fails (not a silent ✓)');
  ok(/Steps \(127\.0\.0\.2:17101\)/.test(e2.message) && /TCP[^\n]*FAILED/.test(e2.message), 'the error lists the per-step Details with the TCP step FAILED');
  b2.closeAll();
}
const s = summary(); console.log(`\n${s.pass} passed, ${s.fail} failed`); if (s.fail) { console.log(s.fails.join('\n')); stopJvm(); process.exit(1); }
stopJvm(); process.exit(0);
