// Build 31: tap the REAL Fire TV remote buttons (real web/ app in Chrome, DOM clicks + pointer taps) → real native backend in Node
// (backend.js → firetv-official.js → firetv-lightning.js / firetv.js) → strict official-spec Fire TV mock. Saved state = a TV paired by builds 27–29.
// SELF-WRITTEN mocks — not a real Fire TV.
import http from 'node:http'; import fs from 'node:fs'; import path from 'node:path';
import puppeteer from '../../tools/node_modules/puppeteer-core/lib/esm/puppeteer/puppeteer-core.js';
import { makeTransport, stopJvm } from './transports.mjs';
import { createBackend, makeStore } from '../../web/native/backend.js';
import { ok, eq, section, summary } from './lib.mjs';
const WEB = path.resolve(new URL('../../web/', import.meta.url).pathname);
const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.svg': 'image/svg+xml', '.png': 'image/png', '.webmanifest': 'application/json' };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const { startFireApiMock } = await import('../mocks/firetv-api-mock.mjs');
const { startAdbMock } = await import('../mocks/adb-mock.mjs');
const adbTv = await startAdbMock({ port: 19495, autoAllow: true, fixedVolume: true, settingsRefused: true })   // a Fire TV that reports fixed volume and refuses CEC changes over ADB;

async function run(label, { adbPort, savedExtra = {}, mock = {} }) {
  section(label);
  const m = await startFireApiMock({ dialPort: 19960, apiPort: 19961, awake: true, strict: true, ...mock }); m.st.token = 'Wj9PP8I';
  const store = makeStore(); const id = 'firetv-127.0.0.1';
  store.set('devices', [{ id, platform: 'firetv', host: '127.0.0.1', name: 'Ben’s Fire TV', paired: true, ports: { adb: adbPort, dial: 19960, lightning: 19961, dialdd: 19962 }, ...savedExtra }]);
  store.set('ftv.lightning.' + id, 'Wj9PP8I');                       // the token builds 27–29 saved
  const be = createBackend({ makeSim: () => null, store, transport: makeTransport() });
  const srv = http.createServer((q, r) => { const u = decodeURIComponent(q.url.split('?')[0]); const f = path.join(WEB, u === '/' ? 'index.html' : u); if (!fs.existsSync(f)) { r.statusCode = 404; return r.end(); } r.setHeader('content-type', MIME[path.extname(f)] || 'application/octet-stream'); r.end(fs.readFileSync(f)); });
  await new Promise((res) => srv.listen(0, '127.0.0.1', res));
  const browser = await puppeteer.launch({ executablePath: '/usr/bin/google-chrome', headless: 'new', args: ['--no-sandbox'] });
  const p = await browser.newPage(); await p.setViewport({ width: 390, height: 844, isMobile: true, hasTouch: true }); await p.setRequestInterception(true);
  const sends = [];
  p.on('request', async (rq) => { const u = new URL(rq.url()); if (!u.pathname.startsWith('/api/')) return rq.continue();
    if (u.pathname === '/api/info') return rq.respond({ status: 200, contentType: 'application/json', body: JSON.stringify(be.info()) });
    try { const o = await be.handler(u.pathname, { method: rq.method(), body: rq.postData() }); if (u.pathname === '/api/send') sends.push(['ok', JSON.parse(rq.postData()).key, o.wire]); rq.respond({ status: 200, contentType: 'application/json', body: JSON.stringify(o) }); }
    catch (e) { if (u.pathname === '/api/send') sends.push(['err', JSON.parse(rq.postData()).key, e.message]); rq.respond({ status: 500, contentType: 'application/json', body: JSON.stringify({ error: e.message, code: e.code }) }); } });
  await p.goto(`http://127.0.0.1:${srv.address().port}/?layout=reel&i=1`, { waitUntil: 'networkidle0' }); await sleep(600);
  await p.evaluate(() => { const f = document.querySelector('#ad-full'); f && f.remove(); window.__tv.expand(1); }); await sleep(2500);
  ok(await p.evaluate(() => window.__tv.state.locked), 'Fire TV remote open');
  const k0 = m.st.keys.length;
  for (const k of ['up', 'play_pause', 'vol_up', 'vol_down', 'mute', 'rew', 'ff']) { await p.evaluate((k) => document.querySelector(`.remote.firetv [data-key=${k}]`).click(), k); await sleep(900); }
  for (const k of ['play_pause', 'vol_up']) { const el = await p.$(`.remote.firetv [data-key=${k}]`); await el.tap(); await sleep(900); }   // real touch taps
  const got = m.st.keys.slice(k0); console.log('  TV got:', JSON.stringify(got), '\n  sends:', JSON.stringify(sends));
  eq(got, ['dpad_up', 'play', 'volume_up', 'volume_down', 'mute', 'scan&direction=back', 'scan&direction=forward', 'play', 'volume_up'], 'every tapped button reached the TV as the official request');
  await browser.close(); srv.close(); be.closeAll(); m.close();
}
await run('1. upgraded from builds 27–29, no ADB on the TV', { adbPort: 19499 });
await run('2. upgraded, ADB fallback also trusted (fixed-volume Fire TV)', { adbPort: 19495 });
adbTv.close(); stopJvm();
const s = summary(); console.log(`\n${s.pass} passed, ${s.fail} failed`); process.exit(s.fail ? 1 : 0);
