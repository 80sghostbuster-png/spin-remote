// build 15 regression tests: Roku request format against a STRICT raw-socket Roku, a 403 ("Limited") Roku, and capability gating that must never block a button unless the TV itself says so.
import { makeTransport, stopJvm } from './transports.mjs';
import { makeStore, createBackend } from '../../web/native/backend.js';
import { ecp } from '../../web/native/roku.js';
import { startStrictRoku } from '../mocks/roku-strict-mock.mjs';
import { startRokuMock } from '../mocks/roku-mock.mjs';
import { ok, eq, section, summary } from './lib.mjs';
import { sleep } from '../../web/native/bytes.js';
import { startAndroidTvMock } from '../mocks/androidtv-mock.mjs';
import { getLog, dlog } from '../../web/native/dbg.js';
const orig = console.log; console.log = (...a) => { if (typeof a[0] === 'string' && a[0].startsWith('[perf]')) return; orig(...a); };
const stub = () => async (p) => ({ stub: p, demo: true });
const mk = (ports) => createBackend({ makeSim: stub, store: makeStore(null), transport: makeTransport(), ports });
const call = (b, path, method = 'GET', body) => b.handler(path, { method, body: body ? JSON.stringify(body) : undefined });
const key = (b, d, k) => call(b, '/api/send', 'POST', { device: d.id, action: 'key', key: k });
const fails = async (p) => { try { await p; return null; } catch (e) { return e; } };
const JARGON = /HTTP \d|\b40\d\b|exception|errno|null|undefined/;
console.log(`transport: ${process.env.TRANSPORT || 'node'}, Roku keep-alive path: ${ecp.keepAlive ? 'ON' : 'OFF'}`);
ok(ecp.keepAlive === false, 'shipped default: one request per press (the path that worked in builds 5–13)');

section('Strict Roku (refuses any malformed HTTP): every press is a well-formed request and is accepted');
{
  const R = await startStrictRoku({ port: 18410 }); const b = mk({ roku: { http: 18410 } });
  const d = await call(b, '/api/devices', 'POST', { platform: 'roku', host: '127.0.0.1' }); ok(d.paired, 'Roku is added (device-info answered)');
  for (const k of ['up', 'down', 'left', 'right', 'select', 'back', 'home', 'play_pause', 'vol_up', 'vol_down', 'mute']) { const r = await key(b, d, k); ok(r.ok, `press ${k} accepted`); }
  await Promise.all(['up', 'up', 'down', 'select', 'right'].map((k) => key(b, d, k))); await sleep(100);
  eq(R.st.bad, [], 'the Roku refused nothing: every request line, Host header and Content-Length was well-formed');
  ok(R.st.raw.length >= 16, `${R.st.raw.length} requests seen`);
  const posts = R.st.raw.filter((x) => x.startsWith('POST'));
  ok(posts.every((x) => /^POST \/keypress\/[A-Za-z_]+ HTTP\/1\.1$/m.test(x.split('\r\n')[0])), 'each press is "POST /keypress/<Key> HTTP/1.1"');
  ok(posts.every((x) => /^host: 127\.0\.0\.1:18410$/im.test(x)), 'with a Host header (ip:port)'); ok(posts.every((x) => /^content-length: 0$/im.test(x)), 'and Content-Length: 0');
  eq(R.st.keys.slice(0, 4), ['Up', 'Down', 'Left', 'Right'], 'keys reach the Roku as the ECP key names');
  ok(R.st.keys.includes('VolumeUp') && R.st.keys.includes('VolumeMute'), 'volume keys are VolumeUp / VolumeMute (a Roku TV)');
  b.closeAll(); await R.close();
}
section('The optional keep-alive client is also well-formed (only used if switched on; it is OFF in the app)');
if (process.env.TRANSPORT !== 'java') {
  const R = await startStrictRoku({ port: 18411 }); const b = mk({ roku: { http: 18411 } }); const d = await call(b, '/api/devices', 'POST', { platform: 'roku', host: '127.0.0.1' });
  ecp.keepAlive = true; for (const k of ['up', 'down', 'select']) await key(b, d, k); ecp.keepAlive = false;
  eq(R.st.bad, [], 'strict Roku refused nothing'); eq(R.st.keys, ['Up', 'Down', 'Select'], 'three presses arrived'); b.closeAll(); await R.close();
}
section('Roku set to "Limited" (keypress answers 403): plain words, no raw status, nothing crashes, and it says what to change');
{
  const R = await startStrictRoku({ port: 18412, limited: true, ws: false }); const b = mk({ roku: { http: 18412 } });
  const d = await call(b, '/api/devices', 'POST', { platform: 'roku', host: '127.0.0.1' });
  const e = await fails(key(b, d, 'select')); ok(!!e, 'the press is reported as not delivered (never shown as success)'); eq(e.code, 'forbidden', 'error kind is "forbidden"');
  ok(/Control by mobile apps/.test(e.message), 'the message tells the user which TV setting to change');
  const e2 = await fails(key(b, d, 'up')); ok(!!e2 && !R.st.keys.length, 'still refused on the next press, nothing delivered'); b.closeAll(); await R.close();
}
section('Roku in "Limited" mode WITH the phone-app channel (Lex: only volume worked): every button now gets through');
{
  const R = await startStrictRoku({ port: 18414, limited: true, volumeOk: true }); const b = mk({ roku: { http: 18414 } });
  const d = await call(b, '/api/devices', 'POST', { platform: 'roku', host: '127.0.0.1' }); ok(d.paired, 'added');
  const ks = ['select', 'up', 'down', 'left', 'right', 'back', 'home', 'play_pause', 'rew', 'ff', 'replay', 'options', 'vol_up', 'vol_down', 'mute', 'power'];
  for (const k of ks) { const r = await key(b, d, k); ok(r.ok, `press ${k} delivered`); }
  eq(R.st.wsKeys, ['Select', 'Up', 'Down', 'Left', 'Right', 'Back', 'Home', 'Play', 'Rev', 'Fwd', 'InstantReplay', 'Info', 'VolumeUp', 'VolumeDown', 'VolumeMute', 'Power'], 'every key arrived over the phone-app channel with the right ECP name, in order');
  eq(R.st.wsBad, [], 'the strict mock found the WebSocket handshake and every masked frame well-formed'); eq(R.st.wsAuth, 1, 'signed in once, the session is reused');
  const hk = R.st.raw.filter((x) => /^POST \/keypress\//.test(x)).length; ok(hk <= 2, `at most the first press (or two) tried the plain HTTP button (${hk})`);
  const before = R.st.wsKeys.length; await Promise.all(['up', 'up', 'down', 'select', 'right'].map((k) => key(b, d, k))); await sleep(100);
  eq(R.st.wsKeys.slice(before), ['Up', 'Up', 'Down', 'Select', 'Right'], 'a rapid burst keeps its order'); eq(R.st.bad, [], 'no malformed HTTP either');
  const t = await call(b, '/api/send', 'POST', { device: d.id, action: 'text', text: 'hi' }).catch((e) => ({ err: e })); ok(!t.err, 'typing text works too'); await sleep(100);
  ok(R.st.wsKeys.slice(-2).join() === 'Lit_h,Lit_i', 'typed letters go as Lit_h, Lit_i');
  b.closeAll(); await R.close();
}
section('Limited Roku that also refuses the phone-app channel: still a plain-words message, nothing delivered');
{
  const R = await startStrictRoku({ port: 18415, limited: true, ws: false }); const b = mk({ roku: { http: 18415 } });
  const d = await call(b, '/api/devices', 'POST', { platform: 'roku', host: '127.0.0.1' }); const e = await fails(key(b, d, 'home'));
  ok(!!e && e.code === 'forbidden' && !R.st.wsKeys.length && !R.st.keys.length, 'refused, and reported as "forbidden"'); ok(/Control by mobile apps/.test(e.message), 'tells the user which setting to change'); b.closeAll(); await R.close();
}
section('Roku that answers 403 to everything');
{
  const R = await startStrictRoku({ port: 18413, forbiddenAll: true }); const b = mk({ roku: { http: 18413 } });
  const e = await fails(call(b, '/api/devices', 'POST', { platform: 'roku', host: '127.0.0.1' })); ok(!!e && e.code === 'forbidden', 'adding it says "forbidden" with the setting to change'); await R.close();
}
section('Capability gating never blocks a Roku unless the TV itself says it is a stick');
for (const [kind, want, pt] of [['tv', 'yes', 18420], ['stick', 'no', 18422], ['box', 'maybe', 18423]]) {
  const R = await startStrictRoku({ port: pt, kind }); const b = mk({ roku: { http: pt } }); const d = await call(b, '/api/devices', 'POST', { platform: 'roku', host: '127.0.0.1' });
  const c = await call(b, '/api/caps', 'POST', { device: d.id }); eq(c.volume, want, `Roku ${kind}: volume = ${want}`);
  const r = await fails(key(b, d, 'up')); ok(!r, `Roku ${kind}: the D-pad is never blocked`);
  const v = await fails(key(b, d, 'vol_up')); if (kind === 'stick') ok(v && v.code === 'no_volume' && !JARGON.test(v.message), 'stick: volume says so in plain words'); else ok(!v, `Roku ${kind}: volume key is sent`);
  b.closeAll(); await R.close();
}
{ // the capability lookup itself fails (403 / unreachable): unknown = 'maybe' = nothing is blocked
  const R = await startStrictRoku({ port: 18424, kind: 'stick' }); const b = mk({ roku: { http: 18424 } }); const d = await call(b, '/api/devices', 'POST', { platform: 'roku', host: '127.0.0.1' }); await R.close();
  const c = await call(b, '/api/caps', 'POST', { device: d.id }); eq(c.volume, 'maybe', 'TV not answering: capability is "maybe", not "no"'); b.closeAll();
}
section('Other platforms: caps never disable anything except Apple TV mute');
{
  const st = makeStore(null); const b = createBackend({ makeSim: stub, store: st, transport: makeTransport(), ports: {} });
  st.set('devices', ['googletv', 'firetv', 'appletv'].map((pf) => ({ id: pf + '-10.9.9.9', platform: pf, name: pf, host: '10.9.9.9', paired: true })));
  for (const [pf, mute] of [['googletv', true], ['firetv', true], ['appletv', false]]) { const c = await call(b, '/api/caps', 'POST', { device: pf + '-10.9.9.9' }); ok(c.volume === 'yes' && c.mute === mute && c.search === true, `${pf}: volume yes, mute ${mute}, search yes (answered without touching the network)`); }
}
section('Google TV: every stage is logged, and a TV that moved to a new address is found again by name');
{
  const atv = await startAndroidTvMock({ pairPort: 16667, remotePort: 16666 }); const ports = { googletv: { pair: 16667, remote: 16666 } };
  const store = makeStore(null); const mkb = (mdns) => createBackend({ makeSim: stub, store, transport: makeTransport({ mdns }), ports });
  let b = mkb([]);
  const d = await call(b, '/api/devices', 'POST', { platform: 'googletv', host: '127.0.0.1' }); await call(b, '/api/pair/start', 'POST', { device: d.id }); await call(b, '/api/pair/finish', 'POST', { device: d.id, code: atv.st.code });
  dlog('MARK0');  ok((await key(b, d, 'home')).ok, 'paired TV: key goes through'); await sleep(100);
  const lg = getLog().split('MARK0').pop();
  for (const st of ['Address', 'TCP + TLS handshake', 'remote_configure from the TV', 'remote_set_active from the TV', 'remote_start (ready)']) ok(lg.includes(st), `Details log has the stage "${st}"`);
  ok(/TLSv1\.[23] \S+ \(client cert sent\) \[TCP \d+ ms, TLS \d+ ms/.test(lg) || (process.env.TRANSPORT || 'node') === 'node', 'Details log shows the TLS version, cipher and timings');
  b.closeAll();
  // the saved address is stale (the router gave the TV another one): nothing answers there, mDNS says where the TV is now
  b = mkb([{ type: '_androidtvremote2._tcp.', host: '127.0.0.1', name: 'Mock TV', port: 16666 }]);
  store.set('devices', [{ id: 'googletv-127.0.0.9', platform: 'googletv', name: 'Mock TV', host: '127.0.0.9', paired: true, ports: ports.googletv }]);
  atv.st.keys.length = 0; dlog('MARK1'); const r = await key(b, { id: 'googletv-127.0.0.9' }, 'back'); await sleep(150);
  ok(r.ok && atv.st.keys.length === 1, 'stale address: found again through mDNS and the key was delivered'); ok(/the TV now answers at 127\.0\.0\.1 \(was 127\.0\.0\.9\)/.test(getLog().split('MARK1').pop()), 'the Details log says which address it switched to');
  b.closeAll();
  // the TV is simply gone: the error lists the stages that were tried, in plain words
  b = mkb([]); const e = await fails(key(b, { id: 'googletv-127.0.0.9' }, 'back') );
  ok(!!e && /Steps:\n1\. Address: OK/.test(e.message) && /TCP connect: FAILED/.test(e.message), 'unreachable TV: the message carries the list of stages (address, TCP connect: FAILED)');
  b.closeAll(); atv.close();
}
console.log = orig; await sleep(50); stopJvm && stopJvm();
const s = summary(); console.log(`\n${s.pass} passed, ${s.fail} failed`); if (s.fail) { console.log(s.fails.join('\n')); process.exit(1); } process.exit(0);
