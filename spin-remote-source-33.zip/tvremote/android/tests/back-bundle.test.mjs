// The real Android bundle (android/www/index.html = what ships in the APK) + Capacitor's real native-bridge.js, with a tiny emulated `androidBridge`.
// Proves the @capacitor/app `backButton` listener is registered through the real bridge and that firing the native backButton event steps back through the app layers.
import http from 'node:http'; import fs from 'node:fs'; import path from 'node:path';
import puppeteer from '../../tools/node_modules/puppeteer-core/lib/esm/puppeteer/puppeteer-core.js';
import { ok, eq, section, summary } from './lib.mjs';
const WWW = path.resolve(new URL('../www/', import.meta.url).pathname);
const NB = fs.readFileSync(path.resolve(new URL('../node_modules/@capacitor/android/capacitor/src/main/assets/native-bridge.js', import.meta.url).pathname), 'utf8');
const srv = http.createServer((q, r) => { r.setHeader('content-type', 'text/html'); r.end(fs.readFileSync(WWW + '/index.html')); });
await new Promise((res) => srv.listen(0, '127.0.0.1', res)); const base = `http://127.0.0.1:${srv.address().port}/`;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const browser = await puppeteer.launch({ executablePath: '/usr/bin/google-chrome', headless: 'new', args: ['--no-sandbox'] });
const p = await browser.newPage(); await p.setViewport({ width: 390, height: 844, isMobile: true, hasTouch: true });
const errs = []; p.on('pageerror', (e) => errs.push(e.message));
await p.evaluateOnNewDocument((NB) => {
  window.__posts = []; window.__backIds = [];
  window.androidBridge = { postMessage(s) {
    const m = JSON.parse(s); window.__posts.push(m.pluginId + '.' + m.methodName);
    if (m.pluginId === 'App' && m.methodName === 'addListener' && m.options && m.options.eventName === 'backButton') window.__backIds.push(m.callbackId);
    if (m.methodName === 'addListener') return;       // like real Android: a listener registration gets no immediate result
    setTimeout(() => window.Capacitor.fromNative({ callbackId: m.callbackId, pluginId: m.pluginId, methodName: m.methodName, success: m.pluginId === 'App', data: {}, error: { message: 'emulated: no TV hardware' }, save: m.methodName === 'addListener' }), 0);
  } };
  window.Capacitor = { PluginHeaders: [{ name: 'App', methods: [{ name: 'addListener', rtype: 'callback' }, { name: 'removeListener' }, { name: 'exitApp' }, { name: 'minimizeApp' }] }, { name: 'TvNative', methods: [] }] };
  window.__fireBack = () => window.__backIds.forEach((id) => window.Capacitor.fromNative({ callbackId: id, pluginId: 'App', methodName: 'backButton', data: { canGoBack: false }, success: true, save: true }));
  (0, eval)(NB);
}, NB);
await p.goto(base, { waitUntil: 'load' }); await p.waitForSelector('#ad-full', { timeout: 8000 }).catch(() => {}); await sleep(1000);
const fire = async () => { await p.evaluate(() => window.__fireBack()); await sleep(250); };
const sheetOn = () => p.$eval('#sheet', (e) => e.classList.contains('on'));
section('Android bundle: @capacitor/app backButton wired through the real Capacitor bridge');
ok(await p.evaluate(() => window.Capacitor.isNativePlatform()), 'the bundle runs as a native Capacitor platform');
ok((await p.evaluate(() => window.__posts)).includes('App.addListener'), 'the app registered an App.addListener call'); eq(await p.evaluate(() => window.__backIds.length), 1, 'exactly one backButton listener is registered');
 ok(!!(await p.$('#ad-full')), 'full-screen ad placeholder is up at launch'); await fire(); ok(!(await p.$('#ad-full')), 'native back #1 closes the full-screen ad placeholder (app not exited)');
await p.evaluate(() => window.__tv.openSettings()); await sleep(300); ok(await sheetOn(), 'Settings open'); await fire(); ok(!(await sheetOn()), 'native back closes Settings');
await p.evaluate(() => window.__tv.openDevices()); await sleep(300); await fire(); ok(!(await sheetOn()), 'native back closes Your TVs');
await p.evaluate(() => document.querySelector('.pairbtn').click()); await sleep(900); ok(await p.$eval('#pscreen', (e) => !e.hidden), 'pairing screen open');
const ip = await p.$('[data-act=psip]'); if (ip) { await ip.click(); await sleep(300); ok(!!(await p.$('#psmodal .ps-modal')), 'a modal is open over the pairing screen'); await fire(); ok(!(await p.$('#psmodal .ps-modal')) && await p.$eval('#pscreen', (e) => !e.hidden), 'native back closes only the modal'); }
await fire(); ok(await p.$eval('#pscreen', (e) => e.hidden), 'native back closes the pairing screen');
await p.evaluate(() => window.__tv.expand(1)); await sleep(1300); ok(await p.evaluate(() => window.__tv.state.locked), 'remote expanded'); await fire(); await sleep(200); ok(!(await p.evaluate(() => window.__tv.state.locked)), 'native back returns to the reel');
const before = await p.evaluate(() => document.body.innerHTML.length); await fire(); await fire(); ok(!(await p.$('#ad-full')) && (await p.evaluate(() => !window.__posts.includes('App.exitApp') && !window.__posts.includes('App.minimizeApp'))), 'on the main reel back does nothing: no exit or minimize call');
eq(errs.length, 0, 'no page errors' + (errs.length ? ': ' + errs[0] : ''));
await browser.close(); srv.close();
const s = summary(); console.log(`\n${s.pass} passed, ${s.fail} failed`); if (s.fail) { console.log(s.fails.join('\n')); process.exit(1); } process.exit(0);
