// SRP-6a (3072-bit group, SHA-512) as used by HomeKit / Apple "Pair-Setup", written to be byte-compatible with the
// srptools library that pyatv uses against real Apple TVs (verified against it in android/tests/oracle).
import { sha512 } from '@noble/hashes/sha2.js';
import { cat, te } from './bytes.js';

const N_HEX = 'FFFFFFFFFFFFFFFFC90FDAA22168C234C4C6628B80DC1CD129024E088A67CC74020BBEA63B139B22514A08798E3404DDEF9519B3CD3A431B302B0A6DF25F14374FE1356D6D51C245E485B576625E7EC6F44C42E9A637ED6B0BFF5CB6F406B7EDEE386BFB5A899FA5AE9F24117C4B1FE649286651ECE45B3DC2007CB8A163BF0598DA48361C55D39A69163FA8FD24CF5F83655D23DCA3AD961C62F356208552BB9ED529077096966D670C354E4ABC9804F1746C08CA18217C32905E462E36CE3BE39E772C180E86039B2783A2EC07A28FB5C55DF06F4C52C9DE2BCBF6955817183995497CEA956AE515D2261898FA051015728E5A8AAAC42DAD33170D04507A33A85521ABDF1CBA64ECFB850458DBEF0A8AEA71575D060C7DB3970F85A6E1E4C7ABF5AE8CDB0933D71E8C94E04A25619DCEE3D2261AD2EE6BF12FFA06D98A0864D87602733EC86A64521F2B18177B200CBBE117577A615D6C770988C0BAD946E208E24FA074E5AB3143DB5BFCE0FD108E4B82D120A93AD2CAFFFFFFFFFFFFFFFF';
export const N = BigInt('0x' + N_HEX), G = 5n;
const bi = (u8) => { let n = 0n; for (const x of u8) n = (n << 8n) | BigInt(x); return n; };
/** minimal big-endian bytes (srptools int_to_bytes: no leading zeros, but at least one byte) */
export const iToB = (n) => { let h = n.toString(16); if (h.length % 2) h = '0' + h; const o = new Uint8Array(h.length / 2); for (let i = 0; i < o.length; i++) o[i] = parseInt(h.substr(i * 2, 2), 16); return o; };
const NLEN = iToB(N).length;
const pad = (n) => { const b = iToB(n); if (b.length >= NLEN) return b; const o = new Uint8Array(NLEN); o.set(b, NLEN - b.length); return o; };
const H = (...parts) => sha512(cat(...parts));
const Hn = (...parts) => bi(H(...parts));
export function powmod(b, e, m) { b %= m; if (b < 0n) b += m; let r = 1n; while (e > 0n) { if (e & 1n) r = (r * b) % m; b = (b * b) % m; e >>= 1n; } return r; }
const K_MULT = Hn(iToB(N), pad(G));

/** Client side. privateKey = 32 random bytes (HomeKit reuses the Ed25519 secret here, any random value works). */
export function srpClient(username, password, privateKey) {
  const a = bi(privateKey), A = powmod(G, a, N), Abytes = iToB(A);
  return {
    publicKey: Abytes,
    /** server public key B (as transmitted) + salt -> { proof (M1), key (K), expectedServerProof (M2) } */
    process(Bbytes, salt) {
      const B = bi(Bbytes);
      if (B % N === 0n) throw new Error('bad server key');
      const u = Hn(pad(A), pad(B));
      const x = Hn(salt, H(te.encode(username + ':' + password)));
      const S = powmod((B - K_MULT * powmod(G, x, N)) % N, a + u * x, N);
      const K = H(iToB(S));
      const M1 = H(iToB(Hn(iToB(N)) ^ Hn(iToB(G))), iToB(Hn(te.encode(username))), salt, Abytes, Bbytes, K);
      return { proof: M1, key: K, expectedServerProof: H(Abytes, M1, K) };
    },
  };
}

/** Server side (used by the on-box mock Apple TV only). */
export function srpServer(username, password, salt, privateKey) {
  const x = Hn(salt, H(te.encode(username + ':' + password))), v = powmod(G, x, N);
  const b = bi(privateKey), B = (K_MULT * v + powmod(G, b, N)) % N, Bbytes = iToB(B);
  return {
    publicKey: Bbytes,
    process(Abytes) {
      const A = bi(Abytes); if (A % N === 0n) throw new Error('bad client key');
      const u = Hn(pad(A), pad(B));
      const S = powmod(A * powmod(v, u, N) % N, b, N);
      const K = H(iToB(S));
      const M1 = H(iToB(Hn(iToB(N)) ^ Hn(iToB(G))), iToB(Hn(te.encode(username))), salt, Abytes, Bbytes, K);
      return { expectedClientProof: M1, key: K, serverProof: (clientProof) => H(Abytes, clientProof, K) };
    },
  };
}
