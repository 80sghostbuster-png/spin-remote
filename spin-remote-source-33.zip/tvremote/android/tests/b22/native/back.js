// Android back button / gesture (Capacitor App plugin). The handler steps back through the app's own layers and never exits the app.
import { App } from '@capacitor/app';
export function installBack(handleBack) {
  return App.addListener('backButton', () => { try { handleBack(); } catch {} });
}
