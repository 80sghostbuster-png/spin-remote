// Transport = the thin native layer (Java plugin "TvNative"). Everything protocol-related is in JS above it.
// Tests swap in a Node implementation via globalThis.__tvTransport (same method names).
import { b64, unb64 } from './bytes.js';
import { dlog } from './dbg.js';

// Every native call is logged (what was asked, how it ended). Key material, certificates and payloads are never logged.
const BRIEF = {
  tcpOpen: (o) => `${o.host}:${o.port} tls=${!!o.tls}${o.tls12 ? ' (TLS 1.2 only)' : ''} clientCert=${!!o.identity} timeout=${o.timeoutMs}ms`,
  mdns: (o) => o.type, tcpScan: (o) => `ports ${(o.ports || []).join(',')} timeout=${o.timeoutMs}ms`, ssdp: (o) => o.st, http: (o) => `${o.method} ${o.url}`,
  probe: (o) => `${o.host} ports ${(o.ports || []).join(',')}`, genIdentity: () => '', prepare: () => '', rsaSignAdb: () => '',
};
const DONE = {
  tcpOpen: (r) => `ok #${r.id}${r.tls ? ' ' + r.tls : ''}${r.peerCert ? ' serverCert=' + r.peerCert.length + 'b64' : ''}`,
  mdns: (r) => `${r.length} result(s) ${r.map((x) => x.name + '@' + x.host).join(', ')}`, tcpScan: (r) => `${r.length} open${r.prefixes ? ' (scanned ' + r.prefixes.join(',') + ')' : ''}: ${r.map((x) => x.host + ':' + x.port).join(', ')}`,
  ssdp: (r) => `${r.length} reply(ies)`, http: (r) => `status ${r.status}`, probe: (r) => r.map((x) => `${x.port}=${x.state}(${x.ms}ms)${x.detail ? ' ' + x.detail : ''}`).join(' ') + (r.ping != null ? ' ping=' + r.ping : ''),
  genIdentity: () => 'generated new RSA-2048 key + certificate', prepare: (r) => JSON.stringify(r), rsaSignAdb: () => 'signed',
};
function logged(t) {
  const w = {};
  for (const k of Object.keys(t)) {
    w[k] = async (...a) => {
      const hot = k === 'tcpRead' || k === 'tcpWrite' || k === 'tcpClose';
      if (!hot && BRIEF[k]) dlog(`native.${k}(${BRIEF[k](a[0] || {})})`);
      const t0 = Date.now();
      try {
        const r = await t[k](...a);
        if (k === 'tcpRead') { if (r && r.data && r.data.length) dlog(`  read #${a[0]} ${r.data.length}B`); else if (r && r.closed) dlog(`  read #${a[0]} closed by peer`); }
        else if (k === 'tcpWrite') dlog(`  write #${a[0]} ${a[1].length}B`);
        else if (k === 'tcpClose') dlog(`  close #${a[0]}`);
        else if (DONE[k]) dlog(`  ← ${DONE[k](r)} (${Date.now() - t0}ms)`);
        return r;
      } catch (e) { dlog(`  ✗ native.${k} failed after ${Date.now() - t0}ms: ${(e && e.message) || e}`); throw e; }
    };
  }
  return w;
}
export function setTransport(t) { globalThis.__tvTransport = logged(t); }
export function T() {
  if (!globalThis.__tvTransport) throw new Error('native transport not available');
  return globalThis.__tvTransport;
}

/** Wrap a Capacitor plugin proxy in the transport interface (binary <-> base64). */
export function capacitorTransport(P) {
  return {
    ssdp: async (o) => (await P.ssdp(o)).results || [],
    mdns: async (o) => { const r = await P.mdns(o); (r.log || []).forEach((l) => dlog('  native: ' + l)); return r.results || []; },
    prepare: async (o) => P.prepare(o || {}),
    probe: async (o) => { const r = await P.probe(o); const a = r.results || []; a.ping = r.ping; return a; },
    http: async (o) => P.http(o),
    tcpScan: async (o) => { const r = await P.tcpScan(o); const a = r.results || []; a.prefixes = r.prefixes || []; return a; },
    genIdentity: async () => P.genIdentity(),
    rsaSignAdb: async (o) => unb64((await P.rsaSignAdb({ keyPkcs8: o.keyPkcs8, token: b64(o.token) })).sig),
    tcpOpen: async (o) => P.tcpOpen(o),                                   // -> {id, peerCert?: base64 DER}
    tcpWrite: async (id, u8) => { await P.tcpWrite({ id, data: b64(u8) }); },
    tcpRead: async (id, timeoutMs) => { const r = await P.tcpRead({ id, timeoutMs }); return { data: r.data ? unb64(r.data) : null, closed: !!r.closed, timeout: !!r.timeout }; },
    tcpClose: async (id) => { try { await P.tcpClose({ id }); } catch (e) { /* already closed */ } },
  };
}
