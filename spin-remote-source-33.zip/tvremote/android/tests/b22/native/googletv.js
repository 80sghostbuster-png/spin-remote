// Google TV / Android TV "remote v2": TLS + protobuf. Pairing on :6467 (6-digit hex code shown on the TV), remote control on :6466.
import { Sock } from './sock.js';
import { T } from './transport.js';
import * as pb from './pb.js';
import { sha256, cat, unhex, err } from './bytes.js';
import { rsaFromCertDer } from './asn1.js';
import { ANDROID_CODES, ANDROIDTV_APPS } from './keys.js';
import { dlog } from './dbg.js';
import { netReport } from './netdiag.js';

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const CONNECT_MS = 9000;                               // phones on busy Wi-Fi need more than 3-4 s for a first connection to a sleepy TV

// Connect with retries (2-3 tries, ~20 s at most).
async function connect(host, port, tls, identity, what, tries = 3, ms = CONNECT_MS) {
  let last; const t0 = Date.now();
  for (let i = 1; i <= tries; i++) {
    try { const s = await Sock.open({ host, port, tls, identity, timeoutMs: ms }); dlog(`${what}: connected on attempt ${i} (${Date.now() - t0} ms)${s.tls ? ' ' + s.tls : ''}`); return s; }
    catch (e) { last = e; dlog(`${what}: attempt ${i} failed: ${e.message}`); if (i === tries || Date.now() - t0 > 19000) break; await sleep(600 * i); }
  }
  throw last;
}

const FEATURES = 615;
const pending = new Map(), sessions = new Map(), dialing = new Map();
const readMsg = (s, ms) => s.waitFor(lenMsg, ms);
const outer = (payload) => pb.frame(cat(pb.fVarint(1, 2), pb.fVarint(2, 200), payload));   // pairing envelope: protocol_version 2, status 200
const pad2 = (h) => (h.length % 2 ? '0' + h : h);
/** Build 21: a TV can get its own client certificate (after it rejected the shared one, or after "reset this TV"); other TVs keep theirs. */
const idKey = (dev) => `atv.identity.${dev.id}`;
async function identityFor(store, dev) { return (dev && store.get(idKey(dev))) || ensureIdentity(store); }
async function freshIdentity(store, dev) { const i = await T().genIdentity(); store.set(idKey(dev), i); dlog(`pairing: new client certificate for ${dev.name || dev.host}`); return i; }
async function ensureIdentity(store) { let i = store.get('atv.identity'); if (!i) { i = await T().genIdentity(); store.set('atv.identity', i); } return i; }
/** One varint-length-prefixed protobuf message from the stream buffer (or null while incomplete). */
function lenMsg(b) {
  let len = 0, mul = 1, i = 0, done = false;
  while (i < b.length) { const x = b[i++]; len += (x & 127) * mul; mul *= 128; if (!(x & 128)) { done = true; break; } }
  return !done || i + len > b.length ? null : { n: i + len, v: b.slice(i, i + len) };
}

export const portReport = (host) => netReport(host, [{ port: 6467, label: 'pairing' }, { port: 6466, label: 'control' }, { port: 8009, label: 'Cast' }, { port: 8008, label: 'Cast-HTTP' }, { port: 5555, label: 'ADB' }], {
  closed: 'The TV answers on other ports but not on 6467 (the Android TV Remote service). Wake the TV with its own remote (a TV in standby often leaves 6467 silent) and try again. If it stays silent, restart the TV (Settings → System → Restart).',
  open: 'Port 6467 is open, so the problem happens after connecting (TLS or pairing).' });

const GLOBAL_SEARCH_LINK = 'intent:#Intent;action=android.search.action.GLOBAL_SEARCH;end';

/* ---- build 21: where is this TV right now? ----
 * The saved address can be stale (DHCP gave the TV a new IP, a mesh node, two network bands), so pairing and control try,
 * in order: the address that worked last in this app run, the saved address, then every address a FRESH mDNS lookup returns
 * for this TV's name (IPv4 first), each with the port that lookup advertised. Every attempt is logged with its stage. */
const live = new Map();
const forgotten = new Set(), drops = new Map();   // 3 sessions in a row dropped within 15 s = the TV forgot this phone                              // TVs that dropped a fresh session within 15 s (a TV that ignores a stale pairing does this)                                   // dev.id -> { host, remote, pair } that worked last (this app run)
const isV4 = (h) => /^\d+\.\d+\.\d+\.\d+$/.test(h);
async function freshAddrs(dev, log) {
  try {
    const hits = await T().mdns({ type: '_androidtvremote2._tcp.', timeoutMs: 2500 });
    const mine = hits.filter((r) => r.host && (r.host === dev.host || !dev.name || !r.name || r.name === dev.name));
    const out = [];
    for (const r of mine) for (const h of (r.hosts && r.hosts.length ? r.hosts : [r.host])) if (h && !out.some((x) => x.host === h)) out.push({ host: h, remote: r.port || 6466, pair: (r.port || 6466) + 1, how: 'fresh mDNS' });
    out.sort((a, b) => isV4(b.host) - isV4(a.host));
    log('mDNS lookup', true, out.length ? out.map((x) => `${x.host}:${x.remote}`).join(', ') : `no answer for "${dev.name || dev.host}"`);
    return out;                                              // IPv4 first, then IPv6
  } catch (e) { log('mDNS lookup', false, (e && e.message) || String(e)); return []; }
}
function savedAddrs(dev) {
  const out = [], add = (a) => { if (a && a.host && !out.some((x) => x.host === a.host && x.remote === a.remote)) out.push(a); };
  const sv = { host: dev.host, remote: (dev.ports && dev.ports.remote) || 6466, pair: (dev.ports && dev.ports.pair) || 6467, how: 'saved' };
  add(sv); const l = live.get(dev.id); if (l) add({ ...sv, ...l, how: 'last working' });
  return out;
}
const short = (w) => String(w || 'no answer').replace(/^Couldn’t connect to [^:]+:\d+: /, '').replace(/^TCP connect failed: /, '');
export const TV_SIDE_TIPS = 'Things on the TV side that can block this:\n• The TV is asleep or in deep standby: wake it with its own remote.\n• The "Android TV Remote Service" is turned off or out of date: on the TV, Settings → Apps → See all apps → Show system apps → Android TV Remote Service → turn it on, update it in Play Store, or Clear data, then restart the TV.\n• The TV is on a guest network, a different Wi-Fi name, or the router blocks devices from seeing each other (AP / client isolation): put phone and TV on the same main Wi-Fi.\n• Mesh Wi-Fi: phone and TV on different mesh points sometimes cannot reach each other; restart the TV and the nearest mesh point.\n• A VPN or "private DNS"/firewall app on the phone.\nIf other remote apps also can’t connect to this TV, the cause is on the TV or the network, not in this app.';

export const gtv = {
  async probe(host, ports = { pair: 6467 }) {              // for "Add by IP": is the Android TV remote service there?
    let why = '';
    const s = await connect(host, ports.pair, false, null, `probe ${host}:${ports.pair}`).catch((e) => { why = (e && e.message) || ''; return null; });   // plain TCP: a TV that demands a client certificate must not look "absent"
    if (!s) throw err(`Couldn’t reach a Google TV at ${host} (port ${ports.pair}): ${why || 'no answer'}\n1. TCP connect to port ${ports.pair}: FAILED — ${(why || 'no answer').replace(/^Couldn’t connect to [^:]+:\d+: /, '').replace(/^TCP connect failed: /, '')}\n2. TLS handshake: not tried\n3. Pairing request: not tried\n${await portReport(host)}\nCheck the IP address (TV: Settings → Network), that the TV is on, and that this phone is on the same Wi-Fi.`, 'unreachable');
    s.close(); return true;
  },
  async pairStart(dev, store) {
    let ident = await identityFor(store, dev);
    const old = pending.get(dev.id); if (old) old.close();
    let pp = (dev.ports && dev.ports.pair) || 6467;
    // Every step is recorded so that Details can say exactly where it stopped: TCP → TLS → pairing request → TV shows the code.
    const steps = [];
    const S = (name, ok, txt) => { const line = `${steps.length + 1}. ${name}: ${ok ? 'OK' : 'FAILED'}${txt ? ' — ' + txt : ''}`; steps.push(line); dlog('pairing step ' + line); };
    const die = async (msg, code) => { throw err(`${msg}\n\nSteps (${dev.host}:${pp}):\n${steps.join('\n')}\n\n${await portReport(dev.host)}`, code); };
    dlog(`pairing: ${dev.host}:${pp}`);
    const tcpOk = null;
    let why = '', s = null, at = null, tlsRefused = false;
    const mlog = []; const freshP = freshAddrs(dev, (n, ok, t) => mlog.push([n, ok, t])); let freshDone = null;
    const fresh = { then: (f, r) => (freshDone || (freshDone = freshP.then((v) => { mlog.forEach((x) => S(...x)); return v; }))).then(f, r) };                 // look the TV up by name at the same time (costs nothing if the saved address works)
    const tryPair = async (a, tries, ms) => {
      for (const port of [a.pair]) {
        dlog(`pairing: trying ${a.host}:${port} (${a.how})`);
        const x = await connect(a.host, port, true, ident, `pairing ${a.host}:${port}`, tries, ms).catch((e) => { why = (e && e.message) || String(e); return null; });
        if (x) { at = { ...a, pair: port }; return x; }
        if (/TLS handshake/.test(why)) { tlsRefused = true; S('TCP connect', true, `connected to ${a.host}:${port} (${a.how})`); S('TLS handshake (self-signed cert, client cert sent)', false, why.replace(/^.*?TLS handshake/, 'TLS handshake')); }
        else S('TCP connect (3 tries, 9 s each)', false, `${short(why)} [${a.host}:${port}, ${a.how}]`);
      }
      return null;
    };
    for (const a of savedAddrs(dev)) { s = await tryPair(a, 2, 12000); if (s) break; }
    if (!s && tlsRefused) { ident = await freshIdentity(store, dev); tlsRefused = false; for (const a of savedAddrs(dev)) { s = await tryPair({ ...a, how: a.how + ', new certificate' }, 1, 12000); if (s) break; } }
    if (!s) for (const a of (await fresh)) { if (savedAddrs(dev).some((x) => x.host === a.host && x.pair === a.pair)) continue; s = await tryPair(a, 2, 12000); if (s) break; }
    if (!s) {                                                                       // the pairing port is silent: maybe the TV already trusts this phone (only the control port answers)
      for (const a of [...savedAddrs(dev), ...(await fresh)]) {
        try { const ses = await gtv._session({ ...dev, host: a.host, ports: { ...(dev.ports || {}), remote: a.remote } }, store, true); if (ses) { live.set(dev.id, a); S(`Control ${a.host}:${a.remote}`, true, 'the TV already trusts this phone'); return { status: 'paired' }; } }
        catch (e) { S(`Control ${a.host}:${a.remote}`, false, short(e && e.message && e.message.split('\n')[0])); }
      }
      if (tlsRefused) await die(`The Google TV answered but refused the secure connection.\n\n${TV_SIDE_TIPS}`, 'protocol');
      const pr = await portReport(dev.host).catch(() => '');
      if (/answers on other ports but not on 6467/.test(pr) && /(6466|8009|8008)[^\n]*OPEN/.test(pr)) await die(`The TV is on the network but isn’t accepting remote apps (its pairing port 6467 is closed).\n\n${TV_SIDE_TIPS}`, 'tv_refuses');
      await die(`Couldn’t reach the Google TV (pairing port 6467 and control port 6466 both silent).\n\n${TV_SIDE_TIPS}`, 'unreachable');
    }
    live.set(dev.id, at);
    if (tcpOk !== true) S('TCP connect', true, 'connected');
    S('TLS handshake (self-signed cert, client cert sent)', true, s.tls || 'ok');
    if (!s.peerCert) { s.close(); S('TV certificate', false, 'the TV sent no certificate'); await die('The TV did not present a certificate', 'protocol'); }
    pending.set(dev.id, s); s.serverCert = s.peerCert;
    try {
      dlog('pairing: sent pairing_request');
      await s.write(outer(pb.fMsg(10, cat(pb.fString(1, 'atvremote'), pb.fString(2, 'Spin Remote')))));
      const status = (m) => { const st = pb.field(m, 2); if (st && st.v !== 200) throw err(`TV refused pairing (status ${st.v})`, st.v === 402 ? 'bad_code' : 'protocol'); };
      let m = pb.decode(await readMsg(s, 8000)); status(m);
      if (!pb.field(m, 11)) throw err('Unexpected reply from the TV while pairing', 'protocol');
      S('Pairing request', true, 'the TV accepted it');
      const enc = cat(pb.fVarint(1, 3), pb.fVarint(2, 6));
      await s.write(outer(pb.fMsg(20, cat(pb.fMsg(1, enc), pb.fVarint(3, 1)))));
      dlog('pairing: got options'); m = pb.decode(await readMsg(s, 8000)); status(m);
      if (!pb.field(m, 20)) throw err('Unexpected reply from the TV (options)', 'protocol');
      await s.write(outer(pb.fMsg(30, cat(pb.fMsg(1, enc), pb.fVarint(2, 1)))));
      m = pb.decode(await readMsg(s, 8000)); status(m);
      if (!pb.field(m, 31)) throw err('Unexpected reply from the TV (configuration)', 'protocol');
      S('Code on the TV', true, 'options + configuration accepted; the TV is showing the code');
    } catch (e) { dlog('pairing failed: ' + e.message); s.close(); pending.delete(dev.id); S('Pairing request / options', false, e.message); await die(`The Google TV connected but did not complete pairing.`, e.code === 'bad_code' ? 'protocol' : (e.code || 'protocol')); }
    return { status: 'code', kind: 'hex', length: 6, message: 'Look at your TV: a 6-character code (letters A–F and numbers) is on the screen. Type it below, exactly as shown. Phone and TV must be on the same Wi-Fi. No code on the TV? Close this and tap PAIR again.', hint: '' };
  },
  async pairFinish(dev, code, store) {
    const s = pending.get(dev.id); if (!s) throw err('Pairing session expired — start again.', 'protocol');
    code = (code || '').trim().toUpperCase();
    if (!/^[0-9A-F]{6}$/.test(code)) throw err('The code is 6 characters (0-9, A-F).', 'bad_code');
    const ident = await identityFor(store, dev), srv = rsaFromCertDer(s.serverCert);
    const h = await sha256(cat(unhex(ident.modulusHex), unhex(pad2(ident.exponentHex)), srv.n, srv.e.length ? srv.e : unhex('010001'), unhex(code.slice(2))));
    if (h[0] !== parseInt(code.slice(0, 2), 16)) throw err('That code is not right — check the TV and try again.', 'bad_code');
    dlog('pairing: sending secret'); await s.write(outer(pb.fMsg(40, pb.fBytes(1, h))));
    let m;
    try { m = pb.decode(await readMsg(s, 8000)); } catch (e) { pending.delete(dev.id); s.close(); throw err(e.code === 'closed' ? 'The TV rejected that code.' : e.message, 'bad_code'); }
    const st = pb.field(m, 2);
    if ((st && st.v !== 200) || !pb.field(m, 41)) { pending.delete(dev.id); s.close(); throw err('The TV rejected that code.', 'bad_code'); }
    pending.delete(dev.id); s.close();
    return { status: 'paired' };
  },

  session(dev, store) {                                                          // one connect at a time per TV: presses arriving while it opens wait for it instead of dialing again
    const cur = sessions.get(dev.id); if (cur && cur.ready && !cur.sock.closed) return Promise.resolve(cur);
    let p = dialing.get(dev.id); if (!p) { p = gtv._session(dev, store).finally(() => dialing.delete(dev.id)); dialing.set(dev.id, p); }
    return p;
  },
  async _session(dev, store, probeOnly = false) {
    const ident = await identityFor(store, dev);
    const steps = [], t0 = Date.now(); let why = '', rejected = false;
    const S = (name, ok, txt) => { const line = `${steps.length + 1}. ${name}: ${ok ? 'OK' : 'FAILED'}${txt ? ' — ' + txt : ''} (+${Date.now() - t0} ms)`; steps.push(line); dlog('control step ' + line); };
    // Stages: saved/last address → (if silent or refused) fresh mDNS by name, every IPv4 address → TCP+TLS → remote_configure → set_active → remote_start.
    let sock = null, host = dev.host, rp = (dev.ports && dev.ports.remote) || 6466;
    const tryCtl = async (a, tries, ms) => {
      const x = await connect(a.host, a.remote, true, ident, `control ${a.host}:${a.remote}`, tries, ms).catch((e) => { why = (e && e.message) || String(e); return null; });
      if (!x) S(/TLS handshake/.test(why) ? 'TLS handshake (self-signed cert, client cert sent)' : 'TCP connect', false, `${short(why)} [${a.host}:${a.remote}, ${a.how}]`);
      else if (a.how === 'fresh mDNS') S('mDNS lookup', true, `the TV now answers at ${a.host} (was ${dev.host}), port ${a.remote}`);
      if (!x && /TLS handshake/.test(why) && a.how === 'saved') rejected = true;
      if (x) { host = a.host; rp = a.remote; if (!probeOnly) live.set(dev.id, { ...live.get(dev.id), ...a }); }
      return x;
    };
    S('Address', true, `${dev.host}:${rp}${dev.name ? ' (' + dev.name + ')' : ''}`);
    const saved = probeOnly ? [{ host: dev.host, remote: rp, how: 'candidate' }] : savedAddrs(dev).filter((a) => a.how === 'saved');
    for (const a of saved) { sock = await tryCtl(a, probeOnly ? 1 : 2, probeOnly ? 6000 : 12000); if (sock) break; }
    if (!sock && !probeOnly) for (const a of await freshAddrs(dev, S)) { if (saved.some((x) => x.host === a.host && x.remote === a.remote)) continue; sock = await tryCtl(a, 2, 12000); if (sock) break; }
    if (!sock) {
      // A TLS refusal on 6466 means the TV no longer trusts this phone's pairing (TV reset, remote service data cleared): say "not paired" so PAIR shows a fresh code on 6467.
      if (rejected) throw err(`The TV refused this phone’s saved pairing (not paired any more). Pair again: a new code will show on the TV.\n\nSteps:\n${steps.join('\n')}`, 'not_paired');
      throw err(`Can’t connect to the TV at ${host}:${rp}: ${why}\n\nSteps:\n${steps.join('\n')}\n\n${TV_SIDE_TIPS}`, 'unreachable');
    }
    S('TCP + TLS handshake', true, sock.tls || 'ok');
    const ses = { sock, t0: Date.now(), ime: [0, 0], imeSeq: 0, ready: false, features: FEATURES };
    sessions.set(dev.id, ses);
    const send = (inner) => sock.write(pb.frame(inner));
    ses.send = send;
    let onReady, onFail; const ready = new Promise((a, b) => { onReady = a; onFail = b; });
    ses.run = (async () => {
      try {
        for (;;) {
          let raw; try { raw = await readMsg(sock, 30000); } catch (e) { if (e.code === 'timeout') continue; throw e; }
          const m = pb.decode(raw), f = m[0]; if (!f) continue;
          if (f.f === 1) {                                              // remote_configure: reply with the features both sides support
            S('remote_configure from the TV', true, 'answering');
            const sup = pb.field(pb.decode(f.v), 1); ses.features = FEATURES & (sup ? sup.v : FEATURES);
            await send(pb.fMsg(1, cat(pb.fVarint(1, ses.features), pb.fMsg(2, cat(pb.fVarint(3, 1), pb.fString(4, '1'), pb.fString(5, 'atvremote'), pb.fString(6, '1.0.0'))))));
          } else if (f.f === 2) { S('remote_set_active from the TV', true, 'answering'); await send(pb.fMsg(2, pb.fVarint(1, ses.features))); }   // set_active
          else if (f.f === 8) { ses.pings = (ses.pings || 0) + 1; const v = pb.field(pb.decode(f.v), 1); await send(pb.fMsg(9, pb.fVarint(1, v ? v.v : 0))); }  // ping  // ping
          else if (f.f === 21) { const d = pb.decode(f.v); ses.ime = [(pb.field(d, 1) || { v: 0 }).v, (pb.field(d, 2) || { v: 0 }).v]; ses.imeSeq++; }
          else if (f.f === 22) { ses.imeSeq++; }                           // remote_ime_show_request: a text field just got focus on the TV
          else if (f.f === 40) { S('remote_start (ready)', true, 'the TV is listening'); ses.ready = true; onReady(); }
          else if (f.f === 3) { dlog('control: TV sent remote_error ' + Array.from(f.v).slice(0, 40).join(',')); }
          else dlog('control: TV message field ' + f.f);
        }
      } catch (e) { dlog('control: session ended: ' + ((e && e.message) || e) + ` after ${Date.now() - ses.t0} ms`); ses.dead = e; const age = Date.now() - ses.t0, early = ses.ready && age > 4000 && age < 15000 && !ses.pings && e && e.code === 'closed'; /* lived a few seconds, the TV never pinged, then hung up */ drops.set(dev.id, early ? (drops.get(dev.id) || 0) + 1 : 0); if (early && drops.get(dev.id) >= 3) { forgotten.add(dev.id); drops.set(dev.id, 0); dlog('control: the TV dropped a brand-new session: treating the saved pairing as forgotten'); } sessions.delete(dev.id); if (!ses.ready) onFail(e.code === 'closed' ? err('The TV closed the connection — it is not paired with this phone. Pair again.', 'not_paired') : e); }
    })();
    try { await Promise.race([ready, new Promise((_, rej) => setTimeout(() => rej(err('The TV connected but did not start the remote session within 8 s (it may not trust this phone: pair again).', 'timeout')), 8000))]); }
    catch (e) { S('Remote session start', false, e.message); sock.close(); sessions.delete(dev.id); e.message += `\n\nSteps:\n${steps.join('\n')}`; throw e; }
    return ses;
  },
  async _do(dev, store, fn) {
    for (let attempt = 0; ; attempt++) {
      let ses; try { ses = await gtv.session(dev, store); await fn(ses); return; }
      catch (e) { if (e.code === 'not_paired' || attempt >= 1) throw e; const c = sessions.get(dev.id); if (c) { c.sock.close(); sessions.delete(dev.id); } }
    }
  },
  /** Open the TLS control socket ahead of the first press. */
  async warm(dev, store) { await gtv.session(dev, store); },
  hasAck: false,                                                                 // remote v2 has no per-key acknowledgement: "transmitted" is the measurable point
  async key(dev, key, store, o = {}) {
    const code = ANDROID_CODES[key]; if (!code) throw err(`No "${key}" key on Android TV`, 'bad_key');
    await gtv._do(dev, store, async (s) => { await s.send(pb.fMsg(10, cat(pb.fVarint(1, code), pb.fVarint(2, 3)))); if (o.trace) o.trace.transmitted(); });
    return `remote_key_inject KEYCODE ${code} (${key})`;
  },
  async text(dev, text, store, o = {}) {
    await gtv._do(dev, store, async (s) => { await s.send(pb.fMsg(21, cat(pb.fVarint(1, s.ime[0]), pb.fVarint(2, s.ime[1]), pb.fMsg(3, cat(pb.fVarint(1, 1), pb.fMsg(2, cat(pb.fVarint(1, Math.max(0, [...text].length - 1)), pb.fVarint(2, Math.max(0, [...text].length - 1)), pb.fString(3, text)))))))); if (o.trace) o.trace.transmitted(); });
    return `remote_ime_batch_edit "${text}"`;
  },
  /** Voice search: press the TV's search key, wait for the TV to say a text field has focus (remote_ime_show_request / batch edit), then type the words
   *  with remote_ime_batch_edit. Many Google TVs open the Assistant (a listening screen, no text box) for the search key: then the standard Android
   *  "global search" request is sent as an app link and we wait again. Nothing is typed without the TV's text-field signal; the caller is told so. */
  async search(dev, text, store, o = {}) {
    const code = ANDROID_CODES.search; let ses;
    const waitField = async (ms) => { const end = Date.now() + ms; while (ses.imeSeq === ses._seq0 && Date.now() < end && !ses.sock.closed) await new Promise((r) => setTimeout(r, 40)); return ses.imeSeq !== ses._seq0; };
    await gtv._do(dev, store, async (s) => { ses = s; const young = 600 - (Date.now() - s.t0); if (young > 0) await new Promise((r) => setTimeout(r, young)); s._seq0 = s.imeSeq; await s.send(pb.fMsg(10, cat(pb.fVarint(1, code), pb.fVarint(2, 3)))); if (o.trace) o.trace.transmitted(); });
    let how = 'KEYCODE_SEARCH (84)';
    if (!(await waitField(o.fieldWaitMs || 3000))) {
      dlog('gtv: search key opened no text field; trying the global search screen');
      how = 'global search screen';
      try { await gtv._do(dev, store, async (s) => { ses = s; s._seq0 = s.imeSeq; await s.send(pb.fMsg(90, pb.fString(1, GLOBAL_SEARCH_LINK))); }); } catch (e) { dlog('gtv: global search link failed: ' + e.message); }
      if (!(await waitField(o.fieldWaitMs || 3000))) throw err('No search box opened on your TV.', 'no_text_field');
    }
    await new Promise((r) => setTimeout(r, o.settleMs == null ? 150 : o.settleMs));
    const w = await gtv.text(dev, text, store, o);
    o.how = 'typed';
    return `${how} then ${w}`;
  },
  async launch(dev, app, store) {
    const link = ANDROIDTV_APPS[app] || (/^(https?|market|[a-z]+):\/\//.test(app) ? app : null); if (!link) throw err(`Unknown app "${app}"`, 'bad_app');
    await gtv._do(dev, store, (s) => s.send(pb.fMsg(90, pb.fString(1, link))));
    return `app_link_launch ${link}`;
  },
  /** Hidden "reset this TV": forget everything this app holds for ONE Google TV (its own certificate, last address, open sessions). */
  reset(dev, store, auto = false) { store.del(idKey(dev)); forgotten.delete(dev.id); if (auto) dlog('reset: the TV no longer accepts this phone’s pairing; it will be paired fresh'); live.delete(dev.id); const ses = sessions.get(dev.id); if (ses) ses.sock.close(); sessions.delete(dev.id); const p = pending.get(dev.id); if (p) p.close(); pending.delete(dev.id); dlog(`reset: Google TV ${dev.name || dev.host} forgotten`); },
  forgot(id) { return forgotten.has(id); },
  closeAll() { for (const s of sessions.values()) s.sock.close(); sessions.clear(); for (const s of pending.values()) s.close(); pending.clear(); },
};
