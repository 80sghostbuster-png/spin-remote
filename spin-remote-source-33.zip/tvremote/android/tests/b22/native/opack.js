// OPACK (Apple's compact serialization used by the Companion protocol). Port of the format implemented in pyatv/support/opack.py.
// Strings -> JS strings, byte blobs -> Uint8Array, ints -> Number (or BigInt when > 2^53), floats -> {f64: x}.
import { te, td } from './bytes.js';

export const f64 = (x) => ({ __f64: x });
const le = (n, size) => { const o = new Uint8Array(size); let v = BigInt(n); for (let i = 0; i < size; i++) { o[i] = Number(v & 255n); v >>= 8n; } return o; };
const cat2 = (arr) => { let n = 0; for (const p of arr) n += p.length; const o = new Uint8Array(n); let i = 0; for (const p of arr) { o.set(p, i); i += p.length; } return o; };

export function pack(v) {
  if (v === null || v === undefined) return Uint8Array.of(0x04);
  if (v === true) return Uint8Array.of(0x01);
  if (v === false) return Uint8Array.of(0x02);
  if (typeof v === 'bigint' || typeof v === 'number' && Number.isInteger(v)) {
    const n = BigInt(v);
    if (n < 0n) throw new Error('negative ints unsupported');
    if (n < 0x28n) return Uint8Array.of(Number(n) + 8);
    if (n <= 0xffn) return cat2([Uint8Array.of(0x30), le(n, 1)]);
    if (n <= 0xffffn) return cat2([Uint8Array.of(0x31), le(n, 2)]);
    if (n <= 0xffffffffn) return cat2([Uint8Array.of(0x32), le(n, 4)]);
    return cat2([Uint8Array.of(0x33), le(n, 8)]);
  }
  if (v && v.__f64 !== undefined) { const o = new Uint8Array(9); o[0] = 0x36; new DataView(o.buffer).setFloat64(1, v.__f64, true); return o; }
  if (typeof v === 'number') { const o = new Uint8Array(9); o[0] = 0x36; new DataView(o.buffer).setFloat64(1, v, true); return o; }
  if (typeof v === 'string') {
    const e = te.encode(v);
    if (e.length <= 0x20) return cat2([Uint8Array.of(0x40 + e.length), e]);
    if (e.length <= 0xff) return cat2([Uint8Array.of(0x61), le(e.length, 1), e]);
    if (e.length <= 0xffff) return cat2([Uint8Array.of(0x62), le(e.length, 2), e]);
    return cat2([Uint8Array.of(0x63), le(e.length, 3), e]);
  }
  if (v instanceof Uint8Array) {
    if (v.length <= 0x20) return cat2([Uint8Array.of(0x70 + v.length), v]);
    if (v.length <= 0xff) return cat2([Uint8Array.of(0x91), le(v.length, 1), v]);
    if (v.length <= 0xffff) return cat2([Uint8Array.of(0x92), le(v.length, 2), v]);
    return cat2([Uint8Array.of(0x93), le(v.length, 4), v]);
  }
  if (Array.isArray(v)) return cat2([Uint8Array.of(0xd0 + Math.min(v.length, 0xf)), ...v.map(pack), ...(v.length >= 0xf ? [Uint8Array.of(3)] : [])]);
  if (typeof v === 'object') {
    const ks = Object.keys(v);
    return cat2([Uint8Array.of(0xe0 + Math.min(ks.length, 0xf)), ...ks.flatMap((k) => [pack(k), pack(v[k])]), ...(ks.length >= 0xf ? [Uint8Array.of(3)] : [])]);
  }
  throw new Error('opack: unsupported ' + typeof v);
}

const rdLE = (d, o, n) => { let v = 0n; for (let i = n - 1; i >= 0; i--) v = (v << 8n) | BigInt(d[o + i]); return v; };
const num = (b) => (b <= BigInt(Number.MAX_SAFE_INTEGER) ? Number(b) : b);

/** returns [value, nextOffset]; objs = shared back-reference table */
function un(d, o, objs) {
  const t = d[o]; let value, next, add = true;
  if (t === 1) { value = true; next = o + 1; add = false; }
  else if (t === 2) { value = false; next = o + 1; add = false; }
  else if (t === 4) { value = null; next = o + 1; add = false; }
  else if (t === 5) { value = d.slice(o + 1, o + 17); next = o + 17; }
  else if (t === 6) { value = num(rdLE(d, o + 1, 8)); next = o + 9; }
  else if (t >= 0x08 && t <= 0x2f) { value = t - 8; next = o + 1; add = false; }
  else if (t === 0x35) { value = new DataView(d.buffer, d.byteOffset + o + 1, 4).getFloat32(0, true); next = o + 5; }
  else if (t === 0x36) { value = new DataView(d.buffer, d.byteOffset + o + 1, 8).getFloat64(0, true); next = o + 9; }
  else if ((t & 0xf0) === 0x30) { const n = 2 ** (t & 0xf); value = num(rdLE(d, o + 1, n)); next = o + 1 + n; }
  else if (t >= 0x40 && t <= 0x60) { const l = t - 0x40; value = td.decode(d.subarray(o + 1, o + 1 + l)); next = o + 1 + l; }
  else if (t > 0x60 && t <= 0x64) { const nb = t & 0xf, l = Number(rdLE(d, o + 1, nb)); value = td.decode(d.subarray(o + 1 + nb, o + 1 + nb + l)); next = o + 1 + nb + l; }
  else if (t >= 0x70 && t <= 0x90) { const l = t - 0x70; value = d.slice(o + 1, o + 1 + l); next = o + 1 + l; }
  else if (t >= 0x91 && t <= 0x94) { const nb = 1 << ((t & 0xf) - 1), l = Number(rdLE(d, o + 1, nb)); value = d.slice(o + 1 + nb, o + 1 + nb + l); next = o + 1 + nb + l; }
  else if ((t & 0xf0) === 0xd0) {
    const c = t & 0xf; value = []; let p = o + 1; add = false;
    if (c === 0xf) { while (d[p] !== 3) { const [x, q] = un(d, p, objs); value.push(x); p = q; } p++; }
    else for (let i = 0; i < c; i++) { const [x, q] = un(d, p, objs); value.push(x); p = q; }
    next = p;
  } else if ((t & 0xe0) === 0xe0) {
    const c = t & 0xf; value = {}; let p = o + 1; add = false;
    if (c === 0xf) { while (d[p] !== 3) { const [k, q] = un(d, p, objs); const [x, r] = un(d, q, objs); value[k] = x; p = r; } p++; }
    else for (let i = 0; i < c; i++) { const [k, q] = un(d, p, objs); const [x, r] = un(d, q, objs); value[k] = x; p = r; }
    next = p;
  } else if (t >= 0xa0 && t <= 0xc0) { value = objs[t - 0xa0]; next = o + 1; add = false; }
  else if (t >= 0xc1 && t <= 0xc4) { const n = t - 0xc0; value = objs[Number(rdLE(d, o + 1, n))]; next = o + 1 + n; add = false; }
  else throw new Error('opack: unknown tag 0x' + t.toString(16));
  if (add && !objs.some((x) => (x instanceof Uint8Array && value instanceof Uint8Array ? x.length === value.length && x.every((b, i) => b === value[i]) : x === value))) objs.push(value);
  return [value, next];
}
export function unpack(d) { const [v, n] = un(d, 0, []); return [v, d.subarray(n)]; }
