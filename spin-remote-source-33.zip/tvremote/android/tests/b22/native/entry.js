// Capacitor glue (only bundled into the Android build): picks the native backend when running inside the app.
import { Capacitor, registerPlugin } from '@capacitor/core';
import { capacitorTransport } from './transport.js';
import { createBackend, makeStore } from './backend.js';
import { setPlugin } from './plug.js';

export function nativeInit(makeSim) {
  if (!Capacitor.isNativePlatform()) return null;
  const plugin = registerPlugin('TvNative'); setPlugin(plugin);
  const transport = capacitorTransport(plugin);
  return createBackend({ makeSim, store: makeStore(window.localStorage), transport });
}
