// Command timing (dev logs only). One trace per button press:  pressed -> queued -> transmitted -> TV ack (only where the protocol has one) / failed.
// Printed to the in-app debug log, the console (Capacitor mirrors the console to logcat in debug builds, tag Capacitor/Console) and, when the plugin has it, native logcat (tag SpinPerf).
import { dlog } from './dbg.js';
import { getPlugin } from './plug.js';
let seq = 0; const recent = [];
const r1 = (x) => Math.round(x * 10) / 10;
export function perfNew({ platform, key, pressed }) {
  const t = { id: ++seq, platform, key, t0: pressed != null && pressed <= performance.now() && performance.now() - pressed < 5000 ? pressed : performance.now(), q: null, tx: null, ack: null, fail: null, done: false };
  let txRes; t.txP = new Promise((res) => { txRes = res; });
  const fin = () => { if (t.done) return; t.done = true; txRes(); report(t); };
  t.queued = () => { if (t.q == null) t.q = performance.now(); };
  t.transmitted = () => { if (t.tx == null) { t.tx = performance.now(); txRes(); } };
  t.acked = () => { if (t.ack == null) { t.ack = performance.now(); } fin(); };
  t.failed = (e) => { t.fail = performance.now(); t.why = (e && e.message || String(e)).split('\n')[0].slice(0, 80); fin(); };
  t.noAck = () => { fin(); };                                            // protocol has no per-command ack: the transmit time is the measurement
  return t;
}
const verbose = () => { try { return globalThis.__PERF_ECHO === true || (typeof localStorage !== 'undefined' && localStorage.getItem('spin.perf') === '1'); } catch { return false; } };
export const txMs = (t) => (t.tx != null ? r1(t.tx - t.t0) : null);
function report(t) {
  const d = (x) => (x == null ? '-' : r1(x - t.t0) + 'ms');
  const line = t.fail != null ? `[perf] #${t.id} ${t.platform} ${t.key} FAILED after ${d(t.fail)} (${t.why}) · queued ${d(t.q)} · tx ${d(t.tx)}`
    : `[perf] #${t.id} ${t.platform} ${t.key} pressed→queued ${d(t.q)} · →transmitted ${d(t.tx)} · →TV ack ${t.ack != null ? d(t.ack) : 'n/a (protocol has none)'}`;
  recent.push({ id: t.id, platform: t.platform, key: t.key, queued: t.q == null ? null : r1(t.q - t.t0), tx: t.tx == null ? null : r1(t.tx - t.t0), ack: t.ack == null ? null : r1(t.ack - t.t0), failed: t.fail != null }); if (recent.length > 200) recent.shift();
  dlog(line);                                                          // the in-app debug log always has it (in memory, cheap)
  // console + logcat only for failures, or when asked for (localStorage spin.perf = 1): every press must not pay for extra bridge calls
  if (t.fail != null || verbose()) { try { console.log(line); } catch { /* no console */ } try { const p = getPlugin(); if (p && p.perfLog) p.perfLog({ line }).catch(() => {}); } catch { /* best effort */ } }
}
export const perfRecent = () => recent.slice();
