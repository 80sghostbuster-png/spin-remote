// Small byte helpers shared by the native TV protocols (no dependencies).
export const te = new TextEncoder(), td = new TextDecoder();
export const cat = (...parts) => { let n = 0; for (const p of parts) n += p.length; const o = new Uint8Array(n); let i = 0; for (const p of parts) { o.set(p, i); i += p.length; } return o; };
export const b64 = (u8) => { let s = ''; for (let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000)); return btoa(s); };
export const unb64 = (s) => { const bin = atob(s || ''), o = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) o[i] = bin.charCodeAt(i); return o; };
export const hex = (u8) => [...u8].map((x) => x.toString(16).padStart(2, '0')).join('');
export const unhex = (h) => { if (h.length % 2) h = '0' + h; const o = new Uint8Array(h.length / 2); for (let i = 0; i < o.length; i++) o[i] = parseInt(h.substr(i * 2, 2), 16); return o; };
export const sha256 = async (u8) => new Uint8Array(await globalThis.crypto.subtle.digest('SHA-256', u8));
export const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
export const u32le = (n) => new Uint8Array([n & 255, (n >>> 8) & 255, (n >>> 16) & 255, (n >>> 24) & 255]);
export const rd32le = (u8, o = 0) => (u8[o] | (u8[o + 1] << 8) | (u8[o + 2] << 16) | (u8[o + 3] << 24)) >>> 0;
export function bigFromBytes(u8) { let n = 0n; for (const x of u8) n = (n << 8n) | BigInt(x); return n; }
export function bigToBytesLE(n, len) { const o = new Uint8Array(len); for (let i = 0; i < len; i++) { o[i] = Number(n & 255n); n >>= 8n; } return o; }
export function err(message, code, extra) { const e = new Error(message); if (code) e.code = code; if (extra) Object.assign(e, extra); return e; }
