// Fire TV over ADB-over-network (TCP :5555). Needs "ADB debugging" enabled on the Fire TV; the TV shows an "Allow USB debugging?" prompt once.
import { Sock } from './sock.js';
import { T } from './transport.js';
import { cat, te, td, u32le, rd32le, unhex, b64, bigFromBytes, bigToBytesLE, err } from './bytes.js';
import { ANDROID_NAMES, ANDROID_CODES, FIRETV_APPS } from './keys.js';
import { FIREKEYS_HASH, FIREKEYS_DEX_B64 } from './firekeys-dex.js';
import { lightning } from './firetv-lightning.js';
import { dlog } from './dbg.js';
import { connectRetry, netReport } from './netdiag.js';

const ADB_HINT = 'The Fire TV is reachable but nothing accepts connections on the ADB port (5555). On the Fire TV: Settings → My Fire TV → Developer options → ADB debugging = ON (no Developer options? Settings → My Fire TV → About → press OK on the device name 7 times). Restart the Fire TV after switching it on.';
const report = (host, port) => netReport(host, [{ port, label: 'ADB' }, { port: 8009, label: 'Cast' }], { closed: ADB_HINT });

export const A = { CNXN: 0x4e584e43, AUTH: 0x48545541, OPEN: 0x4e45504f, OKAY: 0x59414b4f, CLSE: 0x45534c43, WRTE: 0x45545257 };
const sum = (d) => { let s = 0; for (const x of d) s = (s + x) >>> 0; return s; };
export const packet = (cmd, a0, a1, data = new Uint8Array(0)) => cat(u32le(cmd), u32le(a0), u32le(a1), u32le(data.length), u32le(sum(data)), u32le((cmd ^ 0xffffffff) >>> 0), data);
const readPkt = async (sock, ms) => {
  const h = await sock.readExact(24, ms), len = rd32le(h, 12);
  const d = len ? await sock.readExact(len, ms) : new Uint8Array(0);
  const cmd = rd32le(h, 0); if (((cmd ^ 0xffffffff) >>> 0) !== rd32le(h, 20)) throw err('Corrupt ADB packet', 'protocol');
  return { cmd, a0: rd32le(h, 4), a1: rd32le(h, 8), data: d };
};

/** Android's "adb_pubkey" blob (RSAPublicKey struct for a 2048-bit key), base64 + user tag. */
export function adbPubKey(modulusHex, exponentHex) {
  const n = bigFromBytes(unhex(modulusHex)), e = Number(BigInt('0x' + exponentHex)), W = 64;
  const mod32 = 1n << 32n; let x = n % mod32, inv = 1n;           // inverse of n mod 2^32 by Newton iteration
  for (let i = 0; i < 6; i++) inv = (inv * (2n - x * inv)) % mod32;
  const n0inv = Number((mod32 - inv) % mod32), rr = ((1n << 4096n) % n);
  const blob = cat(u32le(W), u32le(n0inv), bigToBytesLE(n, 256), bigToBytesLE(rr, 256), u32le(e));
  return te.encode(b64(blob) + ' spinremote@phone\0');
}

const conns = new Map(), queues = new Map();
async function connectOnce(dev, store, { waitForUser = false, onPrompt = null } = {}) {
  const ident = await (async () => { let k = store.get('adb.key'); if (!k) { k = await T().genIdentity({ cert: false }); store.set('adb.key', k); } return k; })();
  const aport = (dev.ports && dev.ports.adb) || 5555; let why = '';
  const sock = await connectRetry({ host: dev.host, port: aport }, `adb ${dev.host}:${aport}`).catch((e) => { why = (e && e.message) || String(e); return null; });
  if (!sock) throw err(`Can’t connect to the Fire TV at ${dev.host}:${aport}: ${why}\n${await report(dev.host, aport)}`, 'unreachable');
  dlog('adb: connected, sending CNXN');
  await sock.write(packet(A.CNXN, 0x01000001, 256 * 1024, te.encode('host::\0')));
  let sentKey = false;
  const deadline = Date.now() + (waitForUser ? 45000 : 9000);
  for (;;) {
    let p; try { p = await readPkt(sock, Math.max(500, deadline - Date.now())); } catch (e) { sock.close(); throw e.code === 'timeout' ? err(waitForUser ? 'No answer — did you tap "Allow" on the Fire TV?' : 'The Fire TV did not answer', 'not_paired') : e; }
    if (p.cmd === A.CNXN) return { sock, maxdata: p.a1, next: 1 };
    if (p.cmd === A.AUTH && p.a0 === 1) {
      if (!sentKey) { sentKey = true; const sig = await T().rsaSignAdb({ keyPkcs8: ident.keyPkcs8, token: p.data }); await sock.write(packet(A.AUTH, 2, 0, sig)); }
      else {                                                        // TV does not know our key yet → offer it (TV shows the Allow dialog)
        if (!waitForUser) { sock.close(); throw err('This phone is not authorised on the Fire TV yet. Pair it first.', 'not_paired'); }
        dlog('adb: offering this phone’s key — the TV should now show “Allow USB debugging?”'); await sock.write(packet(A.AUTH, 3, 0, adbPubKey(ident.modulusHex, ident.exponentHex)));
        if (onPrompt) onPrompt();
      }
    } else if (p.cmd === A.CLSE || p.cmd === A.OKAY) { /* ignore */ }
    else { sock.close(); throw err('Unexpected ADB reply from the Fire TV', 'protocol'); }
  }
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
/** One ADB connection. While waiting for the user's "Allow", a dropped socket (some Fire OS builds close it when the dialog appears or times out) is retried: the key may be trusted by now. */
async function connect(dev, store, opts = {}) {
  for (let i = 0; ; i++) {
    try { return await connectOnce(dev, store, opts); }
    catch (e) {
      const dropped = e.code === 'closed' || /socket is closed|connection (closed|reset|lost)|broken pipe|closed by the/i.test(e.message || '');
      if (opts.waitForUser && dropped && i < 2) { dlog(`adb: connection dropped (${e.message}); reconnecting (${i + 1}/2)`); await sleep(1200); continue; }
      throw dropped && e.code !== 'not_paired' ? err(`The Fire TV closed the connection (${e.message}).`, 'closed') : e;
    }
  }
}

/* ---- ADB multiplexer: ONE reader per connection hands every packet to the stream it belongs to, so streams never steal each other's packets ---- */
const nowMs = () => (globalThis.performance ? performance.now() : Date.now());
function muxOf(c) {
  if (c.mux) return c.mux;
  const m = c.mux = { streams: new Map(), dead: null };
  const failAll = (e) => { m.dead = e; for (const s of m.streams.values()) s._end(e); m.streams.clear(); };
  (async () => {
    try {
      for (;;) {
        let p; try { p = await readPkt(c.sock, 30000); } catch (e) { if (e.code === 'timeout') continue; throw e; }
        const s = m.streams.get(p.a1);
        if (p.cmd === A.OKAY) { if (s) s._okay(p.a0); }
        else if (p.cmd === A.WRTE) { if (s) { s._data(td.decode(p.data)); c.sock.write(packet(A.OKAY, p.a1, p.a0)).catch(() => {}); } }
        else if (p.cmd === A.CLSE) { if (s) { m.streams.delete(p.a1); s._end(null, p.a0); } }
      }
    } catch (e) { dlog('adb: reader ended: ' + ((e && e.message) || e)); failAll(e); }
  })();
  return m;
}
/** Opens `shell:<cmd>` ('shell:' alone = interactive shell). Resolves when the TV accepted the stream. */
async function openStream(c, dest, openMs = 5000) {
  const m = muxOf(c); if (m.dead) throw m.dead;
  const local = c.next++;
  let ackW = null, openRes, openRej; const opened = new Promise((a, b) => { openRes = a; openRej = b; }); opened.catch(() => {});   // a late rejection (after a timeout) must not crash the app
  const s = {
    local, remote: null, closed: false, onData: null, onClose: null, _wq: Promise.resolve(),
    _okay(r) { if (this.remote == null) { this.remote = r; openRes(this); } else if (ackW) { const f = ackW; ackW = null; f(); } },
    _data(t) { if (this.onData) this.onData(t); },
    _end(e, remoteId) { if (this.closed) return; this.closed = true; if (this.remote == null) openRej(e || err('The Fire TV refused the shell', 'protocol')); if (ackW) { const f = ackW; ackW = null; f(); } if (!e && remoteId != null) c.sock.write(packet(A.CLSE, this.local, remoteId)).catch(() => {}); if (this.onClose) this.onClose(e); },
    /** WRTE then wait for the TV's OKAY before the next WRTE (ADB flow control). Writes from several callers stay in order. */
    write(text, onSent) {
      const job = this._wq.then(async () => {
        if (this.closed) throw err('Connection closed', 'closed');
        const ack = new Promise((res) => { ackW = res; });
        await c.sock.write(packet(A.WRTE, this.local, this.remote, typeof text === 'string' ? te.encode(text) : text)); if (onSent) onSent();
        let t; await Promise.race([ack, new Promise((r) => { t = setTimeout(r, 4000); })]); clearTimeout(t);
      });
      this._wq = job.catch(() => {}); return job;
    },
    close() { if (!this.closed && this.remote != null) c.sock.write(packet(A.CLSE, this.local, this.remote)).catch(() => {}); this.closed = true; m.streams.delete(this.local); },
  };
  m.streams.set(local, s);
  await c.sock.write(packet(A.OPEN, local, 0, te.encode(`${dest}\0`)));
  let to; const timedOut = new Promise((_, rej) => { to = setTimeout(() => { m.streams.delete(local); rej(err('The Fire TV did not answer the shell request', 'timeout')); }, openMs); });
  try { await Promise.race([opened, timedOut]); } finally { clearTimeout(to); }          // the timer must die with the open, or it would tear down a healthy stream later
  return s;
}
const ERR_OUT = /exception|error:|not found|unknown command|usage:|permission denied|aborted|inaccessible/i;
const errLine = (o) => firstLine((String(o).split(/\r?\n/).find((x) => ERR_OUT.test(x))) || o);
const firstLine = (t) => (String(t).split(/\r?\n/).find((l) => l.trim()) || '').trim().slice(0, 160);

/** The persistent interactive shell: opened once per connection, each key press is one line typed into it (no per-press stream setup, no waiting for a close).
 *  Completion of a line is recognised by the marker `echo __K''<n>__` (typed with an empty-quote pair, so the pty's echo of what we typed never equals the output). */
function shellOf(c) {
  if (c.sh && !c.sh.closed) return Promise.resolve(c.sh);
  if (!c.shP) c.shP = openShell(c).finally(() => { c.shP = null; });
  return c.shP;
}
async function openShell(c) {
  const stream = await openStream(c, 'shell:');
  const sh = c.sh = { stream, closed: false, seq: 0, out: '', waiters: new Map() };
  const fail = (e) => { sh.closed = true; for (const w of sh.waiters.values()) w.rej(e); sh.waiters.clear(); };
  stream.onClose = (e) => fail(e || err('The Fire TV closed the shell', 'closed'));
  stream.onData = (t) => {
    sh.out += t; let m;
    while ((m = /__K(\d+)__/.exec(sh.out))) {
      const seg = sh.out.slice(0, m.index); sh.out = sh.out.slice(m.index + m[0].length);
      const w = sh.waiters.get(+m[1]); if (w) { sh.waiters.delete(+m[1]); w.res(seg.replace(w.line, '')); }
    }
    if (sh.out.length > 8192) sh.out = sh.out.slice(-1024);
  };
  sh.run = (command, ms = 6000, trace = null) => new Promise((res, rej) => {
    const n = ++sh.seq, line = `${command}; echo __K''${n}__`;
    const to = setTimeout(() => { sh.waiters.delete(n); rej(err('The Fire TV did not confirm the key press', 'timeout')); }, ms);
    sh.waiters.set(n, { line, res: (o) => { clearTimeout(to); res(o); }, rej: (e) => { clearTimeout(to); rej(e); } });
    stream.write(line + '\n', () => { if (trace) trace.transmitted(); }).catch((e) => { clearTimeout(to); sh.waiters.delete(n); rej(e); });
  });
  await sh.run('echo ready', 4000).catch((e) => { sh.closed = true; stream.close(); c.sh = null; throw e; });       // proves the interactive shell works before relying on it
  dlog('adb: persistent shell ready');
  // Faster input path: on newer Fire OS (Android 11+) `cmd input …` talks to the input service directly instead of starting a Java program for every press
  // (`input …` = app_process start, typically a few hundred ms on a Fire TV Stick). Older Fire OS answers "No shell command implementation." and keeps `input`.
  try {
    const h = await sh.run('cmd input 2>&1 | head -3', 3000);
    c.inputCmd = /keyevent/i.test(h) && !/no shell command|can't find service|not found|unknown/i.test(h) ? 'cmd input' : 'input';
  } catch (e) { c.inputCmd = 'input'; }
  dlog(`adb: key path = "${c.inputCmd}"`);
  startHelper(c, sh).catch((e) => dlog('adb: fast key helper not available: ' + ((e && e.message) || e)));   // in the background: presses use the shell until it is ready
  return sh;
}

/* ---- Fast key helper (build 20) -------------------------------------------------------------------------------------------------
   `input keyevent` starts a new Java program on the Fire TV for EVERY press (hundreds of ms on a Fire TV Stick) — that is the lag.
   Instead, once per connection, a 4 KB helper (android/firekeys, original code) is copied to /data/local/tmp and started ONCE with app_process
   (the same way the shell's own `input` tool runs, as the ADB shell user, the technique scrcpy uses). It stays running on its own ADB stream and
   injects each key the moment its line arrives (InputManager.injectInputEvent), answering "A<id> ok". Copy = base64 text over the persistent shell.
   If anything about it fails (no base64, app_process refuses, no answer), the shell path above keeps working exactly as before. */
const HELPER_DEX = `/data/local/tmp/spinremote-keys-${FIREKEYS_HASH}.jar`;   // a jar holding classes.dex, the form scrcpy pushes
/** `adb push` over the ADB "sync:" service: SEND path,mode → DATA chunks → DONE mtime → OKAY. Works on every Fire OS (no base64 tool needed). */
async function syncPush(c, path, bytes) {
  const s = await openStream(c, 'sync:');
  let got = ''; const answer = new Promise((res, rej) => { s.onData = (t) => { got += t; if (/^(OKAY|FAIL)/.test(got) && got.length >= 8) res(got); }; s.onClose = (e) => rej(e || err('sync closed: ' + got, 'closed')); });
  answer.catch(() => {});
  const hdr = (id, n) => { const b = new Uint8Array(8); b.set(te.encode(id)); new DataView(b.buffer).setUint32(4, n, true); return b; };
  const spec = te.encode(`${path},33188`);                                                     // 0100644
  await s.write(cat(hdr('SEND', spec.length), spec));
  for (let i = 0; i < bytes.length; i += 4000) { const d = bytes.subarray(i, i + 4000); await s.write(cat(hdr('DATA', d.length), d)); }
  await s.write(hdr('DONE', Math.floor(Date.now() / 1000)));
  let to; const r = await Promise.race([answer, new Promise((_, rej) => { to = setTimeout(() => rej(err('no answer to the file copy', 'timeout')), 8000); })]).finally(() => clearTimeout(to));
  s.write(hdr('QUIT', 0)).catch(() => {}); s.close();
  if (!/^OKAY/.test(r)) throw err('copy refused: ' + r.slice(8, 120), 'protocol');
}
const b64bytes = (b64) => { const bin = atob(b64), u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); return u; };
async function copyHelper(c, sh, H) {
  try { await syncPush(c, H, b64bytes(FIREKEYS_DEX_B64)); dlog('adb: helper copied with adb sync'); return; }
  catch (e) { dlog('adb: adb sync copy failed (' + ((e && e.message) || e) + '), copying as text instead'); }
  const tmp = H + '.b64';
  await sh.run(`rm -f ${tmp}`, 4000);
  for (let i = 0; i < FIREKEYS_DEX_B64.length; i += 900) await sh.run(`echo -n '${FIREKEYS_DEX_B64.slice(i, i + 900)}' >> ${tmp}`, 4000);   // short lines: a pty line holds at most 4096 characters
  const d = await sh.run(`base64 -d ${tmp} > ${H}.part && mv ${H}.part ${H} && rm -f ${tmp} && echo DEX''__OK`, 6000);
  if (!/DEX__OK/.test(d)) throw err('could not copy the helper: ' + firstLine(d), 'protocol');
}
/** Build 21: every stage is logged (have file? → copy → start → READY → ping answered), stderr of app_process is captured, a slow first start gets 15 s,
 *  and a failed start is retried once with a fresh copy. Nothing is shown to the user; presses use the shell path until the helper answers its ping. */
async function startHelper(c, sh) {
  if (c.helper || c.helperP) return;
  c.helperP = (async () => {
    let last;
    for (let attempt = 1; attempt <= 2; attempt++) {
      try { await startHelperOnce(c, sh, attempt); return; }
      catch (e) { last = e; dlog(`adb: helper attempt ${attempt} failed: ${(e && e.message) || e}`); if (sh.closed || (c.mux && c.mux.dead)) break; }
    }
    throw last;
  })().catch((e) => { c.helperFailed = (e && e.message) || String(e); throw e; }).finally(() => { c.helperP = null; });
  return c.helperP;
}
async function startHelperOnce(c, sh, attempt) {
    const t0 = nowMs(), H = HELPER_DEX;
    const have = attempt === 1 ? await sh.run(`[ -s ${H} ] && echo HAVE''__DEX`, 4000) : '';
    if (!/HAVE__DEX/.test(have)) { dlog(`adb: helper stage copy (attempt ${attempt})`); await copyHelper(c, sh, H); }
    else dlog('adb: helper stage copy skipped (already on the TV)');
    dlog('adb: helper stage start app_process');
    const s = await openStream(c, `shell:CLASSPATH=${H} exec app_process / com.spinremote.keys.Main 2>&1`);
    const h = { s, seq: 0, buf: '', waiters: new Map(), dead: false, other: [] };
    let readyRes, readyRej; const ready = new Promise((a, b) => { readyRes = a; readyRej = b; }); ready.catch(() => {});
    const die = (e) => { if (h.dead) return; h.dead = true; if (c.helper === h) c.helper = null; for (const w of h.waiters.values()) w.rej(e); h.waiters.clear(); readyRej(e); dlog('adb: fast key helper stopped: ' + ((e && e.message) || e)); };
    s.onClose = (e) => die(e || err('helper ended' + (h.other.length ? ': ' + h.other.join(' | ') : ''), 'closed'));
    s.onData = (t) => {
      h.buf += t; let i;
      while ((i = h.buf.search(/\r?\n/)) >= 0) {
        const ln = h.buf.slice(0, i).trim(); h.buf = h.buf.slice(h.buf.indexOf('\n') + 1);
        let m;
        if (ln === 'SPINKEYS READY') readyRes();
        else if (/^SPINKEYS FAIL/.test(ln)) die(err(ln, 'protocol'));
        else if ((m = /^A(\d+) (.*)$/.exec(ln))) { const w = h.waiters.get(+m[1]); if (w) { h.waiters.delete(+m[1]); w.res(m[2]); } }
        else if (ln && !/^[kpt] \d+ /.test(ln) && h.other.length < 6) { h.other.push(ln.slice(0, 160)); dlog('adb: helper said: ' + ln.slice(0, 160)); }   // app_process errors (2>&1), not our own echoed lines
      }
      if (h.buf.length > 8192) h.buf = h.buf.slice(-1024);
    };
    h.send = (cmd, arg, ms = 1500) => new Promise((res, rej) => {
      const id = ++h.seq; const to = setTimeout(() => { h.waiters.delete(id); rej(err('helper did not answer', 'timeout')); }, ms);
      h.waiters.set(id, { res: (r) => { clearTimeout(to); res(r); }, rej: (e) => { clearTimeout(to); rej(e); } });
      s.write(`${cmd} ${id} ${arg}\n`).catch((e) => { clearTimeout(to); h.waiters.delete(id); rej(e); });
    });
    try {
      let to; await Promise.race([ready, new Promise((_, rej) => { to = setTimeout(() => rej(err('helper did not start within 15 s' + (h.other.length ? ': ' + h.other.join(' | ') : ''), 'timeout')), 15000); })]).finally(() => clearTimeout(to));
      dlog(`adb: helper stage READY after ${Math.round(nowMs() - t0)} ms`);
      const p = await h.send('p', 'x', 4000);                                        // handshake: the running process must answer a line before keys go to it
      if (p !== 'ok') throw err('helper answered the handshake with: ' + p, 'protocol');
    } catch (e) { s.close(); h.dead = true; throw e; }
    c.helper = h; dlog(`adb: fast key helper ready in ${Math.round(nowMs() - t0)} ms (handshake answered)`);
}
/** Sends a batch through the helper: every press goes out at once (pipelined), answers collected. Returns shell-like output ('' or an error line). */
async function viaHelper(h, batch) {
  const rs = await Promise.all(batch.map((it) => it.kind === 'key'
    ? h.send('k', ANDROID_CODES[it.key] != null ? ANDROID_CODES[it.key] : 0)
    : h.send('t', it.text.replace(/[\r\n]+/g, ' '))));
  const bad = rs.find((r) => r !== 'ok');
  return bad ? `Error: ${bad.replace(/^err /, '')}` : '';
}
/** Fallback: one stream per command (what `adb shell <cmd>` does), still on the shared connection. */
async function oneShot(c, command, trace = null) {
  const s = await openStream(c, `shell:${command}`); if (trace) trace.transmitted();
  return new Promise((res, rej) => {
    let out = ''; const to = setTimeout(() => { s.close(); rej(err('The Fire TV did not finish the command', 'timeout')); }, 10000);
    s.onData = (t) => { out += t; }; s.onClose = (e) => { clearTimeout(to); e ? rej(e) : res(out); };
  });
}
const dialing = new Map();                                                  // device id -> connection being opened (concurrent presses share ONE connect)
function liveConn(dev, store) {
  const c = conns.get(dev.id); if (c && !c.sock.closed && !(c.mux && c.mux.dead)) return Promise.resolve(c);
  let p = dialing.get(dev.id);
  if (!p) { p = connect(dev, store).then((n) => { conns.set(dev.id, n); return n; }).finally(() => dialing.delete(dev.id)); dialing.set(dev.id, p); }
  return p;
}
const quote = (s) => `'${s.replace(/'/g, `'\\''`)}'`;


/* ---- one ordered queue per Fire TV for keys AND typed text ----------------------------------------------------------------------
   Every `input` call costs the TV a process start, so while one shell line is running, the presses that arrive meanwhile are collected and sent
   together as ONE line: consecutive keys become one `input keyevent A B C` (input takes several key codes per call), consecutive typed text becomes one
   `input text '…'`, and the groups are joined in their original order. A held button's repeats never pile up: while a repeat of the same key is still
   waiting, newer repeats are dropped. Volume / mute / power keep their own line (they have fallbacks that must see their own output). */
const lanes = new Map();                                                      // dev.id -> { items: [], busy: false }
const SOLO = new Set(['vol_up', 'vol_down', 'mute', 'power']);
const textArg = (t) => quote(t.replace(/[\r\n]+/g, ' ').replace(/ /g, '%s'));
function lane(dev) { let l = lanes.get(dev.id); if (!l) { l = { items: [], busy: false }; lanes.set(dev.id, l); } return l; }
function enqueue(dev, store, item) {
  const l = lane(dev);
  if (item.repeat && l.busy) {                                                // held button while the TV is busy: keep only the newest repeat waiting (in its place in line), answer now
    for (const i of l.items.filter((i) => i.repeat && i.key === item.key)) { l.items.splice(l.items.indexOf(i), 1); i.res({ out: '', coalesced: true }); }
    dlog(`adb: coalesced repeat ${item.key}`); if (item.trace) item.trace.transmitted();
    item.res = () => {}; item.rej = () => {}; l.items.push(item); return Promise.resolve({ out: '', coalesced: true });
  }
  const p = new Promise((res, rej) => { item.res = res; item.rej = rej; });
  l.items.push(item); if (!l.busy) flushLane(dev, store, l);
  return p;
}
async function flushLane(dev, store, l) {
  l.busy = true;
  try {
    while (l.items.length) {
      const batch = [];                                                       // a solo key goes alone; everything else is taken up to the next solo key
      if (l.items[0].solo) batch.push(l.items.shift());
      else while (l.items.length && !l.items[0].solo && batch.length < 40) batch.push(l.items.shift());
      const c = await liveConn(dev, store).catch(() => null), pfx = (c && c.inputCmd) || 'input';
      const segs = []; for (const it of batch) { const last = segs[segs.length - 1]; if (last && last.kind === it.kind && it.kind === 'key') last.v.push(it.code); else if (last && last.kind === 'text' && it.kind === 'text') last.v.push(it.text); else segs.push({ kind: it.kind, v: [it.kind === 'key' ? it.code : it.text] }); }
      const line = segs.map((g) => g.kind === 'key' ? `${pfx} keyevent ${g.v.join(' ')}` : `${pfx} text ${textArg(g.v.join(''))}`).join('; ');
      const trace = { transmitted() { for (const it of batch) if (it.trace) it.trace.transmitted(); } };
      if (c && c.helper && !c.helper.dead && batch.every((it) => it.kind === 'text' || ANDROID_CODES[it.key] != null)) {
        try {
          const hl = batch.map((it) => it.kind === 'key' ? `k ${ANDROID_CODES[it.key]}` : 't …').join(', ');
          const out = await viaHelper(c.helper, batch); trace.transmitted();
          for (const it of batch) it.res({ out, size: batch.length, line: `fast key ${hl}` });
          continue;
        } catch (e) { dlog(`adb: fast key helper failed (${e.message}); using the shell`); if (c.helper) { try { c.helper.s.close(); } catch (x) { /* already gone */ } c.helper = null; } }
      }
      try {
        let out = await adb.run(dev, store, line, { trace });
        if (ERR_OUT.test(out) && pfx === 'cmd input') {                       // the faster path misbehaved: go back to plain `input` for good and retry this line once
          dlog(`adb: "cmd input" failed (${firstLine(out)}); switching to "input"`); if (c) c.inputCmd = 'input';
          out = await adb.run(dev, store, line.replace(/(^|; )cmd input /g, '$1input '));
        }
        for (const it of batch) it.res({ out, size: batch.length, line });
      } catch (e) { for (const it of batch) it.rej(e); }
    }
  } finally { l.busy = false; }
}

/** After ADB is allowed: if the Fire TV has its own remote API, ask it for a 4-digit code (fast buttons). Without it, ADB alone is used. */
const badCodes = new Map();
async function lightningOffer(dev, store) {
  if (lightning.token(dev, store)) return { status: 'paired' };
  if (!(await lightning.pinDisplay(dev))) { dlog('lightning: this Fire TV did not offer a code; buttons use ADB'); return { status: 'paired' }; }
  return { status: 'code', kind: 'digits', length: 4, adbPaired: true, message: 'Almost done: type the 4-digit code now on your TV. It makes the arrows and OK as fast as Amazon’s own remote app.' };
}
export const adb = {
  async probe(host, ports = { adb: 5555 }) {
    let why = '';
    const s = await connectRetry({ host, port: ports.adb }, `adb probe ${host}:${ports.adb}`).catch((e) => { why = (e && e.message) || ''; return null; });
    if (!s) throw err(`Couldn’t reach a Fire TV at ${host}:${ports.adb}: ${why || 'no answer'}\n${await report(host, ports.adb)}`, 'unreachable');
    s.close(); return true;
  },
  /** "Pairing": ONE connection, like `adb connect`: sign → offer our key → the TV shows Allow → CNXN. Resolves 'paired' when the key is already trusted, else 'confirm'. */
  async pairStart(dev, store) {
    let prompt; const prompted = new Promise((res) => { prompt = res; });
    const p = connect(dev, store, { waitForUser: true, onPrompt: () => prompt() }).then((c) => { conns.set(dev.id, c); return c; });
    p.catch(() => {});
    const r = await Promise.race([p.then(() => 'paired'), prompted.then(() => 'confirm')]);
    if (r === 'paired') return lightningOffer(dev, store);
    conns.set(dev.id + ':pending', p);
    return { status: 'confirm', message: 'Look at your Fire TV and press Allow (tick “Always allow”).' };
  },
  async pairFinish(dev, store, code) {
    if (code) {                                                     // build 22: the 4-digit code for the fast buttons. Build 23: never a dead end —
      try { await lightning.pinVerify(dev, store, code); }          // ADB is already allowed, so anything but a mistyped code just connects over ADB.
      catch (e) {
        if (e.code !== 'bad_code') { lightning.markDown(dev, 'pin/verify: ' + e.message); return { status: 'paired' }; }
        const n = (badCodes.get(dev.id) || 0) + 1; badCodes.set(dev.id, n);
        if (n >= 3) { badCodes.delete(dev.id); lightning.markDown(dev, '3 wrong codes'); return { status: 'paired' }; }
        throw e;
      }
      badCodes.delete(dev.id); return { status: 'paired' };
    }
    const p = conns.get(dev.id + ':pending'); if (!p) throw err('Pairing session expired — start again.', 'protocol');
    try { await p; } catch (e) { conns.delete(dev.id + ':pending'); throw e.code === 'not_paired' ? err('The Fire TV has not accepted this phone yet. Press Allow on the TV, then try again.', 'not_paired') : e; }
    conns.delete(dev.id + ':pending'); return store ? lightningOffer(dev, store) : { status: 'paired' };
  },
  /** Sends one shell command and resolves with what it printed. Taps always go out immediately. A hold-repeat (`repeat`) never queues more than one
   *  follow-up behind the one in flight (the newest wins), so letting go of a button never leaves a backlog on the TV. */
  async run(dev, store, command, { repeat = false, trace = null } = {}) {
    const q = queues.get(dev.id) || { inflight: 0, pending: null }; queues.set(dev.id, q);
    if (repeat && q.inflight >= 1) { q.pending = { dev, store, command }; dlog(`adb: coalesced repeat ${command}`); if (trace) trace.transmitted(); return '(coalesced)'; }
    q.inflight++;
    try { return await adb._exec(dev, store, command, trace); }
    finally { q.inflight--; if (q.pending && q.inflight === 0) { const p = q.pending; q.pending = null; adb.run(p.dev, p.store, p.command).catch(() => {}); } }
  },
  async _exec(dev, store, command, trace = null) {
    for (let attempt = 0; ; attempt++) {
      try {
        const c = await liveConn(dev, store);
        dlog(`adb: shell ${command}`);
        if (!c.oneShotOnly) {
          let sh; try { sh = await shellOf(c); } catch (e) { if (e.code === 'closed' && attempt === 0) throw e; dlog(`adb: no interactive shell (${e.message}); using one stream per command`); c.oneShotOnly = true; }
          if (sh) return await sh.run(command, 6000, trace);
        }
        c.tail = (c.tail || Promise.resolve()).catch(() => {}).then(() => oneShot(c, command, trace)); return await c.tail;
      } catch (e) { dlog(`adb: ${command} failed: ${e.message}`); if (e.code === 'not_paired' || e.code === 'timeout' || attempt >= 1) throw e; const c = conns.get(dev.id); if (c) c.sock.close(); conns.delete(dev.id); }
    }
  },
  /** Open the connection and the persistent shell ahead of the first press. */
  async warm(dev, store) {
    const c = await liveConn(dev, store);
    if (!c.oneShotOnly) { try { await shellOf(c); } catch (e) { c.oneShotOnly = true; } }
  },
  hasAck: true,                                                                 // the shell echoes a marker once the TV has finished the command
  async key(dev, key, store, opts = {}) {
    const n = ANDROID_NAMES[key]; if (!n) throw err(`No "${key}" key on Fire TV`, 'bad_key');
    const code = `KEYCODE_${n}`;
    if (store && lightning.token(dev, store)) {                    // build 22: arrows/OK/Back/Home/Menu/play-pause through the Fire TV's own remote API (what Amazon's app uses)
      try { const w = await lightning.key(dev, store, key); if (w) { if (opts.trace) opts.trace.transmitted(); return w; } }
      catch (e) { dlog(`fast Fire TV API failed for ${key} (${e.message}); using ADB`); }
    }
    if (/^(vol_up|vol_down|mute)$/.test(key)) await adb.ensureCecVolume(dev, store);             // once per connection (cached)
    const r = await enqueue(dev, store, { kind: 'key', key, code, repeat: !!opts.repeat, solo: SOLO.has(key), trace: opts.trace });
    if (r.coalesced) return 'coalesced';
    const out = r.out, sent = r.size > 1 ? `adb shell ${r.line}` : `adb shell ${r.line}`;
    if (ERR_OUT.test(out)) {
      const fb = { vol_up: 'raise', vol_down: 'lower' }[key];
      if (fb) {                                                    // some Fire OS builds reject the key event: adjust the media stream directly (shows Fire TV's own volume bar)
        const alt = `cmd media_session volume --show --stream 3 --adj ${fb}`;
        const o2 = await adb.run(dev, store, alt);
        if (!ERR_OUT.test(o2)) return `adb shell ${alt} (keyevent was rejected: ${firstLine(out)})`;
        throw err(`The Fire TV rejected the volume command: ${firstLine(o2) || firstLine(out)}`, 'bad_key');
      }
      if (key === 'mute') {                                        // VOLUME_MUTE (164) refused: KEYCODE_MUTE (91) is the older mute key
        const o2 = await adb.run(dev, store, 'input keyevent KEYCODE_MUTE');
        if (!ERR_OUT.test(o2)) return 'adb shell input keyevent KEYCODE_MUTE (VOLUME_MUTE was rejected)';
      }
      throw err(`The Fire TV rejected ${code}: ${errLine(out)}`, 'bad_key');
    }
    return sent;
  },
  /** Keyboard: `input text` types into whatever text box has focus on the TV (spaces travel as %s). Goes through the same ordered queue as the keys, so
   *  letters and Backspace never overtake each other, and letters typed while the TV is still busy are sent together. Only plain ASCII survives `input text`. */
  async text(dev, text, store, o = {}) {
    const clean = String(text || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^\x20-\x7e\r\n]/g, '');
    if (!clean) return 'adb shell input text "" (nothing typeable)';
    const r = await enqueue(dev, store, { kind: 'text', text: clean, trace: o.trace });
    if (ERR_OUT.test(r.out)) throw err(`The Fire TV rejected the typing: ${errLine(r.out)}`, 'bad_key');
    return `adb shell ${r.line}`;
  },
  /** Voice search: open the TV's search screen, give it a moment, then type the words through the keyboard queue. First the standard Android
   *  "global search" request (am start -a android.search.action.GLOBAL_SEARCH); when the Fire TV can't resolve it, the SEARCH key (84).
   *  Success only means the TV accepted the commands (o.how = 'typed'); it does not prove a search box had focus. `input text` only understands plain ASCII. */
  async search(dev, text, store, o = {}) {
    const clean = String(text || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^\x20-\x7e]/g, ' ').replace(/\s+/g, ' ').trim();
    if (!clean) throw err('Nothing to search for.', 'empty');
    let how = 'am start GLOBAL_SEARCH';
    const g = await adb.run(dev, store, 'am start -a android.search.action.GLOBAL_SEARCH', { trace: o.trace });
    if (ERR_OUT.test(g)) {
      dlog(`adb: global search not available (${firstLine(g.split(/\r?\n/).slice(1).join('\n')) || firstLine(g)}); using the SEARCH key`); how = 'input keyevent KEYCODE_SEARCH';
      const r = await enqueue(dev, store, { kind: 'key', key: 'search', code: 'KEYCODE_SEARCH', solo: true });
      if (ERR_OUT.test(r.out)) throw err(`The Fire TV rejected the search key: ${errLine(r.out)}`, 'bad_key');
    }
    await sleep(o.settleMs == null ? 1200 : o.settleMs);                   // the search screen needs a moment before it accepts typing
    const t = await enqueue(dev, store, { kind: 'text', text: clean, solo: true });
    if (ERR_OUT.test(t.out)) throw err(`The Fire TV rejected the text: ${errLine(t.out)}`, 'bad_key');
    o.how = 'typed';
    return `adb shell ${how}; input text "${clean}"`;
  },
  async launch(dev, app, store) {
    const pkg = FIRETV_APPS[app] || (/^[a-z][\w.]+$/i.test(app) ? app : null); if (!pkg) throw err(`Unknown app "${app}"`, 'bad_app');
    await adb.run(dev, store, `monkey -p ${pkg} -c android.intent.category.LAUNCHER 1`);
    return `adb shell monkey -p ${pkg}`;
  },
  /** Can this Fire TV change the TV's volume from here? Fire TV Sticks normally drive the TV's volume with INFRARED from their own remote ("Equipment
   *  Control"), which never passes through Fire OS; Fire OS's own HDMI output is fixed-volume. A volume key sent over ADB then only reaches the TV when
   *  Fire OS forwards it over HDMI-CEC. So: fixed volume AND CEC volume forwarding switched off → 'no' (buttons dimmed with a plain explanation). Anything
   *  else, or no answer → 'yes' (keep sending; nothing is hidden on a guess). */
  /** Fire TV Sticks send volume to the TV by infrared from their own remote; Fire OS's own HDMI output is fixed-volume. The only way a volume key
   *  sent over the network can reach the TV is Android's HDMI-CEC volume forwarding: with CEC on and "volume control" on, Fire OS passes
   *  VOLUME_UP/DOWN/MUTE to the TV (or soundbar) over HDMI. Both are ordinary global settings the ADB shell user may change, so before the first
   *  volume press on a connection we read them and switch them on if needed (logged). The TV's own CEC setting (Anynet+, SimpLink, Bravia Sync,
   *  "CEC" on Vizio…) must also be on — that one we cannot reach. */
  async ensureCecVolume(dev, store) {
    const c = await liveConn(dev, store).catch(() => null); if (c && c.cecChecked) return c.cecChecked;
    let res = 'unknown';
    try {
      const g = await adb.run(dev, store, "echo CEC=$(settings get global hdmi_control_enabled) VOL=$(settings get global hdmi_control_volume_control_enabled)");
      const on = /CEC=(1|null)\b/.test(g), vol = /VOL=(1|null)\b/.test(g);
      if (on && vol) res = 'on';
      else {
        const p = await adb.run(dev, store, 'settings put global hdmi_control_enabled 1; settings put global hdmi_control_volume_control_enabled 1; echo CEC=$(settings get global hdmi_control_enabled) VOL=$(settings get global hdmi_control_volume_control_enabled)');
        res = /CEC=1\b/.test(p) && /VOL=1\b/.test(p) ? 'switched on' : 'refused';
      }
      dlog(`adb: HDMI-CEC volume forwarding ${res} (was ${firstLine(g)})`);
    } catch (e) { dlog('adb: CEC check failed: ' + e.message); }
    if (c) c.cecChecked = res;
    return res;
  },
  /** Volume is offered on every Fire TV: forwarding is switched on when needed (above). 'no' only when the Fire TV refused that change AND is fixed-volume. */
  async volumeCaps(dev, store) {
    try {
      const cec = await adb.ensureCecVolume(dev, store);
      if (cec !== 'refused') return 'yes';
      const out = await adb.run(dev, store, "dumpsys audio | grep -iE 'fixedvolume' | head -3");
      return /mUseFixedVolume\s*[=:]\s*true/i.test(out) ? 'no' : 'yes';
    } catch (e) { return 'yes'; }
  },
  closeAll() { for (const [k, c] of conns) if (c && c.sock) c.sock.close(); conns.clear(); lanes.clear(); },
};

