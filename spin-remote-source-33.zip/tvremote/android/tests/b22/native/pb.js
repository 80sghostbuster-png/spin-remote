// Minimal protobuf wire encoder/decoder - just enough for the Android TV remote v2 messages.
import { cat, te } from './bytes.js';
export const varint = (n) => { const o = []; n = Number(n); while (n > 127) { o.push((n % 128) | 128); n = Math.floor(n / 128); } o.push(n); return Uint8Array.from(o); };
export const tag = (f, w) => varint(f * 8 + w);
export const fVarint = (f, n) => cat(tag(f, 0), varint(n));
export const fBytes = (f, u8) => cat(tag(f, 2), varint(u8.length), u8);
export const fString = (f, s) => fBytes(f, te.encode(s));
export const fMsg = fBytes;
/** Decode one message into [{f, w, v}] (v: number for varint, Uint8Array for len-delimited). */
export function decode(u8) {
  const out = []; let i = 0;
  const rv = () => { let r = 0, s = 1; for (;;) { const b = u8[i++]; if (b === undefined) throw new Error('truncated varint'); r += (b & 127) * s; if (!(b & 128)) break; s *= 128; } return r; };
  while (i < u8.length) {
    const k = rv(), f = Math.floor(k / 8), w = k & 7;
    if (w === 0) { const st = i; const v = rv(); out.push({ f, w, v, raw: u8.subarray(st, i) }); }   // raw: the exact bytes (values past 2^53 / negative int32 survive an echo)
    else if (w === 2) { const l = rv(); out.push({ f, w, v: u8.subarray(i, i + l) }); i += l; }
    else if (w === 5) { out.push({ f, w, v: u8.subarray(i, i + 4) }); i += 4; }
    else if (w === 1) { out.push({ f, w, v: u8.subarray(i, i + 8) }); i += 8; }
    else throw new Error('bad wire type ' + w);
  }
  return out;
}
export const field = (m, f) => m.find((x) => x.f === f);
/** Split a stream buffer into varint-length-delimited frames; returns [frames, rest]. */
export function unframe(buf) {
  const frames = []; let i = 0;
  for (;;) {
    let r = 0, s = 1, j = i, ok = false;
    while (j < buf.length) { const b = buf[j++]; r += (b & 127) * s; s *= 128; if (!(b & 128)) { ok = true; break; } }
    if (!ok || j + r > buf.length) break;
    frames.push(buf.subarray(j, j + r)); i = j + r;
  }
  return [frames, buf.subarray(i)];
}
export const frame = (msg) => cat(varint(msg.length), msg);
