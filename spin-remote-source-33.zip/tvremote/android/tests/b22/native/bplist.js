// Minimal binary-plist (bplist00) reader/writer - just enough for the NSKeyedArchiver-style text-input payloads of the Apple TV Companion protocol.
// UID values are represented as { uid: n }.
import { te, td } from './bytes.js';
export const UID = (n) => ({ uid: n });
const be = (n, size) => { const o = new Uint8Array(size); for (let i = size - 1; i >= 0; i--) { o[i] = n & 255; n = Math.floor(n / 256); } return o; };

export function write(root) {
  const objs = []; const refOf = (v) => { objs.push(v); return objs.length - 1; };
  // flatten: depth-first, children get indexes after parent (index assigned at visit time)
  const kids = [];                                              // per object: child refs
  (function visit(v) {
    const idx = refOf(v);
    if (Array.isArray(v)) kids[idx] = v.map(visit);
    else if (v && typeof v === 'object' && !(v instanceof Uint8Array) && v.uid === undefined) { const ks = Object.keys(v); kids[idx] = [ks.map((k) => visit(k)), ks.map((k) => visit(v[k]))]; }
    return idx;
  })(root);
  const refSize = objs.length < 256 ? 1 : 2, parts = [te.encode('bplist00')], offsets = []; let pos = 8;
  const push = (u8) => { parts.push(u8); pos += u8.length; };
  const head = (type, len) => (len < 15 ? Uint8Array.of((type << 4) | len) : (len < 256 ? Uint8Array.of((type << 4) | 15, 0x10, len) : Uint8Array.of((type << 4) | 15, 0x11, len >> 8, len & 255)));
  objs.forEach((v, i) => {
    offsets.push(pos);
    if (typeof v === 'string') {
      if (/^[\x00-\x7f]*$/.test(v)) { push(head(5, v.length)); push(te.encode(v)); }
      else { const u = new Uint8Array(v.length * 2); for (let k = 0; k < v.length; k++) { u[k * 2] = v.charCodeAt(k) >> 8; u[k * 2 + 1] = v.charCodeAt(k) & 255; } push(head(6, v.length)); push(u); }
    } else if (typeof v === 'number') { if (v >= 0 && v < 256) push(Uint8Array.of(0x10, v)); else if (v >= 0 && v < 65536) push(Uint8Array.of(0x11, v >> 8, v & 255)); else if (v >= 0 && v < 2 ** 32) push(Uint8Array.of(0x12, ...be(v, 4))); else push(Uint8Array.of(0x13, ...be(v, 8))); }
    else if (v === true) push(Uint8Array.of(9)); else if (v === false) push(Uint8Array.of(8)); else if (v === null) push(Uint8Array.of(0));
    else if (v instanceof Uint8Array) { push(head(4, v.length)); push(v); }
    else if (Array.isArray(v)) { push(head(0xa, v.length)); for (const r of kids[i]) push(be(r, refSize)); }
    else if (v.uid !== undefined) { const n = v.uid; push(n < 256 ? Uint8Array.of(0x80, n) : Uint8Array.of(0x81, n >> 8, n & 255)); }
    else { const [ks, vs] = kids[i]; push(head(0xd, ks.length)); for (const r of ks) push(be(r, refSize)); for (const r of vs) push(be(r, refSize)); }
  });
  const offSize = pos < 256 ? 1 : pos < 65536 ? 2 : 4, tableAt = pos;
  for (const o of offsets) push(be(o, offSize));
  const trailer = new Uint8Array(32); trailer[6] = offSize; trailer[7] = refSize; trailer.set(be(objs.length, 8), 8); trailer.set(be(0, 8), 16); trailer.set(be(tableAt, 8), 24);
  push(trailer);
  const out = new Uint8Array(pos); let o = 0; for (const p of parts) { out.set(p, o); o += p.length; } return out;
}

export function read(d) {
  const tr = d.length - 32, offSize = d[tr + 6], refSize = d[tr + 7];
  const rd = (o, n) => { let v = 0; for (let i = 0; i < n; i++) v = v * 256 + d[o + i]; return v; };
  const count = rd(tr + 8, 8), rootIdx = rd(tr + 16, 8), table = rd(tr + 24, 8);
  const objAt = (i) => {
    const o = rd(table + i * offSize, offSize), t = d[o] >> 4; let l = d[o] & 15, p = o + 1;
    if ((t === 4 || t === 5 || t === 6 || t === 0xa || t === 0xd) && l === 15) { const nb = 1 << (d[p] & 15); l = rd(p + 1, nb); p += 1 + nb; }
    switch (t) {
      case 0: return l === 8 ? false : l === 9 ? true : null;
      case 1: return rd(p, 1 << l);
      case 2: return l === 3 ? new DataView(d.buffer, d.byteOffset + p, 8).getFloat64(0) : new DataView(d.buffer, d.byteOffset + p, 4).getFloat32(0);
      case 4: return d.slice(p, p + l);
      case 5: return td.decode(d.subarray(p, p + l));
      case 6: { let s = ''; for (let k = 0; k < l; k++) s += String.fromCharCode(rd(p + k * 2, 2)); return s; }
      case 8: return { uid: rd(p, l + 1) };
      case 0xa: { const a = []; for (let k = 0; k < l; k++) a.push(rd(p + k * refSize, refSize)); return { __arr: a }; }
      case 0xd: { const ks = [], vs = []; for (let k = 0; k < l; k++) { ks.push(rd(p + k * refSize, refSize)); vs.push(rd(p + (l + k) * refSize, refSize)); } return { __dict: [ks, vs] }; }
      default: throw new Error('bplist: unsupported type ' + t.toString(16));
    }
  };
  const memo = new Map();
  const build = (i) => {
    if (memo.has(i)) return memo.get(i);
    const o = objAt(i); let v;
    if (o && o.__arr) v = o.__arr.map(build);
    else if (o && o.__dict) { v = {}; o.__dict[0].forEach((k, n) => { v[build(k)] = build(o.__dict[1][n]); }); }
    else v = o;
    memo.set(i, v); return v;
  };
  void count; return build(rootIdx);
}

/** NSKeyedArchiver helper: follow a key path through UID references (as pyatv's read_archive_properties) */
export function archiveProp(archive, path) {
  const objects = archive.$objects; let el = archive.$top;
  try { for (const k of path) { el = el[k]; if (el && el.uid !== undefined) el = objects[el.uid]; } return el; } catch (e) { return undefined; }
}
