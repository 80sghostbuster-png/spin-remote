// A buffered TCP/TLS socket on top of the transport (a background pump keeps reading).
import { T } from './transport.js';
import { cat, err, unb64 } from './bytes.js';

export class Sock {
  static async open({ host, port, tls = false, identity = null, timeoutMs = 4000, tls12 = false }) {
    const t = T();
    let r;
    try { r = await t.tcpOpen({ host, port, tls, identity, timeoutMs, ...(tls12 ? { tls12: true } : {}) }); }
    catch (e) { throw err(`Couldn’t connect to ${host}:${port}: ${(e && e.message) || e}`, 'unreachable'); }
    const s = new Sock(t, r.id); s.peerCert = r.peerCert ? unb64(r.peerCert) : null; s.tls = r.tls || ''; s._pump(); return s;
  }
  constructor(t, id) { this.t = t; this.id = id; this.buf = new Uint8Array(0); this.closed = false; this.waiters = []; this.onData = null; }
  async _pump() {
    try {
      while (!this.closed) {
        const r = await this.t.tcpRead(this.id, 0);   // 0 = block until data/close (a read timeout on a live TLS socket is a needless risk)
        if (r.data && r.data.length) { this.buf = cat(this.buf, r.data); if (this.onData) this.onData(); }
        if (r.closed) break;
      }
    } catch (e) { /* socket gone */ }
    this.closed = true; if (this.onData) this.onData(); this._wake();
  }
  _wake() { const w = this.waiters; this.waiters = []; w.forEach((f) => f()); }
  // Writes are queued per socket: the transport is asynchronous (native threads), and encrypted protocols
  // (Apple TV) break if two frames overtake each other on the wire.
  write(u8) {
    if (this.closed) throw err('Connection closed', 'closed');
    const p = (this._wq || Promise.resolve()).then(() => { if (this.closed) throw err('Connection closed', 'closed'); return this.t.tcpWrite(this.id, u8).catch((e) => { this.closed = true; throw err(`Connection lost: ${(e && e.message) || e}`, 'closed'); }); });
    this._wq = p.catch(() => {}); return p;
  }
  /** Wait until pred(buf) returns a non-null result (consumes via the returned `n` bytes). */
  async waitFor(pred, timeoutMs = 5000) {
    const end = Date.now() + timeoutMs;
    for (;;) {
      const r = pred(this.buf);
      if (r) { this.buf = this.buf.subarray(r.n); return r.v; }
      if (this.closed) throw err('Connection closed by the TV', 'closed');
      const left = end - Date.now(); if (left <= 0) throw err('The TV did not answer in time', 'timeout');
      await new Promise((res) => { const to = setTimeout(res, Math.min(left, 250)); this.onData = () => { clearTimeout(to); res(); }; });
    }
  }
  readExact(n, timeoutMs) { return this.waitFor((b) => (b.length >= n ? { n, v: b.slice(0, n) } : null), timeoutMs); }
  close() { this.closed = true; this.t.tcpClose(this.id); this._wake(); if (this.onData) this.onData(); }
}
