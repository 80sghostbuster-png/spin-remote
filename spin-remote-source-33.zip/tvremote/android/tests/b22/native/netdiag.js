// Shared network diagnostics for every platform: connect with retries, and a human-readable "which ports answer" report.
import { Sock } from './sock.js';
import { T } from './transport.js';
import { dlog } from './dbg.js';

export const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
export const CONNECT_MS = 9000;                      // a first connection from a phone to a sleepy TV can take longer than 3-4 s

/** Sock.open with 2-3 tries (about 20 s at most). Throws the last native error text. */
export async function connectRetry({ host, port, tls = false, identity = null, timeoutMs = CONNECT_MS, tries = 3 }, what) {
  let last; const t0 = Date.now();
  for (let i = 1; i <= tries; i++) {
    try { return await Sock.open({ host, port, tls, identity, timeoutMs }); }
    catch (e) { last = e; dlog(`${what}: attempt ${i} failed: ${e.message}`); if (i === tries || Date.now() - t0 > 19000) break; await sleep(600 * i); }
  }
  throw last;
}

/** specs: [{port,label}], first one = the port that matters. hints: {closed, open} texts for "host answers but main port closed" / "main port open". */
export async function netReport(host, specs, hints = {}) {
  let rows = null; const ni = globalThis.__netinfo || {};
  try { if (T().probe) rows = await T().probe({ host, ports: specs.map((s) => s.port), timeoutMs: 3000 }); } catch (e) { dlog('port check failed', (e && e.message) || e); }
  const out = [];
  if (rows) {
    const lab = (p) => (specs.find((s) => s.port === p) || {}).label || '';
    const st = (r) => (r.state === 'open' ? 'OPEN' : r.state === 'refused' ? 'closed (TV said no)' : r.state === 'timeout' ? 'NO ANSWER' : `error (${r.detail})`);
    out.push(`Port check ${host}: ` + rows.map((r) => `${r.port} ${lab(r.port)} ${st(r)}`).join(' · '));
    const main = rows.find((r) => r.port === specs[0].port);
    if (rows.every((r) => r.state === 'timeout')) out.push('Nothing from the TV answers this phone. Usually the router is isolating Wi-Fi devices from each other (guest network / AP isolation / separate VLAN), or the IP address is wrong. Also check Android Settings → Apps → Spin Remote → Permissions → Nearby devices.');
    else if (main && main.state !== 'open' && rows.some((r) => r.state === 'open' || r.state === 'refused')) out.push(hints.closed || `The TV is reachable but is not accepting connections on port ${main.port}.`);
    else if (main && main.state === 'open' && hints.open) out.push(hints.open);
  }
  out.push(`Phone: ${ni.phoneIp || '?'} · ${ni.network || 'network state unknown'} · Android ${ni.android || '?'}${rows && rows.ping != null ? ' · ping ' + (rows.ping ? 'replied' : 'no reply') : ''}`);
  const txt = out.join('\n'); dlog('REPORT: ' + txt.replace(/\n/g, ' | ')); return txt;
}
