// Roku External Control Protocol (ECP): plain HTTP on port 8060. Fully implemented; no pairing needed.
import { T } from './transport.js';
import { ROKU_KEYS, ROKU_APPS, ROKU_APP_NAMES } from './keys.js';
import { err, te, td, cat } from './bytes.js';
import { Sock } from './sock.js';
import { dlog } from './dbg.js';
import { netReport } from './netdiag.js';
import { rokuWs } from './rokuws.js';

const xml = (s, tag) => { const m = new RegExp(`<${tag}>([^<]*)</${tag}>`).exec(s || ''); return m ? m[1].replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'").trim() : ''; };
const base = (host, port = 8060) => `http://${host}:${port}`;


/* ---- persistent ECP connection --------------------------------------------------------------------------------------------------
   Every key press used to open a fresh TCP connection (SYN/ACK round trip, plus a Wi-Fi radio wake-up on a phone that has been idle) and
   concurrent presses could overtake each other. Now one keep-alive connection per Roku carries the presses in order (HTTP/1.1, Connection: keep-alive).
   Anything unexpected (can't open, chunked reply, no Content-Length, a stale socket) falls back to the old one-shot path, so behaviour never gets worse. */
const keep = new Map();                                              // host:port -> { sock, q }
const hdrEnd = (b) => { for (let i = 3; i < b.length; i++) if (b[i] === 10 && b[i - 1] === 13 && b[i - 2] === 10 && b[i - 3] === 13) return i + 1; return -1; };
async function fastPost(dev, path, trace, timeoutMs) {
  const host = dev.host, port = dev.port || 8060, k = host + ':' + port;
  let c = keep.get(k); if (!c) { c = { sock: null, q: Promise.resolve() }; keep.set(k, c); }
  const run = async () => {
    for (let attempt = 0; attempt < 2; attempt++) {
      let fresh = false;
      if (!c.sock || c.sock.closed) { c.sock = await Sock.open({ host, port, timeoutMs: 2500 }); fresh = true; }
      const s = c.sock;
      try { await s.write(te.encode(`POST ${path} HTTP/1.1\r\nHost: ${host}:${port}\r\nContent-Length: 0\r\nConnection: keep-alive\r\n\r\n`)); }
      catch (e) { s.close(); c.sock = null; if (fresh || attempt) throw e; continue; }   // a socket the Roku had already closed: retry once on a new one (nothing reached the Roku)
      if (trace) trace.transmitted();
      try {
        const head = await s.waitFor((b) => { const n = hdrEnd(b); return n < 0 ? null : { n, v: td.decode(b.subarray(0, n)) }; }, timeoutMs);
        const status = +(/^HTTP\/1\.[01] (\d{3})/.exec(head) || [0, 0])[1];
        const cl = /^content-length:\s*(\d+)/im.exec(head), chunked = /^transfer-encoding:\s*chunked/im.test(head), close = /^connection:\s*close/im.test(head) || (!cl && !chunked);
        let body = '';
        const line = () => s.waitFor((b) => { for (let i = 1; i < b.length; i++) if (b[i] === 10 && b[i - 1] === 13) return { n: i + 1, v: td.decode(b.subarray(0, i - 1)) }; return null; }, timeoutMs);
        if (chunked) { for (;;) { const sz = parseInt((await line()).split(';')[0], 16) || 0; if (sz === 0) { while ((await line()) !== '') { /* trailers */ } break; } body += td.decode(await s.readExact(sz, timeoutMs)); await s.readExact(2, timeoutMs); } }
        else if (cl && +cl[1] > 0) body = td.decode(await s.readExact(+cl[1], timeoutMs));
        if (close) { s.close(); c.sock = null; }
        return { status, body };
      } catch (e) { s.close(); c.sock = null; throw e; }               // no reply: the press may or may not have landed, so it is never repeated
    }
  };
  const p = c.q.then(run, run); c.q = p.catch(() => {}); return p;
}
export const rokuCloseAll = () => { rokuWs.closeAll(); for (const c of keep.values()) { try { c.sock && c.sock.close(); } catch { /* gone */ } } keep.clear(); };

const NO_VOL = 'This Roku can’t change volume; use your TV remote.';
const wsPref = new Set();                                            // Rokus whose plain HTTP buttons are refused (403): their buttons go over the Roku phone-app channel (rokuws.js) first
const swVer = (v) => { const m = /^(\d+)\.(\d+)/.exec(v || ''); return m ? +m[1] * 10 + Math.min(+m[2], 9) : 0; };   // "12.5.5" -> 125 (0 when unknown)
const caps = new Map();                                              // host -> { tv, stick } from /query/device-info (ECP volume keys only act on Roku TVs and soundbars, not sticks)

const FORBIDDEN_HELP = 'On the Roku: Settings → System → Advanced system settings → Control by mobile apps → Network access → choose “Default” or “Permissive” (“Limited” lets apps launch but blocks the buttons).';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
/** The names a Lit_ key may go by on the phone-app channel: the URL-encoded form the Roku docs show for HTTP first, then the plain character (some firmware only takes one of them). */
const litNames = (name) => { const m = /^Lit_(.*%.*)$/.exec(name); if (!m) return [name]; try { return [name, 'Lit_' + decodeURIComponent(m[1])]; } catch { return [name]; } };
async function viaWs(dev, name) {
  const hp = dev.host + ':' + (dev.port || 8060); let last;
  for (const n of litNames(name)) {
    try { const w = await rokuWs.press(dev, n, 3500); wsPref.add(hp); return w; }
    catch (e) { last = e; if (e && e.code !== 'ws_status') throw e; dlog(`roku: phone-app channel refused ${n}${n !== name ? '' : litNames(name).length > 1 ? '; trying the plain character' : ''}`); }
  }
  throw last;
}
/** One Roku key (a button name such as "Home", or a typed character "Lit_a") through the whole fallback chain. Buttons, the keyboard and voice search all use this one chain:
 *   (Rokus known to refuse plain HTTP buttons) phone-app channel first → HTTP /keypress → on 403: phone-app channel → /keydown+/keyup → a plain-language "forbidden" error. */
async function sendName(dev, name, o = {}) {
  const hp = dev.host + ':' + (dev.port || 8060);
  if (wsPref.has(hp)) {                                            // this Roku refused the plain buttons before: go straight to the channel the Roku phone app uses
    try { return await viaWs(dev, name); }
    catch (e) { dlog(`roku: phone-app channel failed for ${name} (${(e && e.message) || e}); trying the plain HTTP button`); }
  }
  const r = await ecp.press(dev, `/keypress/${name}`, o.trace);
  if (r.status === 403) {
    let wsWhy = '';
    try { return await viaWs(dev, name); } catch (e) { wsWhy = (e && e.message) || String(e); dlog(`roku: phone-app channel failed (${wsWhy})`); }
    const d = await ecp.post(dev.host, dev.port, `/keydown/${name}`, { soft: true, timeoutMs: 3000 });   // some firmware answers keypress 403 but accepts keydown/keyup
    if (d.status < 300) { await ecp.post(dev.host, dev.port, `/keyup/${name}`, { soft: true, timeoutMs: 3000 }); return `POST :8060/keydown+keyup/${name} → ${d.status}`; }
    let apps = ''; try { const q = await T().http({ method: 'GET', url: `${base(dev.host, dev.port)}/query/apps`, timeoutMs: 3000 }); apps = ` (and GET /query/apps → ${q.status})`; dlog('ECP GET /query/apps → HTTP ' + q.status); } catch (e) { /* ignore */ }
    throw err(`Roku answered 403 Forbidden to /keypress/${name}${apps}; keydown/keyup was refused too (${d.status}) and the Roku phone-app channel failed (${wsWhy}). ${FORBIDDEN_HELP}`, 'forbidden', { status: 403 });
  }
  if (r.status >= 300) throw err(`Roku rejected /keypress/${name} (HTTP ${r.status})`, 'bad_status', { status: r.status });
  return `POST :8060/keypress/${name} → ${r.status}`;
}
export const ecp = {
  async capabilities(dev) {
    const c = caps.get(dev.host + ":" + (dev.port || "")); if (c) return c;
    const r = await T().http({ method: 'GET', url: `${base(dev.host, dev.port)}/query/device-info`, timeoutMs: 3000 });
    if (r.status !== 200) return null;
    const v = { tv: xml(r.body, 'is-tv') === 'true', stick: xml(r.body, 'is-stick') === 'true' && xml(r.body, 'is-tv') !== 'true', mode: xml(r.body, 'ecp-setting-mode'), ver: swVer(xml(r.body, 'software-version')) };
    caps.set(dev.host + ":" + (dev.port || ""), v); dlog(`roku: ${dev.host} is-tv=${v.tv} is-stick=${v.stick} software=${xml(r.body, 'software-version') || '?'} ecp-setting-mode=${v.mode || '(not reported)'}`);
    if (v.mode && !/^(enabled|permissive|default)$/i.test(v.mode)) { wsPref.add(dev.host + ':' + (dev.port || 8060)); dlog(`roku: network access is "${v.mode}": the plain HTTP buttons are probably refused, so the Roku phone-app channel is used first`); }
    return v;
  },
  async warm(dev) { await ecp.capabilities(dev).catch(() => {}); },
  /** SSDP M-SEARCH for roku:ecp; returns [{host, port}] (the TV's own name is fetched with deviceInfo). */
  async discover({ timeoutMs = 3000, ssdpTarget } = {}) {
    const res = await T().ssdp({ st: 'roku:ecp', timeoutMs, target: ssdpTarget });
    const seen = new Map();
    for (const r of res) {
      const loc = (r.headers && (r.headers.location || r.headers.LOCATION)) || '';
      const m = /^https?:\/\/([^/:]+)(?::(\d+))?/i.exec(loc);
      const host = m ? m[1] : r.ip; if (!host || seen.has(host)) continue;
      seen.set(host, { host, port: m && m[2] ? +m[2] : 8060 });
    }
    return [...seen.values()];
  },
  async deviceInfo(host, port = 8060) {
    let r, why = '';
    for (let i = 1; i <= 2 && !r; i++) { try { r = await T().http({ method: 'GET', url: `${base(host, port)}/query/device-info`, timeoutMs: 8000 }); } catch (e) { why = (e && e.message) || String(e); dlog(`roku: device-info attempt ${i} failed: ${why}`); } }
    if (!r) throw err(`Can't reach the Roku at ${host}: ${why}\n${await netReport(host, [{ port, label: 'ECP' }], { closed: 'The Roku is reachable but its control port (8060) is closed. Wake it and check Settings → System → Advanced system settings → Control by mobile apps.' })}`, 'unreachable');
    dlog(`ECP GET /query/device-info → HTTP ${r.status}`);
    if (r.status === 403) throw err('This Roku blocks remote control. On the Roku: Settings → System → Advanced system settings → Control by mobile apps → set to "Enabled".', 'forbidden', { status: 403 });
    if (r.status !== 200) throw err(`The Roku at ${host} answered HTTP ${r.status}`, 'bad_status', { status: r.status });
    const b = r.body;
    return { name: xml(b, 'user-device-name') || xml(b, 'friendly-device-name') || xml(b, 'friendly-model-name') || xml(b, 'model-name') || 'Roku', model: xml(b, 'model-name'), serial: xml(b, 'serial-number'), id: xml(b, 'device-id'), powerMode: xml(b, 'power-mode') };
  },
  async apps(host, port = 8060) {
    const r = await T().http({ method: 'GET', url: `${base(host, port)}/query/apps`, timeoutMs: 3500 });
    const out = []; const re = /<app\s+id="(\d+)"[^>]*>([^<]*)<\/app>/g; let m;
    while ((m = re.exec(r.body || ''))) out.push({ id: m[1], name: m[2].replace(/&amp;/g, '&') });
    return out;
  },
  /** POST with an empty body (what ECP wants). Every command's HTTP status goes to the debug log. */
  async post(host, port, path, { soft, timeoutMs = 8000 } = {}) {
    const t0 = Date.now();
    const r = await T().http({ method: 'POST', url: `${base(host, port)}${path}`, body: '', timeoutMs }).catch((e) => { dlog(`ECP POST ${path} ✗ ${(e && e.message) || e}`); throw err(`Roku didn't respond to ${path} (${(e && e.message) || e})`, 'unreachable'); });
    dlog(`ECP POST ${path} → HTTP ${r.status}${r.statusLine ? ' [' + r.statusLine + ']' : ''} (${Date.now() - t0}ms) body: ${r.body ? String(r.body).slice(0, 200).replace(/\s+/g, ' ') : '(empty)'}`);
    if (soft) return r;
    if (r.status === 403) throw err(`Roku answered 403 Forbidden to ${path}. On the Roku: Settings → System → Advanced system settings → Control by mobile apps → Network access → choose “Default” or “Permissive” (“Limited” lets apps launch but blocks the buttons).`, 'forbidden', { status: 403 });
    if (r.status >= 300) throw err(`Roku rejected ${path} (HTTP ${r.status})`, 'bad_status', { status: r.status });
    return r;
  },
  /** One ECP command on the persistent connection (falls back to a one-shot request). Same result shape as post({soft:true}). */
  async press(dev, path, trace, timeoutMs = 3000) {
    if (ecp.keepAlive && T().tcpOpen && !dev.noKeepAlive) {      // OFF by default: a hand-written HTTP client on a raw socket is not what every Roku firmware was tested against; the proven one-request-per-press path is used instead
      try { const r = await fastPost(dev, path, trace, timeoutMs); dlog(`ECP POST ${path} → HTTP ${r.status} (keep-alive)`); return r; }
      catch (e) { if (e && (e.code === 'timeout' || e.code === 'unreachable')) throw err(`Roku didn't respond to ${path} (${e.message})`, 'unreachable'); dlog(`ECP keep-alive failed (${(e && e.message) || e}); using a one-shot request`); }
    }
    if (trace) trace.transmitted();
    return ecp.post(dev.host, dev.port, path, { soft: true, timeoutMs });
  },
  /** Can this Roku change the TV volume? 'yes' = Roku TV, 'no' = streaming stick (no volume path at all), 'maybe' = a box that might reach the TV over HDMI-CEC. */
  async volume(dev) { const c = await ecp.capabilities(dev).catch(() => null); return !c ? 'maybe' : c.tv ? 'yes' : c.stick ? 'no' : 'maybe'; },
  async key(dev, key, _store, o = {}) {
    const k = ROKU_KEYS[key]; if (!k) throw err(`Roku has no "${key}" key`, 'bad_key');
    const isVol = key === 'vol_up' || key === 'vol_down' || key === 'mute', cap = isVol ? caps.get(dev.host + ":" + (dev.port || "")) : null;
    if (cap && cap.stick) throw err(NO_VOL, 'no_volume');
    const send = (name) => sendName(dev, name, o);
    try {
      const wire = await send(k);
      if (isVol && !cap) { const c = await ecp.capabilities(dev).catch(() => null); if (c && c.stick) throw err(NO_VOL, 'no_volume'); }   // first volume press: the key is sent, then we learn whether this Roku has a speaker path at all
      return wire;
    }
    catch (e) { if (key === 'power' && e.code === 'bad_status') return send('PowerOff'); throw e; }
  },
  /** Typing on the Roku keyboard: one Lit_ key per character through the same chain as the buttons. Works only while a keyboard / text box is open on the Roku. */
  async text(dev, text, _store, o = {}) {
    let n = 0;
    for (const ch of [...String(text || '')]) { await sendName(dev, `Lit_${encodeURIComponent(ch)}`, o); n++; }
    dlog(`roku: typed ${n} character(s) (${wsPref.has(dev.host + ':' + (dev.port || 8060)) ? 'phone-app channel' : 'plain HTTP'})`);
    return `POST :8060/keypress/Lit_… "${text}"`;
  },
  /** Voice search. Step 1: ECP search/browse, trying the documented forms in an order that suits the Roku's software version
   *  (OS 12.5+: …?<words>= first; older: keyword=<words> first; title=<words> in between/after). Step 2, when the Roku refuses or fails every form (403, 404, anything not 2xx, no answer):
   *  press the Roku's own Search key, wait for the screen, then type the words with the same Lit_ path the keyboard uses. Typing is not submitted (o.submit = true presses Enter afterwards): Roku search shows results while you type.
   *  Success is reported only when the Roku itself accepted every key; o.how says which way it was delivered ('typed' for step 2). */
  async search(dev, text, _store, o = {}) {
    const q = String(text || '').trim(); if (!q) throw err('Nothing to search for.', 'empty');
    const c = await ecp.capabilities(dev).catch(() => null), modernFirst = !(c && c.ver && c.ver < 125), enc = encodeURIComponent(q);
    const modern = `/search/browse?${enc}=`, kw = `/search/browse?keyword=${enc}`, ti = `/search/browse?title=${enc}`;
    const forms = modernFirst ? [modern, kw, ti] : [kw, ti, modern];
    let blocked = false, last = 0, netErr = null;
    for (const p of forms) {
      let r; try { r = await ecp.press(dev, p, o.trace, 5000); } catch (e) { netErr = e; dlog(`roku: search form ${p.replace(enc, '…')} got no answer (${(e && e.message) || e})`); if (e && e.code === 'unreachable') break; continue; }
      last = r.status; netErr = null;
      if (r.status < 300) { o.how = 'search'; return `POST :8060${p} → ${r.status}`; }
      if (r.status === 403) blocked = true;
      dlog(`roku: search form ${p.replace(enc, '…')} refused (HTTP ${r.status})${p === forms[forms.length - 1] ? '' : '; trying the next form'}`);
      if (r.status === 403) break;                                    // the same permission blocks every form
    }
    if (netErr && !last) throw netErr;                                // the Roku could not be reached at all: say so (typing would fail the same way)
    dlog(`roku: search/browse not accepted (last HTTP ${last}): opening Search with the Search key and typing the words instead`);
    let why = '';
    try {
      await sendName(dev, 'Search', o); await sleep(o.settleMs == null ? 1200 : o.settleMs);
      await ecp.text(dev, q, null, o);
      if (o.submit) await sendName(dev, 'Enter', o);
      o.how = 'typed'; return `search/browse not accepted (HTTP ${last}) → Search key + typed "${q}" (each key accepted by the Roku; results not confirmed)`;
    } catch (e) { why = (e && e.message) || String(e); dlog(`roku: search fallback failed (${why})`); if (e && (e.code === 'unreachable' || e.code === 'timeout')) throw e; }
    if (blocked) throw err(`Roku answered 403 Forbidden to /search/browse and the Search key + typing fallback failed (${why}). ${FORBIDDEN_HELP}`, 'search_blocked', { status: 403 });
    throw err(`Roku rejected the search (HTTP ${last}) and the Search key + typing fallback failed (${why})`, 'search_failed', { status: last });
  },
  keepAlive: false,
  hasAck: true,
  async launch(dev, app) {
    let id = ROKU_APPS[app];
    if (/^\d+$/.test(app)) id = app;
    else {                                                              // prefer what's really installed on this Roku
      try { const want = (ROKU_APP_NAMES[app] || app).toLowerCase(); const hit = (await ecp.apps(dev.host, dev.port)).find((a) => a.name.toLowerCase().startsWith(want)); if (hit) id = hit.id; } catch (e) { /* use the well-known id */ }
    }
    if (!id) throw err(`Unknown app "${app}"`, 'bad_app');
    const r = await ecp.post(dev.host, dev.port, `/launch/${id}`);
    return `POST :8060/launch/${id} → ${r.status}`;
  },
};
