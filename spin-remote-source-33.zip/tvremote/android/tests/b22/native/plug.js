// The Capacitor "TvNative" plugin proxy (set once by entry.js); the voice engine and the perf log use it for the few calls that are not byte transport.
let P = null;
export const setPlugin = (p) => { P = p; };
export const getPlugin = () => P;
