// Just enough DER to pull the RSA modulus/exponent out of an X.509 certificate.
function tlv(u8, o) {
  const t = u8[o]; let l = u8[o + 1], p = o + 2;
  if (l & 0x80) { const n = l & 0x7f; l = 0; for (let i = 0; i < n; i++) l = l * 256 + u8[p++]; }
  return { t, s: p, e: p + l, n: p + l };
}
function children(u8, o) { const r = tlv(u8, o), out = []; let p = r.s; while (p < r.e) { const c = tlv(u8, p); out.push({ ...c, o: p }); p = c.n; } return out; }
const strip = (b) => { let i = 0; while (i < b.length - 1 && b[i] === 0) i++; return b.slice(i); };
export function rsaFromCertDer(der) {
  const cert = children(der, 0), tbs = children(der, cert[0].o);
  let i = 0; if (tbs[0].t === 0xa0) i = 1;                 // explicit [0] version
  const spki = tbs[i + 5];                                 // serial, sigAlg, issuer, validity, subject, SPKI
  const parts = children(der, spki.o);
  const bits = parts[1];                                    // BIT STRING (first byte = unused-bits count)
  const seqStart = bits.s + 1;
  const ints = children(der, seqStart);
  return { n: strip(der.slice(ints[0].s, ints[0].e)), e: strip(der.slice(ints[1].s, ints[1].e)) };
}
