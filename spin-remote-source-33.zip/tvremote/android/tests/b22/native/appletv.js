// Apple TV "Companion" protocol (the one the iPhone Remote app / pyatv use), implemented from pyatv's public source:
//   TCP frames [type:1][len:3 big-endian][payload] carrying OPACK dictionaries.
//   Pairing  (HAP Pair-Setup: SRP-3072/SHA-512 with the 4-digit PIN shown on the TV, Ed25519 long-term keys)
//   Session  (HAP Pair-Verify: X25519 + Ed25519, then ChaCha20-Poly1305 frames, key labels ClientEncrypt-main / ServerEncrypt-main)
//   Control  (_systemInfo, _touchStart, _sessionStart, then _hidC button presses, _launchApp, _tiStart/_tiC text input)
import { Sock } from './sock.js';
import { T } from './transport.js';
import { cat, te, hex, unhex, sleep, err } from './bytes.js';
import * as opack from './opack.js';
import { dlog } from './dbg.js';
import { connectRetry, netReport } from './netdiag.js';

const report = (host, port) => netReport(host, [{ port, label: 'control' }, { port: 7000, label: 'AirPlay' }], { closed: 'The Apple TV is reachable but its control port is not the one the app has. The Apple TV changes it at times: tap PAIR again so the app searches for the current port.' });
import * as bplist from './bplist.js';
import { srpClient } from './srp.js';
import { APPLETV_HID, APPLETV_APPS } from './keys.js';
import { ed25519, x25519 } from '@noble/curves/ed25519.js';
import { chacha20poly1305 } from '@noble/ciphers/chacha.js';
import { hkdf } from '@noble/hashes/hkdf.js';
import { sha512 } from '@noble/hashes/sha2.js';

export const FT = { PS_Start: 3, PS_Next: 4, PV_Start: 5, PV_Next: 6, U_OPACK: 7, E_OPACK: 8, P_OPACK: 9 };
export const TLV = { Method: 0, Identifier: 1, Salt: 2, PublicKey: 3, Proof: 4, EncryptedData: 5, SeqNo: 6, Error: 7, Signature: 10, Name: 0x11 };
const rand = (n) => globalThis.crypto.getRandomValues(new Uint8Array(n));
const hk = (salt, info, secret) => hkdf(sha512, secret, te.encode(salt), te.encode(info), 32);
const nonce8 = (label) => cat(new Uint8Array(4), te.encode(label));            // 4 zero bytes + 8 ASCII bytes ("PS-Msg05")
const nonce12 = (n) => { const o = new Uint8Array(12); let v = BigInt(n); for (let i = 0; i < 12; i++) { o[i] = Number(v & 255n); v >>= 8n; } return o; };

export function tlvWrite(items) {                                                   // [[tag, bytes], ...]  (values > 255 are split)
  const out = []; for (const [tag, val] of items) { let p = 0; if (val.length === 0) out.push(Uint8Array.of(tag, 0)); while (p < val.length) { const n = Math.min(255, val.length - p); out.push(Uint8Array.of(tag, n), val.subarray(p, p + n)); p += n; } }
  return cat(...out);
}
export function tlvRead(d) {
  const r = {}; let p = 0;
  while (p + 2 <= d.length) { const tag = d[p], n = d[p + 1], v = d.subarray(p + 2, p + 2 + n); r[tag] = r[tag] ? cat(r[tag], v) : v.slice(); p += 2 + n; }
  return r;
}

const pending = new Map();                       // device id -> pairing in progress
const sessions = new Map(), dialing = new Map();
const lastText = new Map(), textQueue = new Map();                      // device id -> live encrypted session
const credsKey = (id) => 'appletv.creds.' + id;
const loadCreds = (store, id) => { const c = store.get(credsKey(id)); return c ? { ltpk: unhex(c.ltpk), ltsk: unhex(c.ltsk), atvId: unhex(c.atvId), clientId: unhex(c.clientId) } : null; };

class Conn {
  constructor(sock) { this.sock = sock; this.out = null; this.inn = null; this.outN = 0; this.inN = 0; }
  static async open(host, port) {
    let why = '';
    const sock = await connectRetry({ host, port }, `apple tv ${host}:${port}`).catch((e) => { why = (e && e.message) || String(e); return null; });
    if (!sock) throw err(`Can’t connect to the Apple TV at ${host}:${port}: ${why}\n${await report(host, port)}\nMake sure it is awake and on the same Wi-Fi.`, 'unreachable');
    return new Conn(sock);
  }
  enable(outKey, inKey) { this.out = outKey; this.inn = inKey; this.outN = 0; this.inN = 0; }
  async send(type, payload) {
    let len = payload.length, body = payload; if (this.out && len > 0) len += 16;
    const header = Uint8Array.of(type, (len >> 16) & 255, (len >> 8) & 255, len & 255);
    if (this.out && payload.length > 0) body = chacha20poly1305(this.out, nonce12(this.outN++), header).encrypt(payload);
    await this.sock.write(cat(header, body));
  }
  async recv(ms = 8000) {
    const f = await this.sock.waitFor((b) => { if (b.length < 4) return null; const n = (b[1] << 16) | (b[2] << 8) | b[3]; if (b.length < 4 + n) return null; return { n: 4 + n, v: { header: b.slice(0, 4), type: b[0], payload: b.slice(4, 4 + n) } }; }, ms);
    if (this.inn && f.payload.length > 0) {
      try { f.payload = chacha20poly1305(this.inn, nonce12(this.inN++), f.header).decrypt(f.payload); } catch (e) { throw err('Encrypted frame from the Apple TV failed to verify', 'protocol'); }
    }
    return f;
  }
  close() { this.sock.close(); }
}

let xidCounter = Math.floor(Math.random() * 60000);
const dataOf = (f) => { const [m] = opack.unpack(f.payload); return m && typeof m === 'object' ? m : {}; };
async function authExchange(c, type, dict) {
  await c.send(type, opack.pack({ ...dict, _x: xidCounter++ }));
  const f = await c.recv(10000);
  const m = dataOf(f); const pd = m._pd;
  if (!(pd instanceof Uint8Array)) throw err(m._em ? `The Apple TV said: ${m._em}` : 'No pairing data in the Apple TV’s reply', 'protocol');
  const t = tlvRead(pd);
  if (t[TLV.Error]) throw err(t[TLV.Error][0] === 2 ? 'That code was not right — check the code on the TV and try again.' : `The Apple TV refused pairing (error ${t[TLV.Error][0]}).`, t[TLV.Error][0] === 2 ? 'bad_code' : 'protocol');
  return t;
}


/* ---- diagnosable connect: every step is recorded so Details can say exactly where it stopped (TCP → [mDNS port refresh] → Pair-Setup/Verify → Companion session) ---- */
const portCache = new Map();                                                          // host -> Companion port last seen working / advertised (it changes when the Apple TV restarts)
const why1 = (w) => String(w || 'no answer').replace(/^Couldn’t connect to [^:]+:\d+: /, '').replace(/^TCP connect failed: /, '');
function mkSteps(dev) {
  const steps = []; let port = 0;
  const S = (name, ok, txt) => { const line = `${steps.length + 1}. ${name}: ${ok ? 'OK' : 'FAILED'}${txt ? ' — ' + txt : ''}`; steps.push(line); dlog('appletv step ' + line); };
  const die = async (msg, code) => { throw err(`${msg}\n\nSteps (${dev.host}:${port || '?'}):\n${steps.join('\n')}\n\n${await report(dev.host, port || 49153)}`, code); };
  return { S, die, steps, setPort: (p) => { port = p; } };
}
async function openDev(dev, st) {
  const host = dev.host; let port = portCache.get(host) || (dev.ports && dev.ports.companion) || 49153; st.setPort(port);
  const t0 = Date.now(); let why = '';
  let sock = await connectRetry({ host, port, timeoutMs: 4000, tries: 1 }, `apple tv ${host}:${port}`).catch((e) => { why = (e && e.message) || String(e); return null; });
  if (!sock) {                                                                          // the dynamic port may have changed: ask mDNS what this Apple TV advertises now
    st.S(`TCP connect to port ${port}`, false, why1(why));
    let fresh = null, mwhy = '';
    try { fresh = (await T().mdns({ type: '_companion-link._tcp.', timeoutMs: 2500 })).find((r) => r.host === host); } catch (e) { mwhy = (e && e.message) || String(e); }
    if (fresh && fresh.port !== port) { st.S('Look up the current port (mDNS _companion-link._tcp)', true, `${host} now advertises port ${fresh.port} (was ${port})`); port = fresh.port; st.setPort(port); portCache.set(host, port); }
    else st.S('Look up the current port (mDNS _companion-link._tcp)', !!fresh, fresh ? `still port ${port}` : `${mwhy || 'no answer from this IP'} — the port could not be refreshed`);
    sock = await connectRetry({ host, port, tries: 2 }, `apple tv ${host}:${port}`).catch((e) => { why = (e && e.message) || String(e); return null; });
    if (!sock) { st.S(`TCP connect to port ${port} (2 more tries, 9 s each)`, false, why1(why)); await st.die(`Couldn’t connect to the Apple TV at ${host}:${port}. Make sure it is awake (not in standby) and on the same Wi-Fi as this phone.`, 'unreachable'); }
  }
  portCache.set(host, port); st.S(`TCP connect to ${host}:${port}`, true, `${Date.now() - t0} ms`);
  return new Conn(sock);
}

export const atvx = {
  /** "Add by IP" only validates the port; the Companion port is dynamic, so Scan (mDNS) is the normal way. */
  async probe(host, ports = {}) {
    const port = ports.companion || 49153;
    let why = '';
    const s = await connectRetry({ host, port }, `apple tv probe ${host}:${port}`).catch((e) => { why = (e && e.message) || ''; return null; });
    if (!s) throw err(`Couldn’t reach an Apple TV at ${host}:${port}: ${why || 'no answer'}\n${await report(host, port)}\nThe Apple TV’s control port changes, so use Scan (it finds the right port) instead of adding by IP.`, 'unreachable');
    s.close(); return true;
  },

  async pairStart(dev, store) {
    const old = pending.get(dev.id); if (old) { old.conn.close(); pending.delete(dev.id); }
    const st = mkSteps(dev); dlog(`appletv pairing: ${dev.host}`);
    const c = await openDev(dev, st);
    try {
      const t = await authExchange(c, FT.PS_Start, { _pd: tlvWrite([[TLV.Method, Uint8Array.of(0)], [TLV.SeqNo, Uint8Array.of(1)]]), _pwTy: 1 });
      if (!t[TLV.Salt] || !t[TLV.PublicKey]) throw err('Unexpected pairing reply from the Apple TV', 'protocol');
      st.S('Pair-Setup M1/M2 (ask for a code; Apple TV returns SRP salt + public key)', true, 'the Apple TV should now show a 4-digit code');
      pending.set(dev.id, { conn: c, salt: t[TLV.Salt], pub: t[TLV.PublicKey], steps: st });
    } catch (e) { c.close(); st.S('Pair-Setup M1/M2', false, e.message); await st.die('The Apple TV connected but did not start pairing (no code was requested).', e.code === 'closed' ? 'protocol' : (e.code || 'protocol')); }
    return { status: 'code', kind: 'num', length: 4, message: 'Look at your Apple TV: a 4-digit code is on the screen. Type it below. Phone and Apple TV must be on the same Wi-Fi. No code on the TV? Wake the Apple TV, close this and tap PAIR again.', hint: '', details: st.steps.join('\n') };
  },

  async pairFinish(dev, pin, store) {
    const p = pending.get(dev.id); if (!p) throw err('Pairing session expired — start again.', 'protocol');
    pin = String(pin || '').trim(); if (!/^\d{4}$/.test(pin)) throw err('The code is 4 digits.', 'bad_code');
    const c = p.conn, st = p.steps || mkSteps(dev); let stage = 'SRP proof (M3/M4)';
    try {
      const sk = rand(32), signPub = ed25519.getPublicKey(sk), clientId = te.encode(globalThis.crypto.randomUUID().toUpperCase());
      const cl = srpClient('Pair-Setup', pin, sk), r = cl.process(p.pub, p.salt);
      let t = await authExchange(c, FT.PS_Next, { _pd: tlvWrite([[TLV.SeqNo, Uint8Array.of(3)], [TLV.PublicKey, cl.publicKey], [TLV.Proof, r.proof]]), _pwTy: 1 });
      if (!t[TLV.Proof]) throw err('Unexpected pairing reply (proof)', 'protocol');
      st.S('SRP proof (M3/M4: send our proof, verify the Apple TV’s)', true, 'the code was accepted'); stage = 'Exchange long-term keys (M5/M6)';
      const x = hk('Pair-Setup-Controller-Sign-Salt', 'Pair-Setup-Controller-Sign-Info', r.key);
      const encKey = hk('Pair-Setup-Encrypt-Salt', 'Pair-Setup-Encrypt-Info', r.key);
      const sig = ed25519.sign(cat(x, clientId, signPub), sk);
      const inner = tlvWrite([[TLV.Identifier, clientId], [TLV.PublicKey, signPub], [TLV.Signature, sig], [TLV.Name, opack.pack({ name: 'Spin Remote' })]]);
      t = await authExchange(c, FT.PS_Next, { _pd: tlvWrite([[TLV.SeqNo, Uint8Array.of(5)], [TLV.EncryptedData, chacha20poly1305(encKey, nonce8('PS-Msg05')).encrypt(inner)]]), _pwTy: 1 });
      let dec; try { dec = tlvRead(chacha20poly1305(encKey, nonce8('PS-Msg06')).decrypt(t[TLV.EncryptedData])); } catch (e) { throw err('The Apple TV’s final pairing message did not verify', 'protocol'); }
      if (!dec[TLV.Identifier] || !dec[TLV.PublicKey]) throw err('The Apple TV did not return its identity', 'protocol');
      st.S('Exchange long-term keys (M5/M6)', true, 'Apple TV identity received'); store.set(credsKey(dev.id), { ltpk: hex(dec[TLV.PublicKey]), ltsk: hex(sk), atvId: hex(dec[TLV.Identifier]), clientId: hex(clientId) });
    } catch (e) {
      if (e.code === 'bad_code' || e.code === 'closed') { c.close(); pending.delete(dev.id); }
      if (e.code === 'closed') throw err('The Apple TV closed the connection — wrong code? Tap PAIR to try again.', 'bad_code');
      if (e.code === 'bad_code') { st.S(stage, false, 'wrong code'); throw e; }
      st.S(stage, false, e.message); c.close(); pending.delete(dev.id); await st.die(`Pairing with the Apple TV stopped at “${stage}”.`, e.code || 'protocol');
    }
    c.close(); pending.delete(dev.id);
    return { status: 'paired' };
  },

  session(dev, store) {                                                          // one connect at a time per TV
    const cur = sessions.get(dev.id); if (cur && cur.ready && !cur.conn.sock.closed) return Promise.resolve(cur);
    let p = dialing.get(dev.id); if (!p) { p = atvx._session(dev, store).finally(() => dialing.delete(dev.id)); dialing.set(dev.id, p); }
    return p;
  },
  async _session(dev, store) {
    const creds = loadCreds(store, dev.id); if (!creds) throw err('Pair this Apple TV first.', 'not_paired');
    const st = mkSteps(dev), c = await openDev(dev, st); let stage = 'Pair-Verify M1/M2';
    const ses = { conn: c, waiters: new Map(), xid: Math.floor(Math.random() * 60000), creds };
    try {
      // ---- Pair-Verify ----
      const ek = rand(32), ePub = x25519.getPublicKey(ek);
      let t = await authExchange(c, FT.PV_Start, { _pd: tlvWrite([[TLV.SeqNo, Uint8Array.of(1)], [TLV.PublicKey, ePub]]), _auTy: 4 });
      st.S('Pair-Verify M1/M2 (key exchange)', true, ''); stage = 'Pair-Verify M3/M4 (prove we are the paired phone)';
      const srvPub = t[TLV.PublicKey], encData = t[TLV.EncryptedData]; if (!srvPub || !encData) throw err('Unexpected verify reply', 'protocol');
      const shared = x25519.getSharedSecret(ek, srvPub), vKey = hk('Pair-Verify-Encrypt-Salt', 'Pair-Verify-Encrypt-Info', shared);
      let dec; try { dec = tlvRead(chacha20poly1305(vKey, nonce8('PV-Msg02')).decrypt(encData)); } catch (e) { throw err('Apple TV verification failed — pair again.', 'not_paired'); }
      if (hex(dec[TLV.Identifier] || new Uint8Array()) !== hex(creds.atvId) || !ed25519.verify(dec[TLV.Signature], cat(srvPub, dec[TLV.Identifier], ePub), creds.ltpk)) throw err('This Apple TV did not prove its identity — pair again.', 'not_paired');
      const mySig = ed25519.sign(cat(ePub, creds.clientId, srvPub), creds.ltsk);
      const msg3 = chacha20poly1305(vKey, nonce8('PV-Msg03')).encrypt(tlvWrite([[TLV.Identifier, creds.clientId], [TLV.Signature, mySig]]));
      await authExchange(c, FT.PV_Next, { _pd: tlvWrite([[TLV.SeqNo, Uint8Array.of(3)], [TLV.EncryptedData, msg3]]) }).catch((e) => { if (e.code === 'bad_code') throw err('The Apple TV no longer trusts this phone — pair again.', 'not_paired'); throw e; });
      c.enable(hk('', 'ClientEncrypt-main', shared), hk('', 'ServerEncrypt-main', shared));
      st.S('Pair-Verify M3/M4 (this phone is trusted; connection now encrypted)', true, '');
    } catch (e) {
      c.close();
      if (e.code === 'closed') throw err('The Apple TV hung up — it is probably not paired with this phone. Tap PAIR.', 'not_paired');
      if (e.code === 'not_paired') throw e;
      st.S(stage, false, e.message); await st.die(`Connecting to the Apple TV stopped at “${stage}”.`, e.code || 'protocol');
    }
    // reader: route responses by _x
    ses.run = (async () => {
      try { for (;;) { let f; try { f = await c.recv(30000); } catch (e) { if (e.code === 'timeout') continue; throw e; } if (f.type !== FT.E_OPACK && f.type !== FT.U_OPACK && f.type !== FT.P_OPACK) continue; const m = dataOf(f); if (m._t === 3 && ses.waiters.has(m._x)) { ses.waiters.get(m._x)(m); ses.waiters.delete(m._x); } } }
      catch (e) { if (globalThis.__ATV_DEBUG) console.log('ATV session died:', e.code, e.message); ses.dead = e; sessions.delete(dev.id); dlog('appletv: session ended: ' + ((e && e.message) || e)); for (const w of ses.waiters.values()) w({ _em: 'connection closed' }); ses.waiters.clear(); }
    })();
    ses.request = async (ident, content, ms = 8000, trace = null) => {
      const x = ses.xid++; const p = new Promise((res) => { ses.waiters.set(x, res); });
      await c.send(FT.E_OPACK, opack.pack({ _i: ident, _t: 2, _c: content, _x: x })); if (trace) trace.transmitted();
      let to; const m = await Promise.race([p, new Promise((_, rej) => { to = setTimeout(() => { ses.waiters.delete(x); rej(err(`The Apple TV did not answer ${ident} in time`, 'timeout')); }, ms); })]).finally(() => clearTimeout(to));
      if (m._em) throw err(`Apple TV: ${m._em}`, 'protocol'); return m;
    };
    ses.event = (ident, content) => c.send(FT.E_OPACK, opack.pack({ _i: ident, _t: 1, _c: content, _x: ses.xid++ }));
    sessions.set(dev.id, ses);
    try {
      stage = '_systemInfo'; await ses.request('_systemInfo', { _bf: 0, _cf: 512, _clFl: 128, _i: 'spinremote0001', _idsID: creds.clientId, _pubID: 'AA:BB:CC:DD:EE:FF', _sf: 256, _sv: '170.18', model: 'iPhone10,6', name: 'Spin Remote' });
      st.S('Companion _systemInfo', true, ''); stage = '_touchStart'; await ses.request('_touchStart', { _height: opack.f64(1000), _tFl: 0, _width: opack.f64(1000) });
      const local = Math.floor(Math.random() * 2 ** 32);
      st.S('Companion _touchStart', true, ''); stage = '_sessionStart'; await ses.request('_sessionStart', { _srvT: 'com.apple.tvremoteservices', _sid: local });
      st.S('Companion _sessionStart', true, 'ready'); ses.ready = true;
      ses.request('TVRCSessionStart', { ProtocolVersionKey: '1.2' }, 1500).catch(() => {});
    } catch (e) { c.close(); sessions.delete(dev.id); st.S(stage, false, e.message); await st.die(`The Apple TV connected but the remote session stopped at “${stage}”.`, e.code || 'protocol'); }
    return ses;
  },
  async _do(dev, store, fn) {
    for (let attempt = 0; ; attempt++) {
      try { const s = await atvx.session(dev, store); return await fn(s); }
      catch (e) { if (globalThis.__ATV_DEBUG) console.log('ATV _do retry:', e.code, e.message); if (e.code === 'not_paired' || attempt >= 1) throw e; const c = sessions.get(dev.id); if (c) { c.conn.close(); sessions.delete(dev.id); } }
    }
  },
  /** Open + verify the Companion session ahead of the first press. */
  async warm(dev, store) { await atvx.session(dev, store); },
  hasAck: true,                                                                 // every _hidC request is answered by the Apple TV
  async key(dev, key, store, o = {}) {
    if (key === 'power') {
      return atvx._do(dev, store, async (s) => {
        let asleep = false; try { const r = await s.request('FetchAttentionState', {}, 2000); asleep = r._c && r._c.state === 1; } catch (e) { /* unknown -> sleep */ }
        await s.request('_hidC', { _hBtS: 2, _hidC: asleep ? 13 : 12 }); return `_hidC ${asleep ? 'Wake' : 'Sleep'}`;
      });
    }
    if (key === 'backspace') { const t = (lastText.get(dev.id) || '').slice(0, -1); await atvx.text(dev, t, store); return `_tiC "${t}" (backspace)`; }
    if (key === 'enter') key = 'select';
    if (key === 'ff' || key === 'rew' || key === 'replay') key = key === 'ff' ? 'ff' : 'rew';
    if (key === 'ff' || key === 'rew') return atvx._do(dev, store, async (s) => { await s.request('_mcc', { _mcc: 7, _skpS: opack.f64(key === 'ff' ? 10 : -10) }); return `_mcc SkipBy ${key === 'ff' ? '+10s' : '-10s'}`; });
    if (key === 'next' || key === 'prev') return atvx._do(dev, store, async (s) => { await s.request('_mcc', { _mcc: key === 'next' ? 3 : 4 }); return `_mcc ${key}`; });
    if (key === 'mute') throw err('Apple TV has no mute command over the network (only volume up/down, which work when the TV or receiver is set up for it).', 'bad_key');
    const code = APPLETV_HID[key]; if (!code) throw err(`No "${key}" key on Apple TV`, 'bad_key');
    await atvx._do(dev, store, async (s) => { await Promise.all([s.request('_hidC', { _hBtS: 1, _hidC: code }, 4000, o.trace), s.request('_hidC', { _hBtS: 2, _hidC: code }, 4000)]); });
    return `_hidC ${key} (HID ${code})`;
  },
  async launch(dev, app, store) {
    const id = APPLETV_APPS[app] || (/^[A-Za-z0-9.\-]+\.[A-Za-z0-9.\-]+$/.test(app) ? app : null), url = /^[a-z][a-z0-9+.\-]*:\/\//i.test(app) ? app : null;
    if (!id && !url) throw err(`Unknown app "${app}"`, 'bad_app');
    await atvx._do(dev, store, (s) => s.request('_launchApp', url ? { _urlS: url } : { _bundleID: id }));
    return `_launchApp ${url || id}`;
  },
  /** Apple TV text entry sets the whole field: restart the text session, read the session id, send RTI text operations. */
  /** Voice search: Companion can only type into a text field that is already open on the Apple TV (it cannot open the Search app by itself), so without one nothing is sent. */
  async search(dev, text, store, o = {}) {
    const q = String(text || '').trim(); if (!q) throw err('Nothing to search for.', 'empty');
    const w = await atvx.text(dev, q, store, o); if (o.trace) o.trace.transmitted(); return w;
  },
  async text(dev, text, store, o = {}) {
    const prev = textQueue.get(dev.id) || Promise.resolve();                        // keystrokes must not interleave
    const run = prev.catch(() => {}).then(() => atvx._text(dev, text, store, o));
    textQueue.set(dev.id, run); return run;
  },
  async _text(dev, text, store, o = {}) {
    lastText.set(dev.id, text);
    await atvx._do(dev, store, async (s) => {
      await s.request('_tiStop', {}, 2000).catch(() => {});
      const r = await s.request('_tiStart', {});
      const tiD = r._c && r._c._tiD;
      if (!(tiD instanceof Uint8Array)) throw err('No text field is active on the Apple TV right now. Open a search box or sign-in field first.', 'no_text_field');
      const arc = bplist.read(tiD); let uuid = bplist.archiveProp(arc, ['sessionUUID']); if (uuid && uuid['NS.uuidbytes']) uuid = uuid['NS.uuidbytes'];
      if (!(uuid instanceof Uint8Array)) throw err('The Apple TV did not give a text session.', 'protocol');
      await s.event('_tiC', { _tiV: 1, _tiD: clearPayload(uuid) });
      if (text) await s.event('_tiC', { _tiV: 1, _tiD: insertPayload(uuid, text) });
      if (o.trace) o.trace.transmitted();
    });
    return `_tiC "${text}"`;
  },
  closeAll() { for (const s of sessions.values()) s.conn.close(); sessions.clear(); for (const p of pending.values()) p.conn.close(); pending.clear(); },
};

const U = bplist.UID, cls = (n) => ({ $classname: n, $classes: [n, 'NSObject'] });
export const clearPayload = (uuid) => bplist.write({ $version: 100000, $archiver: 'RTIKeyedArchiver', $top: { textOperations: U(1) }, $objects: ['$null', { $class: U(7), targetSessionUUID: U(5), keyboardOutput: U(2), textToAssert: U(4) }, { $class: U(3) }, cls('TIKeyboardOutput'), '', { 'NS.uuidbytes': uuid, $class: U(6) }, cls('NSUUID'), cls('RTITextOperations')] });
export const insertPayload = (uuid, text) => bplist.write({ $version: 100000, $archiver: 'RTIKeyedArchiver', $top: { textOperations: U(1) }, $objects: ['$null', { keyboardOutput: U(2), $class: U(7), targetSessionUUID: U(5) }, { insertionText: U(3), $class: U(4) }, text, cls('TIKeyboardOutput'), { 'NS.uuidbytes': uuid, $class: U(6) }, cls('NSUUID'), cls('RTITextOperations')] });
