// Roku "ecp-2" WebSocket session (ws://ip:8060/ecp-session) — the channel the official Roku phone app uses for its remote buttons.
// Written for this project from the protocol as published in open-source projects (see THIRD_PARTY_NOTICES.md at the repo root):
//   handshake: GET /ecp-session, Sec-WebSocket-Protocol: ecp-2, Sec-WebSocket-Origin: Android · the Roku sends {"notify":"authenticate","param-challenge":C}
//   reply {"request":"authenticate","param-response":base64(SHA1(C + KEY)),"request-id":"0"} → {"response":"authenticate","status":"200"}
//   then {"request":"key-press","param-key":"Home","request-id":"N"} → {"response":"key-press","response-id":"N","status":"200"}.
// It is only used when the plain HTTP keypress is refused (403): Roku TVs set to a restricted "Control by mobile apps" mode still accept this channel.
import { Sock } from './sock.js';
import { cat, te, td, b64, err } from './bytes.js';
import { dlog } from './dbg.js';

const KEY = 'F3A278B8-1C6F-44A9-9D89-F1979CA4C6F1';
const sha1b64 = async (s) => b64(new Uint8Array(await globalThis.crypto.subtle.digest('SHA-1', te.encode(s))));
const rnd = (n) => globalThis.crypto.getRandomValues(new Uint8Array(n));

function frame(op, payload) {                                           // client frames are always masked (RFC 6455 §5.3)
  const n = payload.length, mask = rnd(4);
  const head = n < 126 ? [0x80 | op, 0x80 | n] : n < 65536 ? [0x80 | op, 0x80 | 126, n >> 8, n & 255] : [0x80 | op, 0x80 | 127, 0, 0, 0, 0, (n >>> 24) & 255, (n >>> 16) & 255, (n >>> 8) & 255, n & 255];
  const out = new Uint8Array(head.length + 4 + n); out.set(head, 0); out.set(mask, head.length);
  for (let i = 0; i < n; i++) out[head.length + 4 + i] = payload[i] ^ mask[i & 3];
  return out;
}
function parse(b) {                                                     // one complete frame from the buffer, or null while it is still arriving
  if (b.length < 2) return null;
  const op = b[0] & 15, fin = !!(b[0] & 128), masked = !!(b[1] & 128); let len = b[1] & 127, i = 2;
  if (len === 126) { if (b.length < 4) return null; len = (b[2] << 8) | b[3]; i = 4; }
  else if (len === 127) { if (b.length < 10) return null; len = b[6] * 16777216 + ((b[7] << 16) | (b[8] << 8) | b[9]); i = 10; }
  const m = masked ? b.subarray(i, i + 4) : null; if (masked) i += 4;
  if (b.length < i + len) return null;
  const p = b.slice(i, i + len); if (m) for (let k = 0; k < len; k++) p[k] ^= m[k & 3];
  return { n: i + len, v: { op, fin, p } };
}
const hdrEnd = (b) => { for (let i = 3; i < b.length; i++) if (b[i] === 10 && b[i - 1] === 13 && b[i - 2] === 10 && b[i - 3] === 13) return i + 1; return -1; };

const sessions = new Map();                                             // host:port -> { sock, q, id }
async function msg(c, ms) {                                             // next complete text message (answers pings, fails on close)
  let text = [];
  for (;;) {
    const f = await c.sock.waitFor(parse, ms);
    if (f.op === 8) { c.sock.close(); throw err('The Roku closed the phone-app connection', 'closed'); }
    if (f.op === 9) { await c.sock.write(frame(10, f.p)); continue; }
    if (f.op === 10) continue;
    text.push(f.p);
    if (f.fin) { const s = td.decode(cat(...text)); try { return JSON.parse(s); } catch { text = []; dlog('roku ws: unreadable message ' + s.slice(0, 80)); } }
  }
}
async function connect(host, port) {
  const t0 = Date.now(), sock = await Sock.open({ host, port, timeoutMs: 3500 });
  const c = { sock, id: 0 };
  try {
    const key = b64(rnd(16));
    await sock.write(te.encode(`GET /ecp-session HTTP/1.1\r\nHost: ${host}:${port}\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Key: ${key}\r\nSec-WebSocket-Version: 13\r\nSec-WebSocket-Protocol: ecp-2\r\nSec-WebSocket-Origin: Android\r\n\r\n`));
    const head = await sock.waitFor((b) => { const n = hdrEnd(b); return n < 0 ? null : { n, v: td.decode(b.subarray(0, n)) }; }, 4000);
    const line = head.split('\r\n')[0]; dlog(`roku ws: ${line}`);
    if (!/^HTTP\/1\.[01] 101/.test(line)) throw err(`The Roku refused the phone-app connection (${line})`, 'ws_refused');
    let m = await msg(c, 4000);
    if (!m['param-challenge']) throw err('The Roku sent no sign-in challenge', 'ws_auth');
    await sock.write(frame(1, te.encode(JSON.stringify({ 'param-response': await sha1b64(m['param-challenge'] + KEY), request: 'authenticate', 'request-id': String(c.id++) }))));
    for (let k = 0; k < 6; k++) { m = await msg(c, 4000); if (m.response === 'authenticate') break; }
    if (m.response !== 'authenticate' || String(m.status) !== '200') throw err(`The Roku did not accept the phone-app sign-in (status ${m.status} ${m['status-msg'] || ''})`, 'ws_auth');
    dlog(`roku ws: connected and signed in (${Date.now() - t0} ms)`);
    return c;
  } catch (e) { sock.close(); throw e; }
}
export const rokuWs = {
  /** Press one key over the phone-app channel. Returns the status text for the log; throws when the Roku won't take it. */
  async press(dev, name, timeoutMs = 3500) {
    const host = dev.host, port = dev.port || 8060, k = host + ':' + port;
    let s = sessions.get(k); if (!s) { s = { c: null, q: Promise.resolve() }; sessions.set(k, s); }
    const run = async () => {
      for (let attempt = 0; attempt < 2; attempt++) {
        let fresh = false;
        if (!s.c || s.c.sock.closed) { s.c = await connect(host, port); fresh = true; }
        const c = s.c;
        try {
          const id = String(c.id++);
          try { await c.sock.write(frame(1, te.encode(JSON.stringify({ request: 'key-press', 'param-key': name, 'request-id': id })))); }
          catch (e) { c.sock.close(); s.c = null; if (fresh || attempt) throw e; continue; }          // an old session the Roku had dropped: nothing was sent, open a new one
          for (let j = 0; j < 20; j++) {
            const m = await msg(c, timeoutMs);
            if (m['response-id'] === id) { const st = String(m.status); dlog(`roku ws: key-press ${name} → ${st} ${m['status-msg'] || ''}`); if (st !== '200') throw err(`The Roku answered ${st} ${m['status-msg'] || ''} to ${name}`, 'ws_status', { status: +st }); return `ws key-press ${name} → ${st}`; }
          }
          throw err('The Roku sent no answer', 'timeout');
        } catch (e) { if (e.code !== 'ws_status') { c.sock.close(); s.c = null; } throw e; }
      }
    };
    const p = s.q.then(run, run); s.q = p.catch(() => {}); return p;
  },
  closeAll() { for (const s of sessions.values()) { try { s.c && s.c.sock.close(); } catch { /* gone */ } } sessions.clear(); },
};
