globalThis.__ATV_DEBUG = !!process.env.ATV_DEBUG;
import { makeTransport as makeNodeTransport, stopJvm } from './transports.mjs';
import { mkCert } from './node-transport.mjs';
import { setTransport } from '../../web/native/transport.js';
import { makeStore, createBackend } from '../../web/native/backend.js';
import { startRokuMock } from '../mocks/roku-mock.mjs';
import { startAndroidTvMock } from '../mocks/androidtv-mock.mjs';
import { startAppleTvMock } from '../mocks/appletv-mock.mjs';
import { startAdbMock } from '../mocks/adb-mock.mjs';
import { ok, eq, rejects, section, summary } from './lib.mjs';
import { sleep } from '../../web/native/bytes.js';
import { getLog } from '../../web/native/dbg.js';
import * as pb from '../../web/native/pb.js';
import { adbPubKey } from '../../web/native/firetv.js';
import { rsaFromCertDer } from '../../web/native/asn1.js';
import crypto from 'node:crypto';

const makeSimStub = () => async (path) => ({ stub: path, demo: true });
const mk = (ports, extra = {}) => createBackend({ makeSim: makeSimStub, store: makeStore(null), transport: makeNodeTransport(extra.t), ports, ssdpTarget: extra.ssdpTarget });
const call = (b, path, method = 'GET', body) => b.handler(path, { method, body: body ? JSON.stringify(body) : undefined });

// ---------------------------------------------------------------- unit: protobuf + DER
section('protobuf / DER helpers');
{
  const m = pb.decode(pb.fMsg(3, pb.fString(2, 'héllo')));
  eq(new TextDecoder().decode(pb.field(pb.decode(pb.field(m, 3).v), 2).v), 'héllo', 'protobuf round-trip with utf-8');
  eq([...pb.varint(300)], [172, 2], 'varint(300)');
  const [f, rest] = pb.unframe(new Uint8Array([2, 9, 9, 3, 1]));
  ok(f.length === 1 && rest.length === 2, 'unframe leaves partial frame');
  const { privateKey } = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
  const der = mkCert(privateKey, 'x'); const jwk = new crypto.X509Certificate(der).publicKey.export({ format: 'jwk' });
  eq(Buffer.from(rsaFromCertDer(new Uint8Array(der)).n).toString('base64url'), jwk.n, 'DER parser extracts RSA modulus from an X.509 cert');
  const t = makeNodeTransport(); const id = await t.genIdentity({ cert: false });
}

// ---------------------------------------------------------------- Roku
section('Roku ECP (mock on 127.0.0.1:18060, SSDP responder on udp 11900)');
const roku = await startRokuMock({ port: 18060, ssdpPort: 11900 });
{
  const b = mk({ roku: { http: 18060 } }, { ssdpTarget: { host: '127.0.0.1', port: 11900 } });
  const r = await call(b, '/api/discover', 'POST');
  eq(r.found, 1, 'SSDP discovery finds the Roku'); eq(r.devices[0].name, 'Mock Living Room Roku', 'name read from /query/device-info');
  ok(r.devices[0].paired === true && r.devices[0].platform === 'roku', 'Roku is usable without pairing');
  const id = r.devices[0].id;
  for (const [k, w] of [['up', 'Up'], ['select', 'Select'], ['home', 'Home'], ['back', 'Back'], ['rew', 'Rev'], ['ff', 'Fwd'], ['play_pause', 'Play'], ['vol_up', 'VolumeUp'], ['mute', 'VolumeMute'], ['options', 'Info'], ['replay', 'InstantReplay'], ['enter', 'Enter']]) {
    roku.st.log.length = 0; const s = await call(b, '/api/send', 'POST', { device: id, action: 'key', key: k });
    ok(s.ok && roku.st.log[0] === `POST /keypress/${w}` && s.wire.includes(w), `key ${k} → POST /keypress/${w}`);
  }
  roku.st.text = ''; roku.st.log.length = 0;
  const t = await call(b, '/api/send', 'POST', { device: id, action: 'text', mode: 'append', text: 'Hi & ü 1/2' });
  eq(roku.st.text, 'Hi & ü 1/2', 'text typed via Lit_ keypresses (incl. space, &, ü, /)');
  ok(roku.st.log.includes('POST /keypress/Lit_%20') && roku.st.log.includes('POST /keypress/Lit_%26') && roku.st.log.includes('POST /keypress/Lit_%C3%BC') && roku.st.log.includes('POST /keypress/Lit_%2F'), 'special characters are url-encoded');
  await call(b, '/api/send', 'POST', { device: id, action: 'key', key: 'backspace' }); eq(roku.st.text, 'Hi & ü 1/', 'backspace key deletes a character');
  await call(b, '/api/send', 'POST', { device: id, action: 'launch', app: 'netflix' }); eq(roku.st.launched, '12', 'launch netflix → /launch/12');
  await call(b, '/api/send', 'POST', { device: id, action: 'launch', app: 'disney' }); eq(roku.st.launched, '291097', 'launch disney → id from /query/apps');
  await rejects(call(b, '/api/send', 'POST', { device: id, action: 'launch', app: 'nope' }), 'bad_app', 'unknown app is rejected');
  const pr = await call(b, '/api/pair/start', 'POST', { device: id }); eq(pr.status, 'paired', 'Roku pair/start → paired immediately');
  // add by IP
  const b2 = mk({ roku: { http: 18060 } }); const a = await call(b2, '/api/devices', 'POST', { platform: 'roku', host: '127.0.0.1' }); eq(a.name, 'Mock Living Room Roku', 'add by IP validates and names the Roku');
  await rejects(call(b2, '/api/devices', 'POST', { platform: 'roku', host: 'bad host!' }), 'bad_host', 'bad host string rejected');
  { const e = await rejects(call(b2, '/api/devices', 'POST', { platform: 'appletv', host: '127.0.0.1' }), 'unreachable', 'Apple TV added by IP with nothing listening → clear unreachable error (suggests Scan)'); ok(/Port check 127\.0\.0\.1: 49153 control .*7000 AirPlay/.test(e.message) && /refused|Connection refused/i.test(e.message), 'Apple TV error carries the native reason and a port check'); }
  { const e = await rejects(mk({ roku: { http: 18061 } }).handler('/api/devices', { method: 'POST', body: JSON.stringify({ platform: 'roku', host: '127.0.0.1' }) }), 'unreachable', 'unreachable Roku gives a clear error'); ok(/Port check 127\.0\.0\.1: 18061 ECP/.test(e.message), 'Roku error carries a port check'); }
  // demo toggle
  b.setDemo(true); eq((await call(b, '/api/devices')).stub, '/api/devices', 'demo mode routes to the simulation'); b.setDemo(false);
  ok((await call(b, '/api/devices')).demo === false, 'leaving demo mode returns to real devices');
}
roku.close();
{
  const r2 = await startRokuMock({ port: 18062, ssdpPort: 11901, restricted: true });
  const b = mk({ roku: { http: 18062 } }); const e = await rejects(call(b, '/api/devices', 'POST', { platform: 'roku', host: '127.0.0.1' }), 'forbidden', 'Roku with "Control by mobile apps" disabled → helpful error');
  ok(/Control by mobile apps/.test(e.message), 'error tells the user which Roku setting to change'); r2.close();
  const r3 = await startRokuMock({ port: 18063, ssdpPort: 11902, noPower: true }); const b3 = mk({ roku: { http: 18063 } });
  const d = await call(b3, '/api/devices', 'POST', { platform: 'roku', host: '127.0.0.1' }); const w = await call(b3, '/api/send', 'POST', { device: d.id, action: 'key', key: 'power' });
  ok(w.wire.includes('PowerOff') && r3.st.log.includes('POST /keypress/PowerOff'), 'power falls back to PowerOff when Power is rejected'); r3.close();
}

// ---------------------------------------------------------------- Google TV
section('Google TV / Android TV remote v2 (self-written TLS mock on 16467 (pairing) / 16466 (remote))');
const atv = await startAndroidTvMock({ pairPort: 16467, remotePort: 16466 });
{
  const ports = { googletv: { pair: 16467, remote: 16466 } };
  const b = mk(ports);
  const d = await call(b, '/api/devices', 'POST', { platform: 'googletv', host: '127.0.0.1', name: 'Mock TV' }); ok(d.paired === false, 'Android TV added as needing pairing');
  await rejects(call(b, '/api/send', 'POST', { device: d.id, action: 'key', key: 'up' }), 'not_paired', 'sending before pairing → not_paired');
  const ps = await call(b, '/api/pair/start', 'POST', { device: d.id });
  ok(ps.status === 'code' && ps.kind === 'hex' && ps.length === 6, 'pair/start → asks for 6-char hex code'); ok(/^[0-9A-F]{6}$/.test(atv.st.code), `mock TV is displaying code ${atv.st.code}`);
  ok(atv.st.pairLog.join('|') === 'pairing_request atvremote / Spin Remote|options|configuration', 'handshake order: pairing_request → options → configuration');
  await rejects(call(b, '/api/pair/finish', 'POST', { device: d.id, code: 'ZZZZZZ' }), 'bad_code', 'non-hex code rejected');
  const wrong = ((parseInt(atv.st.code.slice(0, 2), 16) ^ 1).toString(16).padStart(2, '0') + atv.st.code.slice(2)).toUpperCase(); await rejects(call(b, '/api/pair/finish', 'POST', { device: d.id, code: wrong }), 'bad_code', 'wrong code rejected (client-side hash check)');
  const fin = await call(b, '/api/pair/finish', 'POST', { device: d.id, code: atv.st.code.toLowerCase() }); eq(fin.status, 'paired', 'correct code → paired (mock verified the SHA-256 secret)');
  ok(atv.st.pairLog.includes('secret ok'), 'mock TV accepted the secret');
  ok((await call(b, '/api/devices')).devices[0].paired === true, 'device now stored as paired');
  const s = await call(b, '/api/send', 'POST', { device: d.id, action: 'key', key: 'select' }); ok(s.ok, 'key select sent');
  await call(b, '/api/send', 'POST', { device: d.id, action: 'key', key: 'vol_up' }); await call(b, '/api/send', 'POST', { device: d.id, action: 'key', key: 'home' });
  await sleep(150); eq(atv.st.keys.map((k) => k.code), [23, 24, 3], 'TV received DPAD_CENTER(23), VOLUME_UP(24), HOME(3)'); ok(atv.st.keys.every((k) => k.dir === 3), 'direction SHORT');
  await call(b, '/api/send', 'POST', { device: d.id, action: 'text', mode: 'append', text: 'cat' }); await sleep(150);
  eq(atv.st.texts, ['cat'], 'text delivered via remote_ime_batch_edit'); eq([atv.st.lastIme.ime, atv.st.lastIme.field, atv.st.lastIme.end], [7, 9, 2], 'IME counters echoed from the TV (7/9), cursor at end');
  await call(b, '/api/send', 'POST', { device: d.id, action: 'launch', app: 'youtube' }); await sleep(150); eq(atv.st.apps, ['https://www.youtube.com'], 'app launch via app link');
  await sleep(50); ok(atv.st.pings >= 1, 'answered the TV\'s ping'); eq(atv.st.started, 1, 'one remote session reused for all commands');
  // new phone (different cert) must not be able to use a TV it never paired with
  b.closeAll();   // drop the paired phone's live session (sessions are keyed per device inside the app)
  const store2 = makeStore(null); const b3 = createBackend({ makeSim: makeSimStub, store: store2, transport: makeNodeTransport(), ports }); const d3 = await call(b3, '/api/devices', 'POST', { platform: 'googletv', host: '127.0.0.1' });
  store2.set('devices', store2.get('devices').map((x) => ({ ...x, paired: true }))); const e = await rejects(call(b3, '/api/send', 'POST', { device: d3.id, action: 'key', key: 'up' }), 'not_paired', 'unpaired phone is hung up on → not_paired');
  ok(/not paired/i.test(e.message), 'message tells the user to pair again');
  ok((await call(b3, '/api/devices')).devices[0].paired === false, 'device flag flips back to needs-pairing');
  b3.closeAll();
}
atv.close();

// ---------------------------------------------------------------- Apple TV
section('Apple TV Companion protocol (self-written mock on 17000: HAP Pair-Setup/Verify + encrypted OPACK)');
{
  const m = await startAppleTvMock({ port: 17000 });
  const ports = { appletv: { companion: 17000 } };
  const mdns = [
    { type: '_companion-link._tcp.', host: '127.0.0.1', port: 17000, name: 'Living Room', txt: { rpMd: 'AppleTV14,1' } },
    { type: '_companion-link._tcp.', host: '127.0.0.9', port: 49200, name: 'Lex’s iPhone', txt: { rpMd: 'iPhone15,2' } },
    { type: '_companion-link._tcp.', host: '127.0.0.8', port: 49201, name: 'Office HomePod', txt: { rpMd: 'AudioAccessory5,1' } }];
  const b0 = createBackend({ makeSim: makeSimStub, store: makeStore(null), transport: makeNodeTransport({ mdns }), ports: {}, ssdpTarget: { host: '127.0.0.1', port: 11998 } });
  const found = await call(b0, '/api/discover', 'POST');
  ok(found.devices.filter((d) => d.platform === 'appletv').length === 1 && found.devices.find((d) => d.platform === 'appletv').name === 'Living Room', 'mDNS _companion-link finds only the Apple TV (iPhone and HomePod ignored)');
  eq(b0.info().platforms.includes('appletv'), true, 'native info lists appletv as a real platform');
  const store = makeStore(null); const b = createBackend({ makeSim: makeSimStub, store, transport: makeNodeTransport(), ports });
  const d = await call(b, '/api/devices', 'POST', { platform: 'appletv', host: '127.0.0.1', name: 'Mock Apple TV' }); ok(d.paired === false, 'Apple TV added as needing pairing');
  await rejects(call(b, '/api/send', 'POST', { device: d.id, action: 'key', key: 'up' }), 'not_paired', 'sending before pairing → not_paired');
  const ps = await call(b, '/api/pair/start', 'POST', { device: d.id });
  ok(ps.status === 'code' && ps.kind === 'num' && ps.length === 4, 'pair/start → asks for the 4-digit code'); ok(/^\d{4}$/.test(m.st.pin) && m.st.pairLog[0].startsWith('PS M1'), `mock TV is displaying PIN ${m.st.pin}`);
  ok(/4-digit code/.test(ps.message), 'pairing sheet message explains what to look for');
  await rejects(call(b, '/api/pair/finish', 'POST', { device: d.id, code: '12' }), 'bad_code', 'too-short code rejected client-side');
  const wrong = String((Number(m.st.pin) + 1) % 10000).padStart(4, '0');
  await rejects(call(b, '/api/pair/finish', 'POST', { device: d.id, code: wrong }), 'bad_code', 'wrong PIN rejected (mock checked the SRP proof)'); eq(m.st.wrongPins, 1, 'mock TV counted one failed attempt');
  await rejects(call(b, '/api/pair/finish', 'POST', { device: d.id, code: m.st.pin }), 'protocol', 'after a failed attempt the old pairing session is gone (must start again)');
  const ps2 = await call(b, '/api/pair/start', 'POST', { device: d.id }); eq(ps2.status, 'code', 'pairing can be restarted');
  const fin = await call(b, '/api/pair/finish', 'POST', { device: d.id, code: m.st.pin }); eq(fin.status, 'paired', 'correct PIN → paired');
  ok(m.st.pairLog.some((l) => l.startsWith('PS M5 ok, client name Spin Remote')), 'mock verified the phone\'s Ed25519 signature and stored its key');
  ok((await call(b, '/api/devices')).devices[0].paired === true, 'device now stored as paired'); ok(!!store.get('appletv.creds.' + d.id), 'pairing keys saved on the phone');
  const send = (o) => call(b, '/api/send', 'POST', { device: d.id, ...o });
  await send({ action: 'key', key: 'up' }); await send({ action: 'key', key: 'select' }); await send({ action: 'key', key: 'back' }); await send({ action: 'key', key: 'home' }); await send({ action: 'key', key: 'play_pause' }); await send({ action: 'key', key: 'vol_up' });
  eq(m.st.hid.filter((h) => h.state === 1).map((h) => h.code), [1, 6, 5, 7, 14, 8], 'TV received UP, SELECT, MENU(back), HOME, PLAY_PAUSE, VOL_UP (HID down)'); eq(m.st.hid.filter((h) => h.state === 2).length, 6, 'and a matching HID up for each');
  ok(m.st.pairLog.includes('PV ok'), 'session uses Pair-Verify (X25519/Ed25519) then ChaCha20-Poly1305 frames'); eq(m.st.sessions, 1, 'one session reused for all commands');
  await send({ action: 'key', key: 'ff' }); await send({ action: 'key', key: 'rew' }); await send({ action: 'key', key: 'next' });
  eq(m.st.mcc.map((c) => [c._mcc, c._skpS]), [[7, 10], [7, -10], [3, undefined]], 'ff/rew → SkipBy ±10 s (OPACK double), next → _mcc 3');
  await send({ action: 'key', key: 'power' }); eq(m.st.hid.at(-1).code, 12, 'power while awake → Sleep'); m.st.state = 1; await send({ action: 'key', key: 'power' }); eq(m.st.hid.at(-1).code, 13, 'power while asleep → Wake');
  await send({ action: 'launch', app: 'netflix' }); await send({ action: 'launch', app: 'com.example.App' }); eq(m.st.apps, ['com.netflix.Netflix', 'com.example.App'], 'app launch by bundle id');
  await rejects(send({ action: 'launch', app: 'not an app!' }), 'bad_app', 'unknown app rejected');
  await send({ action: 'text', mode: 'set', text: 'stranger things' }); await sleep(100); eq(m.st.field, 'stranger things', 'text set via _tiStart + RTI archive (cleared, then inserted)');
  await send({ action: 'key', key: 'backspace' }); await sleep(100); eq(m.st.field, 'stranger thing', 'backspace re-sets the field one character shorter');
  await send({ action: 'text', mode: 'set', text: '' }); await sleep(100); eq(m.st.field, '', 'clearing the field works');
  for (const t of ['a', 'ab', 'abc']) send({ action: 'text', mode: 'set', text: t }); await sleep(900); eq(m.st.field, 'abc', 'rapid keystrokes are serialised, final text correct');
  // connection dropped by the TV (sleep / Wi-Fi blip): the next command reconnects transparently
  for (const s of [...m.sockets()]) s.destroy(); await sleep(100); await send({ action: 'key', key: 'down' }); eq(m.st.hid.at(-1).code, 2, 'reconnects after the TV dropped the connection'); eq(m.st.sessions, 2, 'by opening a new verified session');
  // TV forgets this phone → app says to pair again
  b.closeAll(); m.unpairAll(); const e = await rejects(send({ action: 'key', key: 'up' }), 'not_paired', 'a TV that no longer trusts the phone → not_paired'); ok(/pair/i.test(e.message), 'message tells the user to pair again');
  ok((await call(b, '/api/devices')).devices[0].paired === false, 'device flag flips back to needs-pairing');
  // a phone that never paired
  const b3 = createBackend({ makeSim: makeSimStub, store: makeStore(null), transport: makeNodeTransport(), ports }); const d3 = await call(b3, '/api/devices', 'POST', { platform: 'appletv', host: '127.0.0.1' });
  await rejects(call(b3, '/api/send', 'POST', { device: d3.id, action: 'key', key: 'up' }), 'not_paired', 'unpaired phone cannot send');
  b.closeAll(); b3.closeAll(); m.close();
}

// ---------------------------------------------------------------- Fire TV
section('Fire TV ADB-over-network (self-written mock on 15555)');
{
  const adbm = await startAdbMock({ port: 15555, autoAllow: false });
  const b = mk({ firetv: { adb: 15555 } });
  const d = await call(b, '/api/devices', 'POST', { platform: 'firetv', host: '127.0.0.1', name: 'Mock Fire TV' }); ok(d.paired === false, 'Fire TV added as needing pairing');
  await rejects(call(b, '/api/send', 'POST', { device: d.id, action: 'key', key: 'up' }), 'not_paired', 'sending before pairing → not_paired');
  const ps = await call(b, '/api/pair/start', 'POST', { device: d.id }); eq(ps.status, 'confirm', 'pair/start → confirm (Allow prompt on TV)');
  await sleep(500); ok(adbm.st.offered.length === 1, 'phone offered its public key (valid 524-byte Android RSAPublicKey blob, n0inv and rr verified by the mock)');
  const early = call(b, '/api/pair/finish', 'POST', { device: d.id }); setTimeout(() => adbm.allow(), 300); eq((await early).status, 'paired', 'after "Allow" on the TV → paired');
  for (const [k, n] of [['up', 'DPAD_UP'], ['select', 'DPAD_CENTER'], ['home', 'HOME'], ['vol_up', 'VOLUME_UP'], ['play_pause', 'MEDIA_PLAY_PLAY'.replace('PLAY_PLAY', 'PLAY_PAUSE')]]) {
    const s = await call(b, '/api/send', 'POST', { device: d.id, action: 'key', key: k }); ok(s.ok, `key ${k} sent`); eq(adbm.st.cmds.at(-1), `shell:input keyevent KEYCODE_${n}`, `  → shell:input keyevent KEYCODE_${n}`);
  }
  await call(b, '/api/send', 'POST', { device: d.id, action: 'text', mode: 'append', text: "it's a test" }); eq(adbm.st.cmds.at(-1), "shell:input text 'it'\\''s%sa%stest'", 'text → input text with %s for spaces and shell quoting');
  await call(b, '/api/send', 'POST', { device: d.id, action: 'launch', app: 'netflix' }); eq(adbm.st.cmds.at(-1), 'shell:monkey -p com.netflix.ninja -c android.intent.category.LAUNCHER 1', 'launch netflix via monkey');
  { // hold-to-repeat: overlapping presses must not steal each other's ADB packets
    const before = adbm.st.cmds.length;
    const rs = await Promise.all(['up', 'down', 'left', 'right', 'select'].map((k) => call(b, '/api/send', 'POST', { device: d.id, action: 'key', key: k })));
    ok(rs.every((r) => r.ok), 'five overlapping key presses all succeed (no hang, no stolen packets)');
    eq(adbm.st.cmds.slice(before), ['UP', 'DOWN', 'LEFT', 'RIGHT', 'CENTER'].map((n) => `shell:input keyevent KEYCODE_DPAD_${n}`), 'they reach the TV one at a time, in order');
    const b4 = adbm.st.cmds.length; const many = await Promise.all(Array.from({ length: 12 }, () => call(b, '/api/send', 'POST', { device: d.id, action: 'key', key: 'vol_up' })));
    ok(many.every((r) => r.ok), '12 quick TAPS never error'); eq(adbm.st.cmds.length - b4, 12, '…and every single tap reaches the TV (taps are never dropped or coalesced)');
    const b5 = adbm.st.cmds.length; const rep = await Promise.all(Array.from({ length: 12 }, () => call(b, '/api/send', 'POST', { device: d.id, action: 'key', key: 'vol_up', repeat: true })));
    await sleep(300); ok(rep.every((r) => r.ok), 'a flood of 12 hold-repeats never errors'); const sent = adbm.st.cmds.length - b5; ok(sent >= 1 && sent <= 2, `…and hold-repeats coalesce to the one in flight + the newest (${sent} of 12 sent)`);
    const b6 = adbm.st.cmds.length; const mix = await Promise.all([...Array.from({ length: 5 }, () => call(b, '/api/send', 'POST', { device: d.id, action: 'key', key: 'vol_down', repeat: true })), call(b, '/api/send', 'POST', { device: d.id, action: 'key', key: 'mute' })]);
    await sleep(300); ok(adbm.st.cmds.slice(b6).includes('shell:input keyevent KEYCODE_VOLUME_MUTE'), 'a mute TAP in the middle of a repeat storm still reaches the TV');
  }
  { // ONE persistent shell stream: no per-press reconnect, no per-press stream setup
    const o0 = adbm.st.opens, ci = adbm.st.interactiveOpens, n0 = adbm.st.cmds.length;
    for (let i = 0; i < 5; i++) await call(b, '/api/send', 'POST', { device: d.id, action: 'key', key: 'down' });
    eq(adbm.st.interactiveOpens, ci, 'five more presses opened no new shell stream'); eq(adbm.st.opens, o0, '…and no new streams at all'); eq(adbm.st.cmds.length - n0, 5, '…and all five arrived');
  }
  b.closeAll();
  { // a Fire TV that hangs up when it shows the Allow dialog ("Socket is closed" on a real phone): pairing must reconnect by itself
    const dm = await startAdbMock({ port: 15556, dropOnOffer: true }); const bd = mk({ firetv: { adb: 15556 } });
    const dd = await call(bd, '/api/devices', 'POST', { platform: 'firetv', host: '127.0.0.1', name: 'Dropper' });
    const ps2 = await call(bd, '/api/pair/start', 'POST', { device: dd.id }); eq(ps2.status, 'confirm', 'pair/start → confirm (one connection, key offered)');
    ok(/press Allow/.test(ps2.message), 'prompt is plain: "Look at your Fire TV and press Allow"');
    const fin = await call(bd, '/api/pair/finish', 'POST', { device: dd.id }); eq(fin.status, 'paired', 'TV dropped the socket at the dialog → reconnected → paired');
    const sk = await call(bd, '/api/send', 'POST', { device: dd.id, action: 'key', key: 'home' }); ok(sk.ok, 'and keys work afterwards'); bd.closeAll(); dm.close();
  }
  // reconnect with a fresh backend that keeps the same key: signature path (no prompt)
  const store = makeStore(null); const t = makeNodeTransport();
  const b1 = createBackend({ makeSim: makeSimStub, store, transport: t, ports: { firetv: { adb: 15555 } } });
  const d1 = await call(b1, '/api/devices', 'POST', { platform: 'firetv', host: '127.0.0.1' });
  const p1 = await call(b1, '/api/pair/start', 'POST', { device: d1.id }); await sleep(300); setTimeout(() => adbm.allow(), 100); await call(b1, '/api/pair/finish', 'POST', { device: d1.id }); b1.closeAll();
  const before = adbm.st.offered.length; const b2 = createBackend({ makeSim: makeSimStub, store, transport: t, ports: { firetv: { adb: 15555 } } });
  const r = await call(b2, '/api/send', 'POST', { device: d1.id, action: 'key', key: 'back' }); ok(r.ok && adbm.st.offered.length === before, 'known key authenticates by RSA signature, no second prompt'); void p1;
  eq(adbm.st.badSig, adbm.st.badSig, 'signature failures counted'); ok(adbm.st.badSig >= 1, 'first connect with an unknown key got a signature rejection before offering the key (expected ADB behaviour)');
  b2.closeAll(); adbm.close();
  const e = await rejects(mk({ firetv: { adb: 15599 } }).handler('/api/devices', { method: 'POST', body: JSON.stringify({ platform: 'firetv', host: '127.0.0.1' }) }), 'unreachable', 'ADB off → helpful error'); ok(/ADB debugging/.test(e.message), 'error says to enable ADB debugging'); ok(/Port check 127\.0\.0\.1: 15599 ADB .*8009 Cast/.test(e.message) && /Phone: /.test(e.message), 'Fire TV error shows the real reason, a port check and the phone network line');
}

// ---------------------------------------------------------------- discovery fallback + certificates
section('Discovery fallback (multicast blocked → /24 port sweep) and generated certificates');
{
  const r = await startRokuMock({ port: 18064, ssdpPort: 11903, name: 'Sweep Roku' }); const a = await startAndroidTvMock({ pairPort: 16467, remotePort: 16466, host: '127.0.0.2' });
  const b = createBackend({ makeSim: makeSimStub, store: makeStore(null), transport: makeNodeTransport({ scanHosts: ['127.0.0.1', '127.0.0.2'] }), ports: { roku: { http: 18064 }, googletv: { pair: 16467, remote: 16466 } }, ssdpTarget: { host: '127.0.0.1', port: 11999 } });
  const res = await call(b, '/api/discover', 'POST');
  ok(res.devices.some((d) => d.platform === 'roku' && d.name === 'Sweep Roku' && d.paired), 'sweep finds the Roku (no SSDP answer) and reads its name');
  ok(res.devices.some((d) => d.platform === 'googletv' && !d.paired), 'sweep finds the Android TV remote port');
  const again = await call(b, '/api/discover', 'POST'); eq(again.found, 0, 'second scan does not duplicate devices'); eq(again.devices.length, 2, 'still two devices');
  const t = makeNodeTransport(); const id = await t.genIdentity();
  const x = new crypto.X509Certificate(Buffer.from(id.certDer, 'base64'));
  ok(x.subject === 'CN=atvremote' && x.checkIssued(x) && x.verify(x.publicKey), 'generated client certificate is a valid self-signed X.509 (parsed + signature verified by Node)');
  eq(Buffer.from(x.publicKey.export({ format: 'jwk' }).n, 'base64url').toString('hex'), id.modulusHex, 'modulusHex matches the certificate public key');
  r.close(); a.close();
}

// ---------------------------------------------------------------- real-phone scenarios (NSD error 7, unreachable TV, debug log)
section('Real-phone scenario: NSD fails (error 7) → only Google TV is searched, sweep finds the TV; failures are explained');
{
  const a = await startAndroidTvMock({ pairPort: 16467, remotePort: 16466, host: '127.0.0.1' });
  const tr = makeNodeTransport({ scanHosts: ['127.0.0.1'], mdnsFail: (t) => `Android's network-service discovery (NSD) failed to start for ${t} (error 7)` });
  const b = createBackend({ makeSim: makeSimStub, store: makeStore(null), transport: tr, ports: { googletv: { pair: 16467, remote: 16466 } } });
  const res = await call(b, '/api/discover', 'POST', { platform: 'googletv' });
  eq(tr.mdnsCalls, ['_androidtvremote2._tcp.'], 'only the Google TV service type was searched (no Fire TV / Apple TV NSD listeners)');
  ok(res.devices.some((d) => d.platform === 'googletv'), 'the TV is found by the port sweep although NSD failed');
  ok(res.diag.mdns.length === 1 && /Google TV/.test(res.diag.mdns[0]) && !/Fire TV|Apple TV/.test(JSON.stringify(res.diag)), 'diagnostics mention only Google TV, never another platform');
  ok(/Scanned .*(16467|6467)/.test(res.diag.sweep) && /127\.0\.0\.1:1646[67]/.test(res.diag.sweep), 'sweep summary lists the ports it scanned and what answered');
  // all platforms: searches are strictly one after another and each failure stays labelled
  let live = 0, maxLive = 0; const t2 = makeNodeTransport({ scanHosts: [] }); const m0 = t2.mdns;
  t2.mdns = async (o) => { live++; maxLive = Math.max(maxLive, live); await sleep(20); try { return await m0(o); } finally { live--; } };
  const b2 = createBackend({ makeSim: makeSimStub, store: makeStore(null), transport: t2, ports: {} });
  await call(b2, '/api/discover', 'POST', {});
  ok(maxLive <= 3, `build 23: mDNS types are asked together (${maxLive} at once); the phone side asks the network directly in parallel and still runs Android NSD one at a time (nsdLock)`);
  eq(t2.mdnsCalls, ['_amzn-wplay._tcp.', '_androidtvremote2._tcp.', '_companion-link._tcp.'], 'all-platform discovery queries each service type exactly once, in order');
  a.close();
}
section('Unreachable TV: retries, port report, real error text, debug log');
{
  const tr = makeNodeTransport({}); const b = createBackend({ makeSim: makeSimStub, store: makeStore(null), transport: tr, ports: { googletv: { pair: 16999, remote: 16998 } } });
  const t0 = Date.now();
  const e = await rejects(call(b, '/api/devices', 'POST', { platform: 'googletv', host: '127.0.0.1' }), 'unreachable', 'adding a Google TV that refuses connections fails with "unreachable"');
  ok(/Couldn’t reach a Google TV at 127\.0\.0\.1 \(port 16999\)/.test(e.message), 'message names the host and port');
  ok(/Port check 127\.0\.0\.1: 6467 pairing .*6466 control .*8009 Cast/.test(e.message), 'message includes the 6467 / 6466 / 8009 port check');
  ok(/Phone: /.test(e.message), 'message includes the phone network line');
  const log = getLog();
  ok((log.match(/probe 127\.0\.0\.1:16999: attempt \d failed/g) || []).length === 3, 'three connection attempts were made and logged');
  ok(/native\.tcpOpen\(127\.0\.0\.1:16999 tls=false clientCert=false timeout=9000ms\)/.test(log), 'connect timeout is 9 s');
  ok(/native\.probe\(127\.0\.0\.1 ports 6467,6466,8009,8008,5555\)/.test(log), 'the port probe is in the debug log');
  ok(!/BEGIN|keyPkcs8|MII[A-Za-z0-9+/]{20}/.test(log), 'debug log contains no key or certificate material');
  ok(Date.now() - t0 < 12000, 'a refused port fails fast instead of waiting out the timeouts');
}

section('Google TV pairing: Details names the step that failed (TCP → TLS → pairing request → code on the TV)');
{
  const net = (await import('node:net')).default;
  // 1. everything fine: the debug log has all four steps, each OK
  const a = await startAndroidTvMock({ pairPort: 17467, remotePort: 17466, host: '127.0.0.1' });
  const mkB = (pair) => createBackend({ makeSim: makeSimStub, store: makeStore(null), transport: makeNodeTransport({}), ports: { googletv: { pair, remote: 17466 } } });
  const b = mkB(17467);
  const d = await call(b, '/api/devices', 'POST', { platform: 'googletv', host: '127.0.0.1' });
  const r = await call(b, '/api/pair/start', 'POST', { device: d.id });
  eq(r.status, 'code', 'pairing starts and the TV shows a code');
  const log = getLog();
  ok(/pairing step 1\. TCP connect: OK/.test(log), 'step 1 (TCP) is logged OK');
  ok(/pairing step 2\. TLS handshake .*: OK/.test(log) && /pairing step 3\. Pairing request: OK/.test(log) && /pairing step 4\. Code on the TV: OK/.test(log), 'steps 2-4 (TLS, pairing request, code on the TV) are logged OK');
  // 2. TCP port closed → step 1 and the TCP step fail, with the port check
  a.close(); await sleep(100);
  const e1 = await rejects(call(b, '/api/pair/start', 'POST', { device: d.id }), 'unreachable', 'TV port closed → unreachable');
  ok(/Steps \(127\.0\.0\.1:17467\):\n1\. TCP connect \(3 tries, 9 s each\): FAILED/.test(e1.message), 'Details: step 1 (TCP connect) FAILED');
  ok(/Port check 127\.0\.0\.1/.test(e1.message) && /Phone: /.test(e1.message), 'Details: TCP step FAILED, plus the port check and the phone line');
  // 3. TCP fine but TLS refused (something that is not a TLS server)
  const junk = net.createServer((c) => { c.on('error', () => {}); c.end(Buffer.from('HTTP/1.0 400 not tls\r\n\r\n')); }); await new Promise((res) => junk.listen(17499, '127.0.0.1', res));
  const b3 = mkB(17499); const d3 = await call(b3, '/api/devices', 'POST', { platform: 'googletv', host: '127.0.0.1' });
  const e2 = await rejects(call(b3, '/api/pair/start', 'POST', { device: d3.id }), 'protocol', 'TCP ok but no TLS → protocol error (not "unreachable")');
  ok(/1\. TCP connect: OK/.test(e2.message) && /2\. TLS handshake .*: FAILED/.test(e2.message), 'Details: TCP OK, TLS handshake FAILED');
  ok(/refused the secure connection/.test(e2.message), 'headline says the TV refused the secure connection');
  junk.close();
}

section('Roku "Control by mobile apps" = Limited: launch works but keypress is 403 → clear, visible error + diagnostics');
{
  const http = (await import('node:http')).default; const hits = [];
  const srv = http.createServer((q, r) => { hits.push(q.method + ' ' + q.url); if (q.url === '/query/device-info') { r.end('<device-info><user-device-name>Limited Roku</user-device-name></device-info>'); return; } if (q.url.startsWith('/launch/')) { r.statusCode = 200; r.end(); return; } r.statusCode = 403; r.end('Forbidden'); });
  await new Promise((res) => srv.listen(18077, '127.0.0.1', res));
  const b = createBackend({ makeSim: makeSimStub, store: makeStore(null), transport: makeNodeTransport({}), ports: { roku: { http: 18077 } } });
  const d = await call(b, '/api/devices', 'POST', { platform: 'roku', host: '127.0.0.1' });
  const l = await call(b, '/api/send', 'POST', { device: d.id, action: 'launch', app: 'netflix' });
  ok(/launch\/12 → 200/.test(l.wire), 'launch still works and its wire text shows the HTTP status');
  const e = await rejects(call(b, '/api/send', 'POST', { device: d.id, action: 'key', key: 'up' }), 'forbidden', 'keypress 403 → "forbidden" error');
  ok(/403 Forbidden to \/keypress\/Up/.test(e.message) && /Network access/.test(e.message) && /Limited/.test(e.message), 'message names the 403, the setting and "Limited"');
  ok(hits.includes('POST /keydown/Up') && hits.includes('GET /query/apps'), 'keydown fallback was tried and /query/apps was checked for the diagnosis');
  ok(/ECP POST \/keypress\/Up → HTTP 403/.test(getLog()), 'HTTP status of the command is in the debug log');
  srv.close();
}

section('Pair screen lists only TVs seen right now (saved TVs elsewhere stay stored but are not listed)');
{
  const http = (await import('node:http')).default;
  const srv = http.createServer((q, r) => { if (q.url === '/query/device-info') r.end('<device-info><user-device-name>Here Roku</user-device-name></device-info>'); else r.end('ok'); });
  await new Promise((res) => srv.listen(18078, '127.0.0.1', res));
  const store = makeStore(null);
  store.set('devices', [
    { id: 'roku-127.0.0.1', platform: 'roku', host: '127.0.0.1', name: 'Here Roku', paired: true },
    { id: 'roku-127.0.0.3', platform: 'roku', host: '127.0.0.3', name: 'Home Roku (other network)', paired: true },
    { id: 'firetv-127.0.0.4', platform: 'firetv', host: '127.0.0.4', name: 'Ben’s Fire TV', paired: true },
    { id: 'googletv-127.0.0.5', platform: 'googletv', host: '127.0.0.5', name: 'Lex’s room TV', paired: true },
  ]);
  const b = createBackend({ makeSim: makeSimStub, store, transport: makeNodeTransport({}), ports: { roku: { http: 18078 } }, ssdpTarget: { host: '127.0.0.1', port: 11997 } });
  const r = await call(b, '/api/discover', 'POST', {});
  ok(Array.isArray(r.seen), 'discover returns the list of TVs seen in this scan');
  console.log(getLog().split('\n').filter((l) => /discover: seen|probe/.test(l)).slice(-3).join('\n'));
  ok(r.seen.includes('roku-127.0.0.1'), 'the reachable saved TV is listed (fast reachability check)');
  ok(!r.seen.includes('roku-127.0.0.3') && !r.seen.includes('firetv-127.0.0.4') && !r.seen.includes('googletv-127.0.0.5'), 'saved TVs that do not answer here are NOT listed');
  eq(r.devices.length, 4, 'saved TVs are still stored (quick reconnect when back home)');
  const rc = await call(b, '/api/reachable', 'POST', {});
  eq(rc.live, ['roku-127.0.0.1'], '/api/reachable returns only the saved TVs that answer on this network right now');
  srv.close();
}
const s = summary(); console.log(`\n${s.pass} passed, ${s.fail} failed`); if (s.fail) { console.log(s.fails.join('\n')); stopJvm(); process.exit(1); }
stopJvm(); process.exit(0);
