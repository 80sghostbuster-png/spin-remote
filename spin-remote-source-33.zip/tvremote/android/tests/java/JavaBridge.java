import com.spinremote.app.NetCore;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Test harness only (not part of the app): exposes the app's real NetCore Java code over stdin/stdout so the Node test-suite can run
 * the shipped JS protocol code against the mock TVs THROUGH the Java networking code.
 * Request:  id TAB method TAB base64(arg)...   Response: id TAB OK TAB json   |   id TAB ERR TAB base64(message)
 */
public class JavaBridge {
    static String q(String s) {
        if (s == null) return "null";
        StringBuilder b = new StringBuilder("\"");
        for (char c : s.toCharArray()) { if (c == '"' || c == '\\') b.append('\\').append(c); else if (c < 32) b.append(String.format("\\u%04x", (int) c)); else b.append(c); }
        return b.append('"').toString();
    }
    static String d(String b64) { return new String(Base64.getDecoder().decode(b64), StandardCharsets.UTF_8); }

    static String handle(String m, String[] a) throws Exception {
        switch (m) {
            case "genIdentity": { NetCore.Identity i = NetCore.genIdentity(Boolean.parseBoolean(d(a[0]))); return "{\"keyPkcs8\":" + q(i.keyPkcs8) + ",\"modulusHex\":" + q(i.modulusHex) + ",\"exponentHex\":" + q(i.exponentHex) + ",\"certDer\":" + q(i.certDer) + "}"; }
            case "rsaSignAdb": return "{\"sig\":" + q(Base64.getEncoder().encodeToString(NetCore.rsaSignAdb(d(a[0]), Base64.getDecoder().decode(a[1])))) + "}";
            case "open": { Map<String, String> r = NetCore.open(d(a[0]), Integer.parseInt(d(a[1])), Boolean.parseBoolean(d(a[2])), a[3].isEmpty() ? null : d(a[3]), a[4].isEmpty() ? null : d(a[4]), Integer.parseInt(d(a[5])), a.length > 6 && Boolean.parseBoolean(d(a[6]))); return "{\"id\":" + r.get("id") + ",\"peerCert\":" + q(r.get("peerCert")) + ",\"tls\":" + q(String.valueOf(r.get("tls"))) + "}"; }
            case "write": NetCore.write(Integer.parseInt(d(a[0])), Base64.getDecoder().decode(a[1])); return "{}";
            case "read": { NetCore.ReadResult r = NetCore.read(Integer.parseInt(d(a[0])), Integer.parseInt(d(a[1]))); return "{\"data\":" + (r.data == null ? "null" : q(Base64.getEncoder().encodeToString(r.data))) + ",\"closed\":" + r.closed + ",\"timeout\":" + r.timeout + "}"; }
            case "close": NetCore.close(Integer.parseInt(d(a[0]))); return "{}";
            case "http": { NetCore.HttpResult r = NetCore.http(d(a[0]), d(a[1]), d(a[2]), Integer.parseInt(d(a[3]))); return "{\"status\":" + r.status + ",\"body\":" + q(r.body) + "}"; }
            case "ssdp": {
                String host = d(a[2]); List<NetCore.SsdpHit> hits = NetCore.ssdp(d(a[0]), Integer.parseInt(d(a[1])), host.isEmpty() ? null : host, host.isEmpty() ? 0 : Integer.parseInt(d(a[3])));
                StringBuilder b = new StringBuilder("[");
                for (NetCore.SsdpHit h : hits) { if (b.length() > 1) b.append(','); b.append("{\"ip\":").append(q(h.ip)).append(",\"headers\":{"); boolean f = true; for (Map.Entry<String, String> e : h.headers.entrySet()) { if (!f) b.append(','); f = false; b.append(q(e.getKey())).append(':').append(q(e.getValue())); } b.append("}}"); }
                return b.append(']').toString();
            }
            case "tcpScan": {
                String[] ps = d(a[0]).split(","); int[] p = new int[ps.length]; for (int i = 0; i < p.length; i++) p[i] = Integer.parseInt(ps[i]);
                List<String> hosts = new ArrayList<>(); for (String h : d(a[2]).split(",")) if (!h.isEmpty()) hosts.add(h);
                StringBuilder b = new StringBuilder("[");
                for (String[] r : NetCore.tcpScan(p, Integer.parseInt(d(a[1])), hosts)) { if (b.length() > 1) b.append(','); b.append("{\"host\":").append(q(r[0])).append(",\"port\":").append(r[1]).append('}'); }
                return b.append(']').toString();
            }
            case "probe": {
                String[] ps = d(a[1]).split(","); int[] p = new int[ps.length]; for (int i = 0; i < p.length; i++) p[i] = Integer.parseInt(ps[i]);
                StringBuilder b = new StringBuilder("[");
                for (String[] r : NetCore.probe(d(a[0]), p, Integer.parseInt(d(a[2])))) { if (b.length() > 1) b.append(','); b.append("{\"port\":").append(r[0]).append(",\"state\":").append(q(r[1])).append(",\"ms\":").append(r[2]).append(",\"detail\":").append(q(r[3])).append('}'); }
                return b.append(']').toString();
            }
            case "mdnsQuery": {
                StringBuilder b = new StringBuilder("[");
                for (NetCore.MdnsHit h : NetCore.mdnsQuery(d(a[0]), Integer.parseInt(d(a[1])), d(a[2]).isEmpty() ? null : d(a[2]), d(a[2]).isEmpty() ? 0 : Integer.parseInt(d(a[3])))) {
                    if (b.length() > 1) b.append(','); b.append("{\"name\":").append(q(h.name)).append(",\"host\":").append(q(h.host)).append(",\"port\":").append(h.port).append(",\"txt\":{"); boolean f = true;
                    for (Map.Entry<String, String> e : h.txt.entrySet()) { if (!f) b.append(','); f = false; b.append(q(e.getKey())).append(':').append(q(e.getValue())); } b.append("}}");
                }
                return b.append(']').toString();
            }
            default: throw new IllegalArgumentException("unknown method " + m);
        }
    }

    public static void main(String[] args) throws Exception {
        PrintStream out = new PrintStream(System.out, true, "UTF-8");
        ExecutorService pool = Executors.newCachedThreadPool();
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8));
        String line;
        while ((line = in.readLine()) != null) {
            final String[] f = line.split("\t", -1);
            pool.execute(() -> {
                String res;
                try { String[] a = new String[f.length - 2]; System.arraycopy(f, 2, a, 0, a.length); res = f[0] + "\tOK\t" + handle(f[1], a); }
                catch (Throwable e) { String msg = e.getClass().getSimpleName() + ": " + e.getMessage(); res = f[0] + "\tERR\t" + Base64.getEncoder().encodeToString(msg.getBytes(StandardCharsets.UTF_8)); }
                synchronized (out) { out.println(res); }
            });
        }
        NetCore.closeAll(); pool.shutdownNow();
    }
}
