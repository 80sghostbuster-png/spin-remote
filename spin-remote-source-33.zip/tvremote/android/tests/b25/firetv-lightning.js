// FROZEN build 25 pairing-code layer (reconstructed exactly) — only used to show the build 26 fix against the real-protocol mock.
// Build 22: the Fire TV's own remote API — the one Amazon's Fire TV phone app uses (community-documented "Lightning" API).
//   wake:   POST http://<tv>:8009/apps/FireTVRemote          (DIAL; starts the API, works while the stick is idle)
//   API:    https://<tv>:8080 (self-signed), headers X-Api-Key: 0987654321 (fixed app key) + X-Client-Token (per phone, from PIN pairing)
//   pair:   POST /v1/FireTV/pin/display {"friendlyName"} -> 4-digit PIN on the TV; POST /v1/FireTV/pin/verify {"pin"} -> {"description": token}
//   keys:   POST /v1/FireTV?action=dpad_up|dpad_down|dpad_left|dpad_right|select|back|home|menu   (NO body: a body makes the TV answer 500)
//           POST /v1/media?action=play (play/pause toggle)
// A key press is one small HTTPS request on a kept-open connection: no adb shell, no Java program started on the TV.
// Original code written from the public protocol notes; no third-party code.
import { Sock } from '../../../web/native/sock.js';
import { err } from '../../../web/native/bytes.js';
import { dlog } from '../../../web/native/dbg.js';

const API_KEY = '0987654321';
const tokKey = (dev) => `ftv.lightning.${dev.id}`;
const conns = new Map(), queues = new Map();
const te = new TextEncoder(), td = new TextDecoder();
// Build 23: hard time limits + a per-TV "off switch". If this API is slow, refuses, or errors, ADB takes over at once and the API is
// left alone for a while, so it can never hold up connecting or button presses.
const BUDGET = { display: 3500, verify: 3500 };
const DOWN_MS = 5 * 60 * 1000;
const down = new Map();                                    // dev.id -> time until which the API is skipped
const isDown = (dev) => (down.get(dev.id) || 0) > Date.now();
function markDown(dev, why) { down.set(dev.id, Date.now() + DOWN_MS); dlog(`lightning: off for this TV for 5 min (${why}); ADB handles everything`); const c = conns.get(dev.id); if (c) { try { c.sock.close(); } catch (e) { /* gone */ } } conns.delete(dev.id); queues.delete(dev.id); }
function within(p, ms, what) { let t; return Promise.race([p, new Promise((_, rej) => { t = setTimeout(() => rej(err(`${what} took too long`, 'timeout')), ms); })]).finally(() => clearTimeout(t)); }
const ports = (dev) => ({ api: (dev.ports && dev.ports.lightning) || 8080, dial: (dev.ports && dev.ports.dial) || 8009 });

/** One HTTP/1.1 response (Content-Length or chunked) from the stream buffer. */
function httpResp(b) {
  const s = td.decode(b), h = s.indexOf('\r\n\r\n'); if (h < 0) return null;
  const head = s.slice(0, h), st = +(/^HTTP\/1\.\d (\d+)/.exec(head) || [])[1] || 0;
  const cl = /\r\ncontent-length:\s*(\d+)/i.exec(head), body0 = h + 4;
  const hb = te.encode(s.slice(0, body0)).length;          // byte offset of the body
  if (cl) { const n = +cl[1]; if (b.length < hb + n) return null; return { n: hb + n, v: { status: st, body: td.decode(b.subarray(hb, hb + n)), head } }; }
  if (/\r\ntransfer-encoding:\s*chunked/i.test(head)) {
    let i = hb, out = '';
    for (;;) { const rest = td.decode(b.subarray(i)), e = rest.indexOf('\r\n'); if (e < 0) return null; const len = parseInt(rest.slice(0, e), 16); const start = i + te.encode(rest.slice(0, e + 2)).length; if (len === 0) { if (b.length < start + 2) return null; return { n: start + 2, v: { status: st, body: out, head } }; } if (b.length < start + len + 2) return null; out += td.decode(b.subarray(start, start + len)); i = start + len + 2; }
  }
  return { n: hb, v: { status: st, body: '', head } };
}

async function conn(dev) {
  const c = conns.get(dev.id); if (c && !c.sock.closed) return c;
  const t0 = Date.now(); const sock = await Sock.open({ host: dev.host, port: ports(dev).api, tls: true, timeoutMs: 2000 });
  dlog(`lightning: connected ${dev.host}:${ports(dev).api} in ${Date.now() - t0} ms`);
  const n = { sock }; conns.set(dev.id, n); return n;
}
async function wake(dev) {
  const t0 = Date.now(), p = ports(dev).dial;
  const s = await Sock.open({ host: dev.host, port: p, tls: false, timeoutMs: 1500 });
  try {
    await s.write(te.encode(`POST /apps/FireTVRemote HTTP/1.1\r\nHost: ${dev.host}:${p}\r\nContent-Length: 0\r\nConnection: close\r\n\r\n`));
    const r = await s.waitFor(httpResp, 1500).catch(() => null); dlog(`lightning: wake ${dev.host}:${p} → ${r ? r.status : 'no answer'} (${Date.now() - t0} ms)`);
  } finally { s.close(); }
}
/** One request on the kept-open HTTPS connection (requests go one after another). */
function request(dev, method, path, { body = null, token = null, ms = 4000, wakeOk = true } = {}) {
  const run = async () => {
    for (let attempt = 0; ; attempt++) {
      let c;
      try {
        c = await conn(dev);
        const b = body == null ? '' : JSON.stringify(body);
        const hdr = `${method} ${path} HTTP/1.1\r\nHost: ${dev.host}:${ports(dev).api}\r\nX-Api-Key: ${API_KEY}\r\n${token ? `X-Client-Token: ${token}\r\n` : ''}${body == null ? '' : 'Content-Type: application/json\r\n'}Content-Length: ${te.encode(b).length}\r\nConnection: keep-alive\r\n\r\n${b}`;
        await c.sock.write(te.encode(hdr));
        const r = await c.sock.waitFor(httpResp, ms);
        if (/\r\nconnection:\s*close/i.test(r.head)) { c.sock.close(); conns.delete(dev.id); }
        return r;
      } catch (e) {
        if (c) { c.sock.close(); conns.delete(dev.id); }
        if (attempt >= 1) throw e;
        if (e.code === 'unreachable' && wakeOk) { dlog('lightning: API not listening; waking it on 8009'); await wake(dev).catch((x) => dlog('lightning: wake failed: ' + x.message)); await new Promise((r) => setTimeout(r, 800)); }
      }
    }
  };
  const p = (queues.get(dev.id) || Promise.resolve()).then(run); queues.set(dev.id, p.catch(() => {}));
  return p;
}

export const lightning = {
  token: (dev, store) => store.get(tokKey(dev)) || null,
  /** Ask the TV for its 4-digit PIN. Resolves true when the PIN is on screen, false when this TV has no such API. */
  async pinDisplay(dev) {
    if (isDown(dev)) return false;
    try {
      const r = await within(request(dev, 'POST', '/v1/FireTV/pin/display', { body: { friendlyName: 'Spin Remote' }, ms: 3000, wakeOk: true }), BUDGET.display, 'pin/display');
      dlog(`lightning: pin/display → HTTP ${r.status}`); const ok = r.status >= 200 && r.status < 300; if (!ok) markDown(dev, 'pin/display HTTP ' + r.status); return ok;
    } catch (e) { markDown(dev, 'pin/display failed: ' + e.message); return false; }
  },
  async pinVerify(dev, store, pin) {
    const r = await within(request(dev, 'POST', '/v1/FireTV/pin/verify', { body: { pin: String(pin).trim() }, ms: 3000, wakeOk: false }), BUDGET.verify, 'pin/verify');
    let tok = ''; try { tok = JSON.parse(r.body).description || ''; } catch (e) { /* */ }
    if (r.status < 200 || r.status >= 300 || !tok) throw err('That code is not right — check the TV and try again.', 'bad_code');
    store.set(tokKey(dev), tok); dlog('lightning: paired (token saved)'); return true;
  },
  forget(dev, store) { store.del(tokKey(dev)); const c = conns.get(dev.id); if (c) c.sock.close(); conns.delete(dev.id); },
  isDown, markDown,
  closeAll() { down.clear(); for (const c of conns.values()) c.sock.close(); conns.clear(); queues.clear(); },
};
