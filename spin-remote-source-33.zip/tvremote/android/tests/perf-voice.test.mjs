// Latency, ordering, hold-to-repeat, reconnect, TV switching, capability detection and voice-search submission — against the self-written mocks (no real TV).
import { makeTransport as makeNodeTransport, stopJvm } from './transports.mjs';
import { dropAllSockets } from './node-transport.mjs';
import { makeStore, createBackend } from '../../web/native/backend.js';
import { ecp } from '../../web/native/roku.js';
import { perfRecent } from '../../web/native/perf.js';
import { startRokuMock } from '../mocks/roku-mock.mjs';
import { startAndroidTvMock } from '../mocks/androidtv-mock.mjs';
import { startAppleTvMock } from '../mocks/appletv-mock.mjs';
import { startAdbMock } from '../mocks/adb-mock.mjs';
import { ok, eq, rejects, section, summary } from './lib.mjs';
import { sleep } from '../../web/native/bytes.js';

const orig = console.log; console.log = (...a) => { if (typeof a[0] === 'string' && a[0].startsWith('[perf]')) return; orig(...a); };
const stub = () => async (p) => ({ stub: p, demo: true });
const mk = (ports) => createBackend({ makeSim: stub, store: makeStore(null), transport: makeNodeTransport(), ports });
const call = (b, path, method = 'GET', body) => b.handler(path, { method, body: body ? JSON.stringify(body) : undefined });
const send = (b, d, o) => call(b, '/api/send', 'POST', { device: d.id, ...o });
const key = (b, d, k, extra) => send(b, d, { action: 'key', key: k, ...extra });
const med = (a) => { const s = [...a].sort((x, y) => x - y); return s[Math.floor(s.length / 2)]; };
const p95 = (a) => { const s = [...a].sort((x, y) => x - y); return s[Math.min(s.length - 1, Math.floor(s.length * 0.95))]; };
const LAT = {};

const rigs = {
  async roku(kind = 'tv', port = 18301, extra = {}) { const m = await startRokuMock({ port, ssdpPort: 11990 + (port % 9), kind, ...extra }); const b = mk({ roku: { http: port } }); const d = await call(b, '/api/devices', 'POST', { platform: 'roku', host: '127.0.0.1' }); return { m, b, d, keys: () => m.st.keys.map((k) => k.k) }; },
  async googletv(pp = 16601, rp = 16602) { const m = await startAndroidTvMock({ pairPort: pp, remotePort: rp }); const b = mk({ googletv: { pair: pp, remote: rp } }); const d = await call(b, '/api/devices', 'POST', { platform: 'googletv', host: '127.0.0.1' }); await call(b, '/api/pair/start', 'POST', { device: d.id }); await call(b, '/api/pair/finish', 'POST', { device: d.id, code: m.st.code }); return { m, b, d, keys: () => m.st.keys.map((k) => k.code) }; },
  async firetv(port = 15701, extra = {}) { const m = await startAdbMock({ port, autoAllow: true, ...extra }); const b = mk({ firetv: { adb: port } }); const d = await call(b, '/api/devices', 'POST', { platform: 'firetv', host: '127.0.0.1' }); await call(b, '/api/pair/start', 'POST', { device: d.id }); await call(b, '/api/pair/finish', 'POST', { device: d.id }); return { m, b, d, keys: () => m.st.keys.map((k) => k.k) }; },
  async appletv(port = 17201, host = '127.0.0.1') { const m = await startAppleTvMock({ port, host }); const b = mk({ appletv: { companion: port } }); const d = await call(b, '/api/devices', 'POST', { platform: 'appletv', host }); await call(b, '/api/pair/start', 'POST', { device: d.id }); await call(b, '/api/pair/finish', 'POST', { device: d.id, code: m.st.pin }); return { m, b, d, keys: () => m.st.hid.filter((h) => h.state === 1).map((h) => h.code) }; },
};
const DIRS = ['up', 'down', 'left', 'right'];
const WANT = {
  roku: ['Up', 'Down', 'Left', 'Right'], googletv: [19, 20, 21, 22], firetv: ['KEYCODE_DPAD_UP', 'KEYCODE_DPAD_DOWN', 'KEYCODE_DPAD_LEFT', 'KEYCODE_DPAD_RIGHT'],
};
const dirCode = { appletv: null };

section('Rapid D-pad presses: all arrive, in the order pressed, on every platform');
for (const name of ['roku', 'googletv', 'firetv', 'appletv']) {
  const r = await rigs[name](...(name === 'roku' ? ['tv', 18301] : [])); await call(r.b, '/api/warm', 'POST', { device: r.d.id });
  const seq = Array.from({ length: 40 }, (_, i) => DIRS[(i * 7 + (i >> 2)) % 4]);
  const n0 = r.keys().length; await Promise.all(seq.map((k) => key(r.b, r.d, k))); await sleep(300);
  const got = r.keys().slice(n0);
  let want; if (name === 'appletv') ok(got.length === 40, 'appletv: 40 of 40 presses arrived');
  if (name === 'appletv') { ok(new Set(got).size === 4, 'appletv: four different HID codes arrived'); // order: compare against a one-by-one reference run
    const n1 = r.keys().length; for (const k of seq) await key(r.b, r.d, k); await sleep(200); eq(got, r.keys().slice(n1), 'appletv: a burst arrives in exactly the order a slow press-by-press run does'); }
  else { const W = WANT[name]; want = seq.map((k) => W[DIRS.indexOf(k)]); eq(got, want, `${name}: 40 rapid presses arrive complete and in order`); }
  r.b.closeAll(); r.m.close();
}

section('Roku (optional keep-alive path, OFF in the app): when enabled, one connection carries the presses');
{
  ok(ecp.keepAlive === false, 'the app ships with the proven one-request-per-press Roku path'); ecp.keepAlive = true;
  const r = await rigs.roku('tv', 18302); await call(r.b, '/api/warm', 'POST', { device: r.d.id }); const c0 = r.m.st.conns;
  for (let i = 0; i < 30; i++) await key(r.b, r.d, DIRS[i % 4]);
  ok(r.m.st.conns - c0 <= 1, `30 presses used ${r.m.st.conns - c0} new connection(s)`);
  eq(r.m.st.keys.length, 30, 'all 30 arrived');
  r.b.closeAll(); r.m.close(); ecp.keepAlive = false;
}

section('Repeated volume (hold-to-repeat keys): every press goes out, none of the wrong platform');
{
  const r = await rigs.googletv(16611, 16612); const n0 = r.m.st.keys.length;
  for (let i = 0; i < 24; i++) await key(r.b, r.d, i % 3 === 2 ? 'vol_down' : 'vol_up', { repeat: i > 0 });
  await sleep(200); eq(r.keys().slice(n0), Array.from({ length: 24 }, (_, i) => (i % 3 === 2 ? 25 : 24)), 'Google TV: 24 volume presses arrive as keycodes 24/25, in order');
  r.b.closeAll(); r.m.close();
  const f = await rigs.firetv(15711, { inputMs: 120 }); await call(f.b, '/api/warm', 'POST', { device: f.d.id });
  const n1 = f.m.st.keys.length; const t0 = Date.now(); const ps = [];
  for (let i = 0; i < 30; i++) { ps.push(key(f.b, f.d, 'vol_up', { repeat: i > 0 }).catch(() => {})); await sleep(110); }       // a thumb held on VOL+ for ~3.3 s with a slow TV (120 ms per keyevent)
  const lift = Date.now(); await Promise.allSettled(ps); await sleep(400);
  const got = f.m.st.keys.slice(n1); const lastArrive = Math.max(...got.map((k) => k.t));
  ok(got.length >= 12 && got.length <= 30, `Fire TV with a slow TV: ${got.length} of 30 held-repeats reached it (extras are coalesced, never queued up)`);
  ok(lastArrive - lift < 400, `nothing is still arriving ${lastArrive - lift} ms after the finger lifts (no backlog)`);
  f.b.closeAll(); f.m.close();
}

section('Switching between TVs: each press reaches only its own TV, in order');
{
  const R = await rigs.roku('tv', 18303), G = await rigs.googletv(16621, 16622), F = await rigs.firetv(15721), A = await rigs.appletv(17221, '127.0.0.3');
  const all = [R, G, F, A], n0 = all.map((x) => x.keys().length), order = [];
  for (let i = 0; i < 24; i++) { const x = all[i % 4]; order.push(i % 4); await key(x.b, x.d, DIRS[i % 4]); }
  await sleep(200);
  for (let t = 0; t < 4; t++) eq(all[t].keys().length - n0[t], 6, `${['roku', 'googletv', 'firetv', 'appletv'][t]} got exactly its 6 presses`);
  eq(R.keys().slice(n0[0]), Array.from({ length: 6 }, () => 'Up'), 'Roku only saw its own key (Up)'); eq(G.keys().slice(n0[1]), Array.from({ length: 6 }, () => 20), 'Google TV only saw its own key (Down)');
  for (const x of all) { x.b.closeAll(); x.m.close(); }
}

section('Capability detection (asked from the TV, never assumed)');
{
  for (const [kind, port, want] of [['tv', 18311, 'yes'], ['stick', 18312, 'no'], ['box', 18313, 'maybe']]) {
    const r = await rigs.roku(kind, port); const c = await call(r.b, '/api/caps', 'POST', { device: r.d.id });
    eq([c.volume, c.mute, c.search], [want, want !== 'no', true], `Roku ${kind}: volume=${want}`); r.b.closeAll(); r.m.close();
  }
  const A = await rigs.appletv(17231, '127.0.0.4'); const c = await call(A.b, '/api/caps', 'POST', { device: A.d.id }); eq([c.volume, c.mute], ['yes', false], 'Apple TV: volume yes, mute no'); A.b.closeAll(); A.m.close();
  const G = await rigs.googletv(16631, 16632); eq((await call(G.b, '/api/caps', 'POST', { device: G.d.id })).volume, 'yes', 'Google TV: volume yes'); G.b.closeAll(); G.m.close();
  const F = await rigs.firetv(15731); eq((await call(F.b, '/api/caps', 'POST', { device: F.d.id })).volume, 'yes', 'Fire TV: volume yes'); F.b.closeAll(); F.m.close();
}

section('Reconnect after the phone\'s Wi-Fi drops (every socket reset): the next press still gets through');
for (const name of ['roku', 'googletv', 'firetv', 'appletv']) {
  const r = await rigs[name](...(name === 'roku' ? ['tv', 18321] : [])); await key(r.b, r.d, 'up'); await sleep(80);
  const n0 = r.keys().length, dropped = dropAllSockets(); await sleep(150);
  const t0 = performance.now(); let res, err; try { res = await key(r.b, r.d, 'down'); } catch (e) { err = e; }
  const ms = Math.round(performance.now() - t0); await sleep(150);
  ok(!err && res && res.ok, `${name}: press after the drop succeeded (${dropped} sockets were reset) in ${ms} ms${err ? ' — ' + err.message.split('\n')[0] : ''}`);
  eq(r.keys().length - n0, 1, `${name}: delivered exactly once (no duplicate, no loss)`);
  r.b.closeAll(); r.m.close();
}

section('A TV that is really gone fails promptly and says so (and is recorded as a failure in the timing log)');
{
  const r = await rigs.roku('tv', 18331); r.m.close(); await sleep(100);
  const t0 = performance.now(); const e = await rejects(key(r.b, r.d, 'up'), null, 'press to an unreachable Roku rejects'); const ms = performance.now() - t0;
  ok(ms < 4500, `...within ${Math.round(ms)} ms`); ok(perfRecent().at(-1).failed === true && perfRecent().at(-1).key === 'up', 'the perf log marks it failed'); r.b.closeAll(); void e;
}

section('Latency on the mocks: pressed → transmitted, and → TV acknowledgement where the protocol has one (50 isolated presses each)');
for (const delayMs of [0, 8]) {
  for (const name of ['roku', 'googletv', 'firetv', 'appletv']) {
    const r = await rigs[name](...(name === 'roku' ? ['tv', 18341, { delayMs }] : name === 'firetv' ? [15741, { delayMs }] : [])); await call(r.b, '/api/warm', 'POST', { device: r.d.id }); await sleep(100);
    const from = perfRecent().length; const tx = [], ack = [];
    for (let i = 0; i < 50; i++) { await key(r.b, r.d, DIRS[i % 4], { t_press: performance.now() }); await sleep(25); }
    for (const t of perfRecent().slice(-50)) { if (t.tx != null) tx.push(t.tx); if (t.ack != null) ack.push(t.ack); }
    LAT[`${name} (one-way mock delay ${delayMs} ms)`] = { txMed: med(tx), txP95: p95(tx), ackMed: ack.length ? med(ack) : null, ackP95: ack.length ? p95(ack) : null, n: tx.length };
    ok(tx.length === 50, `${name}/${delayMs}ms: 50 timing records`); ok(med(tx) < 100, `${name}/${delayMs}ms: median press→transmit ${med(tx).toFixed(1)} ms (<100)`);
    r.b.closeAll(); r.m.close();
  }
}

section('Voice search → the right command on the right platform, with real acknowledgement where there is one');
{
  const text = 'the office season 2';
  const R = await rigs.roku('tv', 18351); const s = await send(R.b, R.d, { action: 'search', text }); ok(s.ok && R.m.st.search === text, 'Roku: POST /search/browse (the words) reached the Roku (HTTP 200)'); 
  await send(R.b, R.d, { action: 'search', text: 'tom & jerry 100%' }); eq(R.m.st.search, 'tom & jerry 100%', 'Roku: & and % are URL-encoded correctly'); R.b.closeAll(); R.m.close();
  const G = await rigs.googletv(16641, 16642); const g = await send(G.b, G.d, { action: 'search', text }); await sleep(100);
  ok(g.ok && G.m.st.keys.at(-1).code === 84, 'Google TV: sent the search key (84)'); eq(G.m.st.texts.at(-1), text, 'Google TV: the words were typed into the text field the TV opened');
  const nTexts = G.m.st.texts.length; G.m.st.searchBox = false; const e1 = await rejects(send(G.b, G.d, { action: 'search', text: 'x', fieldWaitMs: 300 }), 'no_text_field', 'Google TV: no text field opened → refused'); await sleep(100); eq(G.m.st.texts.length, nTexts, 'Google TV: nothing was typed when no field opened'); void e1;
  G.b.closeAll(); G.m.close();
  const F = await rigs.firetv(15751); const f = await send(F.b, F.d, { action: 'search', text: "Tom & Jerry's \"best\" $HOME café" }); await sleep(100);
  ok(f.ok && F.m.st.keys.at(-1).k === 'KEYCODE_SEARCH', 'Fire TV: opened search with KEYCODE_SEARCH');
  eq(F.m.st.texts.at(-1), `'Tom%s&%sJerry'\\''s%s"best"%s$HOME%scafe'`, 'Fire TV: text is shell-quoted, spaces as %s, apostrophe escaped, accent flattened'); F.b.closeAll(); F.m.close();
  const A = await rigs.appletv(17251, '127.0.0.5'); const a = await send(A.b, A.d, { action: 'search', text }); await sleep(150); ok(a.ok && A.m.st.field === text, 'Apple TV: the words were typed into the open text field');
  A.m.st.noField = true; await rejects(send(A.b, A.d, { action: 'search', text: 'zzz' }), 'no_text_field', 'Apple TV: no text field open → refused, not reported as success'); A.b.closeAll(); A.m.close();
}

section('Never send one platform\'s command to another');
{
  const R = await rigs.roku('tv', 18361), G = await rigs.googletv(16651, 16652); const gk = G.m.st.keys.length, gt = G.m.st.texts.length;
  await send(R.b, R.d, { action: 'search', text: 'abc' }); await key(R.b, R.d, 'vol_up'); await sleep(100);
  eq([G.m.st.keys.length, G.m.st.texts.length], [gk, gt], 'Roku commands never reach the Google TV'); ok(R.m.st.keys.every((k) => !/KEYCODE|^\d+$/.test(k.k)), 'Roku saw only ECP key names');
  for (const x of [R, G]) { x.b.closeAll(); x.m.close(); }
}

console.log('\nMeasured on the mocks (ms, pressed → transmitted | → TV ack):');
for (const [k, v] of Object.entries(LAT)) console.log(`  ${k.padEnd(40)} transmit median ${v.txMed.toFixed(1).padStart(5)}  p95 ${v.txP95.toFixed(1).padStart(5)}   ack ${v.ackMed == null ? 'n/a (protocol has none)' : `median ${v.ackMed.toFixed(1)}  p95 ${v.ackP95.toFixed(1)}`}`);
const s = summary(); console.log(`\n${s.pass} passed, ${s.fail} failed`); if (s.fail) { console.log(s.fails.join('\n')); stopJvm(); process.exit(1); }
stopJvm(); process.exit(0);
