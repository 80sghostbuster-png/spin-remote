// Build 23. All on SELF-WRITTEN mocks and a SIMULATED network — not real TVs.
//  (Build 24: the Fire TV remote-API checks were removed with the API itself; Fire TV is back on the build 21 path, see tools/fire-parity.mjs.)
//  B. Discovery: everything in parallel, TVs listed as they answer; time-to-first-TV measured before (build 22 code) vs after.
import net from 'node:net';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { makeTransport as makeNodeTransport, stopJvm } from './transports.mjs';
import { makeStore, createBackend } from '../../web/native/backend.js';
import { createBackend as createOldBackend, makeStore as makeOldStore } from './b22/native/backend.js';
import { ok, eq, rejects, section, summary } from './lib.mjs';

const stub = () => async (p) => ({ stub: p, demo: true });
const mem = () => { const m = new Map(); return { getItem: (k) => (m.has(k) ? m.get(k) : null), setItem: (k, v) => m.set(k, v), removeItem: (k) => m.delete(k) }; };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const listen = (srv, port) => new Promise((r) => srv.listen(port, '127.0.0.1', r));
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'r23-'));
execFileSync('openssl', ['req', '-x509', '-newkey', 'rsa:2048', '-nodes', '-keyout', dir + '/k.pem', '-out', dir + '/c.pem', '-subj', '/CN=FireMock', '-days', '30'], { stdio: 'ignore' });
const KEY = fs.readFileSync(dir + '/k.pem'), CERT = fs.readFileSync(dir + '/c.pem');
const { startAdbMock } = await import('../mocks/adb-mock.mjs');
const https = (await import('node:https')).default;

// ------------------------------------------------------------------------------------------------ B. discovery speed
// Simulated phone network layer. The native side's timing is modelled on the Java code:
//   build 22 native: mDNS = Android NSD, one search at a time (a lock), each runs its whole window, then resolves (~150 ms).
//   build 23 native: mDNS asks the network directly first, no lock, stops once every answer is complete (≥350 ms window + reply).
//   SSDP waits its whole window in both (real UDP to the Roku mock). Port sweep ≈ its per-host timeout. Saved-TV check = real TCP.
function simTransport({ mdns, scanHosts, native }) {
  const base = makeNodeTransport({ mdns, scanHosts }); let lock = Promise.resolve();
  return { ...base,
    async mdns(o) { const hits = mdns.filter((r) => r.type === o.type);
      if (native === 'b22') { const run = lock.then(() => sleep(o.timeoutMs + 150)); lock = run; await run; return hits; }
      await sleep(hits.length ? 380 : Math.min(o.timeoutMs, 1500)); return hits; },
    async tcpScan(o) { const r = await base.tcpScan(o); await sleep(o.timeoutMs + 50); return r; } };
}
const { startRokuMock } = await import('../mocks/roku-mock.mjs');
const { startAndroidTvMock } = await import('../mocks/androidtv-mock.mjs');
const roku = await startRokuMock({ port: 18460, ssdpPort: 11960, name: 'Living Room Roku' });
const fireM = await startAdbMock({ port: 19335, autoAllow: true });
const gtvM = await startAndroidTvMock({ pairPort: 16467, remotePort: 16466, host: '127.0.0.1' }).catch(() => null);
const P = { roku: { http: 18460 }, firetv: { adb: 19335 }, googletv: { pair: 16467, remote: 16466 } };
const FIRE = { type: '_amzn-wplay._tcp.', host: '127.0.0.1', port: 19335, name: 'x', txt: { n: 'Ben’s Fire TV' } };
const GTV = { type: '_androidtvremote2._tcp.', host: '127.0.0.5', port: 16466, name: 'Den Google TV', txt: {} };
async function scan(kind, { mdns = [], ssdp = false, saved = [], scanHosts = [] }) {
  const ls = mem(); ls.setItem('spin.devices', JSON.stringify(saved));
  const mk = kind === 'b22' ? createOldBackend : createBackend, st = kind === 'b22' ? makeOldStore : makeStore;
  const b = mk({ makeSim: stub, store: st(ls), transport: simTransport({ mdns, scanHosts, native: kind }), ports: P, ssdpTarget: ssdp ? { host: '127.0.0.1', port: 11960 } : { host: '127.0.0.1', port: 9 } });
  const t0 = Date.now(); let first = null, done = false;
  const poll = (async () => { while (!done) { try { const p = await b.handler('/api/discover/progress', {}); if (first == null && p && p.seen && p.seen.length) first = Date.now() - t0; } catch (e) { return; } await sleep(20); } })();
  const r = await b.handler('/api/discover', { method: 'POST', body: '{}' }); const total = Date.now() - t0; done = true; await poll;
  if (first == null || kind === 'b22') first = r.seen.length ? Math.min(first == null ? total : first, total) : null;   // build 22 lists TVs only when the whole scan ends
  if (kind === 'b22') first = r.seen.length ? total : null;
  b.closeAll && b.closeAll();
  return { first, total, r };
}
section('B. Discovery: time to the first TV on screen, build 22 vs build 23 (simulated network, see model above)');
const cases = [
  ['Fire TV only (mDNS)', { mdns: [FIRE] }],
  ['Roku only (SSDP)', { ssdp: true }],
  ['Google TV only (mDNS)', { mdns: [GTV] }],
  ['Fire TV saved earlier, on this Wi-Fi', { mdns: [FIRE], saved: [{ id: 'firetv-127.0.0.1', platform: 'firetv', host: '127.0.0.1', name: 'Ben’s Fire TV', paired: true }] }],
  ['All of them', { mdns: [FIRE, GTV], ssdp: true }],
];
const table = [];
for (const [name, c] of cases) {
  const o = await scan('b22', c), n = await scan('b23', c);
  table.push({ name, b22first: o.first, b23first: n.first, b22total: o.total, b23total: n.total });
  ok(n.r.seen.length >= o.r.seen.length, `${name}: finds at least as many TVs (${n.r.seen.length} vs ${o.r.seen.length})`);
  ok(n.first != null && o.first != null && n.first < o.first, `${name}: first TV after ${n.first} ms (was ${o.first} ms)`);
  ok(n.r.devices.every((d) => !/\d+\.\d+\.\d+\.\d+/.test(d.name)), `${name}: no IP addresses in TV names`);
}
console.log('\n  DISCOVERY (ms)            first TV: b22 → b23    whole scan: b22 → b23');
for (const t of table) console.log(`  ${t.name.padEnd(38)} ${String(t.b22first).padStart(5)} → ${String(t.b23first).padStart(5)}   ${String(t.b22total).padStart(5)} → ${String(t.b23total).padStart(5)}  (${(t.b22first / t.b23first).toFixed(1)}× faster)`);
fs.writeFileSync('/tmp/discovery23.json', JSON.stringify(table, null, 1));

section('B2. A TV saved on another Wi-Fi is not shown');
{ const r = (await scan('b23', { saved: [{ id: 'roku-10.9.9.9', platform: 'roku', host: '10.9.9.9', name: 'Cabin Roku', paired: true }] })).r;
  ok(!r.seen.includes('roku-10.9.9.9'), 'cabin Roku (other network) not listed'); }
roku.close && roku.close(); fireM.close(); gtvM && gtvM.close && gtvM.close();
stopJvm && stopJvm();
const s = summary(); console.log(`\n${s.pass} passed, ${s.fail} failed`); if (s.fail) process.exit(1); else process.exit(0);
