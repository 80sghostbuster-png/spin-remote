// Picks the transport the protocol tests run on: TRANSPORT=node (default, pure Node) or TRANSPORT=java (the app's real NetCore.java via a JVM child process).
import { spawn, execFileSync } from 'node:child_process';
import readline from 'node:readline';
import fs from 'node:fs';
import { makeNodeTransport } from './node-transport.mjs';

const here = new URL('../', import.meta.url).pathname;
let jvm = null;
function startJvm() {
  if (jvm) return jvm;
  const out = here + 'build-jvm';
  fs.mkdirSync(out, { recursive: true });
  const javac = process.env.JAVA_HOME ? process.env.JAVA_HOME + '/bin/javac' : 'javac', java = process.env.JAVA_HOME ? process.env.JAVA_HOME + '/bin/java' : 'java';
  execFileSync(javac, ['-d', out, here + 'android/app/src/main/java/com/spinremote/app/NetCore.java', here + 'android/app/src/main/java/com/spinremote/app/CertGen.java', here + 'tests/java/JavaBridge.java']);
  const p = spawn(java, ['-cp', out, 'JavaBridge'], { stdio: ['pipe', 'pipe', 'inherit'] });
  const pending = new Map(); let n = 0;
  readline.createInterface({ input: p.stdout }).on('line', (l) => { const [id, st, ...rest] = l.split('\t'); const w = pending.get(id); if (!w) return; pending.delete(id); const body = rest.join('\t'); st === 'OK' ? w.res(JSON.parse(body)) : w.rej(new Error(Buffer.from(body, 'base64').toString())); });
  jvm = { call: (m, ...args) => new Promise((res, rej) => { const id = String(++n); pending.set(id, { res, rej }); p.stdin.write([id, m, ...args.map((a) => Buffer.from(String(a ?? '')).toString('base64'))].join('\t') + '\n'); }), raw: (m, ...b64s) => new Promise((res, rej) => { const id = String(++n); pending.set(id, { res, rej }); p.stdin.write([id, m, ...b64s].join('\t') + '\n'); }), stop: () => p.kill() };
  return jvm;
}
export function javaCall(m, ...a) { return startJvm().call(m, ...a); }
export function javaRaw(m, ...a) { return startJvm().raw(m, ...a); }
export function stopJvm() { if (jvm) jvm.stop(); }

export function makeTransport(opts = {}) {
  if ((process.env.TRANSPORT || 'node') !== 'java') return makeNodeTransport(opts);
  const J = startJvm(), scanHosts = (opts.scanHosts || []).join(',');
  const B = (u8) => Buffer.from(u8).toString('base64');
  return {
    ...makeNodeTransport(opts),                         // mdns stays a stub (Android NsdManager only exists on a phone)
    async ssdp({ st, timeoutMs = 1500, target }) { return J.call('ssdp', st, timeoutMs, target ? target.host : '', target ? target.port : 0); },
    async http({ method, url, body, timeoutMs = 4000 }) { return J.call('http', method, url, body || '', timeoutMs); },
    async genIdentity(o = {}) { const r = await J.call('genIdentity', o.cert !== false); if (!r.certDer) delete r.certDer; return r; },
    async rsaSignAdb({ keyPkcs8, token }) { return new Uint8Array(Buffer.from((await J.raw('rsaSignAdb', Buffer.from(keyPkcs8).toString('base64'), B(token))).sig, 'base64')); },
    async tcpOpen({ host, port, tls, identity, timeoutMs = 4000, tls12 = false }) { const r = await J.call('open', host, port, !!tls, identity ? identity.certDer : '', identity ? identity.keyPkcs8 : '', timeoutMs, !!tls12); return { id: r.id, peerCert: r.peerCert, tls: r.tls }; },
    async tcpWrite(id, u8) { await J.raw('write', Buffer.from(String(id)).toString('base64'), B(u8)); },
    async tcpRead(id, timeoutMs) { const r = await J.call('read', id, timeoutMs); return { data: r.data ? new Uint8Array(Buffer.from(r.data, 'base64')) : null, closed: r.closed, timeout: r.timeout }; },
    async tcpClose(id) { await J.call('close', id); },
    async tcpScan({ ports, timeoutMs = 400 }) { const r = await J.call('tcpScan', ports.join(','), timeoutMs, scanHosts); r.prefixes = []; return r; },
    async probe({ host, ports, timeoutMs = 1000 }) { const r = await J.call('probe', host, ports.join(','), timeoutMs); r.ping = false; return r; },
  };
}
