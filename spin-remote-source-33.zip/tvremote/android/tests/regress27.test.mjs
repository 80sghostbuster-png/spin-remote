// Build 27: Fire TV the way Amazon's own Fire TV phone app connects (wake on 8009 → HTTPS 8080 → TV shows a 4-digit code →
// token → buttons over the same API), with the build 21 ADB path as the automatic silent fallback.
// SELF-WRITTEN mocks modelled on public findings — not a real Fire TV.
import { makeTransport, stopJvm } from './transports.mjs';
import { makeStore } from '../../web/native/backend.js';
import { fire } from '../../web/native/firetv-official.js';
import { adb } from '../../web/native/firetv.js';
import { lightning } from '../../web/native/firetv-lightning.js';
import { ok, eq, rejects, section, summary } from './lib.mjs';

globalThis.__tvTransport = makeTransport();
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const { startAdbMock } = await import('../mocks/adb-mock.mjs');
const { startFireApiMock } = await import('../mocks/firetv-api-mock.mjs');
const adbTv = await startAdbMock({ port: 19365, autoAllow: true });
let n = 0, pd = 19600;
const NOADB = 19399;   // nothing listens: ADB debugging off
const tv = async (o = {}, adbPort = NOADB) => { pd += 10; const m = await startFireApiMock({ dialPort: pd, apiPort: pd + 1, ...o, ddPort: o.ddPort ? pd + 2 : 0, appUrlPort: o.appUrlPort ? pd + 3 : 0 });
  return [m, { id: 'firetv-o' + (++n), host: '127.0.0.1', platform: 'firetv', name: 'Fire', ports: { adb: adbPort, dial: pd, lightning: pd + 1, dialdd: pd + 2 } }]; };
const timed = async (p) => { const t = Date.now(); const r = await p; return [r, Date.now() - t]; };
const adbAuth = async (d, st) => { const r = await adb.pairStart(d, st); if (r.status === 'confirm') await adb.pairFinish(d, st); };   // also trusted over ADB (Allow pressed earlier)
const pairOfficial = async (d, st) => { const r = await fire.pairStart(d, st); if (r.status !== 'code') return r; return fire.pairFinish(d, st, '4821'); };

section('1. official pairing on a sleeping Fire TV with ADB debugging OFF');
let [m, d] = await tv(); let st = makeStore();
let [r, ms] = await timed(fire.pairStart(d, st));
eq([r.status, r.kind, r.length], ['code', 'digits', 4], `shared PIN popup, 4 digits (${ms} ms incl. ~2 s service start)`);
eq(m.st.wakes, 1, 'woken first: POST :8009/apps/FireTVRemote'); ok(m.st.shown === '4821', 'TV shows the code');
ok([...m.st.uas].every((u) => u === 'okhttp/4.12.0'), 'User-Agent okhttp/4.12.0 like the official app');
await rejects(fire.pairFinish(d, st, '0000'), 'bad_code', 'wrong code → asked again');
eq((await fire.pairFinish(d, st, '4821')).status, 'paired', 'correct code → paired'); eq(lightning.token(d, st), 'Wj9PP8I', 'token saved');

section('2. buttons through the official API (no ADB on this TV)');
const c0 = m.st.conns; for (const k of ['up', 'down', 'left', 'right', 'select', 'back', 'home', 'menu', 'play_pause']) await fire.key(d, k, st);
eq(m.st.keys, ['dpad_up', 'dpad_down', 'dpad_left', 'dpad_right', 'select', 'back', 'home', 'menu', 'play'], 'every press reached the TV, in order, body-less (a body would be HTTP 500)');
ok(m.st.conns - c0 <= 1, `9 presses on one kept-open connection (${m.st.conns - c0} new TLS connection)`);
const t0 = Date.now(); for (let i = 0; i < 20; i++) await fire.key(d, 'down', st); ok(Date.now() - t0 < 3000, `20 rapid presses in ${Date.now() - t0} ms`);

section('3. saved TV after app restart: no code again, buttons still official');
fire.closeAll(); m.close(); [m] = [await startFireApiMock({ dialPort: d.ports.dial, apiPort: d.ports.lightning, startMs: 1500 })]; m.st.token = 'Wj9PP8I';
[r, ms] = await timed(fire.key(d, 'select', st)); eq(m.st.keys, ['select'], `TV had gone to sleep → woken, press delivered (${ms} ms)`); eq(m.st.wakes, 1, 'one wake');
eq(m.st.reqs.filter((x) => x.includes('pin')).length, 0, 'no new code asked'); m.close(); fire.closeAll();

section('4. DIAL fallback: 8009 closed, wake via Application-URL from :60000/dd.xml');
[m, d] = await tv({ noDial: true, ddPort: true, appUrlPort: true }); st = makeStore();
eq((await pairOfficial(d, st)).status, 'paired', 'paired'); eq(m.st.wakeVia, [d.ports.dial + 3], 'woken via the DIAL Application-URL'); m.close(); fire.closeAll();

section('5. token rejected (TV reset) → that press goes over ADB, token forgotten');
[m, d] = await tv({ awake: true }, 19365); st = makeStore(); await adbAuth(d, st); await pairOfficial(d, st); m.st.token = 'other';
let k0 = adbTv.st.keys.length; await fire.key(d, 'up', st); await sleep(300);
ok(adbTv.st.keys.length > k0, 'press delivered over ADB'); eq(lightning.token(d, st), null, 'token forgotten'); m.close(); fire.closeAll();

section('6. official service gone mid-use → press over ADB');
[m, d] = await tv({ awake: true }, 19365); st = makeStore(); await adbAuth(d, st); await pairOfficial(d, st); m.close(); fire.closeAll();
k0 = adbTv.st.keys.length; [r, ms] = await timed(fire.key(d, 'left', st)); await sleep(300); ok(adbTv.st.keys.length > k0, `press delivered over ADB (${ms} ms)`);

section('7. no official service at all → build 21 ADB pairing, fast');
[m, d] = await tv({ noDial: true }, 19365); st = makeStore(); [r, ms] = await timed(fire.pairStart(d, st));
ok(['confirm', 'paired'].includes(r.status) && ms < 3000, `ADB pairing (${r.status}) after ${ms} ms`);
if (r.status === 'confirm') r = await fire.pairFinish(d, st); eq(r.status, 'paired', 'paired over ADB');
k0 = adbTv.st.keys.length; await fire.key(d, 'down', st); await sleep(300); ok(adbTv.st.keys.length > k0, 'buttons over ADB'); eq(m.st.reqs.length, 0, 'nothing sent to the official API'); m.close();

section('8. 3 wrong codes / code check error / service never starts / pin/display error → ADB');
[m, d] = await tv({ awake: true }, 19365); st = makeStore(); await fire.pairStart(d, st);
await rejects(fire.pairFinish(d, st, '1111'), 'bad_code', 'wrong #1'); await rejects(fire.pairFinish(d, st, '2222'), 'bad_code', 'wrong #2');
r = await fire.pairFinish(d, st, '3333'); ok(['confirm', 'paired'].includes(r.status), `wrong #3 → ADB pairing (${r.status})`); m.close();
[m, d] = await tv({ awake: true, verifyStatus: 500 }, 19365); st = makeStore(); await fire.pairStart(d, st);
r = await fire.pairFinish(d, st, '4821'); ok(['confirm', 'paired'].includes(r.status), `verify HTTP 500 → ADB (${r.status})`); m.close();
[m, d] = await tv({ startMs: 60000 }, 19365); st = makeStore(); [r, ms] = await timed(fire.pairStart(d, st));
ok(['confirm', 'paired'].includes(r.status), `service never starts → ADB after ${ms} ms`); m.close();
[m, d] = await tv({ awake: true, displayStatus: 500 }, 19365); st = makeStore();
ok(['confirm', 'paired'].includes((await fire.pairStart(d, st)).status), 'pin/display error → ADB'); m.close();

section('9. answers without Content-Length');
[m, d] = await tv({ noLength: true }); st = makeStore(); eq((await pairOfficial(d, st)).status, 'paired', 'paired'); await fire.key(d, 'home', st); eq(m.st.keys, ['home'], 'press delivered'); m.close();

section('10. manual add by IP with ADB off');
ok(await fire.probe('127.0.0.1', { adb: NOADB }).then(() => false, () => true), 'nothing on ADB or 8009 → not a Fire TV');

fire.closeAll(); adbTv.close(); stopJvm();
const s = summary(); console.log(`\n${s.pass} passed, ${s.fail} failed`); process.exit(s.fail ? 1 : 0);
