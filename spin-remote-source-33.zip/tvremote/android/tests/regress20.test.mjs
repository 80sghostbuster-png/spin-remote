// Build 20: Fire TV fast key helper (one long-running app_process on the TV, keys injected directly) — on the ADB mock.
// Timing model of the mock (simulated, not a real Fire TV): `input` = 120 ms process start per call, helper = 2 ms per key.
import { makeTransport as makeNodeTransport, stopJvm } from './transports.mjs';
import { makeStore, createBackend } from '../../web/native/backend.js';
import { startAdbMock } from '../mocks/adb-mock.mjs';
import { startRokuMock } from '../mocks/roku-mock.mjs';
import { ok, eq, rejects, section, summary } from './lib.mjs';
import { sleep } from '../../web/native/bytes.js';
import { FIREKEYS_HASH, FIREKEYS_DEX_B64 } from '../../web/native/firekeys-dex.js';

const stub = () => async (p) => ({ stub: p, demo: true });
let port = 15700;
async function setup(opts = {}, wait = 900) {
  const p = port++; const m = await startAdbMock({ port: p, autoAllow: true, inputMs: 120, ...opts });
  const b = createBackend({ makeSim: stub, store: makeStore(null), transport: makeNodeTransport(), ports: { firetv: { adb: p } } });
  const call = (path, method = 'GET', body) => b.handler(path, { method, body: body ? JSON.stringify(body) : undefined });
  const d = await call('/api/devices', 'POST', { platform: 'firetv', host: '127.0.0.1' });
  await call('/api/pair/start', 'POST', { device: d.id }); await call('/api/pair/finish', 'POST', { device: d.id });
  await call('/api/warm', 'POST', { device: d.id }); await sleep(wait);
  const send = (x) => call('/api/send', 'POST', { device: d.id, ...x });
  return { m, b, d, call, send, close: () => { b.closeAll(); m.close(); } };
}
const median = (a) => { const s = [...a].sort((x, y) => x - y); return s[Math.floor(s.length / 2)]; };
async function perPress(t, n = 15) { const ms = []; for (let i = 0; i < n; i++) { const t0 = performance.now(); await t.send({ action: 'key', key: i % 2 ? 'left' : 'right' }); ms.push(performance.now() - t0); } return median(ms); }

section('Helper is copied once, started once, and then carries the keys');
{
  ok(FIREKEYS_DEX_B64.length > 1000 && /^[0-9a-f]{12}$/.test(FIREKEYS_HASH), 'helper dex is embedded in the app');
  const t = await setup({ helper: true });
  const file = `/data/local/tmp/spinremote-keys-${FIREKEYS_HASH}.jar`;
  ok(t.m.st.files.has(file) && t.m.st.files.get(file).length === Buffer.from(FIREKEYS_DEX_B64, 'base64').length, 'helper copied byte-for-byte to /data/local/tmp');
  eq(t.m.st.helperStarts, 1, 'helper started once');
  const r = await t.send({ action: 'key', key: 'up' }); ok(r.ok && /fast key k 19/.test(r.wire), `key went through the helper (${r.wire})`);
  eq(t.m.st.keys.at(-1).via, 'helper', 'TV got it from the helper'); eq(t.m.st.keys.at(-1).k, 'KEYCODE_DPAD_UP', '  as DPAD_UP (19)');
  const cmdsBefore = t.m.st.cmds.length; for (const k of ['down', 'select', 'back', 'home', 'menu', 'vol_up', 'vol_down', 'mute', 'play_pause', 'rew', 'ff', 'power']) await t.send({ action: 'key', key: k });
  eq(t.m.st.cmds.length, cmdsBefore, 'no `input` program started for any of 12 buttons');
  eq(t.m.st.keys.slice(-12).map((k) => k.k), ['DPAD_DOWN', 'DPAD_CENTER', 'BACK', 'HOME', 'MENU', 'VOLUME_UP', 'VOLUME_DOWN', 'VOLUME_MUTE', 'MEDIA_PLAY_PAUSE', 'MEDIA_REWIND', 'MEDIA_FAST_FORWARD', 'POWER'].map((n) => 'KEYCODE_' + n), 'all buttons arrive with the right key codes, in order');
  await t.send({ action: 'text', mode: 'append', text: "it's a test" }); eq(t.m.st.texts.at(-1), "it's a test", 'typing goes through the helper (no shell quoting needed)');
  await t.send({ action: 'key', key: 'backspace' }); eq(t.m.st.keys.at(-1).k, 'KEYCODE_DEL', 'Backspace → DEL');
  const rs = await Promise.all(['up', 'up', 'right', 'down'].map((k) => t.send({ action: 'key', key: k }))); ok(rs.every((x) => x.ok), 'fast overlapping presses ok');
  eq(t.m.st.keys.slice(-4).map((k) => k.k), ['KEYCODE_DPAD_UP', 'KEYCODE_DPAD_UP', 'KEYCODE_DPAD_RIGHT', 'KEYCODE_DPAD_DOWN'], '  in order');
  t.close();
  // reconnect: file already there → not copied again
  const p = port++; const m2 = await startAdbMock({ port: p, autoAllow: true, helper: true }); m2.st.files.set(file, Buffer.from(FIREKEYS_DEX_B64, 'base64'));
  const b2 = createBackend({ makeSim: stub, store: makeStore(null), transport: makeNodeTransport(), ports: { firetv: { adb: p } } });
  const c2 = (path, body) => b2.handler(path, { method: 'POST', body: JSON.stringify(body) });
  const d2 = await b2.handler('/api/devices', { method: 'POST', body: JSON.stringify({ platform: 'firetv', host: '127.0.0.1' }) });
  await c2('/api/pair/start', { device: d2.id }); await c2('/api/pair/finish', { device: d2.id }); await c2('/api/warm', { device: d2.id }); await sleep(700);
  ok(!m2.st.setup.includes('chunk'), 'helper already on the TV → not copied again'); await c2('/api/send', { device: d2.id, action: 'key', key: 'up' }); eq(m2.st.keys.at(-1).via, 'helper', '  and used');
  b2.closeAll(); m2.close();
}

section('Fallbacks: anything wrong with the helper → the old shell path, nothing lost');
{
  const t = await setup({ helper: false });
  ok((await t.send({ action: 'key', key: 'up' })).ok && t.m.st.cmds.at(-1) === 'shell:input keyevent KEYCODE_DPAD_UP', 'helper refused to start → input keyevent'); t.close();
  const t2 = await setup({ helper: true, noBase64: true, noSync: true });
  ok((await t2.send({ action: 'key', key: 'up' })).ok && t2.m.st.cmds.at(-1) === 'shell:input keyevent KEYCODE_DPAD_UP', 'no base64 on the TV → input keyevent'); t2.close();
  const t3 = await setup({ helper: true, failInput: /VOLUME_UP/ });
  const r = await t3.send({ action: 'key', key: 'vol_up' }); ok(r.ok && t3.m.st.vol.length === 1, 'helper refuses a volume key → media_session volume fallback still used'); t3.close();
  const t4 = await setup({ helper: true, failInput: /^input text/ });
  await rejects(t4.send({ action: 'text', mode: 'append', text: 'x' }), 'bad_key', 'refused typing still reported honestly'); t4.close();
  const t5 = await setup({ helper: true }, 0);                                       // presses before the helper is ready use the shell, then switch
  const r5 = await t5.send({ action: 'key', key: 'up' }); ok(r5.ok, 'press during helper start-up works'); await sleep(900); await t5.send({ action: 'key', key: 'down' }); eq(t5.m.st.keys.at(-1).via, 'helper', '  later presses use the helper'); t5.close();
}

section('Volume: HDMI-CEC volume forwarding switched on before the first volume press, keys via the helper');
{
  const t = await setup({ helper: true, fixedVolume: true });
  for (const k of ['vol_up', 'vol_down', 'mute']) ok((await t.send({ action: 'key', key: k })).ok, `${k} ok`);
  eq(t.m.st.settings.hdmi_control_volume_control_enabled, '1', 'Fire TV setting hdmi_control_volume_control_enabled switched on');
  eq(t.m.st.settingsPuts.filter((x) => /volume_control/.test(x)).length, 1, '  only once per connection');
  eq(t.m.st.keys.slice(-3).map((k) => k.k + '/' + k.via), ['KEYCODE_VOLUME_UP/helper', 'KEYCODE_VOLUME_DOWN/helper', 'KEYCODE_VOLUME_MUTE/helper'], 'volume keys 24/25/164 through the helper');
  eq((await t.call('/api/caps', 'POST', { device: t.d.id })).volume, 'yes', 'volume buttons offered (not dimmed)');
  t.close();
  const t2 = await setup({ helper: true, cecVolume: '1' }); await t2.send({ action: 'key', key: 'vol_up' }); eq(t2.m.st.settingsPuts.length, 0, 'already on → settings left alone'); t2.close();
}

section('Latency per press (simulated timings — real Fire TV numbers will differ)');
{
  const res = {};
  { const t = await setup({ helper: false }); res['Fire TV, old path (input keyevent per press)'] = await perPress(t); t.close(); }
  { const t = await setup({ helper: true, helperMs: 2 }); res['Fire TV, fast key helper'] = await perPress(t); t.close(); }
  { const r = await startRokuMock({ port: 18190, ssdpPort: 11999, kind: 'tv' }); const b = createBackend({ makeSim: stub, store: makeStore(null), transport: makeNodeTransport(), ports: { roku: { http: 18190 } } });
    const d = await b.handler('/api/devices', { method: 'POST', body: JSON.stringify({ platform: 'roku', host: '127.0.0.1' }) });
    res['Roku ECP (reference)'] = await perPress({ send: (x) => b.handler('/api/send', { method: 'POST', body: JSON.stringify({ device: d.id, ...x }) }) }); b.closeAll(); r.close(); }
  for (const [k, v] of Object.entries(res)) console.log(`  [latency] ${k}: median ${v.toFixed(1)} ms`);
  ok(res['Fire TV, fast key helper'] < 40, `helper press < 40 ms on the mock (${res['Fire TV, fast key helper'].toFixed(1)} ms)`);
  ok(res['Fire TV, fast key helper'] * 3 < res['Fire TV, old path (input keyevent per press)'], 'helper is several times faster than input keyevent');
}
stopJvm && stopJvm();
summary();
