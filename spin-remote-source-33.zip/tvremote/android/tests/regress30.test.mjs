import { FORMS } from '../../web/native/firetv-volume.js';
// Build 30: Fire TV play/pause, rewind/fast-forward, volume and mute sent exactly as the official app's requests (spec: docs/FIRETV-PROTOCOL.md).
// The mock in strict mode accepts ONLY that form. SELF-WRITTEN mocks — not a real Fire TV.
import { makeTransport, stopJvm } from './transports.mjs';
import { makeStore } from '../../web/native/backend.js';
import { fire } from '../../web/native/firetv-official.js';
import { adb } from '../../web/native/firetv.js';
import { SCAN, reqId, OFFICIAL } from '../../web/native/firetv-lightning.js';
import { ok, eq, section, summary } from './lib.mjs';

globalThis.__tvTransport = makeTransport();
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const { startAdbMock } = await import('../mocks/adb-mock.mjs');
const { startFireApiMock } = await import('../mocks/firetv-api-mock.mjs');
const adbTv = await startAdbMock({ port: 19395, autoAllow: true });
let n = 0, pd = 19900; const NOADB = 19399;
const tv = async (o = {}, adbPort = NOADB) => { pd += 10; const m = await startFireApiMock({ dialPort: pd, apiPort: pd + 1, awake: true, strict: true, ...o });
  const d = { id: 'firetv-q' + (++n), host: '127.0.0.1', platform: 'firetv', name: 'Fire', ports: { adb: adbPort, dial: pd, lightning: pd + 1, dialdd: pd + 2 } };
  const st = makeStore(); const r = await fire.pairStart(d, st); if (r.status === 'code') await fire.pairFinish(d, st, '4821'); return [m, d, st]; };
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;

section('1. the official forms come first');
eq(OFFICIAL.play_pause[0], '/v1/media?action=play', 'play/pause = body-less media play');
eq(OFFICIAL.rew[0], ['/v1/media?action=scan', { direction: 'back', durationInSeconds: '10', speed: '1' }], 'rewind = scan + official body');
eq(OFFICIAL.ff[0], ['/v1/media?action=scan', SCAN('forward')], 'fast-forward = scan + official body');
eq(FORMS[0], { id: 'tap', why: 'official short tap (empty body)', steps: [null] }, 'volume/mute: official tap first (build 33: firetv-volume.js)');
ok(UUID.test(reqId()) && reqId() !== reqId(), 'request ids are fresh UUID v4');

section('2. strict official-spec TV: every button accepted on the FIRST request');
let [m, d, st] = await tv(); const r0 = m.st.reqs.length;
for (const k of ['play_pause', 'play_pause', 'rew', 'ff', 'vol_up', 'vol_down', 'mute']) { const w = await fire.key(d, k, st); ok(/Fire TV (remote|volume)/.test(w), `${k} → ${w}`); }
eq(m.st.keys, ['play', 'play', 'scan&direction=back', 'scan&direction=forward', 'volume_up', 'volume_down', 'mute'], 'exact official requests, in order');
eq(m.st.reqs.slice(r0).filter((x) => x.startsWith('POST')).length, 7, 'one button request per press (build 33: plus the volume read-back GETs)');
const ids = m.st.rids.slice(-7); ok(ids.every((x) => UUID.test(x || '')), 'every request carries x-amzn-request-id'); ok(new Set(ids).size === 7, 'request ids unique');
ok(m.st.ctypes.filter(Boolean).slice(-7).every((c) => c === 'application/json; charset=utf-8'), 'Content-Type as the official app sends it');
ok([...m.st.uas].every((u) => u === 'okhttp/4.12.0'), 'User-Agent okhttp/4.12.0');
m.close(); fire.closeAll();

section('3. volume buttons are never hidden when paired the official way');
[m, d, st] = await tv({}, 19395); { const r = await adb.pairStart(d, st); if (r.status === 'confirm') await adb.pairFinish(d, st); }
eq(await fire.volumeCaps(d, st), 'yes', 'official token → volume available (ADB fixed-volume flag ignored)'); m.close(); fire.closeAll();

section('4. build 21 fallback kept: official refused → ADB keys');
[m, d, st] = await tv({ refuse: ['play', 'pause', 'scan', 'volume_up', 'volume_down', 'mute', 'volume_mute'] }, 19395); { const r = await adb.pairStart(d, st); if (r.status === 'confirm') await adb.pairFinish(d, st); }
const k0 = adbTv.st.keys.length; for (const k of ['play_pause', 'vol_up', 'vol_down', 'mute', 'rew', 'ff']) await fire.key(d, k, st); await sleep(500);
const g = adbTv.st.keys.slice(k0).map((x) => x.k).join(' '); for (const w of ['MEDIA_PLAY_PAUSE', 'VOLUME_UP', 'VOLUME_DOWN', 'VOLUME_MUTE', 'MEDIA_REWIND', 'MEDIA_FAST_FORWARD']) ok(g.includes(w), `${w} over ADB`);
m.close(); fire.closeAll(); adbTv.close(); stopJvm();
const s = summary(); console.log(`\n${s.pass} passed, ${s.fail} failed`); process.exit(s.fail ? 1 : 0);
