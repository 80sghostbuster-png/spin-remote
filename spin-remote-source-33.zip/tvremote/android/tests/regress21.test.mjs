// Build 21: Google TV found by mDNS but "Couldn't reach" (stale address / port, pairing port silent, refused saved pairing) and
// Fire TV fast key helper start-up made sturdier (adb sync copy, jar form, 15 s start, ping handshake, app_process errors logged).
// All on SELF-WRITTEN mocks — simulated, not real TVs.
import { makeTransport as makeNodeTransport, stopJvm } from './transports.mjs';
import { makeStore, createBackend } from '../../web/native/backend.js';
import { startAndroidTvMock } from '../mocks/androidtv-mock.mjs';
import { startAdbMock } from '../mocks/adb-mock.mjs';
import { ok, eq, rejects, section, summary } from './lib.mjs';
import { sleep } from '../../web/native/bytes.js';
import { getLog } from '../../web/native/dbg.js';
import { FIREKEYS_HASH } from '../../web/native/firekeys-dex.js';

const stub = () => async (p) => ({ stub: p, demo: true });
const mem = () => { const m = new Map(); return { getItem: (k) => (m.has(k) ? m.get(k) : null), setItem: (k, v) => m.set(k, v), removeItem: (k) => m.delete(k) }; };
const H = '_androidtvremote2._tcp.';

section('Google TV: saved address is stale, a fresh mDNS lookup finds the TV (new IP and port) → pairing reaches it');
{
  const a = await startAndroidTvMock({ pairPort: 17567, remotePort: 17566, host: '127.0.0.1' });
  const ls = mem(); ls.setItem('spin.devices', JSON.stringify([{ id: 'googletv-127.0.0.9', platform: 'googletv', name: 'Lex’s room TV', host: '127.0.0.9', paired: false }]));
  const b = createBackend({ makeSim: stub, store: makeStore(ls), transport: makeNodeTransport({ mdns: [{ type: H, name: 'Lex’s room TV', host: '127.0.0.1', hosts: ['127.0.0.1'], port: 17566 }] }), ports: { googletv: { pair: 17567, remote: 17566 } } });
  const call = (p, body) => b.handler(p, { method: 'POST', body: JSON.stringify(body) });
  const r = await call('/api/pair/start', { device: 'googletv-127.0.0.9' });
  eq(r.status, 'code', 'pairing reached the TV at its fresh address');
  const log = getLog();
  ok(/mDNS lookup: OK — 127\.0\.0\.1:17566/.test(log), 'stage log names the fresh mDNS address');
  ok(/trying 127\.0\.0\.1:17567 \(fresh mDNS\)/.test(log), 'pairing tried the advertised port + 1 (17567)');
  b.closeAll(); a.close();
}

section('Google TV: nothing answers anywhere → clear error with stage list and the TV-side checklist');
{
  const ls = mem(); ls.setItem('spin.devices', JSON.stringify([{ id: 'googletv-127.0.0.9', platform: 'googletv', name: 'Gone TV', host: '127.0.0.9', paired: false, ports: { pair: 17667, remote: 17666 } }]));
  const b = createBackend({ makeSim: stub, store: makeStore(ls), transport: makeNodeTransport({ mdns: [] }), ports: { googletv: { pair: 17667, remote: 17666 } } });
  const e = await rejects(b.handler('/api/pair/start', { method: 'POST', body: JSON.stringify({ device: 'googletv-127.0.0.9' }) }), 'unreachable', 'nothing answers → unreachable');
  ok(/Android TV Remote Service/.test(e.message) && /guest network/.test(e.message) && /Mesh/.test(e.message), 'Details include the TV-side checklist');
  ok(/mDNS lookup/.test(e.message) && /Control 127\.0\.0\.9:17666/.test(e.message), 'Details list every stage tried (pair port, mDNS, control port)'); if (!/Control 127/.test(e.message)) console.log(e.message);
  b.closeAll();
}

section('Google TV: control port refuses this phone’s saved pairing → "not paired" (PAIR shows a fresh code), not "couldn’t reach"');
{
  const net = (await import('node:net')).default;
  const junk = net.createServer((c) => { c.on('error', () => {}); c.end(Buffer.from('nope\r\n')); }); await new Promise((res) => junk.listen(17766, '127.0.0.1', res));
  const ls = mem(); ls.setItem('spin.devices', JSON.stringify([{ id: 'googletv-127.0.0.1', platform: 'googletv', name: 'TV', host: '127.0.0.1', paired: true, ports: { pair: 17767, remote: 17766 } }]));
  const b = createBackend({ makeSim: stub, store: makeStore(ls), transport: makeNodeTransport({ mdns: [] }), ports: { googletv: { pair: 17767, remote: 17766 } } });
  await rejects(b.handler('/api/send', { method: 'POST', body: JSON.stringify({ device: 'googletv-127.0.0.1', action: 'key', key: 'up' }) }), 'not_paired', 'TLS refused on the control port');
  b.closeAll(); junk.close();
}

section('Hidden "reset this TV": forgets this TV’s own certificate and pairing, other TVs untouched');
{
  const ls = mem(); ls.setItem('spin.devices', JSON.stringify([{ id: 'googletv-a', platform: 'googletv', name: 'A', host: '127.0.0.9', paired: true }, { id: 'googletv-b', platform: 'googletv', name: 'B', host: '127.0.0.8', paired: true }]));
  ls.setItem('spin.atv.identity.googletv-a', '{"x":1}'); ls.setItem('spin.atv.identity', '{"shared":1}');
  const b = createBackend({ makeSim: stub, store: makeStore(ls), transport: makeNodeTransport({ mdns: [] }), ports: {} });
  const r = await b.handler('/api/devices/reset', { method: 'POST', body: JSON.stringify({ device: 'googletv-a' }) });
  ok(r.ok && ls.getItem('spin.atv.identity.googletv-a') == null, 'TV A’s own certificate deleted');
  ok(ls.getItem('spin.atv.identity') != null, 'shared certificate kept (the downstairs TV stays paired)');
  const devs = JSON.parse(ls.getItem('spin.devices')); ok(devs.find((d) => d.id === 'googletv-a').paired === false && devs.find((d) => d.id === 'googletv-b').paired === true, 'A unpaired, B still paired');
  b.closeAll();
}

let port = 15900;
async function fire(opts = {}, wait = 900) {
  const p = port++; const m = await startAdbMock({ port: p, autoAllow: true, inputMs: 120, helper: true, ...opts });
  const b = createBackend({ makeSim: stub, store: makeStore(null), transport: makeNodeTransport(), ports: { firetv: { adb: p } } });
  const call = (path, body) => b.handler(path, { method: 'POST', body: JSON.stringify(body) });
  const d = await call('/api/devices', { platform: 'firetv', host: '127.0.0.1' });
  await call('/api/pair/start', { device: d.id }); await call('/api/pair/finish', { device: d.id }); await call('/api/warm', { device: d.id }); await sleep(wait);
  return { m, send: (x) => call('/api/send', { device: d.id, ...x }), close: () => { b.closeAll(); m.close(); } };
}
section('Fire TV helper: copied with adb sync (no base64 tool needed), as a jar, handshake answered before use');
{
  const t = await fire();
  ok(t.m.st.setup.includes('sync') && !t.m.st.setup.includes('chunk'), 'copied with adb sync, not as text');
  ok(t.m.st.files.has(`/data/local/tmp/spinremote-keys-${FIREKEYS_HASH}.jar`), 'stored as a .jar (the form scrcpy uses)');
  ok(/helper ready in \d+ ms \(handshake answered\)/.test(getLog()), 'handshake answered is logged');
  eq((await t.send({ action: 'key', key: 'up' })) && t.m.st.keys.at(-1).via, 'helper', 'keys go through the helper');
  t.close();
  const t2 = await fire({ noSync: true });
  ok(t2.m.st.setup.includes('chunk') && t2.m.st.keys.length === 0 && (await t2.send({ action: 'key', key: 'up' })).ok && t2.m.st.keys.at(-1).via === 'helper', 'sync refused → text copy fallback, helper still used');
  t2.close();
  const t3 = await fire({ helperStartMs: 7000, helperNoise: 'WARNING: linker: something harmless\n' }, 7600);
  ok((await t3.send({ action: 'key', key: 'up' })).ok && t3.m.st.keys.at(-1).via === 'helper', 'slow first start (7 s, like a cold Fire TV Stick) still comes up');
  ok(/helper said: WARNING: linker/.test(getLog()), 'app_process output is captured in the debug log');
  t3.close();
}
stopJvm && stopJvm();
summary();
