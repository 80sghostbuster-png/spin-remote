// Build 32: the TV's full answer to every Fire TV button is in the debug log, and the device info (GET /v1/FireTV) the official app reads first
// (isVolumeControlsSupported / volumeCapabilityLevelOfSupport) is fetched and logged. Requests unchanged. SELF-WRITTEN mocks — not a real Fire TV.
import { makeTransport, stopJvm } from './transports.mjs';
import { makeStore } from '../../web/native/backend.js';
import { fire } from '../../web/native/firetv-official.js';
import { getLog } from '../../web/native/dbg.js';
import { ok, eq, section, summary } from './lib.mjs';
globalThis.__tvTransport = makeTransport();
const { startFireApiMock } = await import('../mocks/firetv-api-mock.mjs');
const m = await startFireApiMock({ dialPort: 19970, apiPort: 19971, awake: true, strict: true, volumeSupported: false }); m.st.token = 'Wj9PP8I';
const d = { id: 'firetv-r32', host: '127.0.0.1', platform: 'firetv', name: 'Fire', ports: { adb: 19979, dial: 19970, lightning: 19971, dialdd: 19972 } };
const st = makeStore(); st.set('ftv.lightning.' + d.id, 'Wj9PP8I');
section('1. warm reads and logs the device info');
await fire.warm(d, st); await new Promise((r) => setTimeout(r, 800));
const L = () => String(getLog());
ok(/GET \/v1\/FireTV → HTTP\/1\.1 200/.test(L()), 'device info status line logged'); ok(/volume supported = false, volume level = NONE/.test(L()), 'volume support logged in plain words');
section('2. every press logs the full status line and body');
for (const k of ['vol_up', 'vol_down', 'mute', 'play_pause']) await fire.key(d, k, st);
eq(m.st.keys, ['volume_up', 'volume_down', 'mute', 'play'], 'requests unchanged (official tap form)');
for (const a of ['volume_up', 'volume_down', 'mute']) ok(new RegExp(`action=${a}(?: \\(empty body\\))? → HTTP/1\\.1 200 OK body: \\{"description":"OK"\\}`).test(L()), `${a}: status + body in the log`);
fire.closeAll(); m.close(); stopJvm();
const s = summary(); console.log(`\n${s.pass} passed, ${s.fail} failed`); process.exit(s.fail ? 1 : 0);
