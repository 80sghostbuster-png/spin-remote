// Node implementation of the transport interface (same methods as the Java "TvNative" plugin) - lets the exact shipped JS protocol code run on the box.
import net from 'node:net';
import tls from 'node:tls';
import dgram from 'node:dgram';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { execFileSync } from 'node:child_process';

const SHA1_PREFIX = Buffer.from('3021300906052b0e03021a05000414', 'hex');
const socks = new Map(); let nextId = 1;

/** Test helper: the phone's Wi-Fi drops - every open TCP/TLS connection is reset at once. */
export function dropAllSockets() { let n = 0; for (const r of socks.values()) { try { r.s.destroy(); n++; } catch { /* gone */ } } return n; }
export function makeNodeTransport({ mdns = [], scanHosts = [], mdnsFail = null } = {}) {
  const mdnsCalls = [];
  return {
    mdnsCalls,
    async prepare() { return { android: 'node-test', device: 'node', network: 'test transport', phoneIp: '127.0.0.1', nearbyPermission: 'n/a', localNetworkPermission: 'n/a' }; },
    async probe({ host, ports, timeoutMs = 1000 }) { const out = []; for (const port of ports) { const t0 = Date.now(); out.push(await new Promise((res) => { const c = net.connect({ host, port }); c.setTimeout(timeoutMs, () => { c.destroy(); res({ port, state: 'timeout', ms: Date.now() - t0, detail: '' }); }); c.on('connect', () => { c.destroy(); res({ port, state: 'open', ms: Date.now() - t0, detail: '' }); }); c.on('error', (e) => res({ port, state: /ECONNREFUSED/.test(e.code) ? 'refused' : 'error', ms: Date.now() - t0, detail: e.message })); })); } out.ping = false; return out; },
    async tcpScan({ ports, timeoutMs = 400 }) { const out = []; out.prefixes = []; for (const host of scanHosts) for (const port of ports) if (await new Promise((res) => { const c = net.connect({ host, port }); c.setTimeout(timeoutMs, () => { c.destroy(); res(false); }); c.on('connect', () => { c.destroy(); res(true); }); c.on('error', () => res(false)); })) out.push({ host, port }); return out; },
    async ssdp({ st, timeoutMs = 1500, target }) {
      return new Promise((resolve) => {
        const s = dgram.createSocket('udp4'), out = [];
        s.on('message', (m, r) => { const lines = m.toString().split('\r\n'); const h = {}; for (const l of lines.slice(1)) { const i = l.indexOf(':'); if (i > 0) h[l.slice(0, i).trim().toLowerCase()] = l.slice(i + 1).trim(); } out.push({ ip: r.address, headers: h }); });
        s.bind(0, () => {
          const msg = Buffer.from(`M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\nMAN: "ssdp:discover"\r\nMX: 2\r\nST: ${st}\r\n\r\n`);
          s.send(msg, (target && target.port) || 1900, (target && target.host) || '239.255.255.250');
          setTimeout(() => { s.close(); resolve(out); }, timeoutMs);
        });
      });
    },
    async mdns({ type }) { mdnsCalls.push(type); if (mdnsFail) { const m = mdnsFail(type); if (m) throw new Error(m); } return mdns.filter((r) => r.type === type); },
    async http({ method, url, body, timeoutMs = 4000 }) {
      const r = await fetch(url, { method, body: method === 'GET' ? undefined : body, signal: AbortSignal.timeout(timeoutMs) });
      return { status: r.status, statusLine: `HTTP/1.1 ${r.status} ${r.statusText}`, body: await r.text() };
    },
    async genIdentity(o = {}) {
      const { publicKey, privateKey } = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
      const jwk = publicKey.export({ format: 'jwk' });
      const out = { keyPkcs8: privateKey.export({ type: 'pkcs8', format: 'der' }).toString('base64'), modulusHex: Buffer.from(jwk.n, 'base64url').toString('hex'), exponentHex: Buffer.from(jwk.e, 'base64url').toString('hex').replace(/^0+/, '') };
      if (o.cert !== false) out.certDer = mkCert(privateKey, 'atvremote').toString('base64');
      return out;
    },
    async rsaSignAdb({ keyPkcs8, token }) {
      const key = crypto.createPrivateKey({ key: Buffer.from(keyPkcs8, 'base64'), format: 'der', type: 'pkcs8' });
      return new Uint8Array(crypto.privateEncrypt({ key, padding: crypto.constants.RSA_PKCS1_PADDING }, Buffer.concat([SHA1_PREFIX, Buffer.from(token)])));
    },
    async tcpOpen({ host, port, tls: useTls, identity, timeoutMs = 4000, tls12 = false }) {
      return new Promise((resolve, reject) => {
        const opts = { host, port, rejectUnauthorized: false, ...(tls12 ? { maxVersion: 'TLSv1.2' } : {}) };
        if (useTls && identity) { opts.key = crypto.createPrivateKey({ key: Buffer.from(identity.keyPkcs8, 'base64'), format: 'der', type: 'pkcs8' }).export({ type: 'pkcs8', format: 'pem' }); opts.cert = new crypto.X509Certificate(Buffer.from(identity.certDer, 'base64')).toString(); }
        const s = useTls ? tls.connect(opts) : net.connect(opts); if (s.setNoDelay) s.setNoDelay(true);   // like NetCore.java (setTcpNoDelay)
        const rec = { s, q: [], closed: false, waiter: null, tcp: false }; s.once('connect', () => { rec.tcp = true; });
        const t = setTimeout(() => { s.destroy(); reject(new Error('connect timeout')); }, timeoutMs);
        s.on('data', (d) => { rec.q.push(d); if (rec.waiter) rec.waiter(); });
        s.on('close', () => { rec.closed = true; if (rec.waiter) rec.waiter(); });
        s.on('error', (e) => { clearTimeout(t); if (!rec.opened) reject(useTls && rec.tcp ? new Error(`TLS handshake failed with ${host}:${port} (TCP connected fine): ${e.message}`) : new Error(`TCP connect failed: ${e.message}`)); rec.closed = true; if (rec.waiter) rec.waiter(); });
        s.once(useTls ? 'secureConnect' : 'connect', () => { clearTimeout(t); rec.opened = true; const id = nextId++; socks.set(id, rec); resolve({ id, peerCert: useTls ? s.getPeerCertificate(true).raw.toString('base64') : null, tls: useTls ? `${s.getProtocol()} ${(s.getCipher() || {}).name || ''}` : undefined }); });
      });
    },
    async tcpWrite(id, u8) { const r = socks.get(id); if (!r || r.closed) throw new Error('closed'); r.s.write(Buffer.from(u8)); },
    async tcpRead(id, timeoutMs) {
      const r = socks.get(id); if (!r) return { data: null, closed: true };
      if (!r.q.length && !r.closed) await new Promise((res) => { const t = timeoutMs > 0 ? setTimeout(res, timeoutMs) : null; r.waiter = () => { if (t) clearTimeout(t); res(); }; });
      r.waiter = null;
      if (r.q.length) { const d = Buffer.concat(r.q); r.q = []; return { data: new Uint8Array(d), closed: false }; }
      return { data: null, closed: r.closed, timeout: !r.closed };
    },
    async tcpClose(id) { const r = socks.get(id); if (r) { r.s.destroy(); socks.delete(id); } },
  };
}

export function mkCert(privateKey, cn) {
  const d = fs.mkdtempSync(path.join(os.tmpdir(), 'cert-'));
  fs.writeFileSync(d + '/k.pem', privateKey.export({ type: 'pkcs8', format: 'pem' }));
  const der = execFileSync('openssl', ['req', '-x509', '-new', '-key', d + '/k.pem', '-subj', '/CN=' + cn, '-days', '3650', '-outform', 'DER']);
  fs.rmSync(d, { recursive: true }); return der;
}
