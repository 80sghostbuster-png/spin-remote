let pass = 0, fail = 0; const fails = [];
export function ok(cond, msg) { if (cond) { pass++; console.log('  ✓', msg); } else { fail++; fails.push(msg); console.log('  ✗ FAIL:', msg); } }
export const eq = (a, b, msg) => ok(JSON.stringify(a) === JSON.stringify(b), `${msg}${JSON.stringify(a) === JSON.stringify(b) ? '' : `  (got ${JSON.stringify(a)}, want ${JSON.stringify(b)})`}`);
export async function rejects(p, code, msg) { try { await p; ok(false, msg + ' (did not throw)'); } catch (e) { ok(!code || e.code === code, `${msg} → ${e.code || e.message}`); return e; } }
export const summary = () => ({ pass, fail, fails });
export const section = (t) => console.log('\n' + t);
