// web/voice.js against a scripted stand-in for the Android plugin (the real SpeechRecognizer is Java and is not exercised here).
import { ok, eq, section, summary } from './lib.mjs';
import { setPlugin } from '../../web/native/plug.js';
import { voiceEngine, VOICE_MSG } from '../../web/voice.js';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
function plugin(startResult) {
  const L = new Set(), calls = [];
  const P = {
    calls, listeners: L,
    async addListener(name, fn) { calls.push('listen:' + name); const h = { fn, remove: async () => { L.delete(h); calls.push('unlisten'); } }; L.add(h); return h; },
    async voiceStart() { calls.push('start'); if (startResult instanceof Error) throw startResult; return startResult; },
    async voiceStop() { calls.push('stop'); }, async voiceCancel() { calls.push('cancel'); },
    emit(ev) { for (const h of [...L]) h.fn(ev); },
  };
  return P;
}
section('Native engine: events pass through, listener is released at the end');
{
  const P = plugin({ state: 'started' }); setPlugin(P); const e = voiceEngine(); const got = [];
  await e.start((ev) => got.push(ev));
  P.emit({ state: 'listening' }); P.emit({ state: 'partial', text: 'the off' }); P.emit({ state: 'partial', text: 'the office' }); P.emit({ state: 'final', text: 'the office' }); await sleep(20);
  eq(got.map((g) => g.state), ['listening', 'partial', 'partial', 'final'], 'listening → interim words → final words arrive in order');
  eq(got[3].text, 'the office', 'final text is delivered');
  eq(P.listeners.size, 0, 'listener removed after the final result');
}
section('Permission denied / recognizer missing → a clear error, listener removed, mic never left open');
for (const code of ['denied', 'unavailable']) {
  const P = plugin({ state: code }); setPlugin(P); const e = voiceEngine(); const got = []; await e.start((ev) => got.push(ev));
  eq(got, [{ state: 'error', code }], `${code}: reported as an error`); eq(P.listeners.size, 0, `${code}: no listener left`);
  ok(VOICE_MSG[code] && !/exception|error code|SpeechRecognizer|null|undefined/i.test(VOICE_MSG[code]), `${code}: the message is plain language`);
}
{
  const P = plugin(new Error('boom')); setPlugin(P); const got = []; await voiceEngine().start((ev) => got.push(ev));
  eq(got, [{ state: 'error', code: 'unavailable' }], 'a plugin failure is reported as "unavailable", not thrown');
}
section('Done and Cancel');
{
  const P = plugin({ state: 'started' }); setPlugin(P); const e = voiceEngine(); await e.start(() => {});
  await e.stop(); ok(P.calls.includes('stop'), 'Done asks the recognizer to finish (words so far are delivered)');
  await e.cancel(); ok(P.calls.includes('cancel') && P.listeners.size === 0, 'Cancel releases the microphone and drops the listener');
  const n = P.calls.length; await e.cancel(); ok(P.calls.length >= n, 'cancelling twice is harmless');
}
section('Starting again never double-listens');
{
  const P = plugin({ state: 'started' }); setPlugin(P); const e = voiceEngine(); await e.start(() => {}); await e.start(() => {}); eq(P.listeners.size, 1, 'one listener after two starts');
}
section('Every spoken error has a plain-language message');
for (const c of ['denied', 'unavailable', 'no_speech', 'no_match', 'network', 'busy', 'audio']) ok(typeof VOICE_MSG[c] === 'string' && VOICE_MSG[c].length > 10, `message for ${c}`);
const s = summary(); console.log(`\n${s.pass} passed, ${s.fail} failed`); if (s.fail) { console.log(s.fails.join('\n')); process.exit(1); } process.exit(0);
