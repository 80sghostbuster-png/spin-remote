// UI rule: a TV appears nowhere (Your TVs sheet, header pill, pair list) unless it answers on the network the phone is on right now.
// The page is the real web/ app; a fake bridge (request interception) plays the "native" backend so the real-phone code path (info.native) runs.
import http from 'node:http'; import fs from 'node:fs'; import path from 'node:path';
import puppeteer from '../../tools/node_modules/puppeteer-core/lib/esm/puppeteer/puppeteer-core.js';
import { ok, eq, section, summary } from './lib.mjs';
const WEB = path.resolve(new URL('../../web/', import.meta.url).pathname);
const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.svg': 'image/svg+xml', '.png': 'image/png', '.webmanifest': 'application/json' };
let ADS_OFF = false;
const srv = http.createServer((q, r) => { const u = decodeURIComponent(q.url.split('?')[0]); if (u === '/config.js' && ADS_OFF) { r.setHeader('content-type', 'text/javascript'); return r.end('export const ADS_PLACEHOLDERS_ENABLED = false; export const AD_ROTATE_MS = 20000;'); } const f = path.join(WEB, u === '/' ? 'index.html' : u); if (!f.startsWith(WEB) || !fs.existsSync(f)) { r.statusCode = 404; return r.end(); } r.setHeader('content-type', MIME[path.extname(f)] || 'application/octet-stream'); r.end(fs.readFileSync(f)); });
await new Promise((res) => srv.listen(0, '127.0.0.1', res)); const base = `http://127.0.0.1:${srv.address().port}/`;
const SAVED = [
  { id: 'googletv-192.168.4.28', platform: 'googletv', name: 'Lex’s room TV', host: '192.168.4.28', paired: false },
  { id: 'roku-192.168.4.40', platform: 'roku', name: 'Living Room Roku', host: '192.168.4.40', paired: true },
  { id: 'firetv-192.168.4.41', platform: 'firetv', name: 'Ben’s Fire TV', host: '192.168.4.41', paired: true },
];
let LIVE = [], SEEN = [], calls = [], EXTRA = [], finishes = [];
const PAIRSTART = { googletv: { status: 'code', kind: 'hex', length: 6, message: 'Look at your TV.' }, appletv: { status: 'code', kind: 'num', length: 4, message: 'Look at your TV.' }, firetv: { status: 'confirm', message: 'Allow on TV' }, roku: { status: 'paired' } };
const browser = await puppeteer.launch({ executablePath: '/usr/bin/google-chrome', headless: 'new', args: ['--no-sandbox'] });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let PRE = null;
async function open(b = browser) {
  const p = await b.newPage(); await p.setCacheEnabled(false); await (await p.createCDPSession()).send('Network.setBypassServiceWorker', { bypass: true }); await p.setViewport({ width: 390, height: 844, isMobile: true, hasTouch: true });
  await p.setRequestInterception(true);
  p.on('request', (rq) => {
    const u = new URL(rq.url()); if (!u.pathname.startsWith('/api/')) return rq.continue();
    calls.push(u.pathname); const j = (o) => rq.respond({ status: 200, contentType: 'application/json', body: JSON.stringify(o) });
    if (u.pathname === '/api/info') return j({ platforms: ['roku', 'firetv', 'googletv', 'appletv'], native: true, demo: false });
    if (u.pathname === '/api/devices') return j({ devices: SAVED.concat(EXTRA), demo: false });
    if (u.pathname === '/api/pair/start') { const id = JSON.parse(rq.postData() || '{}').device || ''; return j(PAIRSTART[id.split('-')[0]] || { status: 'paired' }); }
    if (u.pathname === '/api/pair/finish') { const b = JSON.parse(rq.postData() || '{}'); finishes.push(b.code); if (/^firetv/.test(b.device || '')) return setTimeout(() => j({ status: 'paired' }), 2500); const good = b.code === 'A1B2C3' || b.code === '4821'; return rq.respond({ status: good ? 200 : 400, contentType: 'application/json', body: JSON.stringify(good ? { status: 'paired' } : { error: 'wrong', code: 'bad_code' }) }); }
    if (u.pathname === '/api/reachable') return j({ live: LIVE });
    if (u.pathname === '/api/discover') return j({ found: 0, devices: SAVED.concat(EXTRA), seen: SEEN, diag: { mdns: [], sweep: '' } });
    return j({ ok: true });
  });
  if (PRE) await p.evaluateOnNewDocument(PRE);
  await p.goto(base + '?layout=reel&i=2', { waitUntil: 'networkidle0' }); await sleep(500); return p;
}
const pill = (p) => p.$eval('#pill-text', (e) => e.textContent);
const sheetText = (p) => p.$eval('#sheet-body', (e) => e.innerText);
const nowhere = (txt) => !/room TV|Living Room|Ben’s|192\.168|needs pairing/.test(txt);

section('At work (nothing saved answers): saved TVs are not shown anywhere');
{
  LIVE = []; SEEN = []; const p = await open();
  eq(await pill(p), 'Tap PAIR to find your TV', 'header pill is neutral, with no saved TV name or IP');
  await p.evaluate(() => window.__tv.openDevices()); await sleep(400);
  const t = await sheetText(p);
  ok(nowhere(t), 'Your TVs sheet shows no saved TV, no IP address, no “needs pairing”'); ok(/No TVs detected/.test(t), 'Your TVs sheet says no TV is detected on this network');
  ok(calls.includes('/api/reachable'), 'the app checks which saved TVs answer right now');
  await p.evaluate(() => window.__tv.closeSheet()); await p.evaluate(() => document.querySelector('.pairbtn').click()); await sleep(900);
  ok((await p.$$('.ps-dev')).length === 0, 'pair screen lists nothing when nothing is detected');
  ok(nowhere(await p.$eval('#pscreen', (e) => e.innerText)), 'pair screen text shows no saved TV or IP');
  await p.close();
}
section('At home: a detected, paired TV connects without “needs pairing”; IP addresses never shown');
{
  LIVE = ['roku-192.168.4.40']; SEEN = ['roku-192.168.4.40']; const p = await open(); await p.evaluate(() => window.__tv.wheel.goTo(0)); await sleep(800);
  ok(/Living Room Roku · ready/.test(await pill(p)), 'pill shows the live paired TV as ready');
  ok(!/needs pairing/.test(await pill(p)), 'no “needs pairing” for a paired TV');
  await p.evaluate(() => window.__tv.openDevices()); await sleep(400);
  const t = await sheetText(p);
  ok(/Living Room Roku/.test(t) && !/192\.168/.test(t), 'Your TVs lists the live TV by name and platform only (no IP)');
  ok(!/Ben’s|room TV/.test(t), 'saved TVs that do not answer are still hidden');
  await p.evaluate(() => window.__tv.closeSheet());
  section('Leaving home: the TV disappears on the next check (no restart)');
  LIVE = []; await p.evaluate(() => document.dispatchEvent(new Event('visibilitychange'))); await sleep(600);
  eq(await pill(p), 'Tap PAIR to find your TV', 'pill goes neutral when the TV stops answering');
  await p.close();
}
section('Unpaired TV that IS detected: shown by name (no IP) with a Pair action');
{
  LIVE = ['googletv-192.168.4.28']; SEEN = LIVE; const p = await open();
  await p.evaluate(() => window.__tv.openDevices()); await sleep(400); const t = await sheetText(p);
  ok(/Lex’s room TV/.test(t) && /Pair/.test(t) && !/192\.168/.test(t), 'detected unpaired TV listed by name with Pair, no IP');
  await p.close();
}

section('Tapping remote buttons while no TV is connected: quiet. Only PAIR opens pairing');
{
  const probe = async (live, saved) => {
    LIVE = live; SEEN = live; const p = await open(); await p.evaluate(() => document.querySelector('#ad-full') && document.querySelector('#ad-full').remove());
    await p.evaluate(() => window.__tv.expand && window.__tv.expand(2)); await sleep(700);
    const before = calls.length; calls = [];
    for (const sel of ['[data-key=up]', '[data-key=select]', '[data-key=play_pause]', '[data-key=vol_up]', '[data-launch=youtube]']) { await p.evaluate((s) => { const e = document.querySelector('.remote.googletv ' + s) || document.querySelector(s); e && e.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, pointerId: 1 })); e && e.dispatchEvent(new PointerEvent('pointerup', { bubbles: true, pointerId: 1 })); e && e.click(); }, sel); await sleep(120); }
    await sleep(400);
    const r = { pair: await p.$eval('#pscreen', (e) => !e.hidden), sheet: await p.$eval('#sheet', (e) => e.classList.contains('on')), toast: await p.$eval('#toast', (e) => e.classList.contains('show')), pillTxt: await p.$eval('#pill-text', (e) => e.textContent), sends: calls.filter((c) => c === '/api/send').length };
    await p.close(); return r;
  };
  const none = await probe([]);
  ok(!none.pair && !none.sheet, 'no TV connected: pressing buttons never opens the pairing screen or any sheet');
  ok(!none.toast, 'no TV connected: no toast'); eq(none.pillTxt, 'Tap PAIR to find your TV', 'no TV connected: the header pill stays neutral (no note)'); eq(none.sends, 0, 'no TV connected: nothing is sent');
  const unp = await probe(['googletv-192.168.4.28']);
  ok(!unp.pair && !unp.sheet && !unp.toast && unp.sends === 0, 'a detected but unpaired TV: buttons still press quietly (no pairing screen, no toast, nothing sent)');
  const p2 = await (async () => { LIVE = ['roku-192.168.4.40']; SEEN = LIVE; const p = await open(); await p.evaluate(() => { const f = document.querySelector('#ad-full'); f && f.remove(); window.__tv.wheel.goTo(0); }); await sleep(900); calls = []; await p.evaluate(() => window.__tv.expand(0)); await sleep(700); await p.evaluate(() => { const e = document.querySelector('.remote.roku [data-key=up]'); e.click(); }); await sleep(500); return p; })();
  ok(calls.includes('/api/send'), 'a paired, connected TV still receives the command'); ok(/Up/.test(await p2.$eval('#pill-text', (e) => e.textContent)), 'the result pill still shows when a TV is connected');
  await p2.close();
}

section('FAKE sample ads: made-up creatives with an "Ad" label in the top banner (no controls) and in the full-screen first-open panel ("Close ad" top right); no SDK, no network');
{
  LIVE = []; SEEN = []; const ext = []; calls = [];
  const p = await open(); p.on('request', (rq) => { if (!rq.url().startsWith(base)) ext.push(rq.url()); });
  const full = await p.$('#ad-full'); ok(!!full, 'a full-screen sample ad is shown when the app opens');
  const btn = await p.$('#ad-full button'); const label = btn && await btn.evaluate((e) => e.textContent);
  eq(label, 'Close ad', 'its button is labeled exactly “Close ad”');
  const fb = await full.boundingBox(), bb = await btn.boundingBox();
  ok(fb.width >= 389 && fb.height >= 843, 'it covers the whole screen'); ok(bb.x + bb.width > fb.width - 30 && bb.y < 70, 'the button is at its top right');
  const ft = await full.evaluate((e) => ({ brand: e.querySelector('.adc-brand')?.textContent, slogan: e.querySelector('.adc-slogan')?.textContent, label: e.querySelector('.adc-label')?.textContent, bg: getComputedStyle(e.querySelector('.adc')).backgroundImage }));
  eq(ft.brand, 'SampleBrand', 'the full-screen ad shows a made-up brand'); ok(/Your ad here/.test(ft.slogan), 'and a sample slogan'); eq(ft.label, 'Ad', 'with a small “Ad” label'); ok(/gradient/.test(ft.bg), 'drawn with a gradient (no image file)');
  const lb = await (await p.$('#ad-full .adc-label')).boundingBox(); ok(lb.width < 60 && lb.height < 30, 'the “Ad” label is small');
  eq(await p.$$eval('#ad-banner button, #ad-banner a, #ad-banner input, #ad-banner [role=button]', (n) => n.length), 0, 'the top banner has NO close button (or any control)');
  const bt = await p.$eval('#ad-banner', (e) => e.innerText); ok(/SampleBrand/.test(bt) && /\bAd\b/.test(bt), 'the banner shows the first sample ad with its “Ad” label');
  ok(await p.$eval('#ad-banner', (e) => !e.querySelector('img, iframe, script, video, a, link')), 'the creatives are plain shapes and text: no images, frames, links or scripts');
  const cc = await p.$eval('#ad-close', (e) => { const s = getComputedStyle(e); return [s.color, s.borderTopWidth, s.backgroundColor]; });
  ok(cc[0] === 'rgb(20, 20, 28)' && parseFloat(cc[1]) >= 1 && cc[2] === 'rgb(255, 255, 255)', '“Close ad” is dark text on white with a border (legible over the ad)');
  const hdr = await (await p.$('#top')).boundingBox(), bn = await (await p.$('#ad-banner')).boundingBox(), stg = await (await p.$('#stage')).boundingBox();
  ok(bn.y >= hdr.y + hdr.height - 1 && bn.y - (hdr.y + hdr.height) < 10 && bn.height >= 40, 'the banner sits right under the header, always shown');
  ok(stg.y >= bn.y + bn.height - 1 && stg.y - (bn.y + bn.height) < 12, 'the remote area starts right under the banner (layout reflowed, no gap)');
  await btn.click(); await sleep(150);
  ok(!(await p.$('#ad-full')), 'Close ad reveals the app'); ok(!!(await p.$('#ad-banner')), 'the banner stays (always shown)');
  // slow rotation: step it by hand and check that nothing moves
  const geo = async () => JSON.stringify([await (await p.$('#ad-banner')).boundingBox(), await (await p.$('#stage')).boundingBox(), await (await p.$('#top')).boundingBox()]);
  const g0 = await geo(), seen = [];
  for (let n = 0; n < 5; n++) { seen.push(await p.$eval('#ad-banner .ad-layer.on .adc-brand', (e) => e.textContent)); await p.evaluate(async () => (await import('/ads.js')).rotateBanner()); await sleep(750); eq(await geo(), g0, `rotation step ${n + 1}: banner, header and remote area did not move or resize`); }
  eq(seen.slice(0, 4), ['SampleBrand', 'Fakeco Snacks', 'Nimbly Demo', 'Orbit Dummy Co.'], 'it cycles through four different made-up sample ads'); eq(seen[4], 'SampleBrand', 'and wraps around');
  eq(await p.$$eval('#ad-banner .ad-layer', (n) => n.length), 2, 'always exactly two layers (cross-fade, nothing added over time)'); eq(await p.$$eval('#ad-banner .adc', (n) => n.length), 2, 'and two creatives in them (no build-up)');
  const names = await p.evaluate(async () => (await import('/ads.js')).FAKE_ADS.map((a) => a.brand + ' ' + a.slogan).join(' | ')); ok(/^SampleBrand Your ad here/.test(names) && !/Google|Amazon|Apple|Netflix|Roku|Samsung|Coca|Nike|Pepsi|Disney/i.test(names), 'brand names are invented (no real companies)');
  await p.evaluate(() => document.querySelector('#stage').dispatchEvent(new Event('x')));
  ok(ext.length === 0 && !calls.some((c) => /ad/i.test(c.replace('/api/', '').split('/')[0]) && c !== '/api/info'), 'no external or ad network requests were made');
  await p.close();
  PRE = () => { const si = window.setInterval; window.__ivs = []; window.setInterval = (f, ms, ...a) => { const mine = typeof f === 'function' && /rotateBanner/.test(String(f)); if (mine) window.__ivs.push(ms); return si(f, mine ? 400 : ms, ...a); }; };   // the timer is registered with 20000 ms; the test shortens it so it can be seen firing
  const t = await open(); PRE = null; await sleep(1500);
  ok((await t.evaluate(() => window.__ivs)).includes(20000), 'the banner timer is registered for 20 seconds'); const nowB = await t.$eval('#ad-banner .ad-layer.on .adc-brand', (e) => e.textContent); ok(nowB !== 'SampleBrand', `the timer rotates it by itself (now “${nowB}”)`);
  await t.close();
  ADS_OFF = true; const ctxOff = await browser.createBrowserContext(); const q = await open(ctxOff);
  ok(!(await q.$('#ad-full')) && !(await q.$('#ad-banner')), 'the config flag (ADS_PLACEHOLDERS_ENABLED=false) removes both ads');
  await q.close(); await ctxOff.close(); ADS_OFF = false;
}
section('Pairing: a code shown on the TV is the only way to finish (Google TV 6-char, Apple TV 4-digit); Fire TV says choose Allow; clean SVG check, no ✓ glyph');
{
  EXTRA = [{ id: 'appletv-192.168.4.50', platform: 'appletv', name: 'Den Apple TV', host: '192.168.4.50', paired: false }, { id: 'firetv-192.168.4.51', platform: 'firetv', name: 'Den Fire TV', host: '192.168.4.51', paired: false }];
  const openPS = async (id) => { LIVE = [id]; SEEN = [id]; const p = await open(); await p.evaluate(() => { const f = document.querySelector('#ad-full'); f && f.remove(); }); await p.evaluate(() => document.querySelector('.pairbtn').click()); await sleep(900); await p.evaluate(() => document.querySelector('.ps-dev').click()); await sleep(900); return p; };
  const modal = (p) => p.$eval('#psmodal', (e) => e.innerText).catch(() => '');
  let p = await openPS('googletv-192.168.4.28'); let m = await modal(p);
  ok(/Enter the code shown on your TV/.test(m), 'Google TV: the modal says “Enter the code shown on your TV”'); ok(/6-character/.test(m), 'Google TV: it says the code is 6 characters');
  eq(await p.$$eval('#psmodal button', (b) => b.map((x) => x.textContent.trim()).join('|')), 'Cancel|OK', 'Google TV: only Cancel and OK — there is no Skip');
  ok(!/skip/i.test(await p.$eval('#pscreen', (e) => e.innerText)), 'no Skip anywhere on the pairing screen'); ok(await p.$eval('#psmodal [data-act=psok]', (e) => e.disabled), 'OK is disabled until the whole code is typed');
  const inp = await p.$('#pscode'); await inp.type('A1B2'); ok(await p.$eval('#psmodal [data-act=psok]', (e) => e.disabled), 'OK stays disabled with a partial code'); ok(!finishes.length, 'nothing was sent to finish pairing without the code');
  await inp.type('ZZ'); eq(await p.$eval('#pscode', (e) => e.value), 'A1B2', 'only hex characters are accepted'); await inp.type('00'); await sleep(300);
  await p.click('#psmodal [data-act=psok]'); await sleep(700); ok(/didn.t match/.test(await modal(p)), 'a wrong code shows a clear failure and the modal stays'); eq(finishes.at(-1), 'A1B200', 'the typed code was sent for validation');
  await p.evaluate(() => { const i = document.querySelector('#pscode'); i.value = 'A1B2C3'; i.dispatchEvent(new Event('input')); }); await sleep(200); await p.click('#psmodal [data-act=psok]'); await sleep(500);
  const okm = await modal(p); ok(/Paired/.test(okm) && (await p.$('#psmodal .bigck svg')), 'the right code shows a Paired success state with an SVG check badge'); await sleep(1600);
  ok(await p.$eval('#pscreen', (e) => e.hidden), 'then the pairing screen closes'); await p.close();
  p = await openPS('appletv-192.168.4.50'); m = await modal(p); ok(/Enter the code shown on your TV/.test(m) && /4-digit/.test(m), 'Apple TV: “Enter the code shown on your TV”, 4-digit');
  await (await p.$('#pscode')).type('48a2'); eq(await p.$eval('#pscode', (e) => e.value), '482', 'Apple TV accepts digits only'); await p.close();
  p = await openPS('firetv-192.168.4.51'); m = await modal(p); ok(/Look at your TV and choose Allow/.test(m), 'Fire TV: “Look at your TV and choose Allow”'); ok(!(await p.$('#pscode')), 'Fire TV has no code box'); await p.close();
  EXTRA = [];
  LIVE = ['roku-192.168.4.40']; SEEN = LIVE; const q = await open(); await q.evaluate(() => { const f = document.querySelector('#ad-full'); f && f.remove(); window.__tv.wheel.goTo(0); }); await sleep(900);
  const txts = await q.evaluate(() => document.body.innerText); ok(!/[✓✗]/.test(txts), 'no ✓/✗ text glyph is on screen'); await q.evaluate(() => window.__tv.expand(0)); await sleep(600); await q.evaluate(() => document.querySelector('.remote.roku [data-key=up]').click()); await sleep(500);
  ok(!!(await q.$('#pill-text .ck svg')) && /Up/.test(await q.$eval('#pill-text', (e) => e.textContent)), 'the result pill shows “Up” with an SVG check badge'); ok(!/[✓✗]/.test(await q.$eval('#pill-text', (e) => e.textContent)), 'the pill has no glyph text'); await q.close();
}
section('Back button / gesture: steps back through the app layers, never leaves; pairing screen has no photo background');
{
  EXTRA = [];
  const back = (p) => p.evaluate(() => window.__tv.back());
  const openPair = async (id) => { LIVE = [id]; SEEN = [id]; const p = await open(); await p.evaluate(() => document.querySelector('.pairbtn').click()); await sleep(900); return p; };
  // layer 0: the full-screen ad placeholder comes first
  LIVE = []; SEEN = []; let p = await open();
  ok(!!(await p.$('#ad-full')), 'ad open at launch'); eq(await back(p), true, 'back with the ad open: handled'); ok(!(await p.$('#ad-full')), 'back closes the full-screen ad placeholder first'); ok(!!(await p.$('#ad-banner')), 'the banner is untouched');
  // layers: sheets
  await p.evaluate(() => window.__tv.openDevices()); await sleep(300); ok(await p.$eval('#sheet', (e) => e.classList.contains('on')), 'Your TVs sheet open'); eq(await back(p), true, 'back with Your TVs open: handled'); await sleep(100); ok(!(await p.$eval('#sheet', (e) => e.classList.contains('on'))), 'back closes Your TVs');
  await p.evaluate(() => window.__tv.openSettings()); await sleep(300); await back(p); ok(!(await p.$eval('#sheet', (e) => e.classList.contains('on'))), 'back closes Settings');
  await p.evaluate(() => window.__tv.expand(2)); await sleep(1200); ok(await p.evaluate(() => window.__tv.state.locked), 'remote expanded');
  await p.evaluate(() => window.__tv.openKeyboard()); await sleep(400); ok(await p.$eval('#sheet', (e) => e.classList.contains('on')), 'keyboard sheet open over the expanded remote');
  await back(p); await sleep(100); ok(!(await p.$eval('#sheet', (e) => e.classList.contains('on'))) && await p.evaluate(() => window.__tv.state.locked), 'back closes the keyboard first and the remote stays expanded');
  eq(await back(p), true, 'back with the remote expanded: handled'); await sleep(100); ok(!(await p.evaluate(() => window.__tv.state.locked)), 'next back returns from the expanded remote to the reel');
  eq(await back(p), false, 'on the main reel with nothing open: nothing to close (stays in the app)'); ok(await p.evaluate(() => !document.getElementById('pscreen').classList.contains('on')), 'and nothing opened'); await p.close();
  // layers: pairing screen > code modal
  EXTRA = [];
  p = await openPair('googletv-192.168.4.28'); await p.evaluate(() => { const f = document.querySelector('#ad-full'); f && f.remove(); });
  ok(await p.$eval('#pscreen', (e) => !e.hidden), 'pairing screen open');
  await p.evaluate(() => document.querySelector('.ps-dev').click()); await sleep(900); ok(!!(await p.$('#pscode')), 'code modal open over it');
  eq(await back(p), true, 'back with the code modal open: handled'); await sleep(150); ok(!(await p.$('#pscode')) && await p.$eval('#pscreen', (e) => !e.hidden), 'back closes only the code modal; the pairing screen stays');
  await back(p); await sleep(300); ok(await p.$eval('#pscreen', (e) => e.hidden), 'next back closes the pairing screen'); eq(await back(p), false, 'then nothing else is open'); await p.close();
  // pairing screen look: no photo/header image, dark app background, no gap
  p = await openPair('googletv-192.168.4.28'); await p.evaluate(() => { const f = document.querySelector('#ad-full'); f && f.remove(); });
  ok(!(await p.$('.ps-photo')), 'pairing screen: the TV photo header is gone'); const bg = await p.$eval('#pscreen', (e) => { const s = getComputedStyle(e); return [s.backgroundColor, s.backgroundImage]; });
  eq(bg[1], 'none', 'pairing screen: no background image'); eq(bg[0], await p.$eval('body', (e) => getComputedStyle(e).backgroundColor), 'pairing screen: same plain dark background as the app');
  const xb = await (await p.$('.ps-x')).boundingBox(), cb = await (await p.$('.ps-cap')).boundingBox(), rb = await (await p.$('.ps-dev')).boundingBox();
  ok(xb.x < 20 && xb.y < 30, 'the X close is still top-left'); ok(cb.y > xb.y && cb.y < 140, 'the caption sits right under the top'); ok(rb.y - (cb.y + cb.height) < 40, 'the device rows follow the caption with no empty gap');
  ok(/Please select the device to connect/.test(await p.$eval('#pscreen', (e) => e.innerText)), 'caption text is kept'); await p.screenshot({ path: path.resolve(WEB, '../android/dist/test13-pair-screen.png') }); await p.close();
}
await browser.close(); srv.close();
const s = summary(); console.log(`\n${s.pass} passed, ${s.fail} failed`); if (s.fail) { console.log(s.fails.join('\n')); process.exit(1); } process.exit(0);
