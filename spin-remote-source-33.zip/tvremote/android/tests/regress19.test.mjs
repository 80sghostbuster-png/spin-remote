// Build 19: Fire TV smoothness (cmd input + batching + no repeat backlog), keyboard, volume/menu, voice-search typed fallback — all on the ADB mock.
import { makeTransport as makeNodeTransport, stopJvm } from './transports.mjs';
import { makeStore, createBackend } from '../../web/native/backend.js';
import { startAdbMock } from '../mocks/adb-mock.mjs';
import { startAndroidTvMock } from '../mocks/androidtv-mock.mjs';
import { ok, eq, rejects, section, summary } from './lib.mjs';
import { sleep } from '../../web/native/bytes.js';

const stub = () => async (p) => ({ stub: p, demo: true });
let port = 15600;
async function setup(opts = {}) {
  const p = port++; const m = await startAdbMock({ port: p, autoAllow: true, ...opts });
  const b = createBackend({ makeSim: stub, store: makeStore(null), transport: makeNodeTransport(), ports: { firetv: { adb: p } } });
  const call = (path, method = 'GET', body) => b.handler(path, { method, body: body ? JSON.stringify(body) : undefined });
  const d = await call('/api/devices', 'POST', { platform: 'firetv', host: '127.0.0.1' });
  await call('/api/pair/start', 'POST', { device: d.id }); await call('/api/pair/finish', 'POST', { device: d.id });
  await call('/api/warm', 'POST', { device: d.id });
  const send = (x) => call('/api/send', 'POST', { device: d.id, ...x });
  return { m, b, d, call, send, close: () => { b.closeAll(); m.close(); } };
}
const keysOf = (m) => m.st.keys.map((k) => k.k);

section('Key path: "cmd input" used when the Fire TV supports it, plain "input" otherwise');
for (const cmdInput of [true, false]) {
  const t = await setup({ cmdInput });
  const r = await t.send({ action: 'key', key: 'up' }); ok(r.ok, `${cmdInput ? 'new' : 'old'} Fire OS: key sent`);
  eq(t.m.st.cmds.at(-1), cmdInput ? 'shell:cmd input keyevent KEYCODE_DPAD_UP' : 'shell:input keyevent KEYCODE_DPAD_UP', `  → ${cmdInput ? 'cmd input' : 'input'} keyevent`);
  t.close();
}

section('Batching: presses that arrive while the TV is busy go out together, in order, as one line');
{
  const t = await setup({ inputMs: 150 });
  const seq = ['up', 'up', 'right', 'down', 'select', 'left', 'back', 'home'];
  const rs = await Promise.all(seq.map((k) => t.send({ action: 'key', key: k })));
  ok(rs.every((r) => r.ok), 'all 8 presses ok');
  eq(keysOf(t.m), seq.map((k) => 'KEYCODE_' + { up: 'DPAD_UP', right: 'DPAD_RIGHT', down: 'DPAD_DOWN', select: 'DPAD_CENTER', left: 'DPAD_LEFT', back: 'BACK', home: 'HOME' }[k]), 'TV got every key in the order pressed');
  ok(t.m.st.lines < 8, `8 presses needed only ${t.m.st.lines} shell lines (batched)`);
  t.close();
}

section('Held button: repeats never pile up behind a slow TV');
{
  const t = await setup({ inputMs: 200 });
  const ps = []; for (let i = 0; i < 20; i++) { ps.push(t.send({ action: 'key', key: 'down', repeat: i > 0 })); await sleep(20); }
  await Promise.all(ps); const n = keysOf(t.m).length;
  ok(n <= 5, `20 repeat ticks in 400 ms on a 200 ms TV → only ${n} keys reached the TV (stale repeats dropped)`);
  const t0 = Date.now(); await t.send({ action: 'key', key: 'select' }); ok(Date.now() - t0 < 600, `a tap after letting go is not stuck behind a backlog (${Date.now() - t0} ms)`);
  t.close();
}

section('Latency on the mock (input = 120 ms process start, cmd input = 15 ms)');
{
  const res = {};
  for (const [name, o] of [['input, one press', { inputMs: 120 }], ['cmd input, one press', { cmdInput: true, cmdMs: 15, inputMs: 120 }]]) {
    const t = await setup(o); const ms = [];
    for (let i = 0; i < 10; i++) { const t0 = performance.now(); await t.send({ action: 'key', key: 'right' }); ms.push(performance.now() - t0); }
    ms.sort((a, b) => a - b); res[name] = ms[5]; t.close();
  }
  for (const [name, o] of [['input, 10 fast presses', { inputMs: 120 }], ['cmd input, 10 fast presses', { cmdInput: true, cmdMs: 15, inputMs: 120 }]]) {
    const t = await setup(o); const t0 = performance.now();
    await Promise.all(Array.from({ length: 10 }, () => t.send({ action: 'key', key: 'right' }))); res[name] = performance.now() - t0; t.close();
  }
  for (const [k, v] of Object.entries(res)) console.log(`  [latency] ${k}: ${v.toFixed(1)} ms`);
  ok(res['cmd input, one press'] < res['input, one press'], 'cmd input is faster per press');
  ok(res['input, 10 fast presses'] < 10 * 120, `10 fast presses on plain input finish in ${res['input, 10 fast presses'].toFixed(0)} ms (< 1200 ms one-by-one)`);
}

section('Keyboard: typing, Backspace and Enter in order; errors are reported');
{
  const t = await setup({ inputMs: 80 });
  const ps = ['H', 'i', ' ', 't'].map((c) => t.send({ action: 'text', mode: 'append', text: c }));
  ps.push(t.send({ action: 'key', key: 'backspace' })); ps.push(t.send({ action: 'text', mode: 'append', text: "'s" })); ps.push(t.send({ action: 'key', key: 'enter' }));
  const rs = await Promise.all(ps); ok(rs.every((r) => r.ok), 'all typing commands ok');
  const typed = t.m.st.cmds.filter((c) => /input (text|keyevent)/.test(c)).join(' | ');
  ok(/'H'.*KEYCODE_DEL.*'\\''s'.*KEYCODE_ENTER/.test(typed) || /H.*i.*%s.*t.*DEL.*s.*ENTER/.test(typed), `order kept: ${typed}`);
  const all = t.m.st.texts.join('');
  ok(/H/.test(all) && /%s/.test(all), 'space sent as %s');
  t.close();
  const t2 = await setup({ failInput: /^input text/ });
  await rejects(t2.send({ action: 'text', mode: 'append', text: 'x' }), 'bad_key', 'rejected typing is reported, not shown as ok'); t2.close();
}

section('Volume, mute, menu: right key codes; fixed-volume Fire TV says so plainly');
{
  const t = await setup();
  for (const [k, n] of [['vol_up', 'VOLUME_UP'], ['vol_down', 'VOLUME_DOWN'], ['mute', 'VOLUME_MUTE'], ['menu', 'MENU']]) { await t.send({ action: 'key', key: k }); eq(t.m.st.cmds.at(-1), `shell:input keyevent KEYCODE_${n}`, `${k} → KEYCODE_${n}`); }
  eq((await t.call('/api/caps', 'POST', { device: t.d.id })).volume, 'yes', 'normal Fire TV: volume offered');
  t.close();
  const t2 = await setup({ fixedVolume: true, settingsRefused: true });
  const c = await t2.call('/api/caps', 'POST', { device: t2.d.id }); eq(c.volume, 'no', 'fixed volume and the Fire TV refuses to turn on HDMI-CEC volume: volume buttons dimmed'); eq(c.mute, false, '  and mute');
  t2.close();
  const t3 = await setup({ failInput: /VOLUME_MUTE/ });
  const r = await t3.send({ action: 'key', key: 'mute' }); ok(r.ok && t3.m.st.cmds.at(-1) === 'shell:input keyevent KEYCODE_MUTE', 'mute rejected → older KEYCODE_MUTE tried'); t3.close();
}

section('Voice search typed fallback on Fire TV');
{
  const t = await setup({ globalSearch: true });
  const r = await t.send({ action: 'search', text: 'star trek' }); ok(r.ok && r.how === 'typed', 'search screen opened via GLOBAL_SEARCH, words typed → how=typed');
  ok(t.m.st.searchOpen === 1 && t.m.st.texts.at(-1) === "'star%strek'", 'TV got the intent and the text');
  t.close();
  const t2 = await setup();
  const r2 = await t2.send({ action: 'search', text: 'star trek' }); ok(r2.ok && keysOf(t2.m).includes('KEYCODE_SEARCH'), 'no global search on this TV → SEARCH key, then typed');
  t2.close();
  const t3 = await setup({ failInput: /^input text/ });
  await rejects(t3.send({ action: 'search', text: 'x' }), 'bad_key', 'typing refused → search reports failure'); t3.close();
}
section('Google TV voice search: search key, else the global search screen, then typed via remote_ime_batch_edit');
for (const [label, box, link, expect] of [['search key opens a box', true, false, 'typed'], ['search key opens the Assistant; global search screen opens a box', false, true, 'typed'], ['no text box at all', false, false, 'fail']]) {
  const atv = await startAndroidTvMock({ pairPort: 16767, remotePort: 16766 }); atv.st.searchBox = box ? undefined : false; atv.st.linkSearch = link;
  const b = createBackend({ makeSim: stub, store: makeStore(null), transport: makeNodeTransport(), ports: { googletv: { pair: 16767, remote: 16766 } } });
  const call = (path, method = 'GET', body) => b.handler(path, { method, body: body ? JSON.stringify(body) : undefined });
  const d = await call('/api/devices', 'POST', { platform: 'googletv', host: '127.0.0.1' }); await call('/api/pair/start', 'POST', { device: d.id }); await call('/api/pair/finish', 'POST', { device: d.id, code: atv.st.code });
  if (expect === 'typed') { const r = await call('/api/send', 'POST', { device: d.id, action: 'search', text: 'the office' }); await sleep(100); ok(r.ok && r.how === 'typed' && atv.st.texts.at(-1) === 'the office', `${label} → typed "the office"`); if (link) ok(atv.st.apps.some((a) => /GLOBAL_SEARCH/.test(a)), '  global search link was sent'); }
  else { await rejects(call('/api/send', 'POST', { device: d.id, action: 'search', text: 'x' }), 'no_text_field', `${label} → honest failure, nothing typed`); ok(atv.st.texts.length === 0, '  nothing typed'); }
  ok(atv.st.keys.some((k) => k.code === 84), '  search key 84 sent');
  b.closeAll(); atv.close();
}
stopJvm && stopJvm();
summary();
