// Build 26: Fire TV 4-digit code step (pairing only) against a mock that behaves like a REAL Fire TV:
// the code API (8080) is closed until woken with POST :8009/apps/FireTVRemote, and only comes up ~2 s later.
// SELF-WRITTEN mocks — not a real Fire TV. Buttons/connecting stay on the build 21 ADB path (tools/fire-parity.mjs).
import { makeTransport, stopJvm } from './transports.mjs';
import { makeStore } from '../../web/native/backend.js';
import { adb } from '../../web/native/firetv.js';
import { lightning } from '../../web/native/firetv-lightning.js';
import { lightning as b25 } from './b25/firetv-lightning.js';
import { ok, eq, rejects, section, summary } from './lib.mjs';

globalThis.__tvTransport = makeTransport();
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const { startAdbMock } = await import('../mocks/adb-mock.mjs');
const { startFireApiMock } = await import('../mocks/firetv-api-mock.mjs');
const fire = await startAdbMock({ port: 19355, autoAllow: true });
let n = 0, pd = 19500;
const dev = (p) => ({ id: 'firetv-t' + (++n), host: '127.0.0.1', platform: 'firetv', name: 'Fire', ports: { adb: 19355, dial: p, lightning: p + 1 } });
const tv = async (o = {}) => { pd += 10; const m = await startFireApiMock({ dialPort: pd, apiPort: pd + 1, ...o }); return [m, dev(pd)]; };
const pair = async (d, st) => { const r = await adb.pairStart(d, st); return r.status === 'confirm' ? adb.pairFinish(d, st) : r; };   // Allow pressed (mock auto-allows)
const timed = async (p) => { const t = Date.now(); const r = await p; return [r, Date.now() - t]; };

section('0. before/after: sleeping Fire TV (API starts ~2 s after the wake)');
{ const [m, d] = await tv(); const ok25 = await b25.pinDisplay(d); ok(!ok25 && !m.st.shown, `build 25 code: TV never showed a code (wakes sent: ${m.st.wakes}, API asked: ${JSON.stringify(m.st.reqs)}) — reproduces Lex's report`); m.close(); }
{ const [m, d] = await tv(); const [shown, ms] = await timed(lightning.pinDisplay(d)); ok(shown && m.st.shown === '4821', `build 26: code shown on the TV after ${ms} ms`); eq(m.st.wakes, 1, 'woken first with POST :8009/apps/FireTVRemote'); m.close(); }

section('1. code shown (full pairing flow), 2. wrong code, 3. correct code');
let [m, d] = await tv(); let st = makeStore();
let [r, ms] = await timed(pair(d, st));
eq([r.status, r.kind, r.length, r.adbPaired], ['code', 'digits', 4, true], `same PIN popup asked (${ms} ms), ADB already connected`);
ok(m.st.shown === '4821', 'the TV shows the 4-digit code');
await rejects(adb.pairFinish(d, st, '0000'), 'bad_code', 'wrong code → asked again');
eq((await adb.pairFinish(d, st, '4821')).status, 'paired', 'correct code → paired');
ok(lightning.token(d, st) === 'Wj9PP8I', 'TV’s token saved');
const before = m.st.reqs.length, k0 = fire.st.keys.length;
for (const k of ['up', 'select', 'back']) await adb.key(d, k, st);
await sleep(300);
ok(fire.st.keys.length >= k0 + 3, `buttons over ADB (build 21 path): ${fire.st.keys.length - k0} key(s)`);
eq(m.st.reqs.length, before, 'buttons sent nothing to Amazon’s API');
section('saved TV: no code again');
eq((await adb.pairStart(d, st)).status, 'paired', 'already paired → no popup'); eq(m.st.reqs.length, before, 'TV not asked again'); m.close();

section('3 wrong codes → connected anyway');
[m, d] = await tv({ awake: true }); st = makeStore(); await pair(d, st);
await rejects(adb.pairFinish(d, st, '1111'), 'bad_code', 'wrong #1'); await rejects(adb.pairFinish(d, st, '2222'), 'bad_code', 'wrong #2');
eq((await adb.pairFinish(d, st, '3333')).status, 'paired', 'wrong #3 → connected anyway'); m.close();

section('answers without Content-Length (read until close)');
[m, d] = await tv({ noLength: true }); st = makeStore(); r = await pair(d, st); eq(r.status, 'code', 'code shown');
eq((await adb.pairFinish(d, st, '4821')).status, 'paired', 'correct code accepted'); ok(lightning.token(d, st) === 'Wj9PP8I', 'token read from a body without length'); m.close();

section('4. timeouts');
[m, d] = await tv({ displayHang: true }); st = makeStore(); [r, ms] = await timed(pair(d, st));
ok(r.status === 'paired', `TV never answers pin/display → connected anyway after ${ms} ms, no popup`); m.close();
[m, d] = await tv({ awake: true, verifyHang: true }); st = makeStore(); r = await pair(d, st); eq(r.status, 'code', 'code shown');
[r, ms] = await timed(adb.pairFinish(d, st, '4821')); ok(r.status === 'paired', `code check hangs → connected anyway (${ms} ms)`); m.close();
[m, d] = await tv({ startMs: 60000 }); st = makeStore(); [r, ms] = await timed(pair(d, st));
ok(r.status === 'paired', `remote service never starts → connected anyway (${ms} ms)`); m.close();
[m, d] = await tv({ awake: true, displayStatus: 500 }); st = makeStore();
eq((await pair(d, st)).status, 'paired', 'TV error on pin/display → connected anyway'); m.close();

section('5. no service at all');
[m, d] = await tv({ noDial: true }); st = makeStore(); [r, ms] = await timed(pair(d, st));
ok(r.status === 'paired', `no code service → connected over ADB (${ms} ms)`);
const k1 = fire.st.keys.length; await adb.key(d, 'down', st); await sleep(200); ok(fire.st.keys.length > k1, 'buttons work'); m.close();

adb.closeAll(); fire.close(); stopJvm();
const s = summary(); console.log(`\n${s.pass} passed, ${s.fail} failed`); process.exit(s.fail ? 1 : 0);
