// build 17 regression: Roku KEYBOARD (Lit_ characters) and VOICE SEARCH (search/browse) go through the same fallback chain as the buttons,
// including a "Limited" Roku whose plain HTTP /keypress and /search/browse answer 403 but whose phone-app channel (ecp-2 WebSocket) works.
import { makeTransport } from './transports.mjs';
import { makeStore, createBackend } from '../../web/native/backend.js';
import { startStrictRoku } from '../mocks/roku-strict-mock.mjs';
import { ok, eq, section, summary } from './lib.mjs';
import { readFileSync } from 'node:fs';
const orig = console.log; console.log = (...a) => { if (typeof a[0] === 'string' && a[0].startsWith('[perf]')) return; orig(...a); };
const stub = () => async (p) => ({ stub: p, demo: true });
const mk = (port) => createBackend({ makeSim: stub, store: makeStore(null), transport: makeTransport(), ports: { roku: { http: port } } });
const call = (b, path, method = 'GET', body) => b.handler(path, { method, body: body ? JSON.stringify(body) : undefined });
const add = (b) => call(b, '/api/devices', 'POST', { platform: 'roku', host: '127.0.0.1' });
const text = (b, d, t) => call(b, '/api/send', 'POST', { device: d.id, action: 'text', mode: 'append', text: t });
const key = (b, d, k) => call(b, '/api/send', 'POST', { device: d.id, action: 'key', key: k });
const search = (b, d, t) => call(b, '/api/send', 'POST', { device: d.id, action: 'search', text: t });
const fails = async (p) => { try { await p; return null; } catch (e) { return e; } };
const TYPED = 'Ab c€!';
const LIT = ['Lit_A', 'Lit_b', 'Lit_%20', 'Lit_c', 'Lit_%E2%82%AC', 'Lit_!'];
console.log(`transport: ${process.env.TRANSPORT || 'node'}`);

section('Keyboard: Roku with "Control by mobile apps" enabled — each character is POST /keypress/Lit_<encoded char>, in order');
{
  const R = await startStrictRoku({ port: 18430 }); const b = mk(18430); const d = await add(b);
  const r = await text(b, d, TYPED); ok(r.ok, 'typing is accepted');
  eq(R.st.keys, ['Lit_A', 'Lit_b', 'Lit_ ', 'Lit_c', 'Lit_€', 'Lit_!'], 'letters, uppercase, space, a euro sign and punctuation arrive in order');
  ok(R.st.raw.some((x) => x.startsWith('POST /keypress/Lit_%20 HTTP/1.1')) && R.st.raw.some((x) => x.startsWith('POST /keypress/Lit_%E2%82%AC HTTP/1.1')), 'space is Lit_%20 and non-ASCII is UTF-8 percent-encoded');
  eq(R.st.bad, [], 'strict Roku refused nothing'); eq(R.st.wsOpen, 0, 'the phone-app channel is not used when plain HTTP works');
  ok((await key(b, d, 'backspace')).ok && (await key(b, d, 'enter')).ok, 'Backspace and Enter work'); eq(R.st.keys.slice(-2), ['Backspace', 'Enter'], 'as Backspace / Enter keys');
  b.closeAll(); await R.close();
}
section('Keyboard: LIMITED Roku (plain /keypress is 403) — the characters go over the phone-app channel instead');
{
  const R = await startStrictRoku({ port: 18431, limited: true }); const b = mk(18431); const d = await add(b);
  const r = await text(b, d, TYPED); ok(r.ok, 'typing is accepted (not "forbidden")');
  eq(R.st.wsKeys, LIT, 'every character reached the Roku over the phone-app channel, in order, encoded like the HTTP form');
  eq(R.st.keys, [], 'no plain HTTP key was accepted'); eq(R.st.wsBad, [], 'no malformed frames');
  ok((await key(b, d, 'backspace')).ok, 'Backspace works on the same channel'); eq(R.st.wsKeys.slice(-1), ['Backspace'], 'as Backspace');
  b.closeAll(); await R.close();
}
section('Keyboard: LIMITED Roku, first press is the keyboard (never a button) — HTTP 403 is discovered on a Lit_ key and falls back');
{
  const R = await startStrictRoku({ port: 18432, limited: true, version: '12.5.5' }); const b = mk(18432); const d = await add(b);
  const r = await text(b, d, 'hi'); ok(r.ok, 'typing works without any earlier button press'); eq(R.st.wsKeys, ['Lit_h', 'Lit_i'], 'h, i over the phone-app channel'); b.closeAll(); await R.close();
}
section('Keyboard: a Roku whose phone-app channel only accepts the plain character (not the percent-encoded form)');
{
  const R = await startStrictRoku({ port: 18433, limited: true, wsRawLit: true }); const b = mk(18433); const d = await add(b);
  const r = await text(b, d, TYPED); ok(r.ok, 'typing still succeeds');
  eq(R.st.wsKeys, ['Lit_A', 'Lit_b', 'Lit_ ', 'Lit_c', 'Lit_€', 'Lit_!'], 'space and the euro sign are retried as the plain character');
  b.closeAll(); await R.close();
}
section('Keyboard: nothing works (Limited, no Lit_ over the phone-app channel) — a clear "forbidden", never a crash or a silent success');
{
  const R = await startStrictRoku({ port: 18434, limited: true, wsNoLit: true }); const b = mk(18434); const d = await add(b);
  const e = await fails(text(b, d, 'hi')); ok(!!e && e.code === 'forbidden', `error code is "forbidden" (got ${e && e.code})`);
  ok(/Control by mobile apps/.test(e.message), 'the technical text names the Roku setting (shown under Details)'); b.closeAll(); await R.close();
}

section('Voice search: Roku OS 12.5+ — the words are the parameter name (…/search/browse?<words>=)');
{
  const R = await startStrictRoku({ port: 18435, version: '12.5.5', searchStyle: 'modern' }); const b = mk(18435); const d = await add(b);
  const r = await search(b, d, 'Teenage Mutant Ninja Turtles'); ok(r.ok, 'search accepted');
  eq(R.st.searches, [{ style: 'modern', q: 'Teenage Mutant Ninja Turtles' }], 'the Roku searched for the real words (not the word "keyword")');
  eq(R.st.searchRaw, ['/search/browse?Teenage%20Mutant%20Ninja%20Turtles='], 'exact request: words percent-encoded, trailing "="');
  eq(R.st.bad, [], 'strict Roku refused nothing'); b.closeAll(); await R.close();
}
section('Voice search: older Roku OS (9.x) — keyword=<words>');
{
  const R = await startStrictRoku({ port: 18436, version: '9.4.0', searchStyle: 'legacy' }); const b = mk(18436); const d = await add(b);
  const r = await search(b, d, 'the office'); ok(r.ok, 'search accepted'); eq(R.st.searches, [{ style: 'legacy', q: 'the office' }], 'old form keyword=the%20office');
  eq(R.st.searchRaw, ['/search/browse?keyword=the%20office'], 'tried once, no wrong form first'); b.closeAll(); await R.close();
}
section('Voice search: version unknown/odd — if the first form is rejected (404) the other one is tried');
{
  const R = await startStrictRoku({ port: 18437, version: '12.5.5', searchStyle: 'legacy' }); const b = mk(18437); const d = await add(b);
  const r = await search(b, d, 'seinfeld'); ok(r.ok, 'search accepted after the fallback'); eq(R.st.searches, [{ style: 'legacy', q: 'seinfeld' }], 'second form delivered'); eq(R.st.searchRaw.length, 2, 'exactly two attempts'); b.closeAll(); await R.close();
}
section('Voice search: LIMITED Roku (search/browse is 403) — Search key, then the words typed over the phone-app channel');
{
  const R = await startStrictRoku({ port: 18438, limited: true }); const b = mk(18438); const d = await add(b);
  const t0 = Date.now(); const r = await search(b, d, 'Up TV'); ok(r.ok, `search reported done (${Date.now() - t0} ms; includes a short wait for the Search screen)`);
  eq(r.how, 'typed', 'reported as typed'); eq(R.st.wsKeys, ['Search', 'Lit_U', 'Lit_p', 'Lit_%20', 'Lit_T', 'Lit_V'], 'Search key, then the characters in order, all over the phone-app channel'); eq(R.st.searches, [], 'no search/browse was accepted');
  b.closeAll(); await R.close();
}
section('Voice search: nothing works (everything 403) — the error says search is blocked, not "that button"');
{
  const R = await startStrictRoku({ port: 18439, limited: true, wsNoLit: true, ws: false }); const b = mk(18439); const d = await add(b);
  const e = await fails(search(b, d, 'friends')); ok(!!e && e.code === 'search_blocked', `code is "search_blocked" (got ${e && e.code})`); ok(!!e && /Control by mobile apps/.test(e.message), 'details name the setting'); b.closeAll(); await R.close();
}
section('Voice search: Roku that answers 404 to every search form — falls back to the Search key + typing, reported as typed (not as results)');
{
  const R = await startStrictRoku({ port: 18441, version: '12.5.5', searchStyle: 'none' }); const b = mk(18441); const d = await add(b);
  const r = await search(b, d, 'x y'); ok(r.ok, 'accepted'); eq(r.how, 'typed', 'the result says it was typed, not "searched"');
  eq(R.st.searchRaw.length, 3, 'all three documented forms were tried first'); eq(R.st.keys, ['Search', 'Lit_x', 'Lit_ ', 'Lit_y'], 'Search key, then x, space, y — each accepted by the Roku over plain HTTP, no Enter');
  eq(R.st.bad, [], 'strict Roku refused nothing'); b.closeAll(); await R.close();
}
section('Voice search: the title= form is tried too (older OS, only title= accepted)');
{
  const R = await startStrictRoku({ port: 18443, version: '9.4.0', searchStyle: 'title' }); const b = mk(18443); const d = await add(b);
  const r = await search(b, d, 'the wire'); ok(r.ok && r.how === 'search', 'accepted as a real search'); eq(R.st.searchRaw, ['/search/browse?keyword=the%20wire', '/search/browse?title=the%20wire'], 'keyword= first, then title=');
  eq(R.st.searches, [{ style: 'title', q: 'the wire' }], 'delivered through title='); eq(R.st.keys, [], 'no typing needed'); b.closeAll(); await R.close();
}
section('Voice search: Roku OS 12.5+ search returns 500 on every form — still falls back to typing');
{
  const R = await startStrictRoku({ port: 18444, version: '14.1.0', searchStyle: 'none' }); const b = mk(18444); const d = await add(b);
  const r = await search(b, d, 'ok'); ok(r.ok && r.how === 'typed', 'typed instead'); eq(R.st.keys, ['Search', 'Lit_o', 'Lit_k'], 'Search then o, k'); b.closeAll(); await R.close();
}
section('Voice search: search refused AND the keys are refused (HTTP 500) — "search_failed", never success');
{
  const R = await startStrictRoku({ port: 18445, version: '12.5.5', searchStyle: 'none', keyStatus: 500 }); const b = mk(18445); const d = await add(b);
  const e = await fails(search(b, d, 'abc')); ok(!!e && e.code === 'search_failed', `code is "search_failed" (got ${e && e.code})`); b.closeAll(); await R.close();
}
section('Voice search: optional Enter after typing is off by default');
{
  const R = await startStrictRoku({ port: 18446, version: '12.5.5', searchStyle: 'none' }); const b = mk(18446); const d = await add(b); await search(b, d, 'hi');
  ok(!R.st.keys.includes('Enter') && !R.st.keys.includes('Select'), 'no Enter / Select was pressed'); b.closeAll(); await R.close();
}
section('Empty speech is refused before anything is sent');
{
  const R = await startStrictRoku({ port: 18442 }); const b = mk(18442); const d = await add(b); const n = R.st.raw.length; const e = await fails(search(b, d, '   ')); ok(!!e && e.code === 'empty', 'empty'); eq(R.st.raw.length, n, 'nothing sent'); b.closeAll(); await R.close();
}
section('Plain-language messages (app.js)');
{
  const src = readFileSync(new URL('../../web/app.js', import.meta.url), 'utf8');
  ok(/c === 'search_blocked'\) return `Your \$\{R\} won’t let this phone start a search/.test(src), 'search_blocked has its own plain message');
  ok(/c === 'search_failed'\) return `Your \$\{R\} couldn’t open search/.test(src), 'search_failed has its own plain message');
  const msgs = [...src.matchAll(/c === 'search_(?:blocked|failed)'\) return `([^`]*)`/g)].map((m) => m[1]); ok(msgs.length === 2 && msgs.every((m) => !/HTTP|\b40\d\b|exception|null|undefined/.test(m)), 'no technical words in them');
}
const s = summary(); console.log(`\n${s.pass} passed, ${s.fail} failed`); if (s.fail) { console.log(s.fails.join('\n')); process.exit(1); } process.exit(0);
