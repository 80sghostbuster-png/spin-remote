// Per-press latency on the self-written mocks. WEB=<dir of web/> selects which build of the app logic is measured (default: current).
// Usage: WEB=/tmp/web_base node latency.bench.mjs  (before)   |   node latency.bench.mjs  (after)
import { makeTransport } from './transports.mjs';
import { startRokuMock } from '../mocks/roku-mock.mjs';
import { startAndroidTvMock } from '../mocks/androidtv-mock.mjs';
import { startAppleTvMock } from '../mocks/appletv-mock.mjs';
import { startAdbMock } from '../mocks/adb-mock.mjs';
const WEB = process.env.WEB || new URL('../../web', import.meta.url).pathname;
const { createBackend, makeStore } = await import(`${WEB}/native/backend.js`);
const INPUT_MS = +(process.env.INPUT_MS || 0), DELAY = +(process.env.DELAY_MS || 8);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const sim = () => async () => ({});
const mk = (ports) => createBackend({ makeSim: sim, store: makeStore(null), transport: makeTransport(), ports });
const call = (b, p, m = 'GET', body) => b.handler(p, { method: m, body: body ? JSON.stringify(body) : undefined });
const med = (a) => { const s = [...a].sort((x, y) => x - y); return s[Math.floor(s.length / 2)]; };
const fmt = (x) => (x == null ? '—' : x.toFixed(0).padStart(4) + ' ms');
const out = {};

async function platform(name) {
  let mock, b, d, keyTimes, ports;
  if (name === 'roku') { mock = await startRokuMock({ port: 18061, kind: 'tv', delayMs: DELAY }); ports = { roku: { http: 18061 } }; keyTimes = () => mock.st.keys.map((k) => k.t); }
  if (name === 'firetv') { mock = await startAdbMock({ port: 15561, autoAllow: true, delayMs: DELAY, inputMs: INPUT_MS }); ports = { firetv: { adb: 15561 } }; keyTimes = () => mock.st.keys.map((k) => k.t); }
  if (name === 'googletv') { mock = await startAndroidTvMock({ pairPort: 16461, remotePort: 16462 }); ports = { googletv: { pair: 16461, remote: 16462 } }; keyTimes = () => mock.st.keys.map((k) => k.t); }
  if (name === 'appletv') { mock = await startAppleTvMock({ port: 17061 }); ports = { appletv: { companion: 17061 } }; keyTimes = () => mock.st.hid.filter((h) => h.state === 1).map((h) => h.t); }
  b = mk(ports); d = await call(b, '/api/devices', 'POST', { platform: name, host: '127.0.0.1', name });
  if (name === 'firetv') { await call(b, '/api/pair/start', 'POST', { device: d.id }); await sleep(400); await call(b, '/api/pair/finish', 'POST', { device: d.id }); }
  if (name === 'googletv') { await call(b, '/api/pair/start', 'POST', { device: d.id }); await call(b, '/api/pair/finish', 'POST', { device: d.id, code: mock.st.code }); }
  if (name === 'appletv') { await call(b, '/api/pair/start', 'POST', { device: d.id }); await call(b, '/api/pair/finish', 'POST', { device: d.id, code: mock.st.pin }); }
  const send = (key, repeat) => call(b, '/api/send', 'POST', { device: d.id, action: 'key', key, repeat });
  const r = {};
  // 1. first press after the app opened (connection closed): includes whatever the app must set up. New build warms the TV when its remote is opened, so a "warm" variant is measured too.
  b.closeAll(); await sleep(100);
  let n0 = keyTimes().length, t0 = performance.now(); await send('vol_up'); r.coldAck = performance.now() - t0; await sleep(60); r.coldArrive = (keyTimes()[n0] ?? NaN) - (Date.now() - (performance.now() - t0));
  if (b.handler && WEB.indexOf('web_base') < 0) { b.closeAll(); await sleep(100); await call(b, '/api/warm', 'POST', { device: d.id }).catch(() => {}); n0 = keyTimes().length; const t1 = performance.now(); await send('vol_up'); r.warmAck = performance.now() - t1; }
  // 2. isolated presses on an open connection
  const acks = [], arr = []; for (let i = 0; i < 15; i++) { const n = keyTimes().length, t = performance.now(), w = Date.now(); const pr = send(i % 2 ? 'up' : 'down'); while (keyTimes().length === n && performance.now() - t < 3000) await sleep(1); arr.push(keyTimes()[n] - w); await pr; acks.push(performance.now() - t); await sleep(40); }
  r.ack = med(acks); r.arrive = med(arr);
  // 3. burst: 10 taps issued at once; time until the last one reaches the TV
  n0 = keyTimes().length; const tb = Date.now(); const tp = performance.now(); await Promise.all(Array.from({ length: 10 }, (_, i) => send('right'))); r.burstAck = performance.now() - tp; await sleep(80);
  const kt = keyTimes().slice(n0); r.burstArrive = kt.length ? Math.max(...kt) - tb : NaN; r.burstN = kt.length;
  // 4. hold-repeat for 2 s at 120 ms (VOL +): how far behind the finger is the TV when the finger lifts, and how many arrived
  n0 = keyTimes().length; const th = Date.now(); const ps = []; let issued = 0;
  let lift = 0; for (let i = 0; i < 17; i++) { issued++; ps.push(send('vol_up', i > 0)); lift = Date.now(); if (i < 16) await sleep(120); } await Promise.allSettled(ps); await sleep(INPUT_MS * 3 + 150);
  const hk = keyTimes().slice(n0); r.holdIssued = issued; r.holdGot = hk.length; r.holdLag = hk.length ? Math.max(...hk) - lift : NaN; r.holdDrain = keyTimes().length ? Date.now() - lift : NaN;
  b.closeAll(); mock.close && mock.close(); out[name] = r;
}
for (const p of ['roku', 'firetv', 'googletv', 'appletv']) { try { await platform(p); } catch (e) { out[p] = { error: e.message }; } }
const lines = [`build=${WEB.includes('web_base') ? 'BEFORE (test6)' : 'AFTER (test7)'}  one-way mock delay=${DELAY} ms  fire-tv input-JVM=${INPUT_MS} ms`];
for (const [p, r] of Object.entries(out)) lines.push(r.error ? `${p}: ERROR ${r.error}` : `${p.padEnd(8)} first-press-after-idle ${fmt(r.coldAck)}${r.warmAck != null ? `  (after warm ${fmt(r.warmAck)})` : ''} | tap: reaches TV ${fmt(r.arrive)}, UI told ${fmt(r.ack)} | 10-tap burst: last arrives +${fmt(r.burstArrive)} (${r.burstN}/10 delivered) | hold 2 s: ${r.holdGot}/${r.holdIssued} arrived, TV ${fmt(r.holdLag)} behind finger-lift`);
console.log(lines.join('\n')); process.exit(0);
