// Build 29: Fire TV play/pause and volume — only the request forms public sources show the official app sending, each tried in order,
// the working one remembered per TV, "HTTP 200 + error text" counted as NOT accepted, and anything not accepted falling through to ADB.
// SELF-WRITTEN mocks — not a real Fire TV.
import { makeTransport, stopJvm } from './transports.mjs';
import { makeStore } from '../../web/native/backend.js';
import { fire } from '../../web/native/firetv-official.js';
import { adb } from '../../web/native/firetv.js';
import { accepted } from '../../web/native/firetv-lightning.js';
import { REMOTES } from '../../web/remotes.js';
import { ok, eq, section, summary } from './lib.mjs';

globalThis.__tvTransport = makeTransport();
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const { startAdbMock } = await import('../mocks/adb-mock.mjs');
const { startFireApiMock } = await import('../mocks/firetv-api-mock.mjs');
const adbTv = await startAdbMock({ port: 19385, autoAllow: true });
let n = 0, pd = 19800; const NOADB = 19397;
const tv = async (o = {}, adbPort = NOADB) => { pd += 10; const m = await startFireApiMock({ dialPort: pd, apiPort: pd + 1, awake: true, ...o });
  const d = { id: 'firetv-p' + (++n), host: '127.0.0.1', platform: 'firetv', name: 'Fire', ports: { adb: adbPort, dial: pd, lightning: pd + 1, dialdd: pd + 2 } };
  const st = makeStore(); const r = await fire.pairStart(d, st); if (r.status === 'code') await fire.pairFinish(d, st, '4821'); return [m, d, st]; };
const adbKeys = (k0) => adbTv.st.keys.slice(k0).map((x) => x.k).join(' ');

section('0. every Fire TV remote button is wired to the Fire TV key path');
{ const h = typeof REMOTES.firetv.html === 'function' ? REMOTES.firetv.html() : String(REMOTES.firetv.html || REMOTES.firetv.markup || JSON.stringify(REMOTES.firetv));
  for (const k of ['play_pause', 'rew', 'ff', 'vol_up', 'vol_down', 'mute']) ok(new RegExp(`data-key=["']?${k}\\b`).test(h), `Fire TV remote has a ${k} button`); }

section('1. accepted(): 2xx + error text is NOT accepted');
ok(accepted({ status: 200, body: '{"description":"OK"}' }), '200 OK accepted'); ok(!accepted({ status: 200, body: '{"description":"Error: no media session"}' }), '200 + error not accepted');
ok(!accepted({ status: 500, body: '' }), '500 not accepted'); ok(accepted({ status: 204, body: '' }), '204 accepted');

section('2. play/pause: body-less /v1/media?action=play (the documented form)');
let [m, d, st] = await tv(); await fire.key(d, 'play_pause', st); await fire.key(d, 'play_pause', st);
eq(m.st.keys, ['play', 'play'], 'two presses, two body-less play requests'); m.close(); fire.closeAll();

section('3/4. build 31: one official request per press; refused → ADB MEDIA_PLAY_PAUSE');
[m, d, st] = await tv({ refuse: ['play', 'pause'] }, 19385); { const r = await adb.pairStart(d, st); if (r.status === 'confirm') await adb.pairFinish(d, st); }
let k0 = adbTv.st.keys.length; await fire.key(d, 'play_pause', st); await sleep(400); ok(adbKeys(k0).includes('MEDIA_PLAY_PAUSE'), 'fell through to ADB MEDIA_PLAY_PAUSE');

section('5. volume refused / 200+error by the official API → ADB VOLUME keys');
m.close(); fire.closeAll(); [m, d, st] = await tv({ refuse: ['volume_up', 'volume_down', 'mute'] }, 19385); { const r = await adb.pairStart(d, st); if (r.status === 'confirm') await adb.pairFinish(d, st); }
k0 = adbTv.st.keys.length; for (const k of ['vol_up', 'vol_down', 'mute']) await fire.key(d, k, st); await sleep(400);
const g = adbKeys(k0); for (const w of ['VOLUME_UP', 'VOLUME_DOWN', 'VOLUME_MUTE']) ok(g.includes(w), `${w} over ADB`); m.close(); fire.closeAll();

section('6. background ADB connect runs when paired the official way');
[m, d, st] = await tv({}, 19385); adb.closeAll(); const of = adbTv.st.offered.length; await fire.warm(d, st); await sleep(1500); ok(adbTv.st.offered.length > of, 'never-trusted phone: key offered in the background (TV shows Allow)'); const k6 = adbTv.st.keys.length; await adb.key(d, 'vol_up', st); await sleep(400); ok(adbKeys(k6).includes('VOLUME_UP'), 'after Allow, ADB fallback works'); m.close();

fire.closeAll(); adbTv.close(); stopJvm();
const s = summary(); console.log(`\n${s.pass} passed, ${s.fail} failed`); process.exit(s.fail ? 1 : 0);
