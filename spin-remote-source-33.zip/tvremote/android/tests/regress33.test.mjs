// Build 33: Fire TV volume lives in web/native/firetv-volume.js. A bare 200 is not trusted: the TV's reported volume is read before and
// after, the official forms are tried once each, the one that really moved the volume is remembered. SELF-WRITTEN mocks — not a real Fire TV.
import { makeTransport, stopJvm } from './transports.mjs';
import { makeStore } from '../../web/native/backend.js';
import { fire } from '../../web/native/firetv-official.js';
import { getLog } from '../../web/native/dbg.js';
import { readVolumeFields } from '../../web/native/firetv-volume.js';
import { ok, eq, section, summary } from './lib.mjs';
globalThis.__tvTransport = makeTransport();
const { startFireApiMock } = await import('../mocks/firetv-api-mock.mjs');
const { startAdbMock } = await import('../mocks/adb-mock.mjs').catch(() => ({}));
const L = () => String(getLog());
let port = 19980;
async function tv(volume, extra = {}) {
  const dial = port++, api = port++;
  const m = await startFireApiMock({ dialPort: dial, apiPort: api, awake: true, strict: true, volume, ...extra }); m.st.token = 'Wj9PP8I';
  const d = { id: `firetv-r33-${api}`, host: '127.0.0.1', platform: 'firetv', name: 'Fire', ports: { adb: 19999, dial, lightning: api, dialdd: port++ } };
  const st = makeStore(); st.set('ftv.lightning.' + d.id, 'Wj9PP8I'); return { m, d, st };
}
const res = async (p) => { try { return { v: await p }; } catch (e) { return { e }; } };

section('0. reading the TV\'s volume out of its answers');
eq(readVolumeFields({ volumeLevel: 7, isMuted: false }), { level: 7, muted: false }, 'volumeLevel / isMuted');
eq(readVolumeFields({ isVolumeControlsSupported: true, volumeCapabilityLevelOfSupport: 'FULL' }), null, 'capability flags are not a volume level');
eq(readVolumeFields({ turnstileVersion: '1' }), null, 'no volume → null');

section('1. TV obeys the official tap: one request, change seen, remembered');
{ const { m, d, st } = await tv({ level: 10, needs: 'tap' });
  const r = await res(fire.key(d, 'vol_up', st));
  eq(m.st.volReqs, ['volume_up tap'], 'only the tap sent'); eq(m.st.vol.level, 11, 'volume 10 → 11');
  ok(r.v && /tap changed 10 → 11/.test(r.v), 'success text names the checked change'); eq(st.get(`ftv.volume.form.${d.id}`), 'tap', 'tap remembered');
  ok(/before GET \/v1\/FireTV\/status → HTTP\/1\.1 200/.test(L()), 'before-read logged'); ok(/\[tap\] POST \/v1\/FireTV\?action=volume_up \(empty body\) → HTTP\/1\.1 200 OK body: \{"description":"OK"\}/.test(L()), 'press + full TV answer logged');
  const h = m.st.hdrs.find((x) => x.url === '/v1/FireTV?action=volume_up').raw; const names = h.filter((_, i) => i % 2 === 0);
  eq(names, ['x-amzn-request-id', 'x-api-key', 'x-client-token', 'Content-Type', 'Content-Length', 'Host', 'Connection', 'Accept-Encoding', 'User-Agent'], 'OkHttp header order');
  const hv = Object.fromEntries(names.map((n, i) => [n, h[i * 2 + 1]]));
  eq([hv['Content-Length'], hv.Connection, hv['Accept-Encoding'], hv['User-Agent'], hv['Content-Type']], ['0', 'Keep-Alive', 'gzip', 'okhttp/4.12.0', 'application/json; charset=utf-8'], 'OkHttp header values (empty POST → Content-Length: 0)');
  fire.closeAll(); m.close(); }

section('2. TV ignores the tap (200 OK, nothing happens) but obeys the hold form → found silently, then used directly');
{ const { m, d, st } = await tv({ level: 20, needs: 'hold' });
  const r = await res(fire.key(d, 'vol_down', st));
  eq(m.st.volReqs, ['volume_down tap', 'volume_down hold', 'volume_down up'], 'tap, then keyDown + keyUp'); eq(m.st.vol.level, 19, 'volume 20 → 19');
  ok(r.v && /hold changed/.test(r.v), 'success only after the change'); ok(/\[tap\] TV said OK but its volume did not change/.test(L()), 'the ignored tap is logged as such');
  m.st.volReqs.length = 0; await fire.key(d, 'vol_up', st);
  eq(m.st.volReqs, ['volume_up hold', 'volume_up up'], 'next press uses the remembered form only'); eq(m.st.vol.level, 20, 'volume 19 → 20');
  fire.closeAll(); m.close(); }

section('3. only keyDownUp works');
{ const { m, d, st } = await tv({ level: 5, needs: 'downup', where: 'properties' });
  await fire.key(d, 'vol_up', st); eq(m.st.vol.level, 6, 'changed via keyDownUp (volume read from /properties)'); eq(st.get(`ftv.volume.form.${d.id}`), 'downup', 'remembered');
  fire.closeAll(); m.close(); }

section('4. mute: the TV\'s mute flag is the check');
{ const { m, d, st } = await tv({ level: 5, needs: 'tap' });
  const r = await res(fire.key(d, 'mute', st)); eq(m.st.vol.muted, true, 'muted'); ok(r.v && /muted false → muted true/.test(r.v), 'mute change checked'); fire.closeAll(); m.close(); }

section('5. nothing moves the volume → no success shown (falls to the build 21 path, which has no ADB here → error)');
{ const { m, d, st } = await tv({ level: 30, needs: 'none' });
  const r = await res(fire.key(d, 'vol_up', st));
  eq(m.st.volReqs, ['volume_up tap', 'volume_up hold', 'volume_up up', 'volume_up downup'], 'each form tried once for this press'); ok(!!r.e, 'press reported as failed, not as success');
  ok(/accepted the volume press but its volume did not change/.test(L()), 'plain reason logged'); ok(!st.get(`ftv.volume.form.${d.id}`), 'nothing remembered');
  fire.closeAll(); m.close(); }

section('6. TV does not report volume → the official tap, once, and success (can\'t be checked)');
{ const { m, d, st } = await tv({ level: 10, needs: 'tap', report: false });
  const r = await res(fire.key(d, 'vol_up', st)); eq(m.st.volReqs, ['volume_up tap'], 'one official tap'); ok(r.v && /does not report its volume/.test(r.v), 'says it could not be checked');
  fire.closeAll(); m.close(); }

section('7. gzip answers are unpacked');
{ const { m, d, st } = await tv({ level: 40, needs: 'tap' }, { gzip: true });
  const r = await res(fire.key(d, 'vol_down', st)); eq(m.st.vol.level, 39, 'changed'); ok(r.v && /tap changed 40 → 39/.test(r.v), 'volume read from a gzip answer');
  fire.closeAll(); m.close(); }

stopJvm();
const s = summary(); console.log(`\n${s.pass} passed, ${s.fail} failed`); process.exit(s.fail ? 1 : 0);
