
## test12 — pairing needs the TV's code; SVG check
- Code platforms (Google TV 6-char, Apple TV 4-digit): the modal says “Enter the code shown on your TV”; OK stays disabled until the full code is typed; there is no Skip (the `optional`/skip paths were removed); wrong code → “didn’t match” and the modal stays; right code → “Paired” with a check badge, then the screen closes. The demo sim no longer accepts a missing code.
- Fire TV: “Look at your TV and choose Allow”. Roku needs no pairing.
- ✓/✗ glyphs replaced by an inline SVG circle badge (PAIRED button, result pill, Copied, pair-done). Covered by ui-live (54 checks); mocks are self-written.

## test13 — back button; plain pairing screen
- @capacitor/app backButton listener (web/native/back.js) → handleBack() in app.js: ad placeholder → modal (code/Allow/error/IP: its Cancel) → pairing screen → sheets (Your TVs/Settings/Details/What happened/keyboard) → expanded remote → reel. On the main reel it does nothing (never exits/minimizes). android:enableOnBackInvokedCallback=true. Tests: ui-live (82) + back-bundle (real native-bridge.js with an emulated androidBridge).
- Pairing screen: TV photo header removed; plain app-dark background; caption/rows reflow.

## test14 additions (latency, volume capability, voice search)
- `perf-voice.test.mjs` — rapid D-pad / repeated volume / held-button behaviour, keep-alive reuse on Roku, ordering, TV switching, capability detection, reconnect after the phone's Wi-Fi drops, transmit-latency numbers (printed), voice-search submission per platform (Roku `/search/browse`, Google TV search key + text field, Fire TV `KEYCODE_SEARCH` + escaped `input text`, Apple TV text field), and refusal of cross-platform commands.
- `voice-ui.test.mjs` — the real web app with a scripted (mock) speech recognizer: overlay states, interim/final text, permission denied / recognizer unavailable / nothing heard, microphone released on Cancel / Back / backgrounded, no "sent" message unless the send succeeded, dimmed volume/mute on TVs that lack them.
- `voice-engine.test.mjs` — `web/voice.js` against a scripted Capacitor plugin (the contract with `TvNativePlugin.java`'s `voiceStart/voiceStop/voiceCancel` + `voice` events).
Everything here talks to **self-written mocks** (Roku ECP, Android TV remote v2, ADB, Apple Companion) on localhost. No real TV or phone was used; the real SpeechRecognizer, microphone permission dialog and Wi-Fi low-latency lock can only be verified on a device.

## Build 15 — regression tests
- `mocks/roku-strict-mock.mjs`: a Roku stand-in that rejects a missing Host header, bad request lines, pipelining, chunked requests and POSTs without `Content-Length: 0`; can answer 403 to keypresses (Limited mode) or to everything.
- `tests/regress15.test.mjs` (run with `TRANSPORT=node` and `TRANSPORT=java`): exact request format, 403 handling and wording, capability checks per platform (unknown never blocks a button).
- Roku keep-alive client is opt-in (`ecp.keepAlive`, default false); the shipped path is one request per press.

## Build 16 — Roku in "Limited" mode, Google TV stage log
* `mocks/roku-strict-mock.mjs` now also speaks the Roku phone-app WebSocket channel (`ws:true`) and can answer 403 to everything except volume (`limited`, `volumeOk`).
* `regress15.test.mjs`: Limited Roku → keys delivered over the WebSocket channel in order; Limited Roku without it → plain "forbidden" message; Google TV: every connection stage is in the Details log, a TV that moved address is found again through mDNS, and an unreachable TV's error lists the stages.
* All of this is mocks written by us. None of it proves what a real Roku or a real Google TV does.

## Build 17 — Roku keyboard and voice search
* `mocks/roku-strict-mock.mjs`: also answers `POST /search/browse` (403 when Limited; styles `modern` = `?<words>=`, `legacy` = `keyword=`, `both`, `none`), reports `software-version`, and can refuse `Lit_` keys on the WebSocket channel (`wsNoLit`) or only their percent-encoded form (`wsRawLit`).
* `tests/regress17.test.mjs` (run with `TRANSPORT=node` and `TRANSPORT=java`): characters arrive in order over plain HTTP and, on a Limited Roku, over the phone-app channel; space / uppercase / non-ASCII; search request forms by OS version; the Search key + typing fallback when search is 403; the error codes `forbidden`, `search_blocked`, `search_failed` and their plain-language texts.
* Everything here is a mock written by us. It cannot show what a real Roku accepts for `Lit_` keys on the phone-app channel or for `/search/browse`.

## Build 18 — Roku voice search fallback, fake sample ads
* `regress17.test.mjs` (extended): search tries `keyword=`/`title=`/`?<words>=` in an order that suits the OS; on ANY failure (403, 404, 500, no answer) it presses Search, waits, and types the words with the keyboard's `Lit_` path; no Enter by default; reported as "typed" (`how: 'typed'`), never as results; if the keys are refused too, the error is `search_failed` / `search_blocked`.
* `voice-ui.test.mjs`: a typed fallback shows "Typed into your … search" as a success (not red).
* `ui-live.test.mjs` ad section rewritten for the FAKE sample ads (made-up brands, gradients, "Ad" label; banner with no controls; full-screen panel with "Close ad"; 20 s rotation with no layout shift; no network; config flag still removes both).

## regress19.test.mjs (build 19, Fire TV)
ADB mock options added: `cmdInput`/`cmdMs` (newer Fire OS `cmd input`), `globalSearch`, `fixedVolume`; shell lines are split on `;` outside quotes.
Covers: `cmd input` vs `input` key path, batching of presses that arrive while the TV is busy (order kept), hold-repeat with no backlog,
keyboard text/Backspace/Enter order and refused typing, volume/mute/menu key codes, fixed-volume capability, mute fallback (KEYCODE_MUTE),
voice search via GLOBAL_SEARCH or the SEARCH key then typed text. Prints mock latencies.

## regress20.test.mjs (build 20, Fire TV fast key helper)
ADB mock options: `helper` (TV runs the helper), `helperStartMs`, `helperMs`, `noBase64`; mock keeps `st.files` for /data/local/tmp.
Mock and Node test transport now set TCP_NODELAY (the app's NetCore.java already does), which removed a ~88 ms Nagle/delayed-ACK artefact
from earlier mock measurements. Rebuild the helper with `android/firekeys/build.sh`.

## regress21 (build 21)
Google TV: a stale saved address is replaced by a fresh mDNS lookup (every IPv4 address, advertised port); nothing answering gives a staged error plus a TV-side checklist; a TLS refusal on the control port means "not paired" (PAIR shows a new code). Fire TV helper: copied with adb sync as a jar (text copy fallback), 15 s start window, ping handshake, app_process output logged. All on self-written mocks.


## regress23 (build 23, self-written mocks + simulated network)
- Discovery: build 22's discover (frozen copy in `tests/b22/native/`) vs build 23 on the same simulated network; prints time-to-first-TV and whole-scan times (also written to /tmp/discovery23.json). Native timing is a MODEL of the Java code (NSD lock vs direct mDNS), not a phone measurement.

## build 24: Fire TV back on the build 21 path
- `tools/fire-parity.mjs` loads the shipped build 21 bundle (dist/spin-remote-test21-debug.apk) and the current www bundle in headless Chrome against the same ADB mock Fire TV, pairs through the app, presses up/down/OK/Back/Home/Vol+, and compares every ADB packet the app writes (AUTH key/signature and the push mtime normalized), every TCP connection attempt, and the keys/commands the TV received. `SAVED=1` adds an app restart and reconnect to the saved Fire TV.

## Build 25: Fire TV 4-digit code step (`regress25.test.mjs`)
Pairing only: after Allow, the Fire TV is asked to show a 4-digit code, typed into the same PIN popup as the other TVs.
Covers: code shown, correct, wrong (asked again; after 3 wrong it connects anyway), TV never shows a code (connects after ~3.5 s),
code check hangs, TV error, no code service, saved TV not asked again, and buttons never touching Amazon's API.
`tools/fire-parity.mjs` still requires ADB traffic and keys byte-identical to build 21; the code ports (8080/8009) may be used only before buttons.
Self-written mocks only — not a real Fire TV.

## Build 26: Fire TV code step, real wake sequence (`regress26.test.mjs`, replaces regress25)
Mock `mocks/firetv-api-mock.mjs` behaves like a real Fire TV: port 8080 is closed until `POST :8009/apps/FireTVRemote`, then opens ~2 s later;
X-Api-Key required; optional answers without Content-Length. Section 0 shows the frozen build 25 code (`tests/b25/`) never gets a code on it
and build 26 does. Plus: correct / wrong / 3 wrong / no-length / hangs / service never starts / TV error / no service / saved TV / buttons never on the API.

## Build 27 — Fire TV, the official app's way
`regress27.test.mjs` (JS + Java transports): official pairing with ADB off, buttons through the official API on one kept-open connection,
saved TV woken before a press, DIAL Application-URL wake when 8009 is closed, token rejected / service gone → ADB, no service → build 21 ADB
pairing, 3 wrong codes / verify error / service never starts / pin/display error → ADB, answers without Content-Length.
Mock: `mocks/firetv-api-mock.mjs` (self-written; not a real Fire TV). fire-parity still checks the ADB fallback byte-for-byte against build 21.

## Build 28 — Fire TV volume, rewind/fast-forward, typing, voice search
`regress28.test.mjs`: official requests with ADB off; model variants (volume_mute, /keyboard); refused → ADB keycodes; no search app → ADB search; background ADB connect. Mock-only.

## Build 29 — Fire TV play/pause + volume
`regress29.test.mjs`: button wiring, 200+error not accepted, play variants remembered per TV, play/volume refused → ADB keys, background ADB key offer. Mock-only.
