// Voice search + volume capability UI, using the real web/ app, a fake bridge (request interception) and a scripted microphone (window.__voiceMock).
import http from 'node:http'; import fs from 'node:fs'; import path from 'node:path';
import puppeteer from '../../tools/node_modules/puppeteer-core/lib/esm/puppeteer/puppeteer-core.js';
import { ok, eq, section, summary } from './lib.mjs';
const WEB = path.resolve(new URL('../../web/', import.meta.url).pathname);
const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.svg': 'image/svg+xml', '.png': 'image/png', '.webmanifest': 'application/json' };
const srv = http.createServer((q, r) => { const u = decodeURIComponent(q.url.split('?')[0]); const f = path.join(WEB, u === '/' ? 'index.html' : u); if (!f.startsWith(WEB) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) { r.statusCode = 404; return r.end(); } r.setHeader('content-type', MIME[path.extname(f)] || 'application/octet-stream'); r.end(fs.readFileSync(f)); });
await new Promise((res) => srv.listen(0, '127.0.0.1', res)); const base = `http://127.0.0.1:${srv.address().port}/`;
const DEVS = ['roku', 'firetv', 'googletv', 'appletv'].map((pf, i) => ({ id: `${pf}-192.168.4.${40 + i}`, platform: pf, name: pf + ' tv', host: `192.168.4.${40 + i}`, paired: true }));
const LIVE = DEVS.map((d) => d.id);
let CAPS = {}, SENDS = [], SENDFAIL = null, SENDHOW = null;
const browser = await puppeteer.launch({ executablePath: '/usr/bin/google-chrome', headless: 'new', args: ['--no-sandbox'] });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function open({ mic = true } = {}) {
  const p = await browser.newPage(); await p.setCacheEnabled(false); await (await p.createCDPSession()).send('Network.setBypassServiceWorker', { bypass: true }); await p.setViewport({ width: 390, height: 844, isMobile: true, hasTouch: true });
  if (!mic) await p.evaluateOnNewDocument(() => { window.SpeechRecognition = undefined; window.webkitSpeechRecognition = undefined; });
  if (mic) await p.evaluateOnNewDocument(() => { window.__mic = { open: false, starts: 0, stops: 0, cancels: 0, cb: null }; window.__voiceMock = { async start(cb) { window.__mic.open = true; window.__mic.starts++; window.__mic.cb = cb; cb({ state: 'listening' }); }, stop() { window.__mic.stops++; }, cancel() { window.__mic.open = false; window.__mic.cancels++; } }; });
  await p.setRequestInterception(true);
  p.on('request', (rq) => {
    const u = new URL(rq.url()); if (!u.pathname.startsWith('/api/')) return rq.continue();
    const j = (o, status = 200) => rq.respond({ status, contentType: 'application/json', body: JSON.stringify(o) }); const body = () => JSON.parse(rq.postData() || '{}');
    if (u.pathname === '/api/info') return j({ platforms: ['roku', 'firetv', 'googletv', 'appletv'], native: true, demo: false });
    if (u.pathname === '/api/devices') return j({ devices: DEVS, demo: false });
    if (u.pathname === '/api/reachable') return j({ live: LIVE });
    if (u.pathname === '/api/discover') return j({ found: 0, devices: DEVS, seen: LIVE, diag: { mdns: [], sweep: '' } });
    if (u.pathname === '/api/caps') { const id = u.searchParams.get('device') || body().device || ''; return j(CAPS[id.split('-')[0]] || { volume: 'yes', mute: true, search: true }); }
    if (u.pathname === '/api/send') { const b = body(); SENDS.push(b); if (SENDFAIL && b.action === 'search') return j({ error: SENDFAIL.msg, code: SENDFAIL.code }, 502); return j({ ok: true, how: SENDHOW || undefined, wire: b.action === 'search' ? 'search "' + b.text + '"' : b.key }); }
    return j({ ok: true });
  });
  await p.goto(base + '?layout=reel&i=0', { waitUntil: 'networkidle0' }); await sleep(500); return p;
}
const expand = async (p, i) => { await p.evaluate((i) => window.__tv.expand(i), i); await sleep(1300); };
const mic = (p) => p.evaluate(() => window.__mic);
const vis = (p) => p.evaluate(() => ({ open: window.__tv.voiceOpen(), status: document.querySelector('#v-status').textContent, text: document.querySelector('#v-text').textContent, done: !document.querySelector('#v-done').hidden, retry: !document.querySelector('#v-retry').hidden, cls: document.querySelector('#voice').className }));
const emit = (p, ev) => p.evaluate((ev) => window.__mic.cb(ev), ev);
const click = (p, sel) => p.evaluate((s) => document.querySelector(s).click(), sel);
const JARGON = /exception|errno|null|undefined|SpeechRecognizer|permission_denied|ECONN|\bcode\b|status \d|HTTP \d/i;

section('Voice button: overlay shows listening, live words and the final words');
{
  CAPS = {}; SENDS = []; SENDFAIL = null; const p = await open(); await expand(p, 0);
  await click(p, '#btn-voice'); await sleep(200);
  let v = await vis(p); ok(v.open && /Listening/.test(v.status), 'overlay is visible and says it is listening'); ok(v.done, 'a Done button is offered while listening'); eq((await mic(p)).open, true, 'microphone is on');
  await emit(p, { state: 'partial', text: 'the off' }); v = await vis(p); eq(v.text, 'the off', 'interim words show live');
  await emit(p, { state: 'partial', text: 'the office' }); v = await vis(p); eq(v.text, 'the office', 'interim words keep updating');
  await emit(p, { state: 'final', text: 'the office' }); await sleep(300); v = await vis(p);
  ok(/Sent to your/.test(v.status) && v.text.includes('the office'), 'after the TV accepted it, the overlay says it was sent and shows the words');
  const s = SENDS.filter((x) => x.action === 'search'); eq(s.length, 1, 'exactly one search was sent'); eq(s[0].text, 'the office', 'the final words were what was sent'); ok(s[0].device.startsWith('roku'), 'sent to the selected (Roku) TV only');
  ok(!SENDS.some((x) => x.device && !x.device.startsWith('roku')), 'nothing went to any other platform');
  await sleep(2100); eq((await vis(p)).open, false, 'overlay closes by itself after success'); eq((await mic(p)).open, false, 'microphone is off afterwards');
  await p.close();
}
section('Roku search typed through the keyboard path (the fallback): overlay says "Typed into…", never red, never claims results');
{
  SENDS = []; SENDFAIL = null; SENDHOW = 'typed'; const p = await open(); await expand(p, 0);
  await click(p, '#btn-voice'); await sleep(200); await emit(p, { state: 'final', text: 'ninja turtles' }); await sleep(400); const v = await vis(p);
  ok(/Typed into your roku tv’s search|Typed into your Roku’s search/i.test(v.status), `overlay wording: "${v.status}"`); ok(/ok/.test(v.cls) && !/err/.test(v.cls), 'shown as a success, not an error'); ok(!/accept|button|✗|results/i.test(v.status), 'no "didn’t accept that button" and no claim that results appeared');
  ok(/Voice search typed/.test(await p.$eval('#pill-text', (e) => e.textContent)), 'header pill says the search was typed'); SENDHOW = null; await p.close();
}
section('No success message unless the TV really took it');
{
  SENDS = []; SENDFAIL = { msg: 'x', code: 'no_text_field' }; const p = await open(); await expand(p, 2);
  await click(p, '#btn-voice'); await sleep(200); await emit(p, { state: 'final', text: 'jazz' }); await sleep(400); const v = await vis(p);
  ok(!/Sent/.test(v.status) && !/ok/.test(v.cls.replace('on', '')), 'failure is not shown as sent'); ok(/No search box opened/.test(v.status), 'says in plain words that no search box opened'); ok(v.retry, 'offers Try again'); ok(!JARGON.test(v.status), 'no technical wording');
  SENDFAIL = { msg: 'Couldn’t reach the TV.', code: 'unreachable' }; await click(p, '#v-retry'); await sleep(300); await emit(p, { state: 'final', text: 'jazz' }); await sleep(400);
  const v2 = await vis(p); ok(!/Sent/.test(v2.status), 'a network failure is not shown as sent either'); ok(!/✓/.test(await p.$eval('#pill-text', (e) => e.textContent)), 'the header pill shows no ✓ for the failed search');
  SENDFAIL = null; await p.close();
}
section('Permission denied, recognizer missing, nothing heard');
{
  SENDS = []; const p = await open(); await expand(p, 1);
  for (const [code, re, retry] of [['denied', /Microphone access is turned off/, false], ['unavailable', /isn’t available on this phone/, false], ['no_speech', /didn’t hear anything/, true], ['network', /internet connection/, true]]) {
    await click(p, '#btn-voice'); await sleep(200); await emit(p, { state: 'error', code }); await sleep(100); const v = await vis(p);
    ok(re.test(v.status), `${code}: plain explanation shown`); ok(!JARGON.test(v.status), `${code}: no technical wording`); eq(v.retry, retry, `${code}: Try again is ${retry ? '' : 'not '}offered`); ok(!/Sent/.test(v.status), `${code}: no success text`);
    await click(p, '#v-cancel'); await sleep(100); eq((await vis(p)).open, false, `${code}: Close dismisses it`);
  }
  await emit(p, { state: 'x' }).catch(() => {}); eq(SENDS.filter((x) => x.action === 'search').length, 0, 'nothing was sent to a TV in any of those cases');
  await p.close();
}
section('Final result with no words');
{
  const p = await open(); await expand(p, 1); SENDS = []; await click(p, '#btn-voice'); await sleep(200); await emit(p, { state: 'final', text: '  ' }); await sleep(150); const v = await vis(p);
  ok(/didn’t catch that/.test(v.status) && v.retry, 'asks to try again'); eq(SENDS.filter((x) => x.action === 'search').length, 0, 'nothing sent'); await p.close();
}
section('Done, Cancel, Back and going to the background all release the microphone');
{
  const p = await open(); await expand(p, 3);
  await click(p, '#btn-voice'); await sleep(200); await click(p, '#v-done'); await sleep(100); eq((await mic(p)).stops, 1, 'Done asks the recognizer to finish');
  await click(p, '#v-cancel'); await sleep(100); let m = await mic(p); ok(!m.open && !(await vis(p)).open, 'Cancel: microphone off, overlay gone');
  await click(p, '#btn-voice'); await sleep(200); ok((await mic(p)).open, 'listening again'); const handled = await p.evaluate(() => window.__tv.back()); await sleep(100); m = await mic(p);
  eq(handled, true, 'Back (swipe) is handled by the app'); ok(!m.open && !(await vis(p)).open, 'Back closes the listening overlay and turns the microphone off'); ok(await p.evaluate(() => window.__tv.state.locked), 'the remote underneath stays open (back closes one layer at a time)');
  await click(p, '#btn-voice'); await sleep(200); ok((await mic(p)).open, 'listening a third time');
  await p.evaluate(() => { Object.defineProperty(document, 'visibilityState', { configurable: true, get: () => 'hidden' }); document.dispatchEvent(new Event('visibilitychange')); }); await sleep(100); m = await mic(p);
  ok(!m.open && !(await vis(p)).open, 'App sent to the background: microphone off, overlay gone');
  await p.evaluate(() => { delete document.visibilityState; document.dispatchEvent(new Event('visibilitychange')); });
  await click(p, '#btn-voice'); await sleep(200); await emit(p, { state: 'partial', text: 'late words' }); await click(p, '#v-cancel'); await sleep(50); await emit(p, { state: 'final', text: 'late words' }); await sleep(200);
  eq(SENDS.filter((x) => x.action === 'search' && x.text === 'late words').length, 0, 'words that arrive after Cancel are never sent');
  await p.close();
}
section('Voice does nothing without a connected TV / when the TV has no search / no recognizer on the phone');
{
  let p = await open(); await click(p, '#btn-voice'); await sleep(200); eq((await vis(p)).open, false, 'on the reel (no TV opened) the voice button stays quiet'); await p.close();
  CAPS = { roku: { volume: 'yes', mute: true, search: false } }; p = await open(); await expand(p, 0); await click(p, '#btn-voice'); await sleep(300);
  eq((await vis(p)).open, false, 'a TV that reports no search does not open the microphone'); eq((await mic(p)).starts, 0, 'microphone never started'); await p.close(); CAPS = {};
  p = await open({ mic: false }); await expand(p, 0); await click(p, '#btn-voice'); await sleep(300); const v = await vis(p); ok(v.open && /isn’t available on this phone/.test(v.status), 'a phone with no speech recognizer says so plainly'); await p.close();
}
section('Volume / mute buttons follow what the TV can really do (dimmed, quiet explanation, nothing sent)');
{
  CAPS = { roku: { volume: 'no', mute: false, search: true }, appletv: { volume: 'yes', mute: false, search: true } }; SENDS = []; const p = await open();
  await expand(p, 0); await sleep(500);
  const dim = (pf, k) => p.evaluate((pf, k) => document.querySelector(`.remote.${pf} [data-key=${k}]`).classList.contains('nocap'), pf, k);
  ok(await dim('roku', 'vol_up') && await dim('roku', 'vol_down') && await dim('roku', 'mute'), 'Roku stick: volume and mute are dimmed');
  await p.evaluate(() => document.querySelector('.remote.roku [data-key=vol_up]').click()); await sleep(300);
  eq(SENDS.filter((x) => x.key === 'vol_up').length, 0, 'tapping a dimmed Roku volume key sends nothing');
  const toastTxt = await p.evaluate(() => (document.querySelector('#toast') || {}).textContent || ''); ok(/can’t change your TV’s volume/.test(toastTxt) && !JARGON.test(toastTxt), 'quiet in-app text explains it, in plain words');
  await p.evaluate(() => window.__tv.collapse()); await sleep(900); await expand(p, 3); await sleep(500);
  ok(!(await dim('appletv', 'vol_up')) && await dim('appletv', 'mute'), 'Apple TV: volume works, only mute is dimmed');
  await p.evaluate(() => document.querySelector('.remote.appletv [data-key=vol_up]').click()); await sleep(300); eq(SENDS.filter((x) => x.key === 'vol_up').length, 1, 'Apple TV volume key is sent');
  await p.close();
}
await browser.close(); srv.close();
const s = summary(); console.log(`\n${s.pass} passed, ${s.fail} failed`); if (s.fail) { console.log(s.fails.join('\n')); process.exit(1); } process.exit(0);
