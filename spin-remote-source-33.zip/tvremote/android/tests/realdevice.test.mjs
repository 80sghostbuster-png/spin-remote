// Java-only checks for the code paths that matter on a real phone: raw mDNS client (vs an independent zeroconf-encoded responder), explicit connect/TLS error texts, port probe states.
import { spawn } from 'node:child_process';
import net from 'node:net';
import { javaCall, javaRaw, stopJvm } from './transports.mjs';
import { ok, eq, section, summary } from './lib.mjs';
import { execFileSync } from 'node:child_process';
import { randomBytes } from 'node:crypto';
import { adbPubKey } from '../../web/native/firetv.js';
const here = new URL('./', import.meta.url).pathname;
const py = process.env.PYBIN || '/tmp/pyvenv/bin/python';

section('NetCore.mdnsQuery (the no-NSD fallback) against a zeroconf-encoded responder');
{
  const p = spawn(py, [here + 'oracle/mdns_responder.py', '_androidtvremote2._tcp.local.', 'Den TV', 'den-tv.local.', '192.168.4.28', '6466'], { stdio: ['ignore', 'pipe', 'inherit'] });
  const port = await new Promise((res) => p.stdout.once('data', (d) => res(Number(String(d).trim()))));
  const t0 = Date.now(); const r = await javaCall('mdnsQuery', '_androidtvremote2._tcp.', 3000, '127.0.0.1', port);
  eq(r.length, 1, 'one service found');
  eq([r[0].name, r[0].host, r[0].port], ['Den TV', '192.168.4.28', 6466], 'instance name, IPv4 address and port decoded (name with a space survives)');
  eq(r[0].txt, { bt: 'AA:BB', fn: 'Den' }, 'TXT record decoded');
  ok(Date.now() - t0 < 2500, 'returns as soon as the answer is complete');
  const none = await javaCall('mdnsQuery', '_nothing._tcp.', 700, '127.0.0.1', 9);   // nothing listening: must come back empty, not hang or throw
  eq(none.length, 0, 'no answer → empty list');
  p.kill();
}

section('NetCore connect / TLS errors are explicit, and the port probe tells open / refused apart');
{
  const srv = net.createServer((c) => { c.on('error', () => {}); c.write('not tls at all\r\n'); }); await new Promise((r) => srv.listen(0, '127.0.0.1', r)); const open = srv.address().port;
  const dead = net.createServer(); await new Promise((r) => dead.listen(0, '127.0.0.1', r)); const closed = dead.address().port; await new Promise((r) => dead.close(r));
  const ex = async (args) => { try { await javaCall('open', ...args); return 'no error'; } catch (e) { return e.message; } };
  const m1 = await ex(['127.0.0.1', closed, false, '', '', 3000]);
  ok(/refused/i.test(m1) && m1.includes(`127.0.0.1:${closed}`), `refused is named with host:port → "${m1}"`);
  const m2 = await ex(['127.0.0.1', open, true, '', '', 3000]);
  ok(/TLS handshake failed/i.test(m2) && m2.includes(`127.0.0.1:${open}`), `TLS failure is named → "${m2}"`);
  const pr = await javaCall('probe', '127.0.0.1', [open, closed].join(','), 2000);
  eq(pr.map((x) => x.state), ['open', 'refused'], 'probe: open port → open, closed port → refused (host answered)');
  srv.close();
}
section('Fire TV ADB auth: public-key blob and RSA token signature vs adb-shell (independent oracle)');
{
  const id = await javaCall('genIdentity', false), token = randomBytes(20);
  const o = JSON.parse(execFileSync(py, [here + 'oracle/adb_oracle.py', id.keyPkcs8, token.toString('base64')], { encoding: 'utf8' }));
  const mine = Buffer.from(adbPubKey(id.modulusHex, id.exponentHex)).toString('latin1');
  eq(mine.split(' ')[0], o.pub, 'adb_pubkey blob (len, n0inv, modulus, R², exponent) is byte-identical to adb-shell');
  eq(mine.endsWith(' spinremote@phone\0'), true, 'blob is followed by "user@host" and a NUL like adb');
  const sig = await javaRaw('rsaSignAdb', Buffer.from(id.keyPkcs8).toString('base64'), token.toString('base64'));
  eq(sig.sig, o.sig, 'AUTH token signature (RSA PKCS#1 v1.5, token treated as a SHA-1 digest) is byte-identical to adb-shell');
}
section('Roku ECP on the wire: what the Java HTTP client really sends for a key press');
{
  const seen = []; const srv = net.createServer((c) => { let b = ''; c.on('data', (d) => { b += d; if (b.includes('\r\n\r\n')) { seen.push(b); c.end('HTTP/1.1 200 OK\r\nContent-Length: 0\r\nConnection: close\r\n\r\n'); } }); c.on('error', () => {}); });
  await new Promise((r) => srv.listen(0, '127.0.0.1', r)); const port = srv.address().port;
  const r = await javaCall('http', 'POST', `http://127.0.0.1:${port}/keypress/Up`, '', 3000);
  eq(r.status, 200, 'HTTP 200 comes back');
  const req = seen[0] || '', lines = req.split('\r\n');
  eq(lines[0], 'POST /keypress/Up HTTP/1.1', 'request line is exactly "POST /keypress/Up HTTP/1.1"');
  ok(/^content-length: 0$/im.test(req), 'Content-Length: 0 (empty body, as ECP expects)');
  ok(/^connection: close$/im.test(req), 'Connection: close (no stale pooled connections to a TV)');
  ok(req.endsWith('\r\n\r\n') && !/\r\n\r\n.+/s.test(req), 'no body bytes');
  console.log('    raw request:', JSON.stringify(req));
  srv.close();
}
const s = summary(); console.log(`\n${s.pass} passed, ${s.fail} failed`); stopJvm(); process.exit(s.fail ? 1 : 0);
