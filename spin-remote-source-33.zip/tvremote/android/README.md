
### test8 (Google TV connection)
Mirrors the `androidtvremote2` reference: the first touch of the TV is the real TLS connect to 6467 (the bare TCP pre-check is gone). If a Wi-Fi-pinned socket times out, one retry goes via Android's default route (marked `[default route]` in Details; pinning is then off for 10 min). The port report covers 6467/6466/8009/8008/5555 with hints. Protocol bytes verified against the `androidtvremote2` oracle; the real-TV timeout cause is unverified.

### test9
Pair screen lists only TVs seen right now: `discover` returns `seen` (mDNS/SSDP/subnet hits plus saved TVs that answer a 1.2 s port check); saved TVs elsewhere stay stored but are hidden. The list is emptied on open and replaced on each scan. The keyboard sheet, its button on every remote and the big KEYBOARD bar button use one fixed colour/style on all four platforms.

### test10
A TV appears in the UI only if it answers on the current network: new `/api/reachable` (1.2 s port check of saved TVs) runs at start, on resume, every 20 s and when the TV sheets open. The header pill shows "Tap PAIR to find your TV" when none is live, rows never show IPs, and saved TVs stay stored silently (auto-connect when they reappear). Ad placeholders (`web/ads.js`, switch `ADS_PLACEHOLDERS_ENABLED` in `web/config.js`): blank top banner (no controls) and a blank full-screen panel once per launch with a "Close ad" button. No SDK, no network.

### test11
Ad placeholders are both solid white (blank top banner with no controls; full-screen first-open panel with a dark-text "Close ad" button top right), behind `ADS_PLACEHOLDERS_ENABLED`. Remote buttons never open pairing or show a toast/pill note when no TV is connected (only PAIR opens pairing; the status pill only explains a failed press). Commands and the result pill are unchanged when a TV is connected.
