// Spin Remote Fire TV key helper (original code, same license as the app).
// Runs ON the Fire TV as the ADB shell user:  CLASSPATH=/data/local/tmp/spinremote-keys-<hash>.jar app_process / com.spinremote.keys.Main
// Started once per connection; then every key press is one line on stdin, injected straight into the input system
// (no new Java program per press, which is what makes `input keyevent` slow).
//   in:  "k <id> <keycode>"   press+release a key        "t <id> <text…>"  type text (to end of line)        "p <id> x" ping (handshake)   "q" quit
//   out: "SPINKEYS READY"  once, then  "A<id> ok"  or  "A<id> err <reason>"  per line.
package com.spinremote.keys;

import android.os.SystemClock;
import android.view.InputDevice;
import android.view.InputEvent;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.reflect.Method;

public final class Main {
  private static Object im; private static Method inject;

  private static void bind() throws Exception {
    Exception last = null;
    for (String cls : new String[] { "android.hardware.input.InputManagerGlobal", "android.hardware.input.InputManager" }) {
      try {
        Class<?> c = Class.forName(cls);
        Object o = c.getDeclaredMethod("getInstance").invoke(null);
        Method m = c.getMethod("injectInputEvent", InputEvent.class, int.class);
        im = o; inject = m; return;
      } catch (Exception e) { last = e; }
    }
    throw last;
  }
  private static boolean send(KeyEvent e) throws Exception { return (Boolean) inject.invoke(im, e, 0); }   // 0 = asynchronous: don't wait for the app to handle it
  private static boolean key(int code) throws Exception {
    long t = SystemClock.uptimeMillis();
    boolean a = send(new KeyEvent(t, t, KeyEvent.ACTION_DOWN, code, 0, 0, KeyCharacterMap.VIRTUAL_KEYBOARD, 0, 0, InputDevice.SOURCE_KEYBOARD));
    boolean b = send(new KeyEvent(t, SystemClock.uptimeMillis(), KeyEvent.ACTION_UP, code, 0, 0, KeyCharacterMap.VIRTUAL_KEYBOARD, 0, 0, InputDevice.SOURCE_KEYBOARD));
    return a && b;
  }
  private static boolean text(String s) throws Exception {
    KeyEvent[] ev = KeyCharacterMap.load(KeyCharacterMap.VIRTUAL_KEYBOARD).getEvents(s.toCharArray());
    if (ev == null) return false;
    boolean ok = true;
    for (KeyEvent e : ev) ok &= send(KeyEvent.changeTimeRepeat(e, SystemClock.uptimeMillis(), 0));
    return ok;
  }
  public static void main(String[] args) throws Exception {
    try { bind(); } catch (Exception e) { System.out.println("SPINKEYS FAIL " + e); System.out.flush(); return; }
    System.out.println("SPINKEYS READY"); System.out.flush();
    BufferedReader in = new BufferedReader(new InputStreamReader(System.in, "UTF-8"));
    for (String l; (l = in.readLine()) != null; ) {
      l = l.trim(); if (l.equals("q")) break;
      String[] p = l.split(" ", 3); if (p.length < 3) continue;
      String r;
      try {
        boolean ok = p[0].equals("p") ? true : p[0].equals("k") ? key(Integer.parseInt(p[2].trim())) : p[0].equals("t") ? text(p[2]) : false;
        r = ok ? "ok" : "err refused";
      } catch (Throwable e) { Throwable c = e.getCause() != null ? e.getCause() : e; r = "err " + c.getClass().getSimpleName() + ": " + c.getMessage(); }
      System.out.println("A" + p[1] + " " + r); System.out.flush();
    }
  }
}
