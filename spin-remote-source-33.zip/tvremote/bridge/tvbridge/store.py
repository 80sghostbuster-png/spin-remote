"""Tiny JSON persistence for saved devices + pairing credentials."""
from __future__ import annotations
import json, os, threading, uuid, ipaddress
from pathlib import Path

from .errors import BadRequest

PLATFORMS = ("roku", "firetv", "googletv", "appletv")


def validate_host(host: str) -> str:
    """Only allow private/loopback/link-local IP literals: the bridge must never be
    usable as a proxy to the public internet."""
    host = (host or "").strip()
    try:
        ip = ipaddress.ip_address(host)
    except ValueError:
        raise BadRequest("Host must be an IP address like 192.168.1.50", code="bad_host")
    if not (ip.is_private or ip.is_loopback or ip.is_link_local):
        raise BadRequest("Only local network addresses are allowed", code="bad_host")
    return str(ip)


class DeviceStore:
    def __init__(self, data_dir: str | os.PathLike):
        self.dir = Path(data_dir)
        self.dir.mkdir(parents=True, exist_ok=True)
        self.path = self.dir / "devices.json"
        self._lock = threading.Lock()
        self.devices: dict[str, dict] = {}
        if self.path.exists():
            try:
                self.devices = json.loads(self.path.read_text())
            except Exception:
                self.devices = {}

    def save(self):
        with self._lock:
            tmp = self.path.with_suffix(".tmp")
            tmp.write_text(json.dumps(self.devices, indent=2))
            os.chmod(tmp, 0o600)  # contains pairing credentials
            tmp.replace(self.path)

    def public(self, d: dict) -> dict:
        return {k: v for k, v in d.items() if k not in ("credentials",)}

    def list(self):
        return [self.public(d) for d in self.devices.values()]

    def get(self, did: str) -> dict | None:
        return self.devices.get(did)

    def find(self, platform: str, host: str):
        for d in self.devices.values():
            if d["platform"] == platform and d["host"] == host:
                return d
        return None

    def upsert(self, platform: str, host: str, name: str | None = None, **extra) -> dict:
        if platform not in PLATFORMS:
            raise BadRequest(f"Unknown platform {platform!r}", code="bad_platform")
        d = self.find(platform, host)
        if d is None:
            d = {"id": uuid.uuid4().hex[:8], "platform": platform, "host": host,
                 "name": name or f"{platform} {host}", "paired": platform == "roku"}
            self.devices[d["id"]] = d
        elif name and (d.get("name_auto") or not d.get("name")):
            d["name"] = name
        d.update({k: v for k, v in extra.items() if v is not None})
        self.save()
        return d

    def remove(self, did: str) -> bool:
        if did in self.devices:
            del self.devices[did]
            self.save()
            return True
        return False
