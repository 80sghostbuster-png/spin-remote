"""aiohttp app: serves the PWA and the JSON API (demo backend for now)."""
from __future__ import annotations
import argparse, json, logging
from pathlib import Path

from aiohttp import web

from . import __version__
from .errors import BridgeError, BadRequest
from .demo import DemoBackend
from .store import validate_host, PLATFORMS

WEB_DIR = Path(__file__).resolve().parents[2] / "web"
log = logging.getLogger("tvbridge")


@web.middleware
async def errors_mw(request, handler):
    try:
        return await handler(request)
    except BridgeError as e:
        return web.json_response(e.to_dict(), status=e.status)
    except web.HTTPException:
        raise
    except json.JSONDecodeError:
        return web.json_response({"ok": False, "error": "Invalid JSON", "code": "bad_json"}, status=400)
    except Exception as e:  # pragma: no cover
        log.exception("unhandled")
        return web.json_response({"ok": False, "error": f"Internal error: {e.__class__.__name__}", "code": "internal"}, status=500)


@web.middleware
async def token_mw(request, handler):
    token = request.app.get("token")
    if token and request.path.startswith("/api/") and request.path != "/api/info":
        if request.headers.get("X-Token") != token and request.query.get("token") != token:
            return web.json_response({"ok": False, "error": "Token required", "code": "unauthorized"}, status=401)
    return await handler(request)


@web.middleware
async def nocache_mw(request, handler):
    resp = await handler(request)
    if not request.path.startswith("/api/") and "Cache-Control" not in resp.headers:
        resp.headers["Cache-Control"] = "no-cache"
    if request.path == "/sw.js":
        resp.headers["Service-Worker-Allowed"] = "/"
    return resp


async def body_json(request) -> dict:
    try:
        data = await request.json()
    except Exception:
        raise BadRequest("Expected a JSON body", code="bad_json")
    if not isinstance(data, dict):
        raise BadRequest("Expected a JSON object", code="bad_json")
    return data


def make_app(*, demo: bool = True, token: str | None = None, backend=None, web_dir: Path = WEB_DIR) -> web.Application:
    app = web.Application(middlewares=[errors_mw, token_mw, nocache_mw])
    app["backend"] = backend or DemoBackend()
    app["demo"] = demo
    app["token"] = token
    routes = web.RouteTableDef()

    @routes.get("/api/info")
    async def info(request):
        return web.json_response({"name": "tv-remote-bridge", "version": __version__, "demo": app["demo"],
                                  "platforms": list(PLATFORMS), "auth": bool(app["token"])})

    @routes.get("/api/devices")
    async def devices(request):
        return web.json_response({"devices": app["backend"].list(), "demo": app["demo"]})

    @routes.post("/api/devices")
    async def add_device(request):
        b = await body_json(request)
        if b.get("platform") not in PLATFORMS:
            raise BadRequest("Unknown platform", code="bad_platform")
        host = validate_host(b.get("host", ""))
        return web.json_response(app["backend"].add(b["platform"], host, b.get("name")))

    @routes.delete("/api/devices/{id}")
    async def del_device(request):
        app["backend"].remove(request.match_info["id"])
        return web.json_response({"ok": True})

    async def discover(request):
        devs = await app["backend"].discover()
        return web.json_response({"found": len(devs), "devices": devs, "demo": app["demo"]})
    routes.get("/api/discover")(discover); routes.post("/api/discover")(discover)
    routes.get("/discover")(discover)

    async def send(request):
        return web.json_response(await app["backend"].send(await body_json(request)))
    routes.post("/api/send")(send); routes.post("/send")(send)

    @routes.post("/api/pair/start")
    async def pair_start(request):
        b = await body_json(request)
        return web.json_response(await app["backend"].pair_start(b.get("device")))

    @routes.post("/api/pair/finish")
    async def pair_finish(request):
        b = await body_json(request)
        return web.json_response(await app["backend"].pair_finish(b.get("device"), b.get("code")))

    @routes.get("/api/demo/log")
    async def demo_log(request):
        if not app["demo"]:
            raise web.HTTPNotFound()
        return web.json_response({"log": list(app["backend"].log)})

    app.add_routes(routes)

    async def index(request):
        return web.FileResponse(web_dir / "index.html")
    app.router.add_get("/", index)
    app.router.add_static("/", web_dir, show_index=False)
    return app


def main(argv=None):
    ap = argparse.ArgumentParser(description="Spin Remote bridge")
    ap.add_argument("--host", default="0.0.0.0")
    ap.add_argument("--port", type=int, default=8765)
    ap.add_argument("--demo", action="store_true", help="simulation mode: fake TVs, nothing is sent to real devices")
    ap.add_argument("--token", default=None, help="optional shared secret required for /api calls (X-Token header)")
    ap.add_argument("--cert"); ap.add_argument("--key")
    a = ap.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    if not a.demo:
        raise SystemExit("Real-TV mode isn't built yet in this concept build. Run with --demo.")
    ssl_ctx = None
    if a.cert and a.key:
        import ssl
        ssl_ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER); ssl_ctx.load_cert_chain(a.cert, a.key)
    print(f"\n  SPIN REMOTE — {'DEMO MODE (simulated TVs)' if a.demo else 'LIVE'}\n  Open http{'s' if ssl_ctx else ''}://<this-machine-ip>:{a.port}/ on your phone\n")
    web.run_app(make_app(demo=a.demo, token=a.token), host=a.host, port=a.port, ssl_context=ssl_ctx, print=None)


if __name__ == "__main__":
    main()
