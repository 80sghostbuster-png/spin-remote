"""Canonical key vocabulary shared by the PWA and every driver.

The PWA only ever sends these names; each driver maps them to the platform's
native key names/codes below.
"""

CANONICAL_KEYS = {
    "up", "down", "left", "right", "select", "back", "home", "menu", "options",
    "replay", "rew", "ff", "play_pause", "play", "pause", "vol_up", "vol_down",
    "mute", "power", "assistant", "siri", "tv", "backspace", "enter", "search",
    "next", "prev",
}

# ---- Roku ECP key names (from developer.roku.com External Control API docs) ----
# Documented: Home Rev Fwd Play Select Left Right Down Up Back InstantReplay Info
# Backspace Search Enter, and (Roku TVs) VolumeDown VolumeMute VolumeUp PowerOff.
ROKU_KEYS = {
    "up": "Up", "down": "Down", "left": "Left", "right": "Right",
    "select": "Select", "back": "Back", "home": "Home",
    "options": "Info",          # the "*" button == Info
    "menu": "Info",
    "replay": "InstantReplay",
    "rew": "Rev", "ff": "Fwd",
    "play_pause": "Play", "play": "Play", "pause": "Play",
    "vol_up": "VolumeUp", "vol_down": "VolumeDown", "mute": "VolumeMute",
    "power": "Power",           # toggle on Roku TVs; driver falls back to PowerOff
    "backspace": "Backspace", "enter": "Enter", "search": "Search",
}
ROKU_DOCUMENTED = {
    "Home", "Rev", "Fwd", "Play", "Select", "Left", "Right", "Down", "Up", "Back",
    "InstantReplay", "Info", "Backspace", "Search", "Enter", "FindRemote",
    "VolumeDown", "VolumeMute", "VolumeUp", "PowerOff", "ChannelUp", "ChannelDown",
    "InputTuner", "InputHDMI1", "InputHDMI2", "InputHDMI3", "InputHDMI4", "InputAV1",
}

# Common Roku channel ids (verify on your box with GET /api/roku/apps?device=<id>)
ROKU_APPS = {
    "netflix": "12", "youtube": "837", "prime": "13", "disney": "291097",
    "hulu": "2285", "roku_channel": "151908", "max": "61322", "tubi": "41468",
}

# ---- Android TV Remote v2 (RemoteKeyCode names in remotemessage.proto) ----
ANDROIDTV_KEYS = {
    "up": "DPAD_UP", "down": "DPAD_DOWN", "left": "DPAD_LEFT", "right": "DPAD_RIGHT",
    "select": "DPAD_CENTER", "back": "BACK", "home": "HOME", "menu": "MENU",
    "options": "MENU", "rew": "MEDIA_REWIND", "ff": "MEDIA_FAST_FORWARD",
    "play_pause": "MEDIA_PLAY_PAUSE", "play": "MEDIA_PLAY", "pause": "MEDIA_PAUSE",
    "next": "MEDIA_NEXT", "prev": "MEDIA_PREVIOUS",
    "vol_up": "VOLUME_UP", "vol_down": "VOLUME_DOWN", "mute": "VOLUME_MUTE",
    "power": "POWER", "assistant": "ASSIST", "tv": "TV", "search": "SEARCH",
    "backspace": "DEL", "enter": "ENTER",
}
ANDROIDTV_APPS = {
    "youtube": "https://www.youtube.com",
    "netflix": "https://www.netflix.com/title",
    "prime": "https://app.primevideo.com",
    "disney": "https://www.disneyplus.com",
}

# ---- Fire TV via `adb shell input keyevent` ----
FIRETV_KEYS = {
    "up": "KEYCODE_DPAD_UP", "down": "KEYCODE_DPAD_DOWN", "left": "KEYCODE_DPAD_LEFT",
    "right": "KEYCODE_DPAD_RIGHT", "select": "KEYCODE_DPAD_CENTER",
    "back": "KEYCODE_BACK", "home": "KEYCODE_HOME", "menu": "KEYCODE_MENU",
    "options": "KEYCODE_MENU", "rew": "KEYCODE_MEDIA_REWIND",
    "ff": "KEYCODE_MEDIA_FAST_FORWARD", "play_pause": "KEYCODE_MEDIA_PLAY_PAUSE",
    "play": "KEYCODE_MEDIA_PLAY", "pause": "KEYCODE_MEDIA_PAUSE",
    "next": "KEYCODE_MEDIA_NEXT", "prev": "KEYCODE_MEDIA_PREVIOUS",
    "vol_up": "KEYCODE_VOLUME_UP", "vol_down": "KEYCODE_VOLUME_DOWN",
    "mute": "KEYCODE_VOLUME_MUTE", "power": "KEYCODE_POWER",
    "search": "KEYCODE_SEARCH", "backspace": "KEYCODE_DEL", "enter": "KEYCODE_ENTER",
}

# ---- Apple TV via pyatv RemoteControl methods ----
APPLETV_KEYS = {
    "up": "up", "down": "down", "left": "left", "right": "right",
    "select": "select", "back": "menu", "menu": "menu", "home": "home", "tv": "home",
    "play_pause": "play_pause", "play": "play", "pause": "pause",
    "rew": "skip_backward", "ff": "skip_forward", "next": "next", "prev": "previous",
    "vol_up": "volume_up", "vol_down": "volume_down",
    "power": "power",  # handled specially (suspend / wakeup)
}
