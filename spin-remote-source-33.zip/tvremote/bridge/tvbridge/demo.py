"""Demo / simulation backend: fake TVs, no network access, clearly labelled.

Speaks the exact same JSON contract as the real bridge, so the PWA can't tell the
difference (except for the DEMO banner)."""
from __future__ import annotations
import asyncio, time
from collections import deque

from .errors import BadRequest, NotFound, NotPaired
from .keys import CANONICAL_KEYS, ROKU_KEYS, ANDROIDTV_KEYS, FIRETV_KEYS, APPLETV_KEYS

DEMO_PAIR_CODES = {"googletv": "A1B2C3", "appletv": "1234"}


def wire_text(platform: str, key: str) -> str:
    """What the real driver would put on the wire for this key (for the demo toast)."""
    if platform == "roku":
        return f"POST :8060/keypress/{ROKU_KEYS.get(key, key)}"
    if platform == "firetv":
        return f"adb shell input keyevent {FIRETV_KEYS.get(key, key)}"
    if platform == "googletv":
        return f"key_command {ANDROIDTV_KEYS.get(key, key)}"
    return f"remote_control.{APPLETV_KEYS.get(key, key)}()"


class DemoBackend:
    demo = True

    def __init__(self):
        self.devices = {
            "d1": dict(id="d1", platform="roku", name="Living Room Roku", host="192.168.1.21", paired=True),
            "d2": dict(id="d2", platform="firetv", name="Bedroom Fire TV", host="192.168.1.34", paired=True),
            "d3": dict(id="d3", platform="googletv", name="Den Google TV", host="192.168.1.47", paired=True),
            "d4": dict(id="d4", platform="appletv", name="Office Apple TV", host="192.168.1.58", paired=True),
        }
        self._discoverable = [
            dict(id="d5", platform="googletv", name="Kitchen Google TV", host="192.168.1.63", paired=False),
            dict(id="d6", platform="appletv", name="Patio Apple TV", host="192.168.1.71", paired=False),
        ]
        self.log: deque = deque(maxlen=200)
        self.state: dict[str, dict] = {}
        self._pair_steps: dict[str, str] = {}

    def list(self):
        return list(self.devices.values())

    async def discover(self):
        await asyncio.sleep(1.2)  # pretend to scan
        for d in self._discoverable:
            self.devices.setdefault(d["id"], dict(d))
        return self.list()

    def add(self, platform, host, name):
        did = f"m{len(self.devices) + 1}"
        self.devices[did] = dict(id=did, platform=platform, host=host, name=name or platform, paired=platform == "roku")
        return self.devices[did]

    def remove(self, did):
        if did not in self.devices:
            raise NotFound("Unknown device")
        del self.devices[did]

    def _dev(self, did):
        d = self.devices.get(did)
        if not d:
            raise NotFound("Unknown device", code="not_found")
        return d

    async def send(self, body: dict) -> dict:
        d = self._dev(body.get("device"))
        if not d["paired"]:
            raise NotPaired("Pair this device first")
        action = body.get("action", "key")
        st = self.state.setdefault(d["id"], dict(volume=30, muted=False, playing=False, text=""))
        if action == "key":
            key = body.get("key")
            if key not in CANONICAL_KEYS:
                raise BadRequest(f"Unknown key {key!r}", code="bad_key")
            if key == "vol_up": st["volume"] = min(100, st["volume"] + 2)
            if key == "vol_down": st["volume"] = max(0, st["volume"] - 2)
            if key == "mute": st["muted"] = not st["muted"]
            if key == "play_pause": st["playing"] = not st["playing"]
            wire = wire_text(d["platform"], key)
        elif action == "text":
            t = str(body.get("text", ""))
            st["text"] = t if body.get("mode") == "set" else st["text"] + t
            wire = f"{d['platform']}: text {t!r}"
        elif action == "launch":
            wire = f"{d['platform']}: launch {body.get('app')}"
        else:
            raise BadRequest("Unknown action", code="bad_action")
        self.log.append(dict(t=time.time(), device=d["id"], platform=d["platform"], action=action, wire=wire,
                             **{k: body[k] for k in ("key", "text", "app") if k in body}))
        return dict(ok=True, demo=True, wire=wire, state=st)

    async def pair_start(self, did):
        d = self._dev(did)
        await asyncio.sleep(0.3)
        if d["platform"] == "firetv":
            return dict(status="confirm", message="On your Fire TV choose “Always allow” and press OK, then tap Continue.")
        if d["platform"] == "roku":
            return dict(status="paired")
        hexc = d["platform"] == "googletv"
        return dict(status="code", kind="hex" if hexc else "pin", length=6 if hexc else 4, step=1, of=1,
                    hint=DEMO_PAIR_CODES[d["platform"]],
                    message="Enter the 6-character code shown on your TV." if hexc else "Enter the 4-digit PIN shown on your Apple TV.")

    async def pair_finish(self, did, code):
        d = self._dev(did)
        want = DEMO_PAIR_CODES.get(d["platform"])
        if want and (code or "").upper() != want:
            raise BadRequest(f"That code didn't match. (Demo code: {want})", code="bad_code")
        d["paired"] = True
        return dict(status="paired")
