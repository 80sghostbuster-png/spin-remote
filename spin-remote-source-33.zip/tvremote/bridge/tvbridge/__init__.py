"""TV Remote bridge: a tiny LAN server that turns HTTP calls from the PWA into
Roku ECP / Android TV Remote v2 / ADB / Apple TV (pyatv) commands."""
__version__ = "0.1.0"
