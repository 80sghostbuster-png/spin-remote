class BridgeError(Exception):
    """Error that maps cleanly to an HTTP response."""
    status = 500
    code = "error"

    def __init__(self, message: str, *, code: str | None = None, status: int | None = None, **extra):
        super().__init__(message)
        if code:
            self.code = code
        if status:
            self.status = status
        self.extra = extra

    def to_dict(self):
        return {"ok": False, "error": str(self), "code": self.code, **self.extra}


class BadRequest(BridgeError):
    status, code = 400, "bad_request"


class NotFound(BridgeError):
    status, code = 404, "not_found"


class NotPaired(BridgeError):
    status, code = 409, "not_paired"


class Unreachable(BridgeError):
    status, code = 502, "unreachable"


class Unsupported(BridgeError):
    status, code = 422, "unsupported"
