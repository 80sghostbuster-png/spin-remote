# Third-party notices

Spin Remote talks to TVs using protocols that were worked out and published by others. No code was copied from proprietary or decompiled apps. The files below were **written for this project** from the published protocol descriptions; where a project's work informed them, it is credited here with its license.

## Roku "ecp-2" phone-app channel (`web/native/rokuws.js`)
The handshake used by Roku's own phone app (WebSocket `/ecp-session`, sub-protocol `ecp-2`, challenge/response authentication) was documented in public by the open-source community (a proof-of-concept posted on Home Assistant core issue #83819, **ECP2** by Memphis Marshall — MIT License, https://github.com/Aurillium/ECP2 — and **roku-audio-receiver** by alin23). **No code was copied from them**: `rokuws.js` was written for this project from that description, and the shared key it uses is a published interoperability value. Roku's developer documentation does not sanction third-party use of this channel, so the app only tries it when the normal request is refused. The message format used (`request`, `request-id`, `param-key`, `status`) matches the MIT-licensed ECP2 project; typed characters use the same `Lit_` key names as Roku's public ECP documentation.

**Note on Roam:** the Roam remote (msdrigg/Roam) is published under the PolyForm Noncommercial license, which is *not* a permissive license. Nothing from Roam was copied or used as a source for this project; in particular its text-box (`set-textedit-text`) messages were deliberately **not** implemented.

### Search (`web/native/roku.js`)
Roku's own documentation says the ECP search command was removed in Roku OS 12.0; the form `/search/browse?<url-encoded words>=` was reported working by users on the Roku developer forum and Home Assistant issue #105827. It is tried first on OS 12.5+, with the older `keyword=` form as the fallback.

The plain `/keypress/<Key>` requests follow Roku's public External Control Protocol documentation (developer.roku.com) and the behaviour of **python-roku** (BSD 3-Clause, Copyright (c) 2023 Jeremy Carbaugh), which was used as the reference for the request format only.

## Google TV / Android TV remote v2 (`web/native/googletv.js`, `pb.js`, `CertGen.java`)
Pairing (port 6467, "polo" protocol) and control (port 6466) were matched against **androidtvremote2** by tronikos (https://github.com/tronikos/androidtvremote2), licensed under the **Apache License, Version 2.0** (http://www.apache.org/licenses/LICENSE-2.0). The message order, the feature flags, the pairing secret and the certificate parameters (RSA 2048, SHA-256, CA:TRUE pathlen 0, SAN) follow that project; the code here is a separate JavaScript/Java implementation, not a copy. The test suite runs the real androidtvremote2 library against a self-written TV mock.

Apache-2.0 notice: this product includes software concepts from androidtvremote2, Copyright tronikos and contributors, licensed under the Apache License 2.0. The full license text is available at the URL above.

## Sample ads (`web/ads.js`)
The fake ads are drawn with CSS gradients and shapes. The brand names ("SampleBrand", "Fakeco Snacks", "Nimbly Demo", "Orbit Dummy Co.") and slogans are invented for this project and are not real companies or trademarks. No third-party ad SDK, image or font is included.

## Fire TV fast key helper (build 20)
`android/firekeys/` (embedded as `web/native/firekeys-dex.js`) is original Spin Remote code, no third-party code included.
The technique — copying a small dex to `/data/local/tmp` and running it once with `app_process` as the ADB shell user, then calling
`InputManager.injectInputEvent` for each key — is the approach popularised by scrcpy (Genymobile, Apache-2.0,
https://github.com/Genymobile/scrcpy). No scrcpy source was copied; credited here as the idea's origin.



## Fire TV pairing code (builds 25–26, port 8009 wake + 8080)
`web/native/firetv-lightning.js` is original code. Its request sequence, ports, headers and timeouts (wake on 8009 first, wait for 8080,
then pin/display and pin/verify with X-Api-Key) follow these projects; no code was copied:
- hms-firetv (src/clients/LightningClient.cpp) — MIT License, Copyright (c) 2026 HMS Homelab — https://github.com/hms-homelab/hms-firetv
- debloat-fire-stick-claude-code (tools/firetv.py) — MIT License, Copyright (c) 2026 Gathin — https://github.com/whyashthakker/debloat-fire-stick-claude-code
- SLC-Josh/FireTVRest (README protocol notes; documentation only) — https://github.com/SLC-Josh/FireTVRest
Used for pairing only; buttons use ADB.

## Fire TV official remote protocol (build 27)
Build 27 talks to the Fire TV the way Amazon's Fire TV phone app does. All code is original; only publicly documented facts were used:
- hms-firetv (MIT, Copyright (c) 2026 HMS Homelab), https://github.com/hms-homelab/hms-firetv: endpoints, wake on 8009, API on 8080, headers, timeouts, DIAL description on 60000.
- debloat-fire-stick-claude-code (MIT, Copyright (c) 2026 Gathin): key presses carry no body; wake-then-retry.
- SLC-Josh/FireTVRest and the Home Assistant forum thread "Rest commands for Fire TV": documentation only.
- uc-intg-firetv (MPL-2.0), https://github.com/mase1981/uc-intg-firetv: facts only (User-Agent okhttp/4.10.0, wake request headers, alternative port 8443 noted). No code copied.

Build 28 adds, from the same sources (facts only, original code): volume_up/volume_down/mute|volume_mute actions, /v1/media?action=scan&direction=back|forward, /v1/FireTV/text and /v1/FireTV/keyboard {"text"}, GET /v1/FireTV/appsV2 and POST /v1/FireTV/app/<package>.

Build 29 (facts only, original code): play/pause = POST /v1/media?action=play with no body (SLC-Josh/FireTVRest README; hms-firetv play()); pause action (hms-firetv); media body form {"keyAction":{"keyActionType":…}} and scan body {"direction","keyAction"} (FireTVRest README; uc-intg-firetv, MPL — facts only). Volume through the Fire TV app works only via HDMI-CEC (Amazon help page "Volume or Power Controls Not Working in Fire TV App", cited as a fact, nothing copied).

## Build 30
docs/FIRETV-PROTOCOL.md lists interoperability facts (endpoints, action names, headers, JSON body fields, ports) read from the
official Fire TV app. All code is our own; no Amazon code, assets or logos are copied or bundled. Tool used for reading: jadx (Apache-2.0)
and hermes-dec — tools only, nothing from them is shipped.
