// Tiny synthesized click sounds + haptics. No audio files needed.
let ctx = null;
export const fx = { sound: true, haptics: true };
try { const s = JSON.parse(localStorage.getItem('fx') || '{}'); Object.assign(fx, s); } catch {}
export function saveFx() { try { localStorage.setItem('fx', JSON.stringify(fx)); } catch {} }

function ac() {
  if (!ctx) { const C = window.AudioContext || window.webkitAudioContext; if (!C) return null; ctx = new C(); }
  if (ctx.state === 'suspended') ctx.resume();
  return ctx;
}
export function unlockAudio() { ac(); }

function blip({ f = 1200, f2 = f, dur = 0.02, type = 'square', gain = 0.05, noise = 0 }) {
  if (!fx.sound) return;
  const a = ac(); if (!a) return;
  const t = a.currentTime;
  const g = a.createGain(); g.gain.setValueAtTime(gain, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  const o = a.createOscillator(); o.type = type; o.frequency.setValueAtTime(f, t);
  o.frequency.exponentialRampToValueAtTime(Math.max(30, f2), t + dur);
  const hp = a.createBiquadFilter(); hp.type = 'highpass'; hp.frequency.value = 120;
  o.connect(hp); hp.connect(g); g.connect(a.destination); o.start(t); o.stop(t + dur + 0.01);
  if (noise) {
    const len = Math.floor(a.sampleRate * dur), buf = a.createBuffer(1, len, a.sampleRate), d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / len);
    const s = a.createBufferSource(); s.buffer = buf; const ng = a.createGain(); ng.gain.value = noise;
    s.connect(ng); ng.connect(a.destination); s.start(t);
  }
}
export function vibrate(p) { if (fx.haptics && navigator.vibrate && (!navigator.userActivation || navigator.userActivation.hasBeenActive)) { try { navigator.vibrate(p); } catch {} } }

export const sfx = {
  tap()   { blip({ f: 1500, f2: 900, dur: 0.025, gain: 0.05, noise: 0.03 }); vibrate(8); },
  tick(v = 0) { blip({ f: 700 + Math.min(v, 12) * 60, f2: 400, dur: 0.012, type: 'triangle', gain: 0.045 }); vibrate(4); },
  thunk() { blip({ f: 190, f2: 70, dur: 0.09, type: 'sine', gain: 0.16 }); vibrate(14); },
  hold()  { blip({ f: 1100, f2: 800, dur: 0.012, gain: 0.03 }); vibrate(5); },
  toggle(){ blip({ f: 520, f2: 880, dur: 0.07, type: 'sine', gain: 0.07 }); vibrate(10); },
  error() { blip({ f: 220, f2: 180, dur: 0.12, type: 'sawtooth', gain: 0.05 }); vibrate([30, 40, 30]); },
  expand(){ blip({ f: 140, f2: 520, dur: 0.16, type: 'sine', gain: 0.09 }); setTimeout(() => blip({ f: 900, f2: 1500, dur: 0.05, type: 'triangle', gain: 0.04 }), 110); vibrate([10, 25, 16]); },
  unlock(){ blip({ f: 600, f2: 200, dur: 0.12, type: 'sine', gain: 0.08 }); vibrate([8, 20, 8]); },
  ok()    { blip({ f: 660, f2: 990, dur: 0.12, type: 'sine', gain: 0.08 }); vibrate([12, 30, 18]); },
};
