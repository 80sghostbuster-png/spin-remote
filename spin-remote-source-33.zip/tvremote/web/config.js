// One switch for the fake sample ads. Set to false (or delete ads.js + this import) to remove them; replace the two mount points in ads.js with a real ad SDK later.
export const ADS_PLACEHOLDERS_ENABLED = true;
export const AD_ROTATE_MS = 20000;                                       // how often the banner moves to its next sample creative
