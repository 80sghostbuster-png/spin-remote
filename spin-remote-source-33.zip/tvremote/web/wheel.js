// Physics for an endless spinning wheel of N items.
// pos is continuous (in items). Drag moves it 1:1, release launches it with the
// measured velocity (momentum), and a damped spring then settles on an item (snap).
export class Wheel {
  constructor(n, { onTick, onSelect, onSettle } = {}) {
    this.n = n; this.pos = 0; this.vel = 0;       // items, items/s
    this.target = 0; this.mode = 'idle';           // idle | drag | spring
    this.k = 70; this.c = 2 * Math.sqrt(70) * 0.78; // spring: slight overshoot = "thunk"
    this.decay = 4.0;                              // fling distance = v / decay
    this.maxV = 16;
    this.onTick = onTick; this.onSelect = onSelect; this.onSettle = onSettle;
    this._lastTick = Math.floor(this.pos * 2);
    this._sel = 0;
    this._samples = [];
  }
  get selected() { return ((Math.round(this.pos) % this.n) + this.n) % this.n; }
  get settled() { return this.mode === 'idle' && Math.abs(this.pos - Math.round(this.pos)) < 0.002; }
  wrap(o) { const n = this.n; return ((o + n / 2) % n + n) % n - n / 2; } // -> [-n/2, n/2)

  dragStart() { this.mode = 'drag'; this.vel = 0; this._samples = []; }
  dragBy(dItems, t) {
    this.pos += dItems;
    this._samples.push([t, this.pos]);
    while (this._samples.length > 2 && t - this._samples[0][0] > 90) this._samples.shift();
  }
  dragEnd(t) {
    let v = 0; const s = this._samples;
    if (s.length > 1 && t - s[s.length - 1][0] < 80) {
      const dt = (s[s.length - 1][0] - s[0][0]) / 1000;
      if (dt > 0.005) v = (s[s.length - 1][1] - s[0][1]) / dt;
    }
    this.fling(v);
  }
  fling(v) {
    v = Math.max(-this.maxV, Math.min(this.maxV, v));
    this.vel = v;
    this.target = Math.round(this.pos + v / this.decay);
    this.mode = 'spring';
  }
  impulse(dv) { this.fling((this.mode === 'spring' ? this.vel : 0) + dv); }
  goTo(i) {                       // shortest way round
    const cur = Math.round(this.pos);
    const d = this.wrap(i - cur);
    this.target = cur + d; this.mode = 'spring';
  }
  step(dt) {
    dt = Math.min(dt, 1 / 30);
    if (this.mode === 'spring') {
      // semi-implicit Euler, 4 substeps for stability
      const h = dt / 4;
      for (let i = 0; i < 4; i++) {
        const a = -this.k * (this.pos - this.target) - this.c * this.vel;
        this.vel += a * h; this.pos += this.vel * h;
      }
      if (Math.abs(this.pos - this.target) < 0.0015 && Math.abs(this.vel) < 0.02) {
        this.pos = this.target; this.vel = 0; this.mode = 'idle';
        this._emit(); this.onSettle && this.onSettle(this.selected);
        return;
      }
    } else if (this.mode === 'drag') {
      // velocity estimate for visuals (blur) while dragging
      const s = this._samples;
      if (s.length > 1) {
        const dts = (s[s.length - 1][0] - s[0][0]) / 1000;
        this.vel = dts > 0.005 ? (s[s.length - 1][1] - s[0][1]) / dts : 0;
      } else this.vel *= 0.8;
    }
    this._emit();
  }
  _emit() {
    const tk = Math.floor(this.pos * 2);
    if (tk !== this._lastTick) { this._lastTick = tk; this.onTick && this.onTick(Math.abs(this.vel)); }
    const sel = this.selected;
    if (sel !== this._sel) { this._sel = sel; this.onSelect && this.onSelect(sel); }
  }
}
