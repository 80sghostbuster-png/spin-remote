import { getLog, dlog } from './native/dbg.js';
// Client for the bridge. If no bridge answers (e.g. opened from a static host) it
// falls back to an in-browser simulation so the UI is still fully explorable.
const J = { 'Content-Type': 'application/json' };
let sim = null, native = null;

async function req(path, opts = {}) {
  if (sim) return sim(path, opts);
  const r = await fetch(path, { ...opts, headers: { ...J, ...(opts.headers || {}) } });
  let body = null; try { body = await r.json(); } catch {}
  if (!r.ok) { const e = new Error((body && body.error) || `HTTP ${r.status}`); e.code = body && body.code; e.status = r.status; throw e; }
  return body;
}

export async function init() {
  if (typeof __NATIVE__ !== 'undefined' && __NATIVE__) {        // Android app build only: talk to the TVs directly from the phone
    const nb = (await import('./native/entry.js')).nativeInit(makeSim);
    if (nb) { native = nb; sim = nb.handler; return nb.info(); }
  }
  try {
    if (location.protocol === 'file:') throw 0; // opened from disk: no bridge possible, go straight to the simulation
    const ctrl = new AbortController(); const t = setTimeout(() => ctrl.abort(), 2500);
    const r = await fetch('/api/info', { signal: ctrl.signal }); clearTimeout(t);
    if (!r.ok) throw 0;
    const info = await r.json(); if (!info || !info.platforms) throw 0;
    return info;
  } catch {
    sim = makeSim();
    return { demo: true, simulated_in_browser: true, version: 'sim', platforms: ['roku', 'firetv', 'googletv', 'appletv'] };
  }
}
export const setDemo = (on) => { if (native) native.setDemo(on); return native ? native.info() : null; };
export const getDevices = () => req('/api/devices');
export const discover = (platform) => req('/api/discover', { method: 'POST', body: JSON.stringify({ platform }) });
export const discoverProgress = () => req('/api/discover/progress');
export const reachable = () => req('/api/reachable', { method: 'POST', body: '{}' });
export const debugLog = () => getLog();
export const log = (m) => dlog(m);
export const addDevice = (platform, host, name) => req('/api/devices', { method: 'POST', body: JSON.stringify({ platform, host, name }) });
export const checkDevice = (id) => req('/api/check', { method: 'POST', body: JSON.stringify({ device: id }) });
export const resetDevice = (id) => req('/api/devices/reset', { method: 'POST', body: JSON.stringify({ device: id }) });
export const removeDevice = (id) => req('/api/devices/' + id, { method: 'DELETE' });
export const send = (payload) => req('/api/send', { method: 'POST', body: JSON.stringify(payload) });
export const caps = (device) => req('/api/caps', { method: 'POST', body: JSON.stringify({ device }) });
export const warm = (device) => req('/api/warm', { method: 'POST', body: JSON.stringify({ device }) });
export const pairStart = (device) => req('/api/pair/start', { method: 'POST', body: JSON.stringify({ device }) });
export const pairFinish = (device, code) => req('/api/pair/finish', { method: 'POST', body: JSON.stringify({ device, code }) });

// ---------------- in-browser simulation (same contract as the demo bridge) ----------------
function makeSim() {
  const devs = [
    { id: 'd1', platform: 'roku', name: 'Living Room Roku', host: '192.168.1.21', paired: true },
    { id: 'd2', platform: 'firetv', name: 'Bedroom Fire TV', host: '192.168.1.34', paired: true },
    { id: 'd3', platform: 'googletv', name: 'Den Google TV', host: '192.168.1.47', paired: true },
    { id: 'd4', platform: 'appletv', name: 'Office Apple TV', host: '192.168.1.58', paired: true },
  ];
  const found = [
    { id: 'd5', platform: 'googletv', name: 'Kitchen Google TV', host: '192.168.1.63', paired: false },
    { id: 'd6', platform: 'appletv', name: 'Patio Apple TV', host: '192.168.1.71', paired: false },
  ];
  const wire = { roku: (k) => `POST :8060/keypress/${k}`, firetv: (k) => `adb shell input keyevent ${k}`, googletv: (k) => `remote_message key=${k}`, appletv: (k) => `pyatv remote_control.${k}()` };
  const wait = (v, ms = 120) => new Promise((r) => setTimeout(() => r(v), ms));
  return async (path, opts) => {
    const body = opts.body ? JSON.parse(opts.body) : {};
    const m = opts.method || 'GET';
    if (path === '/api/devices' && m === 'GET') return wait({ devices: devs.map((d) => ({ ...d })), demo: true });
    if (path === '/api/discover') { await wait(0, 1400); found.forEach((f) => { if (!devs.find((d) => d.id === f.id)) devs.push({ ...f }); }); return { found: found.length, devices: devs.map((d) => ({ ...d })), seen: devs.map((d) => d.id) }; }
    if (path === '/api/devices' && m === 'POST') { const d = { id: 'm' + Math.random().toString(36).slice(2, 6), paired: body.platform === 'roku', name: body.name || body.platform, ...body }; devs.push(d); return d; }
    if (path.startsWith('/api/devices/') && m === 'DELETE') { const i = devs.findIndex((d) => d.id === path.split('/').pop()); if (i >= 0) devs.splice(i, 1); return { ok: true }; }
    if (path === '/api/send') { const d = devs.find((x) => x.id === body.device); if (!d) { const e = new Error('Unknown device'); e.code = 'not_found'; throw e; }
      if (!d.paired) { const e = new Error('Pair this device first'); e.code = 'not_paired'; throw e; }
      const label = body.action === 'text' ? `text “${body.text}”` : body.action === 'launch' ? `launch ${body.app}` : body.key;
      return wait({ ok: true, demo: true, wire: body.action === 'key' ? wire[d.platform](body.key) : `${d.platform}: ${label}` }, 40); }
    if (path === '/api/pair/start') { const d = devs.find((x) => x.id === body.device); const hex = d.platform === 'googletv';
      if (d.platform === 'firetv') return wait({ status: 'confirm', message: 'Choose “Always allow” on the Fire TV, then continue.' });
      return wait({ status: 'code', kind: hex ? 'hex' : 'pin', length: hex ? 6 : 4, hint: hex ? 'A1B2C3' : '1234', message: hex ? 'Enter the 6-character code shown on your TV.' : 'Enter the 4-digit PIN shown on your Apple TV.' }); }
    if (path === '/api/pair/finish') { const d = devs.find((x) => x.id === body.device); const ok = body.code === (d.platform === 'googletv' ? 'A1B2C3' : '1234') ;
      if (!ok) { const e = new Error('That code didn’t match. (Demo code: ' + (d.platform === 'googletv' ? 'A1B2C3' : '1234') + ')'); e.code = 'bad_code'; throw e; }
      d.paired = true; return wait({ status: 'paired' }); }
    throw new Error('sim: ' + path);
  };
}
