import { Wheel } from './wheel.js';
import { REMOTES, ORDER, I } from './remotes.js';
import { fx, saveFx, sfx, unlockAudio, vibrate } from './audio.js';
import * as api from './api.js';
import { initAds } from './ads.js';
import { voiceEngine, VOICE_MSG } from './voice.js';

const $ = (s, r = document) => r.querySelector(s);
const N = ORDER.length;
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const lerp = (a, b, t) => a + (b - a) * t;
const smooth = (a, b, v) => { const t = clamp((v - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };
const params = new URLSearchParams(location.search);

const state = {
  info: null, devices: [], demo: false, live: new Set(),     // live = saved/discovered TVs that answer on the network the phone is on right now (the UI shows nothing else)
 
  layout: params.get('layout') || localStorage.getItem('layout') || 'reel',
  mix: 0, mixTarget: 0,
  chosen: {},                      // platform -> device id
  locked: false, pending: false, exTarget: 0, exP: 0, ex: 0,   // lock/expand: ex 0 = reel/ring, 1 = full-size remote
  onWire: null,
  stageW: 390, stageH: 700,
};
state.mix = state.mixTarget = state.layout === 'ring' ? 1 : 0;
document.body.dataset.layout = state.layout;

initAds();                                   // blank ad placeholders (config.js: ADS_PLACEHOLDERS_ENABLED)
const stage = $('#stage'), cardsEl = $('#cards'), ringEl = $('#ring'), fxCanvas = $('#fx'), ctx = fxCanvas.getContext('2d');
const dock = $('#dock'), toastEl = $('#toast');
const easeIO = (t) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);

/* ---------------- build DOM ---------------- */
const cards = ORDER.map((id, i) => {
  const el = document.createElement('div'); el.className = 'card'; el.dataset.id = id; el.innerHTML = REMOTES[id].html();
  el.style.setProperty('--rc', REMOTES[id].accent); cardsEl.appendChild(el); return el;
});
const orbs = ORDER.map((id, i) => {
  const el = document.createElement('button'); el.className = 'orb'; el.style.setProperty('--c', REMOTES[id].accent);
  el.innerHTML = `<span class="n">${String(i + 1).padStart(2, '0')}</span><span class="l">${REMOTES[id].short}</span>`;
  el.setAttribute('aria-label', REMOTES[id].name + ' remote');
  el.addEventListener('click', () => { if (drag.moved || state.locked) return; unlockAudio(); if (i === wheel.selected && wheel.settled) expand(i); else wheel.goTo(i); });
  ringEl.appendChild(el); return el;
});
const dockItems = ORDER.map((id, i) => {
  const el = document.createElement('button'); el.className = 'dock-item'; el.dataset.i = i;
  el.innerHTML = `<span class="dn">${String(i + 1).padStart(2, '0')}</span><span class="dl">${REMOTES[id].name}</span>`;
  el.addEventListener('click', () => { if (state.locked) return; unlockAudio(); wheel.goTo(i); }); dock.appendChild(el); return el;
});
$('#btn-layout').innerHTML = I.ring; $('#btn-layout').dataset.l = 'ring';
$('#btn-back').innerHTML = I.left + '<span>SPIN</span>';
$('#btn-spin').innerHTML = I.reel + '<span>SPIN</span>';
$('#btn-kbd').innerHTML = I.kbd + '<span>KEYBOARD</span>';
$('#btn-voice').innerHTML = I.mic; $('#v-orb').innerHTML = I.mic;

/* ---------------- wheel + feedback ---------------- */
let lastSel = -1;
const wheel = new Wheel(N, {
  onTick: (v) => sfx.tick(v),
  onSelect: (i) => { setSelected(i); },
  onSettle: () => { sfx.thunk(); try { warmFor(ORDER[wheel.selected]); } catch (e) { /* warm is best-effort */ } },
});
const startIdx = params.has('i') ? +params.get('i') : +(localStorage.getItem('sel') || 0);
wheel.pos = wheel.target = clamp(startIdx, 0, N - 1); wheel._sel = wheel.selected; wheel._lastTick = Math.floor(wheel.pos * 2);

function setSelected(i) {
  if (i === lastSel) return; lastSel = i;
  const id = ORDER[i];
  document.documentElement.style.setProperty('--accent', REMOTES[id].accent);
  dockItems.forEach((d, k) => d.classList.toggle('on', k === i));
  $('#dock-ind').style.transform = `translateX(${i * 100}%)`;
  orbs.forEach((o, k) => o.classList.toggle('sel', k === i));
  clearTimeout(setSelected.t); setSelected.t = setTimeout(() => localStorage.setItem('sel', i), 400);   // a synchronous storage write per spin tick is a hitch
  updatePill();
}

/* ---------------- layout maths ---------------- */
function geom() {
  const W = state.stageW, H = state.stageH;
  const fit = Math.min(1, (W - 8) / 340, (H - 10) / 640);
  const g = { W, H, fit, rs: 0.86, spacing: 320 * fit * 0.62 };
  // full-size scale for each remote when expanded (fills the stage)
  g.exS = cards.map((c) => { const r = c.firstElementChild; const w = (r && r.offsetWidth) || 300, h = (r && r.offsetHeight) || 630; return Math.min(1.3, (W - 14) / w, (H - 8) / h); });
  // ring (tilted ellipse in the upper part of the stage, like the reference)
  g.ringC = { x: 0, y: -H * 0.315 }; g.Rx = Math.min(W * 0.40, 170); g.Ry = Math.max(46, H * 0.125); g.tilt = -15 * Math.PI / 180;
  const hz = H * 0.62 - 6; g.sRing = Math.min(0.78, hz / 640); g.dockY = H / 2 - hz / 2 - 4;
  return g;
}
let G = geom();
function ringPoint(theta) {          // theta=0 -> front (bottom of the ellipse)
  const ex = G.Rx * Math.sin(theta), ey = G.Ry * Math.cos(theta);
  const c = Math.cos(G.tilt), s = Math.sin(G.tilt);
  return { x: G.ringC.x + ex * c - ey * s, y: G.ringC.y + ex * s + ey * c, d: (1 + Math.cos(theta)) / 2 };
}
function reelParams(o) {
  const a = Math.abs(o), sg = Math.sign(o) || 1, m = Math.min(a, 1);
  return { x: sg * (m * G.spacing + Math.max(a - 1, 0) * G.spacing * 0.55), y: 0,
    s: G.fit * G.rs * (1 - 0.2 * m - 0.1 * Math.max(a - 1, 0)), ry: sg * Math.min(a, 1.25) * 50,
    op: clamp(1 - 0.45 * m - Math.max(a - 1, 0) * 0.9, 0, 1), blur: 1.4 * m, dim: 0.35 * m };
}
function ringParams(o) {
  const th = o * 2 * Math.PI / N, d = (1 + Math.cos(th)) / 2, f = smooth(0.62, 1, d), p = ringPoint(th);
  return { x: lerp(p.x, 0, f), y: lerp(p.y, G.dockY, f), s: lerp(0.04, G.sRing, f), ry: 0, op: smooth(0.78, 1, d), blur: 0, dim: 0 };
}

/* ---------------- render loop ---------------- */
let last = performance.now(), fxPhase = 0;
// Performance: nothing is redrawn while the UI is at rest (the old loop rewrote every style and the canvas 60x/s forever).
// "lite" mode switches on by itself if real frames run slow on this phone: lighter effects while things move, same look at rest.
const perf = { dirty: 3, ema: 0, base: 1000, n: 0, lite: false };
const markDirty = () => { perf.dirty = 3; };
function frame(now) {
  const rawDt = (now - last) / 1000, dt = Math.min(0.05, rawDt); last = now;
  wheel.step(dt);
  state.mix += (state.mixTarget - state.mix) * Math.min(1, dt * 9); if (Math.abs(state.mixTarget - state.mix) < 0.002) state.mix = state.mixTarget;
  fxPhase += dt;
  if (state.pending && wheel.settled && Math.abs(state.mix - state.mixTarget) < 0.01) { state.pending = false; beginExpand(); }
  const was = state.exP;
  if (state.exP !== state.exTarget) state.exP = state.exTarget > state.exP ? Math.min(1, state.exP + dt / 0.6) : Math.max(0, state.exP - dt / 0.5);
  state.ex = easeIO(state.exP);
  if (was < 1 && state.exP === 1) { sfx.thunk(); }
  const busy = !wheel.settled || state.mix !== state.mixTarget || state.exP !== state.exTarget || state.mix > 0.001 || state.pending;   // ring layout keeps drifting
  if (busy || perf.dirty > 0) {
    if (busy) {                                                   // judge smoothness only from frames where something moves
      if (rawDt > 0.004 && rawDt < 0.25) { perf.base = Math.min(perf.base, rawDt * 1000); perf.ema = perf.ema ? perf.ema * 0.93 + rawDt * 1000 * 0.07 : rawDt * 1000; perf.n++; }
      if (!perf.lite && perf.n > 40 && perf.ema > 20 && perf.ema > perf.base * 1.45) { perf.lite = true; document.body.classList.add('lite'); }
    }
    if (!busy) perf.dirty--;
    document.body.classList.toggle('moving', busy);
    render();
  }
  requestAnimationFrame(frame);
}
// style writes are cached per element so an unchanged value never invalidates style/layout again
const sc = new WeakMap();
function put(el, k, v) { let m = sc.get(el); if (!m) sc.set(el, m = {}); if (m[k] === v) return; m[k] = v; if (k === 'cls') return; if (k.startsWith('--')) el.style.setProperty(k, v); else el.style[k] = v; }
function render() {
  const v = wheel.vel, mb = Math.min(Math.abs(v) * 0.75, 7), mix = state.mix;
  const live = wheel.settled && Math.abs(mix - state.mixTarget) < 0.01, ex = state.ex;
  const moving = !wheel.settled || Math.abs(mix - state.mixTarget) > 0.001 || (state.exP > 0 && state.exP < 1);
  for (let i = 0; i < N; i++) {
    const o = wheel.wrap(i - wheel.pos);
    const a = reelParams(o), b = mix > 0 ? ringParams(o) : a;
    let p = mix > 0 ? { x: lerp(a.x, b.x, mix), y: lerp(a.y, b.y, mix), s: lerp(a.s, b.s, mix), ry: lerp(a.ry, b.ry, mix), op: lerp(a.op, b.op, mix), blur: lerp(a.blur, b.blur, mix), dim: lerp(a.dim, b.dim, mix) } : a;
    const isSel = i === wheel.selected;
    if (ex > 0) {                       // blend toward the full-size remote / push the others away
      if (isSel) p = { x: lerp(p.x, 0, ex), y: lerp(p.y, 0, ex), s: lerp(p.s, G.exS[i], ex), ry: lerp(p.ry, 0, ex), op: lerp(p.op, 1, ex), blur: lerp(p.blur, 0, ex), dim: lerp(p.dim, 0, ex) };
      else p = { ...p, x: p.x + Math.sign(o || 1) * ex * G.W * 0.75, op: p.op * (1 - ex) * (1 - ex), s: p.s * (1 - 0.25 * ex) };
    }
    const el = cards[i];
    let blur = (p.blur + mb * (1 - mix * 0.8)) * (isSel ? 1 - ex : 1);
    if (perf.lite && !isSel && moving) blur = 0;                                  // lite: side remotes aren't blurred while moving
    blur = Math.round(blur * 4) / 4;                                              // 0.25px steps: far fewer filter re-rasterisations
    put(el, 'willChange', moving ? 'transform, opacity, filter' : 'auto');
    put(el, 'transform', `translate3d(${p.x.toFixed(2)}px,${p.y.toFixed(2)}px,0) rotateY(${p.ry.toFixed(2)}deg) scale(${Math.max(p.s, 0.001).toFixed(4)})`);
    put(el, 'opacity', p.op.toFixed(3));
    put(el, 'filter', blur > 0.15 && p.op >= 0.01 ? `blur(${blur.toFixed(2)}px)` : 'none');
    put(el, '--dim-o', p.dim.toFixed(3));
    put(el, 'zIndex', String(Math.round(100 - Math.abs(o) * 10)));
    put(el, 'visibility', p.op < 0.01 ? 'hidden' : 'visible');
    const active = isSel && state.locked && ex > 0.55;
    if (sc.get(el) === undefined || sc.get(el).cls !== active) { (sc.get(el) || {}).cls = active; el.classList.toggle('inactive', !active); el.setAttribute('aria-hidden', active ? 'false' : 'true'); }
    // orbs (only matter in the ring layout / while it is blending in)
    const orb = orbs[i], th = o * 2 * Math.PI / N, rp = ringPoint(th), oo = mix * (0.5 + 0.5 * rp.d) * (1 - ex);
    if (oo < 0.01 && sc.get(orb) && sc.get(orb).visibility === 'hidden') continue;   // already hidden: nothing to update
    const os = (0.62 + 0.5 * rp.d) * (i === wheel.selected && live ? 1.1 : 1);
    const oblur = Math.round(Math.min(Math.abs(v) * 1.0, 6) * (0.5 + 0.5 * rp.d) * 4) / 4;
    put(orb, 'transform', `translate3d(${rp.x.toFixed(2)}px,${rp.y.toFixed(2)}px,0) scale(${os.toFixed(3)})`);
    put(orb, 'opacity', oo.toFixed(3)); put(orb, 'zIndex', String(Math.round(rp.d * 10) + 1));
    put(orb, 'filter', oblur > 0.15 ? `blur(${oblur.toFixed(2)}px)` : 'none');
    put(orb, 'pointerEvents', mix > 0.6 && !state.locked ? 'auto' : 'none'); put(orb, 'visibility', oo < 0.01 ? 'hidden' : 'visible');
  }
  put(fxCanvas, 'opacity', (1 - 0.9 * ex).toFixed(3));
  if (ex < 0.995) drawFx();
}

/* ---------------- background canvas: speed lines (reel) + glowing dot ring (ring) ---------------- */
const PALETTE = ['#b45cff', '#ff9a1f', '#4d9bff', '#e6ebf5', '#35d07f', '#ff5d8a', '#ffc83d', '#25d0e0'];
function sizeCanvas() {
  const r = stage.getBoundingClientRect(), dpr = Math.min(window.devicePixelRatio || 1, 2);
  state.stageW = r.width; state.stageH = r.height;
  fxCanvas.width = Math.round(r.width * dpr); fxCanvas.height = Math.round(r.height * dpr);
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0); G = geom(); lineGrad.clear(); markDirty();
}
const lineGrad = new Map();                      // the 17 vertical floor lines share one gradient per accent colour (was rebuilt every frame)
const floorGrad = (acc, H) => { const k = acc + H; let g = lineGrad.get(k); if (!g) { g = ctx.createLinearGradient(0, 0, 0, H); g.addColorStop(0, 'transparent'); g.addColorStop(0.5, acc); g.addColorStop(1, 'transparent'); lineGrad.set(k, g); } return g; };
function drawFx() {
  const W = state.stageW, H = state.stageH, cx = W / 2, cy = H / 2, mix = state.mix, v = wheel.vel;
  ctx.clearRect(0, 0, W, H);
  const acc = REMOTES[ORDER[wheel.selected]].accent;
  // reel: perspective floor lines + speed streaks
  if (mix < 0.98) {
    ctx.save(); ctx.globalAlpha = 1 - mix;
    const sp = G.spacing * 0.6, off = ((wheel.pos * sp) % sp + sp) % sp;
    ctx.lineWidth = 1;
    for (let k = -8; k <= 8; k++) {
      const x = cx + k * sp - off;
      ctx.strokeStyle = floorGrad(acc, H); ctx.globalAlpha = (1 - mix) * (0.25 + Math.min(Math.abs(v) * 0.08, 0.5)) * (1 - Math.min(Math.abs(x - cx) / W, 1) * 0.8);
      ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke();
    }
    const sv = Math.min(Math.abs(v), 14);
    if (sv > 0.8) {
      for (let k = 0; k < 14; k++) {
        const seed = (k * 977) % 1, y = ((k * 53.7) % H), len = 40 + sv * 22 + (k % 4) * 20;
        const x = ((k * 131.3 + fxPhase * -Math.sign(v) * 900 * sv / 8) % (W + 200) + (W + 200)) % (W + 200) - 100;
        const g = ctx.createLinearGradient(x, 0, x - Math.sign(v) * len, 0); g.addColorStop(0, acc); g.addColorStop(1, 'transparent');
        ctx.strokeStyle = g; ctx.globalAlpha = (1 - mix) * Math.min(sv / 10, 0.7); ctx.lineWidth = 1 + (k % 3);
        ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x - Math.sign(v) * len, y); ctx.stroke();
      }
    }
    ctx.restore();
  }
  // ring: ellipse + 36 dots with motion-blur trails (like the reference clip)
  if (mix > 0.01) {
    ctx.save(); ctx.translate(cx, cy);
    ctx.globalAlpha = mix;
    ctx.beginPath();
    for (let k = 0; k <= 80; k++) { const p = ringPoint(k / 80 * 2 * Math.PI); k ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y); }
    ctx.globalAlpha = mix * 0.2; ctx.strokeStyle = acc; ctx.lineWidth = 1.2; ctx.stroke();
    const M = 36, base = wheel.pos * 2 * Math.PI / N * -1 + fxPhase * 0.06;
    const dirv = Math.sign(v) || 0, speed = Math.min(Math.abs(v), 14);
    const dots = [];
    for (let k = 0; k < M; k++) {
      const th0 = -base + k / M * 2 * Math.PI;
      const trail = 1 + Math.round(speed * 0.9);
      for (let t = trail; t >= 0; t--) {
        const th = th0 + dirv * -1 * t * 0.045 * (speed * 0.12 + 0.2) * (v > 0 ? 1 : 1);
        const p = ringPoint(th);
        const r = (1.6 + 3.2 * p.d) * (1 + t * 0.08);
        dots.push({ z: p.d - t * 0.001, x: p.x, y: p.y, r, a: (0.25 + 0.65 * p.d) * (t === 0 ? 1 : 0.35 / (1 + t * 0.35)), c: PALETTE[k % PALETTE.length], blur: t === 0 ? 0 : 1 });
      }
    }
    dots.sort((a, b) => a.z - b.z);
    for (const d of dots) {
      ctx.globalAlpha = mix * d.a; ctx.fillStyle = d.c; ctx.shadowColor = d.c; ctx.shadowBlur = perf.lite && d.blur ? 0 : (d.blur ? 10 : 6);   // canvas shadowBlur is very slow on phones; lite drops it on the trail dots
      ctx.beginPath(); ctx.arc(d.x, d.y, d.r, 0, 7); ctx.fill();
    }
    ctx.restore();
  }
}

/* ---------------- spin gestures ---------------- */
const drag = { down: false, moved: false, x0: 0, y0: 0, lastX: 0, id: null, card: null, dist: 0, t0: 0 };
function spacingPx() { return lerp(G.spacing, 150, state.mix); }
stage.addEventListener('pointerdown', (e) => {
  if (state.locked || e.target.closest('[data-nospin]')) { drag.down = false; return; }   // locked: the remote owns every touch
  unlockAudio();
  drag.down = true; drag.moved = false; drag.x0 = drag.lastX = e.clientX; drag.y0 = e.clientY; drag.id = e.pointerId;
  drag.card = e.target.closest('.card'); drag.dist = 0; drag.t0 = performance.now();
}, { passive: true });
window.addEventListener('pointermove', (e) => {
  if (!drag.down || e.pointerId !== drag.id) return;
  drag.dist = Math.max(drag.dist, Math.hypot(e.clientX - drag.x0, e.clientY - drag.y0));
  if (!drag.moved) {
    const dx = e.clientX - drag.x0, dy = e.clientY - drag.y0;
    if (Math.abs(dx) < 9 || Math.abs(dx) < Math.abs(dy) * 0.8) return;
    drag.moved = true; wheel.dragStart(); cancelAllPresses(); stage.setPointerCapture && stage.setPointerCapture(e.pointerId);
    document.body.classList.add('spinning');
  }
  const dx = e.clientX - drag.lastX; drag.lastX = e.clientX;
  wheel.dragBy(-dx / spacingPx(), performance.now());
}, { passive: true });
function endDrag(e) {
  if (!drag.down || (e && e.pointerId !== drag.id)) return;
  drag.down = false;
  if (!drag.moved && e && e.type === 'pointerup' && drag.card && drag.dist < 12 && performance.now() - drag.t0 < 700 && !state.locked) {
    expand(cards.indexOf(drag.card)); drag.card = null; return;       // a tap on a remote locks the reel and opens it
  }
  if (drag.moved) { wheel.dragEnd(performance.now()); document.body.classList.remove('spinning'); setTimeout(() => { drag.moved = false; }, 30); }
}
window.addEventListener('pointerup', endDrag, { passive: true }); window.addEventListener('pointercancel', endDrag, { passive: true });
stage.addEventListener('wheel', (e) => { e.preventDefault(); if (state.locked) return; unlockAudio(); const d = Math.abs(e.deltaX) > Math.abs(e.deltaY) ? e.deltaX : e.deltaY; wheel.impulse(clamp(d, -120, 120) / 40); }, { passive: false });
window.addEventListener('keydown', (e) => {
  if (e.target.closest && e.target.closest('input,textarea,select')) return;
  if (state.locked) { if (e.key === 'Escape' || e.key === 'Backspace') collapse(); else if (e.key === 'k' || e.key === 'K') openKeyboard(); return; }
  if ((e.key === 'Enter' || e.key === ' ') && wheel.settled) { expand(wheel.selected); return; }
  if (e.key === 'ArrowLeft' && e.shiftKey) wheel.goTo(wheel.selected - 1);
  else if (e.key === 'ArrowRight' && e.shiftKey) wheel.goTo(wheel.selected + 1);
  else if (e.key === 'ArrowLeft') wheel.goTo(wheel.selected - 1);
  else if (e.key === 'ArrowRight') wheel.goTo(wheel.selected + 1);
});

/* ---------------- lock / expand ---------------- */
function expand(i) {
  warmFor(ORDER[i]);
  if (state.locked) return;
  state.locked = true; state.pending = true; cancelAllPresses(); closeSheet();
  if (i !== wheel.selected || !wheel.settled) wheel.goTo(i);      // spin it to the front first, then expand
}
function beginExpand() {
  state.exTarget = 1; document.body.classList.add('locked'); sfx.expand();
  $('#btn-back').tabIndex = 0;
}
function collapse() {
  if (!state.locked) return;
  state.locked = false; state.pending = false; state.exTarget = 0; cancelAllPresses();
  document.body.classList.remove('locked'); $('#btn-back').tabIndex = -1; closeSheet(); sfx.unlock();
}
$('#btn-back').addEventListener('click', () => { unlockAudio(); collapse(); });
$('#btn-spin').addEventListener('click', () => { unlockAudio(); collapse(); });
$('#btn-kbd').addEventListener('click', () => { unlockAudio(); sfx.tap(); openKeyboard(); });

/* ---------------- layout + settings buttons ---------------- */
function setLayout(l, silent) {
  state.layout = l; state.mixTarget = l === 'ring' ? 1 : 0; document.body.dataset.layout = l; localStorage.setItem('layout', l);
  $('#btn-layout').innerHTML = l === 'ring' ? I.reel : I.ring; if (!silent) sfx.toggle();
}
$('#btn-layout').addEventListener('click', () => { unlockAudio(); setLayout(state.layout === 'ring' ? 'reel' : 'ring'); });
setLayout(state.layout, true);
function paintSound() { const b = $('#btn-sound'); b.innerHTML = fx.sound || fx.haptics ? I.sound : I.soundoff; b.classList.toggle('off', !(fx.sound || fx.haptics)); }
$('#btn-sound').addEventListener('click', () => { unlockAudio(); openSettings(); });
paintSound();

/* ---------------- button handling ----------------
   Plain and immediate, like any TV remote app: a button sends the moment the finger goes down (pointerdown), nothing waits for
   the finger to come up, and nothing about the reel / drag logic is consulted. Only the D-pad arrows and the volume keys repeat while held. */
const REPEAT_DELAY_MS = 400, REPEAT_MS = 110, REPEAT_VOL_MS = 140;                   // hold-to-repeat: a controlled rate, and a repeat never piles on a send that is still running
const presses = new Map(), lastFire = new WeakMap();
function cancelAllPresses() { presses.forEach((p) => { clearTimeout(p.t); clearInterval(p.iv); p.el.classList.remove('pressed'); }); presses.clear(); }
cardsEl.addEventListener('pointerdown', (e) => {
  const el = e.target.closest('[data-key],[data-launch]'); if (!el || !state.locked || el.closest('.inactive')) return;
  if (el.hasAttribute('data-kbd')) return;                                              // opens a sheet: handled by the click, so the same touch can't hit the sheet's backdrop
  unlockAudio(); const nm = el.dataset.key || el.dataset.launch || 'button';
  api.log(`ui: tap ${nm}`);
  const p = { el }; el.classList.add('pressed'); presses.set(e.pointerId, p);
  fire(el, false, e.timeStamp);                                                        // send now (e.timeStamp = the touch-down, so the timing log starts at the finger, not at this handler)
  if (el.hasAttribute('data-repeat')) p.t = setTimeout(() => { p.iv = setInterval(() => fire(el, true), /^vol/.test(nm) ? REPEAT_VOL_MS : REPEAT_MS); }, REPEAT_DELAY_MS);
});
function release(e) {
  const p = presses.get(e.pointerId); if (!p) return;
  presses.delete(e.pointerId); clearTimeout(p.t); clearInterval(p.iv); p.el.classList.remove('pressed');
}
window.addEventListener('pointerup', release); window.addEventListener('pointercancel', release);
// a click that did not come from a pointerdown we handled (keyboard, accessibility service, synthetic click) still sends
cardsEl.addEventListener('click', (e) => {
  const el = e.target.closest('[data-key],[data-launch]'); if (!el || !state.locked || el.closest('.inactive')) return;
  if (performance.now() - (lastFire.get(el) || -1e9) < 700) return;
  api.log(`ui: click ${el.dataset.key || el.dataset.launch || 'button'}`); fire(el);
});

const inflightKeys = new Set();                                                        // keys with a send still running (hold-repeat skips these; a tap never does)
function fire(el, quiet, tPress) {
  lastFire.set(el, performance.now());
  const nm = el.dataset.key || el.dataset.launch || 'button';
  if (quiet && inflightKeys.has(nm)) return;                                           // hold-repeat: the previous press has not finished yet, so don't pile more on the TV
  api.log(`ui: fire ${nm}${quiet ? ' (repeat)' : ''}`);
  const pf = ORDER[wheel.selected];
  if (el.hasAttribute('data-kbd')) { openKeyboard(); return; }
  try { el.classList.remove('fired'); void el.offsetWidth; el.classList.add('fired'); if (!quiet) sfx.tap(); else vibrate(5); } catch (er) { /* feedback must never block a command */ }
  inflightKeys.add(nm);
  const t_press = tPress != null ? tPress : performance.now();
  const p = el.dataset.launch ? doSend({ action: 'launch', app: el.dataset.launch, t_press }, pf) : doSend({ action: 'key', key: el.dataset.key, repeat: !!quiet, t_press }, pf);
  p.finally(() => inflightKeys.delete(nm));
}
const warmed = new Map();
/** Open the TV's control connection before the first press (Fire TV ADB shell, Google TV TLS, Apple TV session, Roku volume capability). */
function warmFor(pf, force) {
  const d = deviceFor(pf); if (!d || !d.paired || !api.warm) return;
  if (!force && Date.now() - (warmed.get(d.id) || 0) < 15000) return;
  warmed.set(d.id, Date.now()); api.warm(d.id).catch(() => {}); loadCaps(pf);
}
/* What each TV can really do (asked once per TV): a Roku stick has no volume, Apple TV has no mute. Those buttons are dimmed and say why, quietly, when tapped. */
const capsCache = new Map();
async function loadCaps(pf) {
  const d = deviceFor(pf); if (!d || !d.paired || !api.caps) return null;
  let c = capsCache.get(d.id);
  if (!c) { try { c = await api.caps(d.id); } catch (e) { c = null; } if (!c || c.error || c.volume === undefined) return null; if (!(c.volume === 'maybe' && pf === 'roku')) capsCache.set(d.id, c); }
  const root = cardsEl.querySelector('.remote.' + pf);
  if (root) {
    root.querySelectorAll('[data-key=vol_up],[data-key=vol_down]').forEach((el) => el.classList.toggle('nocap', c.volume === 'no'));
    root.querySelectorAll('[data-key=mute]').forEach((el) => el.classList.toggle('nocap', c.volume === 'no' || c.mute === false));
  }
  return c;
}
const NOCAP_MSG = { firetv: 'Your Fire TV changes the TV’s volume with its own remote, which this app can’t do. Use your Fire TV or TV remote for volume.', roku: 'This Roku can’t change your TV’s volume. Use your TV remote.', appletv: 'Mute isn’t available from here. Use your TV remote.' };
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') { checkLive(); if (state.locked) warmFor(ORDER[wheel.selected], true); } });

/* ---------------- Apple TV clickpad ---------------- */
(() => {
  const pad = $('[data-clickpad]'); if (!pad) return;
  const dot = $('.cp-dot', pad); let s = null;
  const pos = (e) => { const r = pad.getBoundingClientRect(); const sc = r.width / 226; return { x: (e.clientX - r.left) / sc, y: (e.clientY - r.top) / sc }; };
  pad.addEventListener('pointerdown', (e) => {
    if (pad.closest('.inactive')) return; unlockAudio(); pad.setPointerCapture(e.pointerId);
    const p = pos(e); s = { id: e.pointerId, x0: p.x, y0: p.y, ax: p.x, ay: p.y, moved: false, t0: performance.now() };
    pad.classList.add('touch'); dot.style.transform = `translate(${p.x - 113}px, ${p.y - 113}px)`; sfx.hold();
  });
  pad.addEventListener('pointermove', (e) => {
    if (!s || e.pointerId !== s.id) return; const p = pos(e); dot.style.transform = `translate(${p.x - 113}px, ${p.y - 113}px)`;
    const dx = p.x - s.ax, dy = p.y - s.ay, STEP = 38;
    if (Math.hypot(p.x - s.x0, p.y - s.y0) > 12) s.moved = true;
    if (Math.abs(dx) >= STEP || Math.abs(dy) >= STEP) {                    // scrubbing: one move per STEP px
      const key = Math.abs(dx) > Math.abs(dy) ? (dx > 0 ? 'right' : 'left') : (dy > 0 ? 'down' : 'up');
      s.ax = p.x; s.ay = p.y; flashHint(key); sfx.tick(4); doSend({ action: 'key', key }, 'appletv');
    }
  });
  const up = (e) => {
    if (!s || e.pointerId !== s.id) return; const p = pos(e); pad.classList.remove('touch');
    if (!s.moved) {
      const dx = p.x - 113, dy = p.y - 113, r = Math.hypot(dx, dy);
      let key = 'select';
      if (r > 76) key = Math.abs(dx) > Math.abs(dy) ? (dx > 0 ? 'right' : 'left') : (dy > 0 ? 'down' : 'up');
      flashHint(key); sfx.tap(); doSend({ action: 'key', key }, 'appletv');
    } else if (Math.hypot(p.x - s.x0, p.y - s.y0) > 12 && !s.sentAny) {
      /* swipe shorter than STEP: treat as a flick */
      const dx = p.x - s.x0, dy = p.y - s.y0;
      if (Math.max(Math.abs(dx), Math.abs(dy)) < 38) { const key = Math.abs(dx) > Math.abs(dy) ? (dx > 0 ? 'right' : 'left') : (dy > 0 ? 'down' : 'up'); flashHint(key); sfx.tick(4); doSend({ action: 'key', key }, 'appletv'); }
    }
    s = null;
  };
  pad.addEventListener('pointerup', up); pad.addEventListener('pointercancel', () => { s = null; pad.classList.remove('touch'); });
  function flashHint(key) { const h = $('.cp-hint.' + key, pad); if (!h) return; h.style.transition = 'none'; h.style.color = '#fff'; requestAnimationFrame(() => { h.style.transition = 'color .4s'; h.style.color = ''; }); }
})();

/* ---------------- toast ---------------- */
let toastT;
function toast(msg, err) { toastEl.textContent = msg; toastEl.classList.toggle('err', !!err); toastEl.classList.add('show'); clearTimeout(toastT); toastT = setTimeout(() => toastEl.classList.remove('show'), err ? (msg.length > 80 ? 7000 : 3500) : 1300); }
let noteT; function pillNote(t) { state.pillNote = t; clearTimeout(noteT); updatePill(); noteT = setTimeout(() => { state.pillNote = null; updatePill(); }, /✗/.test(t) ? 6000 : 3500); }

/* ---------------- devices / send ---------------- */
const gated = () => !!(state.info && state.info.native && !state.demo);          // real phone: only TVs that are reachable right now may appear
const shown = () => (gated() ? state.devices.filter((d) => state.live.has(d.id)) : state.devices);
function deviceFor(platform) {
  const list = shown().filter((d) => d.platform === platform);
  return list.find((d) => d.id === state.chosen[platform]) || list.find((d) => d.paired) || list[0];
}
/* crisp SVG check / cross in a small circle badge (replaces the ✓ / ✗ text glyphs everywhere) */
const CHECK_SVG = '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="12" class="ckb"/><path d="M7 12.6l3.3 3.3L17 9" class="ckp"/></svg>';
const CROSS_SVG = '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="12" class="ckb x"/><path d="M8.5 8.5l7 7M15.5 8.5l-7 7" class="ckp"/></svg>';
function escH(s) { return String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])); }
const glyphs = (s) => escH(s).replace(/ ✓/g, ` <i class="ck">${CHECK_SVG}</i>`).replace(/ ✗/g, ` <i class="ck bad">${CROSS_SVG}</i>`);
function updatePill() {
  const pf = ORDER[wheel.selected], d = deviceFor(pf), pill = $('#pill'), txt = $('#pill-text');
  pill.classList.remove('ok', 'warn');
  if (!d) { txt.textContent = 'Tap PAIR to find your TV'; }
  else if (!d.paired) { txt.textContent = `${d.name} · needs pairing`; pill.classList.add('warn'); }
  else { txt.innerHTML = glyphs(`${d.name} · ${state.pillNote || (state.demo ? 'demo' : 'ready')}`); pill.classList.add('ok'); }
  const paired = !!(d && d.paired);
  document.querySelectorAll('.pairbtn').forEach((b) => {
    b.classList.toggle('paired', paired); b.querySelector('.pl').innerHTML = paired ? `PAIRED <i class="ck">${CHECK_SVG}</i>` : 'PAIR';
    b.setAttribute('aria-label', paired ? `${d.name} is paired. Open TV list` : `Pair ${d ? d.name : REMOTES[pf].name}`);
  });
}
async function refreshDevices() { try { const r = await api.getDevices(); state.devices = r.devices || r; } catch (e) { state.devices = []; } updatePill(); }
const NICE = { vol_up: 'Volume +', vol_down: 'Volume −', mute: 'Mute', ch_up: 'Channel +', ch_down: 'Channel −' };
const nice = (k) => NICE[k] || (() => { const t = String(k || '').replace(/_/g, ' '); return t.charAt(0).toUpperCase() + t.slice(1); })();
/** Short real reason for the status pill, in plain words (never a raw "HTTP 403" or a code). */
function shortWhy(e) {
  const st = e.status || +((/HTTP (\d{3})/.exec(e.message || '') || [])[1] || 0);
  if (e.code === 'forbidden' || e.code === 'search_blocked' || st === 401 || st === 403) return 'not allowed'; if (st) return 'TV said no';
  if (e.code === 'unreachable') return 'no connection'; if (e.code === 'timeout') return 'timed out'; if (e.code === 'closed') return 'connection closed';
  if (e.code === 'not_paired') return 'not paired'; if (e.code === 'no_volume') return 'not on this Roku'; if (e.code === 'bad_key') return 'TV rejected it'; return 'failed';
}
/** Plain-language message for a failure; the technical text goes behind a "Details" toggle. */
function friendly(e, platform) {
  const R = platform && REMOTES[platform] ? REMOTES[platform].name : 'TV', m = e && e.message || '', c = e && e.code;
  if (c === 'forbidden') return `Your ${R} is blocking remote control. On the TV: Settings → System → Advanced system settings → Control by mobile apps → Network access → Default.`;
  if (c === 'search_blocked') return `Your ${R} won’t let this phone start a search. On the TV: Settings → System → Advanced system settings → Control by mobile apps → Network access → Default. Or open Search on your ${R} and type here with the keyboard button.`;
  if (c === 'search_failed') return `Your ${R} couldn’t open search for that. Try again, or open Search on your ${R} and type here with the keyboard button.`;
  if (c === 'bad_code') return 'That code didn’t match. Check the TV and try again.';
  if (platform === 'firetv' && /ADB debugging/.test(m)) return 'Your Fire TV isn’t accepting remote connections. On the Fire TV: Settings → My Fire TV → Developer options → turn ADB debugging on.';
  if (platform === 'firetv' && (c === 'closed' || c === 'not_paired' || /closed/i.test(m))) return 'Your Fire TV didn’t get an answer. Look at the TV and press Allow (tick “Always allow”), then try again.';
  if (platform === 'googletv' && /secure connection|did not complete pairing|did not present a cert/.test(m)) return 'Your Google TV answered but didn’t finish pairing. Wake it with its own remote and try again.';
  if (platform === 'googletv' && c === 'tv_refuses') return 'Your Google TV is on the network but isn’t accepting remote apps right now, so it can’t show a pairing code. This is a setting or fault on the TV, not this phone. On the TV: Settings → Apps → System apps → Android TV Remote Service: make sure it’s turned on, then unplug the TV for a minute. If other remote apps also can’t pair, the TV maker’s support or a TV reset is the next step.';
  if (platform === 'googletv' && (c === 'unreachable' || c === 'timeout')) return 'Couldn’t reach your Google TV. Wake it with its own remote and check it’s on the same Wi-Fi as this phone (not a guest network). If other remote apps can’t reach it either: on the TV, open Settings → Apps → System apps → Android TV Remote Service, update it or clear its data, then restart the TV.';
  if (c === 'unreachable' || c === 'timeout' || /reach|connect/i.test(m)) return `Couldn’t reach your ${R}. Check that it’s on and on the same Wi-Fi as this phone.`;
  if (c === 'not_paired') return `Your ${R} needs to be connected first.`;
  if (c === 'bad_status') return `Your ${R} didn’t accept that button. Try again. If it keeps happening, check the TV’s setting that allows phone remotes.`;
  if (c === 'no_text_field' || c === 'no_volume') return m;
  if (c === 'bad_key' && m) return m.split('\n')[0];
  return `Something went wrong talking to your ${R}. Try again.`;
}
const detailsBlock = (msg) => `<button class="sbtn ghost" style="margin:6px auto 0;display:block;font-size:12px;opacity:.8" data-act="det">Details</button>
  <div class="detbox" style="display:none"><div class="err" style="min-height:0;text-align:left;font-size:11.5px;color:#c9c6dd">${esc(msg || '(no details)')}</div>${dbgBtn()}</div>`;
async function doSend(payload, pf) {
  const d = deviceFor(pf), what = payload.key || payload.app || payload.action, label = nice(what);
  if (!d || !d.paired) return;          // no TV connected: the button just presses quietly (no pairing screen, no toast, no pill note). Only the PAIR button opens pairing.
  if (payload.action === 'key' && pf !== 'firetv' && /^(vol_up|vol_down|mute)$/.test(payload.key)) {   // build 31: Fire TV volume is never held back here                // capability known from the TV itself: don't send a key it can't act on
    const c = capsCache.get(d.id);
    if (c && (c.volume === 'no' || (payload.key === 'mute' && c.mute === false))) { if (!payload.repeat) { toast(NOCAP_MSG[pf] || 'This TV can’t do that from here. Use your TV remote.'); pillNote(`${label} — not available`); } return; }
  }
  const t0 = performance.now(); if (!payload.repeat) pillNote(`${label} …`);              // instant feedback: the result replaces this a moment later
  try {
    const r = await api.send({ device: d.id, ...payload });
    const w = (state.demo ? 'DEMO ▸ ' : '') + (r.wire || (payload.key || payload.action));
    if (r.wire === 'coalesced') return r;
    if (!payload.repeat) toast(w); if (state.onWire) state.onWire(w); pillNote(`${label} ✓`);
    state.lastMs = Math.round(performance.now() - t0);
    api.log(`send ${payload.action} ${payload.key || payload.app || ''} → ok ${r.wire || ''} (${state.lastMs} ms)`);
    return r;
  } catch (e) {
    api.log(`send ${payload.action} ${payload.key || payload.app || ''} ✗ ${e.message}`);
    state.lastErr = { t: Date.now(), e, pf };
    if (e.code === 'not_paired') { d.paired = false; updatePill(); if (pf === 'googletv' && !payload.repeat) openPairScreen(pf, d.id); return; }   // Google TV forgot us: show a fresh code right away          // the TV forgot us: go quiet, PAIR is how to reconnect
    if (e.code === 'no_volume' || (e.code === 'bad_key' && pf === 'appletv' && payload.key === 'mute')) { if (!payload.repeat) { toast(NOCAP_MSG[pf] || friendly(e, pf)); pillNote(`${label} — not available`); } return; }   // a limit of this TV, not a failure: quiet text, no error sound
    sfx.error(); toast(friendly(e, pf), true); pillNote(`${label} ✗ ${shortWhy(e)}`);
  }
}

/* ---------------- sheets ---------------- */
const sheet = $('#sheet'), body = $('#sheet-body'), backdrop = $('#backdrop');
function openSheet(html) { sheet.classList.remove('kbsheet'); body.onclick = null; body.onpointerdown = null; body.onmousedown = null; body.innerHTML = html; sheet.classList.add('on'); backdrop.classList.add('on'); document.body.classList.add('sheet-open'); sheet.scrollTop = 0; }
function closeSheet() { sheet.classList.remove('on'); backdrop.classList.remove('on'); document.body.classList.remove('sheet-open'); state.onWire = null; if (document.activeElement) document.activeElement.blur(); }
backdrop.addEventListener('click', closeSheet);
let sheetStartY = null;
sheet.addEventListener('pointerdown', (e) => { if (e.target.closest('.grab')) sheetStartY = e.clientY; });
window.addEventListener('pointerup', (e) => { if (sheetStartY !== null && e.clientY - sheetStartY > 50) closeSheet(); sheetStartY = null; });
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

function devRow(d) {
  const R = REMOTES[d.platform];
  return `<div class="row" style="--c:${R.accent}"><div class="badge">${R.short.slice(0, 4)}</div>
    <div class="meta"><div class="nm">${esc(d.name)}</div><div class="st ${d.paired ? 'ok' : 'warn'}">${esc(R.name)}${d.paired ? '' : ' · tap Pair to connect'}</div></div>
    ${d.paired ? `<button class="sbtn ghost" data-act="rm" data-id="${d.id}">Remove</button>` : `<button class="sbtn" data-act="pair" data-id="${d.id}">Pair</button>`}</div>`;
}
const devListHtml = () => shown().map(devRow).join('') || `<p class="sub">${gated() ? 'No TVs detected on this network. Tap Scan.' : 'Nothing yet — scan below.'}</p>`;
let liveRun = 0, liveTimer = null;
function setLive(ids, merge) {
  const before = [...state.live].sort().join(); state.live = merge ? new Set([...state.live, ...ids]) : new Set(ids);
  if ([...state.live].sort().join() === before) return;
  updatePill(); const dl = $('#devlist'); if (dl) dl.innerHTML = devListHtml();
  if (state.locked) warmFor(ORDER[wheel.selected], true);                         // a paired TV that just appeared connects by itself
  else warmFor(ORDER[wheel.selected]);
}
async function checkLive() {
  if (!gated() || !api.reachable) return; const run = ++liveRun;
  try { const r = await api.reachable(); if (run === liveRun) setLive(r.live || []); } catch (e) { /* keep what we had */ }
}
function openDevices(focusPlatform) {
  if (gated()) checkLive();
  const demoNote = state.demo ? `<div class="hint">Demo mode: these are simulated TVs.</div>` : (state.info && state.info.native ? `<div class="hint">Tap Scan to find your TVs. Make sure the phone and the TV are on the same Wi-Fi.</div>` : '');
  openSheet(`<h2>Your TVs</h2><p class="sub">Each remote controls the TV of its kind. Scan your Wi-Fi to find more.</p>${demoNote}
    <div id="devlist">${devListHtml()}</div>
    <div class="scan"><button class="sbtn wide" data-act="scan">Scan</button></div>${state.info && state.info.native ? `<div class="scan" style="margin-top:8px"><button class="sbtn ghost wide" data-act="demo">${state.demo ? 'Leave demo mode' : 'No TV handy? Try demo mode'}</button></div>` : ''}
    <div class="sec">Add by IP</div>
    <div class="form"><select id="addp">${ORDER.map((id) => `<option value="${id}" ${id === focusPlatform ? 'selected' : ''}>${REMOTES[id].name}</option>`).join('')}</select>
      <input id="addh" inputmode="decimal" placeholder="192.168.1.50"><button class="sbtn" data-act="add">Add</button></div>
    <div class="err" id="deverr"></div>`);
}

// Debug log for support: tap = copy to clipboard, press & hold = show it in a box to select/copy by hand. Native app only.
const dbgBtn = () => (state.info && state.info.native && !state.demo ? `<button class="sbtn ghost wide" style="margin-top:8px;font-size:12px;opacity:.8" data-act="dbgcopy">Copy debug log <small style="opacity:.7">(hold to view)</small></button><textarea id="dbgbox" readonly style="display:none;width:100%;height:150px;margin-top:8px;font:11px/1.35 ui-monospace,monospace;background:#0a0a14;color:#cfe;border:1px solid #333;border-radius:10px;padding:8px"></textarea>` : '');
function showDbgBox() { const t = $('#dbgbox'); if (!t) return null; t.value = api.debugLog(); t.style.display = 'block'; t.focus(); t.select(); return t; }
async function copyDbg(b) {
  const text = api.debugLog(); let ok = false;
  try { if (navigator.clipboard && navigator.clipboard.writeText) { await navigator.clipboard.writeText(text); ok = true; } } catch { /* fall through */ }
  if (!ok) { const t = showDbgBox(); try { ok = !!t && document.execCommand('copy'); } catch { ok = false; } }
  const old = b.innerHTML; b.innerHTML = ok ? `Copied <i class="ck">${CHECK_SVG}</i>` : 'Select the text below and copy it'; setTimeout(() => { b.innerHTML = old; }, 2200);
}
let dbgTimer = null, dbgHeld = false;
for (const host of [body, $('#pscreen')]) host.addEventListener('pointerdown', (e) => { const b = e.target.closest('[data-act=dbgcopy]'); if (!b) return; dbgHeld = false; clearTimeout(dbgTimer); dbgTimer = setTimeout(() => { dbgHeld = true; showDbgBox(); }, 600); });
['pointerup', 'pointercancel', 'pointerleave'].forEach((ev) => body.addEventListener(ev, () => clearTimeout(dbgTimer)));
body.addEventListener('contextmenu', (e) => { if (e.target.closest('[data-act=dbgcopy]')) e.preventDefault(); });

// Native app only: PAIR on a remote whose TV isn't known yet → scan, show what was found, tap one to connect.
function openFind(platform, skipScan) {
  const R = REMOTES[platform];
  openSheet(`<div class="steps">CONNECT · ${esc(R.name.toUpperCase())}</div><h2 style="text-align:center">Connect your ${esc(R.name)}</h2>
    <p class="sub" style="text-align:center" id="fmsg">Looking for your ${esc(R.name)}…</p>
    <div id="fbody"><div class="scan" style="justify-content:center"><div class="spinner"></div></div></div>`);
  sheet.dataset.find = platform;
  const ipForm = () => `<div class="sec">Enter its address</div>
      <div class="form"><input id="fip" inputmode="decimal" placeholder="192.168.1.50" aria-label="TV IP address"><button class="sbtn" data-act="fconnect">Connect</button></div>
      <div class="err" id="ferr"></div>
      <p class="sub" style="text-align:center">${platform === 'googletv' ? 'On the TV: Settings → Network &amp; Internet → your Wi-Fi → “IP address”.' : 'It’s in the TV’s network settings.'}</p>`;
  const wireIp = () => { const i = $('#fip'); i && i.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); const b = document.querySelector('[data-act=fconnect]'); b && b.click(); } }); };
  const list = (devs, details) => {
    $('#fmsg').textContent = devs.length ? 'Tap your TV to connect.' : `We couldn’t find your ${R.name}. Make sure it’s on and connected to the same Wi-Fi as this phone.`;
    $('#fbody').innerHTML = `${devs.map((d) => `<div class="row" style="--c:${R.accent}" data-act="fpick" data-id="${d.id}" role="button" tabindex="0"><div class="badge">${R.short.slice(0, 4)}</div><div class="meta"><div class="nm">${esc(d.name)}</div><div class="st ${d.paired ? 'ok' : 'warn'}">${d.paired ? 'Connected' : 'Tap to connect'}</div></div><button class="sbtn">${d.paired ? 'Open' : 'Connect'}</button></div>`).join('')}
      <button class="sbtn wide" style="margin-top:10px" data-act="fscan">Scan</button>
      <button class="sbtn ghost wide" style="margin-top:8px" data-act="fshowip">Can’t see it? Enter its address</button><div id="fipwrap" style="display:none">${ipForm()}</div>
      ${detailsBlock(details)}`;
  };
  if (skipScan) { list([], 'Scan skipped (address entry).'); $('#fmsg').textContent = 'Enter the TV’s address:'; $('#fipwrap').style.display = 'block'; wireIp(); return; }
  api.discover(platform).then((r) => {
    state.devices = r.devices || state.devices; if (gated()) setLive(r.seen || []); updatePill();
    const found = shown().filter((x) => x.platform === platform), dg = r.diag || {};
    const det = [(dg.mdns && dg.mdns.length ? `Wi-Fi discovery: ${dg.mdns.join(' · ')}` : ''), dg.sweep || ''].filter(Boolean).join('\n') || 'Scan finished.';
    if (!found.length) sfx.error(); else sfx.ok();
    list(found, det);
  }).catch((e) => { sfx.error(); list([], `Scan failed: ${e.message}`); $('#fmsg').textContent = `Couldn’t search your Wi-Fi. ${friendly(e, platform)}`; });
}
function openSettings() {
  openSheet(`<h2>Settings</h2><p class="sub">Feedback while you spin and press.</p>
    <div class="toggle"><span>Click sounds</span><button class="sw ${fx.sound ? 'on' : ''}" data-act="tsound" aria-label="Sounds"></button></div>
    <div class="toggle"><span>Haptics ${navigator.vibrate ? '' : '<small style="color:var(--dim)">(not supported on this device)</small>'}</span><button class="sw ${fx.haptics ? 'on' : ''}" data-act="thaptic" aria-label="Haptics"></button></div>
    <div class="sec">TVs</div><button class="sbtn ghost wide" data-act="devices">Manage TVs &amp; pairing</button>
    ${state.info && state.info.native ? `<div class="toggle"><span>Demo mode <small style="color:var(--dim)">(simulated TVs)</small></span><button class="sw ${state.demo ? 'on' : ''}" data-act="demo" aria-label="Demo mode"></button></div>` : ''}
    ${dbgBtn()}
    <p class="sub" style="margin-top:14px">${state.demo ? '<b style="color:#ffd27a">DEMO MODE</b> — nothing is sent to a TV.' : state.info && state.info.native ? 'Sending commands straight to TVs on your Wi-Fi. Roku works out of the box; Google TV, Fire TV and Apple TV need a one-time pairing.' : 'Connected to the bridge.'}</p>`);
}
function openPair(d) {
  const R = REMOTES[d.platform];
  openSheet(`<div class="steps">PAIR · ${esc(R.name.toUpperCase())}</div><h2 style="text-align:center">${esc(d.name)}</h2><p class="sub" style="text-align:center" id="pmsg">Contacting the TV…</p><div id="pbody"><div class="scan" style="justify-content:center"><div class="spinner"></div></div></div>`);
  api.pairStart(d.id).then((r) => pairStep(d, r)).catch((e) => pairFail(d, e));
}
function pairFail(d, e) {
  $('#pmsg').textContent = ''; state.lastErr = { t: Date.now(), e, pf: d.platform };
  $('#pbody').innerHTML = `<div class="err" style="min-height:0">${esc(friendly(e, d.platform))}</div>${state.info && state.info.native && !state.demo ? `<button class="sbtn wide" data-act="pretry" data-id="${d.id}">Try again</button><button class="sbtn ghost wide" style="margin-top:8px" data-act="pnewip" data-p="${d.platform}">Enter a different address</button>` : ''}<button class="sbtn ghost wide" style="margin-top:8px" data-act="devices">Back</button>${detailsBlock(e.message)}`; sfx.error();
}
const showPerr = (er, d) => { const p = $('#perr'); if (!p) return; state.lastErr = { t: Date.now(), e: er, pf: d && d.platform }; p.innerHTML = `${esc(friendly(er, d && d.platform))}${detailsBlock(er.message)}`; };
function pairStep(d, r) {
  if (r.status === 'paired') return pairDone(d);
  $('#pmsg').textContent = r.message || '';
  if (r.status === 'confirm') {
    const auto = state.info && state.info.native && !state.demo;       // real TV: just wait for the "Allow" on the TV, no extra button
    $('#pmsg').textContent = auto ? 'Look at your TV and press Allow (tick “Always allow”).' : (r.message || '');
    $('#pbody').innerHTML = `<div class="err" id="perr"></div>${auto ? '<div class="scan" style="justify-content:center"><div class="spinner"></div></div>' : '<button class="sbtn wide" data-act="pconfirm">Continue</button>'}`;
    if (auto) api.pairFinish(d.id, null).then((x) => pairStep(d, x)).catch((er) => pairFail(d, er));
  } else {
    const len = r.length || 4, hex = r.kind === 'hex';
    if (r.step) $('.steps').textContent = `PAIR · ${R_NAME(d)} · STEP ${r.step}/${r.of}`;
    $('#pbody').innerHTML = `${state.demo && r.hint ? `<div class="hint">Demo: the code is <b>${r.hint}</b></div>` : ''}
      <div class="codebox" id="cbox">${'<i></i>'.repeat(len)}<input id="pcode" maxlength="${len}" ${hex ? 'autocapitalize="characters" autocomplete="off"' : 'inputmode="numeric" pattern="[0-9]*"'} aria-label="Pairing code"></div>
      <div class="err" id="perr"></div>
      <button class="sbtn wide" data-act="psubmit" disabled>Pair</button>
`;
    const inp = $('#pcode'), boxes = [...document.querySelectorAll('#cbox i')], btn = $('[data-act=psubmit]');
    const paint = () => { const v = inp.value; boxes.forEach((b, k) => { b.textContent = v[k] || ''; b.classList.toggle('cur', k === Math.min(v.length, len - 1)); }); btn.disabled = v.length !== len; };
    inp.addEventListener('input', () => { inp.value = hex ? inp.value.replace(/[^0-9a-fA-F]/g, '').toUpperCase() : inp.value.replace(/\D/g, ''); paint(); sfx.tick(0); if (inp.value.length === len) btn.focus(); });
    paint(); setTimeout(() => inp.focus(), 350);
  }
  sheet.dataset.pair = d.id;
}
/* ---------------- pairing screen (full screen, like mainstream remote apps) ---------------- */
const pscreen = $('#pscreen');
const APPLE = '<svg viewBox="0 0 24 24" width="17" height="17" aria-hidden="true"><path fill="currentColor" d="M12.15 6.9c-.95 0-2.42-1.08-3.96-1.04-2.04.03-3.91 1.18-4.96 3.01-2.12 3.68-.55 9.1 1.52 12.09 1.01 1.45 2.21 3.09 3.79 3.04 1.52-.07 2.09-.99 3.94-.99 1.83 0 2.35.99 3.96.95 1.64-.03 2.68-1.48 3.68-2.95 1.16-1.69 1.64-3.33 1.66-3.42-.04-.01-3.18-1.22-3.22-4.86-.03-3.04 2.48-4.49 2.6-4.56-1.43-2.09-3.62-2.32-4.39-2.38-2-.16-3.68 1.09-4.61 1.09zM15.53 3.83c.84-1.01 1.4-2.43 1.25-3.83-1.21.05-2.66.8-3.53 1.82-.78.9-1.45 2.34-1.27 3.71 1.34.1 2.72-.69 3.55-1.7z"/></svg>';
const PLOGO = {
  roku: '<span class="pl-roku">Roku</span>',
  firetv: '<span class="pl-fire"><b>fire</b> <i>tv</i></span>',
  googletv: '<span class="pl-gtv"><b><u>G</u><u>o</u><u>o</u><u>g</u><u>l</u><u>e</u></b> TV</span>',
  appletv: `<span class="pl-atv">${APPLE}<b>tv</b></span>`,
};
let psRun = 0, psPicking = null, psScanning = false, psScanRun = 0, psPf = null;
/* hidden "reset this TV": hold a TV in the list for 1.5 s → confirm → this app forgets every saved key for that TV (it stays in the list, unpaired) */
let psResetTimer = null, psResetFired = false;
document.addEventListener('pointerdown', (e) => { const row = e.target.closest && e.target.closest('#pscreen [data-act=pspick]'); if (!row) return; clearTimeout(psResetTimer); psResetFired = false;
  psResetTimer = setTimeout(async () => { psResetFired = true; const d = state.devices.find((x) => x.id === row.dataset.id); if (!d || !confirm(`Reset ${d.name}? This phone forgets its pairing with this TV. You can pair again right after.`)) return; try { await api.resetDevice(d.id); d.paired = false; await refreshDevices(); updatePill(); toast(`${d.name} reset. Tap it to pair again.`); } catch (er) { toast('Couldn’t reset that TV.', true); } }, 1500); });
for (const ev of ['pointerup', 'pointercancel', 'pointerleave']) document.addEventListener(ev, () => clearTimeout(psResetTimer));
function openPairScreen(pf, autoId) {
  state.seen = new Set(autoId ? [autoId] : []);          // only TVs seen in THIS scan are listed; saved ones stay stored for quick reconnect
  psPf = pf || (autoId && (state.devices.find((x) => x.id === autoId) || {}).platform) || ORDER[wheel.selected];
  closeSheet(); psRun++; psPicking = null;
  pscreen.innerHTML = `<button class="ps-x" data-act="psclose" aria-label="Close"><svg viewBox="0 0 24 24" width="26" height="26"><path d="M5 5l14 14M19 5L5 19" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" fill="none"/></svg></button>
    <p class="ps-cap">Please select the device to connect</p><div id="pslist"></div><div id="psmodal" class="ps-modal-wrap" hidden></div>`;
  pscreen.hidden = false; requestAnimationFrame(() => pscreen.classList.add('on')); document.body.classList.add('sheet-open');
  psList();
  if (autoId) { const d = state.devices.find((x) => x.id === autoId); if (d) { psPick(d); return; } }
  psScan();
}
function closePairScreen() { psRun++; psScanRun++; pscreen.classList.remove('on'); pscreen.hidden = true; pscreen.innerHTML = ''; document.body.classList.remove('sheet-open'); if (document.activeElement) document.activeElement.blur(); }
const psDevices = () => { const o = ORDER.indexOf(psPf); return state.devices.filter((d) => ORDER.includes(d.platform) && state.seen && state.seen.has(d.id)).sort((a, b) => ((ORDER.indexOf(a.platform) - o + 9) % 9) - ((ORDER.indexOf(b.platform) - o + 9) % 9)); };
function psList() {
  const el = $('#pslist'); if (!el) return; const devs = psDevices();
  el.innerHTML = `${devs.map((d) => `<div class="ps-dev${psPicking === d.id ? ' busy' : ''}" data-act="pspick" data-id="${esc(d.id)}" role="button" tabindex="0" aria-label="${esc(REMOTES[d.platform].name)} ${esc(d.name)}"><span class="ps-logo">${PLOGO[d.platform]}</span><span class="ps-name">${esc(d.name)}</span><span class="ps-spin"></span></div>`).join('')}
    ${psScanning ? '<div class="ps-note"><span class="ps-spin on"></span>Searching…</div>' : (devs.length ? '' : `<div class="ps-note col"><span>No devices found</span><small>Make sure your TV is on and on the same Wi-Fi as this phone.</small></div>${state.psDet ? `<div class="ps-detwrap"><button class="ps-det" data-act="det">Details</button><div class="detbox" style="display:none"><div class="ps-detmsg">${esc(state.psDet)}</div>${dbgBtn()}</div></div>` : ''}`)}
    ${psScanning ? '' : '<div class="ps-links"><button data-act="psscan">Scan again</button><span>·</span><button data-act="psip">Enter IP address</button></div>'}`;
}
async function psScan() {
  const run = ++psScanRun; psScanning = true; state.psDet = ''; psList();
  let diag = null;
  // Build 23: show each TV the moment the scan hears it (the scan reports what it has so far every 200 ms).
  const peek = async () => { while (run === psScanRun && psScanning) { await new Promise((res) => setTimeout(res, 200)); if (run !== psScanRun || !psScanning) return;
    try { const p = await api.discoverProgress(); if (run !== psScanRun || !psScanning || !p || !p.seen) return; const n0 = psDevices().length; state.devices = p.devices || state.devices; state.seen = new Set(p.seen); if (psDevices().length !== n0) psList(); } catch (e) { return; } } };
  peek();
  try { const r = await api.discover(); if (run !== psScanRun) return; state.devices = r.devices || state.devices; state.seen = new Set(r.seen || state.devices.map((d) => d.id)); if (gated()) setLive([...state.seen]); diag = r.diag; state.psDet = (diag && ((diag.mdns && diag.mdns.length ? `Wi-Fi discovery: ${diag.mdns.join(' · ')}` : '') + (diag.sweep ? `\n${diag.sweep}` : ''))).trim() || 'Scan finished, nothing answered.'; updatePill(); psScanning = false; psList(); if (psDevices().length) sfx.ok(); else sfx.error(); }
  catch (e) { if (run !== psScanRun) return; state.psDet = `Scan failed: ${e.message || e}`; psScanning = false; psList(); sfx.error(); state.lastErr = { t: Date.now(), e, pf: psPf }; }
  state.psDiag = diag;
}
/* modal: title + subtitle (+ input) + two blue buttons side by side */
function psModal({ title = 'Pairing with device', sub = '', input = null, buttons = [], details = null, note = '', spin = false, check = false }) {
  const m = $('#psmodal'); if (!m) return; const dtl = details != null ? `<button class="ps-det" data-act="det">Details</button><div class="detbox" style="display:none"><div class="ps-detmsg">${esc(details || '(no details)')}</div>${dbgBtn()}</div>` : '';
  m.innerHTML = `<div class="ps-modal" role="alertdialog" aria-label="${esc(title)}"><div class="ps-mb"><h3>${esc(title)}</h3><p>${esc(sub)}</p>${check ? `<div class="bigck">${CHECK_SVG}</div>` : ''}${spin ? '<div class="ps-msp"><span class="ps-spin on"></span></div>' : ''}${input ? `<input id="pscode" class="ps-input" ${input.hex ? 'inputmode="text" autocapitalize="characters" autocomplete="off" autocorrect="off" spellcheck="false"' : 'inputmode="numeric" pattern="[0-9]*" autocomplete="off"'} maxlength="${input.len || 40}" placeholder="${esc(input.placeholder || '')}" aria-label="${esc(input.label || 'Code')}">` : ''}<div class="ps-err" id="pserr">${esc(note)}</div>${dtl}</div>
    <div class="ps-btns">${buttons.map((b, k) => `<button class="${b.bold ? 'bold' : ''}" data-act="${b.act}"${b.disabled ? ' disabled' : ''}>${esc(b.label)}</button>`).join('')}</div></div>`;
  m.hidden = false; m.classList.add('on');
  const i = $('#pscode'); if (i) { setTimeout(() => i.focus(), 120); i.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); const ok = m.querySelector('[data-act=psok]'); ok && ok.click(); } }); }
  return i;
}
const psModalClose = () => { const m = $('#psmodal'); if (m) { m.hidden = true; m.classList.remove('on'); m.innerHTML = ''; } };
const psBusy = (id) => { psPicking = id; psList(); };
async function psPick(d) {
  const run = ++psRun; state.psDev = d;
  if (d.paired && d.platform === 'googletv' && state.info && state.info.native && !state.demo) {                    // Google TV: "ready" only after the TV really finished the handshake; a TV that forgot this phone goes straight to a fresh code
    psBusy(d.id);
    try { await api.checkDevice(d.id); if (run !== psRun) return; psFinish(d, false); return; }
    catch (e) { if (run !== psRun) return; if (e.code !== 'not_paired') { psFail(d, e); return; } d.paired = false; updatePill(); }
  }
  if (d.paired) { psBusy(d.id); await new Promise((r) => setTimeout(r, 350)); if (run !== psRun) return; psFinish(d, false); return; }
  psBusy(d.id);
  try { const r = await api.pairStart(d.id); if (run !== psRun) return; await psNext(d, r, run); } catch (e) { if (run !== psRun) return; psFail(d, e); }
}
async function psNext(d, r, run) {
  if (r.status === 'paired') { psModal({ title: 'Paired', sub: `${REMOTES[d.platform].name} is connected. This remote is live.`, check: true }); sfx.ok(); await new Promise((res) => setTimeout(res, 1100)); if (run !== psRun) return; return psFinish(d, true); }
  if (r.status === 'confirm') {
    const real = state.info && state.info.native && !state.demo, nm = REMOTES[d.platform].name;
    psModal({ title: 'Look at your TV and choose Allow', sub: real ? `On your ${nm}, choose Allow (or Always allow) when it asks.` : (r.message || 'Please confirm on the TV'), spin: real, buttons: real ? [{ label: 'Cancel', act: 'pscancel' }] : [{ label: 'Cancel', act: 'pscancel' }, { label: 'OK', act: 'psgo', bold: true }] });
    if (real) { try { const x = await api.pairFinish(d.id, null); if (run !== psRun) return; await psNext(d, x, run); } catch (e) { if (run !== psRun) return; psFail(d, e); } }
    return;
  }
  const len = r.length || 4, hex = r.kind === 'hex';
  const nm = REMOTES[d.platform].name;
  psModal({ title: 'Enter the code shown on your TV', sub: `Look at your ${nm}. Type the ${len}-${hex ? 'character' : 'digit'} code it shows${r.step ? ` (step ${r.step} of ${r.of})` : ''}. Pairing finishes only when the code is right.`, input: { len, hex, label: 'Code shown on your TV', placeholder: hex ? 'e.g. A1B2C3' : '• • • •' }, note: state.demo && r.hint ? `Demo code: ${r.hint}` : '', buttons: [{ label: 'Cancel', act: 'pscancel' }, { label: 'OK', act: 'psok', bold: true, disabled: true }] });
  const i = $('#pscode'), ok = $('#psmodal [data-act=psok]'); state.psCode = { d, len, hex, run };
  i.addEventListener('input', () => { i.value = hex ? i.value.replace(/[^0-9a-fA-F]/g, '').toUpperCase() : i.value.replace(/\D/g, ''); ok.disabled = i.value.length !== len; const e = $('#pserr'); if (e && !(state.demo && r.hint)) e.textContent = ''; });
}
function psFinish(d, fresh) {
  const pf = d.platform; d.paired = true; setLive([d.id], true); refreshDevices(); updatePill(); sfx.ok(); closePairScreen();
  const k = ORDER.indexOf(pf); if (k >= 0 && !state.locked && k !== wheel.selected) wheel.goTo(k);
  toast(fresh ? `${REMOTES[pf].name} paired. This remote is live` : `${REMOTES[pf].name} is connected`);
}
function psFail(d, e) {
  psPicking = null; psList(); state.lastErr = { t: Date.now(), e, pf: d.platform }; sfx.error();
  psModal({ title: 'Couldn’t connect', sub: friendly(e, d.platform), details: e.message || String(e), buttons: [{ label: 'Cancel', act: 'pscancel' }, { label: 'Try again', act: 'psretry', bold: true }] });
}
const psClick = async (e) => {
  const b = e.target.closest('[data-act]'); if (!b || !b.dataset.act.startsWith('ps')) return; unlockAudio();
  const act = b.dataset.act, d = state.psDev;
  if (act === 'psclose') { sfx.tap(); closePairScreen(); }
  else if (act === 'psscan') { sfx.tap(); psScan(); }
  else if (act === 'pspick') { if (psPicking || psResetFired) { psResetFired = false; return; } const dd = state.devices.find((x) => x.id === b.dataset.id); if (dd) { sfx.tap(); psPick(dd); } }
  else if (act === 'pscancel') { psRun++; psPicking = null; psModalClose(); psList(); }
  else if (act === 'psretry') { psModalClose(); if (d && d.id) psPick(d); else { const x = pscreen.querySelector('[data-act=psip]'); x ? x.click() : psList(); } }
  else if (act === 'psgo') { const run = ++psRun; psModalClose(); try { const x = await api.pairFinish(d.id, null); if (run === psRun) await psNext(d, x, run); } catch (er) { if (run === psRun) psFail(d, er); } }
  else if (act === 'psok') {
    const c = state.psCode, i = $('#pscode'); if (!c || !i || i.value.length !== c.len) return;
    b.disabled = true; const run = ++psRun, code = i.value;
    try { const x = await api.pairFinish(c.d.id, code); if (run !== psRun) return; psModalClose(); await psNext(c.d, x, run); }
    catch (er) {
      if (run !== psRun) return; state.lastErr = { t: Date.now(), e: er, pf: c.d.platform };
      if (er.code === 'bad_code') { sfx.error(); const e2 = $('#pserr'), i2 = $('#pscode'), ok = $('#psmodal [data-act=psok]'); if (e2) e2.textContent = 'That code didn’t match. Check the code on your TV and try again.'; if (i2) { i2.value = ''; i2.focus(); } if (ok) ok.disabled = true; }
      else psFail(c.d, er);
    }
  }
  else if (act === 'psip') {
    sfx.tap(); const R = REMOTES[psPf];
    psModal({ title: 'Enter TV address', sub: `${R.name} IP address`, input: { hex: true, placeholder: '192.168.1.50', label: 'TV IP address' }, buttons: [{ label: 'Cancel', act: 'pscancel' }, { label: 'Connect', act: 'psipgo', bold: true }] });
    const i = $('#pscode'); i.setAttribute('inputmode', 'decimal'); i.setAttribute('autocapitalize', 'none'); i.removeAttribute('maxlength');
  }
  else if (act === 'psipgo') {
    const i = $('#pscode'), host = (i && i.value || '').trim(); if (!host) { $('#pserr').textContent = 'Type the TV’s IP address first.'; return; }
    b.disabled = true; const pf = psPf;
    try {
      const nd = await api.addDevice(pf, host, `${REMOTES[pf].name} ${host}`); setLive([nd.id], true);
      for (const o of state.devices.filter((x) => x.platform === pf && !x.paired && x.id !== nd.id)) { try { await api.removeDevice(o.id); } catch (er) { /* ignore */ } }
      await refreshDevices(); const dd = state.devices.find((x) => x.id === nd.id) || nd; (state.seen || (state.seen = new Set())).add(dd.id); setLive([dd.id], true); psModalClose(); psList(); psPick(dd);
    } catch (er) { b.disabled = false; state.lastErr = { t: Date.now(), e: er, pf }; sfx.error(); state.psDev = null; psFail({ platform: pf, id: null }, er); }
  }
};
pscreen.addEventListener('click', psClick);
window.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !pscreen.hidden) closePairScreen(); });

const R_NAME = (d) => REMOTES[d.platform].name.toUpperCase();
function pairDone(d) {
  d.paired = true; setLive([d.id], true); sfx.ok(); updatePill(); refreshDevices();
  $('#pmsg').textContent = ''; $('#pbody').innerHTML = `<div class="bigck">${CHECK_SVG}</div><p class="sub" style="text-align:center">Paired. This remote is live.</p><button class="sbtn wide" data-act="close">Done</button>`;
}
const onSheetClick = async (e) => {
  const b = e.target.closest('[data-act]'); if (!b) return; unlockAudio();
  const act = b.dataset.act, id = b.dataset.id;
  if (act === 'dbgcopy') { if (dbgHeld) { dbgHeld = false; return; } return copyDbg(b); }
  if (act === 'close') closeSheet();
  if (act === 'devices') { sfx.tap(); openDevices(); }
  if (act === 'tsound') { fx.sound = !fx.sound; saveFx(); b.classList.toggle('on', fx.sound); sfx.toggle(); paintSound(); }
  if (act === 'thaptic') { fx.haptics = !fx.haptics; saveFx(); b.classList.toggle('on', fx.haptics); vibrate(25); sfx.toggle(); paintSound(); }
  if (act === 'demo') { sfx.tap(); await applyInfo(api.setDemo(!state.demo)); closeSheet(); toast(state.demo ? 'Demo mode on — nothing is sent to a TV' : 'Demo mode off'); return; }
  if (act === 'rm') { await api.removeDevice(id); await refreshDevices(); openDevices(); }
  if (act === 'pair') { closeSheet(); openPairScreen(null, id); }
  if (act === 'scan') {
    b.disabled = true; b.innerHTML = '<span class="spinner" style="display:inline-block;vertical-align:-3px;margin-right:8px"></span>Scanning…';
    try { const r = await api.discover(); state.devices = r.devices || state.devices; if (gated()) setLive(r.seen || []); updatePill(); openDevices(); sfx.ok(); } catch (er) { b.disabled = false; b.textContent = 'Scan'; $('#deverr').textContent = er.message; sfx.error(); }
  }
  if (act === 'add') {
    const host = $('#addh').value.trim(), p = $('#addp').value; if (!host) return;
    try { const nd0 = await api.addDevice(p, host, `${REMOTES[p].name} ${host}`); setLive([nd0.id], true); await refreshDevices(); openDevices(p); sfx.ok(); } catch (er) { $('#deverr').textContent = er.message; sfx.error(); }
  }
  const d = state.devices.find((x) => x.id === sheet.dataset.pair);
  if (act === 'psubmit') {
    b.disabled = true; $('#perr').textContent = '';
    try { pairStep(d, await api.pairFinish(d.id, $('#pcode').value)); } catch (er) { b.disabled = false; showPerr(er, d); sfx.error(); const i = $('#pcode'); if (i) { i.value = ''; i.dispatchEvent(new Event('input')); } }
  }
  if (act === 'pretry') openPair(state.devices.find((x) => x.id === id));
  if (act === 'pnewip') { openFind(b.dataset.p, true); }
  if (act === 'fscan') { openFind(sheet.dataset.find); }
  if (act === 'fconnect') {
    const pf = sheet.dataset.find, host = ($('#fip').value || '').trim(); if (!host) { $('#ferr').textContent = 'Type the TV’s IP address first.'; return; }
    b.disabled = true; b.textContent = 'Connecting…'; $('#ferr').textContent = '';
    try { const nd = await api.addDevice(pf, host, `${REMOTES[pf].name} ${host}`); setLive([nd.id], true); for (const o of state.devices.filter((x) => x.platform === pf && !x.paired && x.id !== nd.id)) { try { await api.removeDevice(o.id); } catch (er) { /* ignore */ } } await refreshDevices(); const dd = state.devices.find((x) => x.id === nd.id) || nd; if (dd.paired) { closeSheet(); toast(`${REMOTES[pf].name} added`); } else openPair(dd); }
    catch (er) { b.disabled = false; b.textContent = 'Connect'; state.lastErr = { t: Date.now(), e: er, pf }; $('#ferr').textContent = friendly(er, pf); const dbx = document.querySelector('#fbody .detbox .err'); if (dbx) dbx.textContent = `Connecting to ${host}: ${er.message}\n\n${dbx.textContent}`; sfx.error(); }
  }
  if (act === 'pconfirm') { b.disabled = true; try { pairStep(d, await api.pairFinish(d.id, null)); } catch (er) { b.disabled = false; showPerr(er, d); sfx.error(); } }
  if (act === 'det') { const bx = b.nextElementSibling; if (bx) { const on = bx.style.display === 'none'; bx.style.display = on ? 'block' : 'none'; b.textContent = on ? 'Hide details' : 'Details'; } }
  if (act === 'fshowip') { $('#fipwrap').style.display = 'block'; b.style.display = 'none'; const i = $('#fip'); i && i.focus(); }
  if (act === 'fpick') { const dd = state.devices.find((x) => x.id === id); if (dd) { if (dd.paired) { closeSheet(); toast(`${REMOTES[dd.platform].name} is connected`); } else openPair(dd); } }
};
body.addEventListener('click', onSheetClick);
pscreen.addEventListener('click', onSheetClick);
const pairTap = () => { unlockAudio(); sfx.tap(); const pf = ORDER[wheel.selected], d = deviceFor(pf);
  if (state.pillNote && /✗/.test(state.pillNote) && state.lastErr) { const le = state.lastErr; openSheet(`<h2>What happened</h2><p class="sub">${esc(friendly(le.e, le.pf))}</p>${detailsBlock(le.e.message)}`); return; } openPairScreen(pf); };
$('#pill').addEventListener('click', () => { if (state.pillNote && /✗/.test(state.pillNote) && state.lastErr) pairTap(); });   // the status pill never opens pairing; it only explains a failed press (PAIR is the one way in)
document.querySelectorAll('.pairbtn').forEach((b) => b.addEventListener('click', pairTap));

/* ---------------- text entry ---------------- */
function openKeyboard() {
  const pf = ORDER[wheel.selected], R = REMOTES[pf]; let typed = ''; const lines = [];
  openSheet(`<div class="kb-head"><div><div class="steps">KEYBOARD · ${esc(R.name.toUpperCase())}${state.demo ? ' · <span class="demo-tag">DEMO</span>' : ''}</div><h2>Type on your ${esc(R.name)}</h2></div><button class="sbtn ghost" data-act="kdone">Done</button></div>
    <div class="textbox"><input id="tin" enterkeyhint="search" autocomplete="off" autocapitalize="off" autocorrect="off" spellcheck="false" placeholder="Tap here and type…" aria-label="Text to send to the TV"><button class="kbtn x" data-act="kclear" aria-label="Clear text">${I.close}</button></div>
    <div class="kb-actions"><button class="kbtn" data-act="kback" aria-label="Backspace">${I.backspace}<span>Backspace</span></button><button class="kbtn primary" data-act="tenter" aria-label="Enter or search"><span>Enter / Search</span>${I.enter}</button></div>
    <div class="sec">${state.demo ? 'Demo · would send to the TV' : 'Sent to the TV'}</div><div id="kblog" class="kblog"><div class="empty">Start typing — every key shows up here.</div></div>`);
  sheet.classList.add('kbsheet');
  const inp = $('#tin'), logEl = $('#kblog');
  state.onWire = (w) => {
    if (lines.length === 0) logEl.innerHTML = '';
    lines.unshift(w); lines.length = Math.min(lines.length, 6);
    logEl.innerHTML = lines.map((l) => `<div>› ${esc(l)}</div>`).join('');
  };
  const apply = (v) => {                       // diff the field against what the TV already has
    if (pf === 'appletv') doSend({ action: 'text', mode: 'set', text: v }, pf);       // Apple TV: set the whole field
    else if (v.length > typed.length && v.startsWith(typed)) doSend({ action: 'text', mode: 'append', text: v.slice(typed.length) }, pf);
    else for (let k = typed.length; k > v.length; k--) doSend({ action: 'key', key: 'backspace' }, pf);
    typed = v; sfx.tick(0);
  };
  inp.addEventListener('input', () => apply(inp.value));
  inp.addEventListener('keydown', (ev) => { if (ev.key === 'Enter') { ev.preventDefault(); sfx.tap(); doSend({ action: 'key', key: 'enter' }, pf); } });
  const keep = (ev) => { if (ev.target.closest('.kbtn')) ev.preventDefault(); };       // buttons must not steal focus (keeps the phone keyboard up)
  body.onpointerdown = keep; body.onmousedown = keep;
  body.onclick = (ev) => {
    const b = ev.target.closest('[data-act]'); if (!b) return; const act = b.dataset.act;
    if (act === 'kback') { sfx.tap(); if (typed) { inp.value = typed.slice(0, -1); apply(inp.value); } else doSend({ action: 'key', key: 'backspace' }, pf); inp.focus(); }
    else if (act === 'kclear') { sfx.tap(); if (pf === 'appletv') { inp.value = ''; apply(''); } else { const n = Math.min(typed.length, 24); inp.value = ''; for (let k = 0; k < n; k++) doSend({ action: 'key', key: 'backspace' }, pf); typed = ''; } inp.focus(); }
    else if (act === 'tenter') { sfx.tap(); doSend({ action: 'key', key: 'enter' }, pf); inp.focus(); }
    else if (act === 'kdone') closeSheet();
  };
  inp.focus({ preventScroll: true });              // inside the tap, so phones raise the native keyboard
}

/* ---------------- voice search ----------------
   Voice button -> microphone permission (asked now, not at install) -> listening overlay with live words -> the words go to the selected TV as a search.
   "Sent" is only shown when the send really succeeded. The microphone is released on Done, Cancel, Back, a result, an error, or when the app goes to the background. */
const voiceEl = $('#voice'), vStatus = $('#v-status'), vText = $('#v-text');
let vs = null;                                                                           // { eng, pf, token } while the overlay is up
const voiceOpen = () => !voiceEl.hidden;
function vShow(cls, status, text, { done = false, retry = false } = {}) {
  voiceEl.className = cls ? 'on ' + cls : 'on'; vStatus.textContent = status; if (text != null) vText.textContent = text;
  $('#v-done').hidden = !done; $('#v-retry').hidden = !retry; $('#v-cancel').textContent = retry || cls === 'ok' ? 'Close' : 'Cancel';
}
function closeVoice() {
  if (voiceEl.hidden) return false;
  const s = vs; vs = null; if (s) { s.token = -1; try { const r = s.eng.cancel(); if (r && r.catch) r.catch(() => {}); } catch (e) { /* mic already released */ } }
  voiceEl.classList.remove('on'); voiceEl.hidden = true; return true;
}
async function openVoice() {
  if (!state.locked || voiceOpen()) return;
  const pf = ORDER[wheel.selected], d = deviceFor(pf), R = REMOTES[pf];
  if (!d || !d.paired) return;                                                            // no TV connected: quiet, like every other button
  unlockAudio(); sfx.tap(); api.log(`voice: open for ${pf}`);
  const c = await loadCaps(pf).catch(() => null); if (c && c.search === false) { toast(`Voice search isn’t available for ${R.name}.`); return; }
  const eng = voiceEngine();
  voiceEl.hidden = false; void voiceEl.offsetWidth;
  if (!eng) { vs = { eng: { cancel() {}, stop() {} }, pf, token: 0 }; vShow('err', VOICE_MSG.unavailable, '', { retry: false }); return; }
  vs = { eng, pf, token: ++voiceTok };
  vShow('', 'Getting the microphone ready…', '', { done: false });
  const tok = vs.token; let heard = '';
  const live = () => vs && vs.token === tok;
  try {
    await eng.start((ev) => {
      if (!live()) return;
      if (ev.state === 'listening' || ev.state === 'speaking') vShow('hearing', 'Listening…', heard || '', { done: true });
      else if (ev.state === 'partial') { heard = ev.text || ''; vShow('hearing', 'Listening…', heard, { done: true }); }
      else if (ev.state === 'final') { heard = (ev.text || heard || '').trim(); if (!heard) vShow('err', VOICE_MSG.no_match, '', { retry: true }); else submitVoice(heard, pf, tok); }
      else if (ev.state === 'error') { api.log('voice: ' + ev.code); vShow('err', VOICE_MSG[ev.code] || VOICE_MSG.unavailable, '', { retry: ev.code !== 'denied' && ev.code !== 'unavailable' }); }
      else if (ev.state === 'stopped') closeVoice();
    });
  } catch (e) { if (live()) vShow('err', VOICE_MSG.unavailable, '', { retry: false }); }
}
let voiceTok = 0;
async function submitVoice(text, pf, tok) {
  const live = () => vs && vs.token === tok, d = deviceFor(pf), R = REMOTES[pf];
  vShow('', `Searching your ${R.name}…`, `“${text}”`);
  try {
    const r = await api.send({ device: d.id, action: 'search', text, t_press: performance.now() });
    if (!live()) return;
    if (state.onWire) state.onWire(r.wire || 'search'); pillNote('Voice search ✓');
    if (r.how === 'typed') { pillNote('Voice search typed ✓'); vShow('ok', `Typed into your ${R.name}’s search`, `“${text}”`); } else vShow('ok', `Sent to your ${R.name}`, `“${text}”`);
    setTimeout(() => { if (live()) closeVoice(); }, 1800);
  } catch (e) {
    api.log(`voice: search ✗ ${e.message}`); if (!live()) return;
    const msg = e.code === 'no_text_field' || e.code === 'no_search' || e.code === 'empty' ? (e.code === 'no_text_field' ? `No search box opened on your ${R.name}. Open search on the TV, then try again.` : e.message) : friendly(e, pf);
    vShow('err', msg, `“${text}”`, { retry: true });
  }
}
$('#btn-voice').addEventListener('click', () => openVoice());
$('#v-done').addEventListener('click', () => { if (vs) { try { vs.eng.stop(); } catch (e) { /* not running */ } } });
$('#v-cancel').addEventListener('click', closeVoice);
$('#v-retry').addEventListener('click', () => { closeVoice(); openVoice(); });
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') closeVoice(); });     // backgrounded: the microphone must not stay open

/* sheets ride above the phone's on-screen keyboard */
if (window.visualViewport) {
  const vv = window.visualViewport, adj = () => { const b = Math.max(0, window.innerHeight - vv.height - vv.offsetTop); sheet.style.bottom = b + 'px'; sheet.style.maxHeight = Math.max(240, vv.height - 24) + 'px'; };
  vv.addEventListener('resize', adj); vv.addEventListener('scroll', adj);
}

/* ---------------- boot ---------------- */
new ResizeObserver(() => { sizeCanvas(); }).observe(stage);
sizeCanvas();
setSelected(wheel.selected);
requestAnimationFrame(frame);
if (params.has('locked')) { state.locked = true; state.pending = false; state.exTarget = state.exP = state.ex = 1; document.body.classList.add('locked'); $('#btn-back').tabIndex = 0; }
async function applyInfo(info) {          // (re)read demo/native state: the demo banner is on only while TVs are simulated
  if (info) state.info = info;
  state.demo = !!state.info.demo; $('#demo-banner').hidden = !state.demo;
  if (state.info.simulated_in_browser) $('#demo-note').textContent = 'simulated in your browser · no bridge found · no TV is controlled';
  sizeCanvas(); await refreshDevices(); checkLive();
}
api.init().then(async (info) => {
  await applyInfo(info); warmFor(ORDER[wheel.selected]);
  if (info.native && !info.demo && !state.devices.length) api.discover('roku').then((r) => { state.devices = r.devices || []; setLive(r.seen || [], true); updatePill(); }).catch(() => {});   // first launch (Rokus only: no NSD) in the app: look for TVs by itself
  if (params.has('pair')) { const d = state.devices.find((x) => !x.paired) ; }
});
if (typeof __BUNDLE__ === 'undefined' && 'serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost' || location.hostname === '127.0.0.1')) {
  navigator.serviceWorker.register('/sw.js').catch(() => {});
}

clearInterval(liveTimer); liveTimer = setInterval(() => { if (document.visibilityState === 'visible') checkLive(); }, 20000);
// test hooks
/* Android back button / gesture: step back through the app's own layers; never leave the app. Returns true when it closed something. */
function handleBack() {
  if (closeVoice()) return true;                                              // the listening overlay is the top layer: back closes it and releases the microphone
  const ad = document.getElementById('ad-full'); if (ad) { ad.remove(); return true; }
  if (!pscreen.hidden) {
    const m = $('#psmodal');
    if (m && !m.hidden && !m.querySelector('[data-act]')) return true;                                              // the brief “Paired” confirmation: let it finish
    if (m && !m.hidden) { const c = m.querySelector('[data-act=pscancel]'); if (c) c.click(); else { psRun++; psPicking = null; psModalClose(); psList(); } return true; }   // PIN / Allow / error / IP modal: same as its Cancel
    closePairScreen(); return true;
  }
  if (sheet.classList.contains('on')) { closeSheet(); return true; }          // Your TVs, Settings, Details, What happened, keyboard
  if (state.locked) { collapse(); return true; }                              // expanded remote -> back to the reel
  return false;                                                               // already on the main screen: stay (never exit)
}
if (typeof __NATIVE__ !== 'undefined' && __NATIVE__) import('./native/back.js').then((m) => m.installBack(handleBack)).catch(() => {});
window.__tv = { back: handleBack, openVoice, closeVoice, voiceOpen, loadCaps, capsCache, updatePill, wheel, state, expand, collapse, setLayout, openDevices, openPair, openSettings, openKeyboard, closeSheet, get devices() { return state.devices; }, toast };
