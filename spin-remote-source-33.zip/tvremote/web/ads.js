// FAKE sample ads: no ad SDK, no network calls, nothing is fetched or tracked. Every creative is made here (CSS gradients and shapes, invented brand names), none uses a real company, logo or trademark.
//  1. #ad-banner: a 50px strip under the header, always shown, no close button and no controls. Two stacked layers cross-fade to the next creative every AD_ROTATE_MS (20 s) — the strip's size never changes, so nothing around it moves.
//  2. #ad-full: a full-screen sample ad shown once per app launch, with a "Close ad" button at its top right; closing it reveals the app.
// Both carry a small "Ad" label. Everything sits behind ADS_PLACEHOLDERS_ENABLED (config.js).
import { ADS_PLACEHOLDERS_ENABLED, AD_ROTATE_MS } from './config.js';
export const FAKE_ADS = [
  { brand: 'SampleBrand', slogan: 'Your ad here', a: '#ff7a59', b: '#ffb347', shape: 'circle' },
  { brand: 'Fakeco Snacks', slogan: 'Crunch that isn’t real', a: '#1fa2a6', b: '#2b5876', shape: 'diamond' },
  { brand: 'Nimbly Demo', slogan: 'Sample slogan goes here', a: '#7b4397', b: '#dc2430', shape: 'bars' },
  { brand: 'Orbit Dummy Co.', slogan: 'A placeholder, not a product', a: '#11998e', b: '#7ed957', shape: 'ring' },
];
let shownThisLaunch = false, timer = null, cur = 0, front = 0, layers = [];
function creative(ad, kind) {                                            // one creative as plain DOM: gradient background, one decorative shape, brand + slogan, and the "Ad" label
  const el = document.createElement('div'); el.className = `adc adc-${kind}`; el.style.background = `linear-gradient(120deg, ${ad.a}, ${ad.b})`;
  const sh = document.createElement('span'); sh.className = `adc-shape adc-${ad.shape}`; sh.setAttribute('aria-hidden', 'true');
  const tx = document.createElement('span'); tx.className = 'adc-text';
  const br = document.createElement('b'); br.className = 'adc-brand'; br.textContent = ad.brand;
  const sl = document.createElement('span'); sl.className = 'adc-slogan'; sl.textContent = ad.slogan;
  const lb = document.createElement('i'); lb.className = 'adc-label'; lb.textContent = 'Ad';
  tx.append(br, sl); el.append(sh, tx, lb); return el;
}
/** Show the next banner creative (exported so tests can step the rotation without waiting 20 s). */
export function rotateBanner() {
  if (layers.length < 2) return;
  cur = (cur + 1) % FAKE_ADS.length; const back = layers[1 - front];
  back.replaceChildren(creative(FAKE_ADS[cur], 'banner')); back.classList.add('on'); layers[front].classList.remove('on'); front = 1 - front;
}
export function initAds() {
  if (!ADS_PLACEHOLDERS_ENABLED) return;
  const top = document.getElementById('top'); if (!top) return;
  const banner = document.createElement('div'); banner.id = 'ad-banner'; banner.setAttribute('aria-hidden', 'true'); banner.dataset.ad = 'banner';
  layers = [0, 1].map(() => { const l = document.createElement('div'); l.className = 'ad-layer'; banner.append(l); return l; });
  cur = 0; front = 0; layers[0].append(creative(FAKE_ADS[0], 'banner')); layers[0].classList.add('on');
  top.after(banner);
  clearInterval(timer); timer = setInterval(() => { if (!document.hidden && banner.isConnected) rotateBanner(); }, AD_ROTATE_MS);
  if (shownThisLaunch) return; shownThisLaunch = true;
  const full = document.createElement('div'); full.id = 'ad-full'; full.dataset.ad = 'fullscreen'; full.setAttribute('role', 'dialog'); full.setAttribute('aria-label', 'Advertisement');
  const close = document.createElement('button'); close.id = 'ad-close'; close.type = 'button'; close.textContent = 'Close ad';
  close.addEventListener('click', () => full.remove());                 // a plain removal: the app underneath is already running
  full.append(creative(FAKE_ADS[0], 'full'), close); document.body.append(full);
}
