// Voice engines behind one tiny interface:   engine.start(cb) · engine.stop() (done speaking: deliver what was heard) · engine.cancel() (release the microphone, deliver nothing)
// cb({ state: 'listening' | 'speaking' | 'partial' | 'final' | 'error' | 'stopped', text?, code? })   error codes: denied · unavailable · no_speech · no_match · network · busy · audio
//   Android app ... the TvNative plugin (Android SpeechRecognizer; RECORD_AUDIO is requested by voiceStart, i.e. only when the voice button is pressed)
//   browser ....... Web Speech API where the browser has it
//   tests ......... window.__voiceMock, a scripted recognizer
import { getPlugin } from './native/plug.js';

function nativeEngine(P) {
  let h = null;
  const drop = async () => { const x = h; h = null; if (x) { try { await x.remove(); } catch { /* already gone */ } } };
  return {
    async start(cb) {
      await drop();
      h = await P.addListener('voice', (ev) => { cb(ev); if (ev.state === 'final' || ev.state === 'error' || ev.state === 'stopped') drop(); });
      let r; try { r = await P.voiceStart(); } catch { r = { state: 'unavailable' }; }
      if (r && (r.state === 'denied' || r.state === 'unavailable')) { await drop(); cb({ state: 'error', code: r.state }); }
      else if (r && r.state === 'stopped') { await drop(); cb({ state: 'stopped' }); }
    },
    stop() { return P.voiceStop().catch(() => {}); },
    async cancel() { await drop(); try { await P.voiceCancel(); } catch { /* nothing running */ } },
  };
}
function webEngine(SR) {
  let rec = null, dead = false;
  return {
    async start(cb) {
      rec = new SR(); dead = false; rec.interimResults = true; rec.continuous = false; rec.lang = navigator.language || 'en-US';
      rec.onstart = () => cb({ state: 'listening' });
      rec.onspeechstart = () => cb({ state: 'speaking' });
      rec.onresult = (e) => { const r = e.results[e.results.length - 1]; const t = r[0].transcript; cb(r.isFinal ? { state: 'final', text: t } : { state: 'partial', text: t }); };
      rec.onerror = (e) => { if (dead) return; const c = { 'not-allowed': 'denied', 'service-not-allowed': 'denied', 'no-speech': 'no_speech', network: 'network', 'audio-capture': 'audio' }[e.error] || 'unavailable'; cb({ state: 'error', code: c }); };
      try { rec.start(); } catch { cb({ state: 'error', code: 'unavailable' }); }
    },
    stop() { try { rec && rec.stop(); } catch { /* not running */ } },
    cancel() { dead = true; try { rec && rec.abort(); } catch { /* not running */ } rec = null; },
  };
}
export function voiceEngine() {
  const P = getPlugin();
  if (P && P.voiceStart) return nativeEngine(P);
  if (typeof window !== 'undefined' && window.__voiceMock) return window.__voiceMock;
  const SR = typeof window !== 'undefined' && (window.SpeechRecognition || window.webkitSpeechRecognition);
  return SR ? webEngine(SR) : null;
}
/** Plain-language text for each failure (no codes, no jargon). */
export const VOICE_MSG = {
  denied: 'Microphone access is turned off. Allow it for Spin Remote in your phone’s settings to use voice search.',
  unavailable: 'Voice search isn’t available on this phone right now.',
  no_speech: 'I didn’t hear anything. Tap the mic and try again.',
  no_match: 'I didn’t catch that. Tap the mic and try again.',
  network: 'Voice search needs an internet connection on this phone.',
  busy: 'The microphone is busy. Try again in a moment.',
  audio: 'The microphone isn’t working right now. Try again in a moment.',
};
