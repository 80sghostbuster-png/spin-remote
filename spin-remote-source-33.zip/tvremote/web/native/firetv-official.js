// Build 27: Fire TV = the official app's way first, the build 21 ADB path as an automatic, silent fallback.
//  pairing:  wake the Fire TV remote service → the TV shows a 4-digit code → typed into the shared PIN popup → token.
//            No service / no code / code check fails → build 21 ADB pairing (press Allow on the TV), unchanged.
//  buttons:  with a token, arrows/OK/Back/Home/Menu/Play go through the official remote API; any failure → the same press over ADB.
//            Build 28: volume up/down/mute, rewind, fast-forward and backspace too (see firetv-lightning.js OFFICIAL).
//            Without a token (TVs paired by build ≤26, or no service) every press is the build 21 ADB path, byte for byte.
//  typing:   official POST /v1/FireTV/text (then /keyboard); ADB `input text` fallback.
//  voice search: official app list → search app → typed words; ADB GLOBAL_SEARCH + `input text` fallback.
//  apps: the build 21 ADB path.
//  With a token, ADB is also connected quietly in the background so the fallback is ready when needed.
import { adb } from './firetv.js';
import { lightning } from './firetv-lightning.js';
import { err } from './bytes.js';
import { dlog } from './dbg.js';

const badCodes = new Map();
const bgAsked = new Set();   // devices we already asked (this app session) to trust the ADB fallback
const CODE = { status: 'code', kind: 'digits', length: 4, message: 'Type the 4-digit code shown on your TV.' };

export const fire = {
  ...adb,
  /** Manual add by IP: ADB port, or the official remote service (works with ADB debugging off). */
  async probe(host, ports = { adb: 5555 }) {
    try { return await adb.probe(host, ports); }
    catch (e) { if (await lightning.reachable({ host, ports: {} })) { dlog(`fire: ${host} has no ADB, but answers on the Fire TV remote service`); return true; } throw e; }
  },
  async pairStart(dev, store) {
    badCodes.delete(dev.id);
    if (await lightning.pinDisplay(dev)) return { ...CODE };
    dlog('fire: official pairing unavailable; using ADB (build 21)');
    return adb.pairStart(dev, store);
  },
  async pairFinish(dev, store, code) {
    if (!code) return adb.pairFinish(dev, store);
    try { await lightning.pinVerify(dev, store, code); badCodes.delete(dev.id); return { status: 'paired' }; }
    catch (e) {
      if (e.code === 'bad_code') {
        const n = (badCodes.get(dev.id) || 0) + 1; badCodes.set(dev.id, n);
        if (n < 3) throw e;
        dlog('fire: 3 wrong codes; using ADB (build 21)');
      } else dlog(`fire: code check failed (${e.message}); using ADB (build 21)`);
      badCodes.delete(dev.id); return adb.pairStart(dev, store);
    }
  },
  async key(dev, key, store, opts = {}) {
    if (lightning.token(dev, store) && lightning.pathsFor(key)) {
      try { return await lightning.key(dev, store, key); }
      catch (e) { dlog(`fire: official ${key} failed (${e.message}); sending over ADB`); }
    }
    return adb.key(dev, key, store, opts);
  },
  async text(dev, text, store, o = {}) {
    if (lightning.token(dev, store) && String(text || '')) {
      try { return await lightning.text(dev, store, String(text)); }
      catch (e) { dlog(`fire: official typing failed (${e.message}); typing over ADB`); }
    }
    return adb.text(dev, text, store, o);
  },
  /** Voice search: the words land in the Fire TV's search, like on Roku. Official first, ADB if any step is refused. */
  async search(dev, text, store, o = {}) {
    const words = String(text || '').replace(/\s+/g, ' ').trim();
    if (!words) throw err('Nothing to search for.', 'empty');
    if (lightning.token(dev, store)) {
      try {
        const app = await lightning.openSearch(dev, store);
        await new Promise((r) => setTimeout(r, o.settleMs == null ? 1500 : o.settleMs));   // the search screen needs a moment before it accepts typing
        const w = await lightning.text(dev, store, words);
        o.how = 'typed'; return `Fire TV remote: opened ${app}; ${w} "${words}"`;
      } catch (e) { dlog(`fire: official voice search failed (${e.message}); using ADB`); }
    }
    return adb.search(dev, text, store, o);
  },
  async warm(dev, store) {
    if (lightning.token(dev, store)) {                       // paired the official way: also get the build 21 ADB connection ready for the fallback (volume etc.)
      lightning.warm(dev, store).catch(() => {});
      adb.warm(dev, store).catch((e) => {
        dlog(`fire: background ADB connect: ${e.message}`);
        if (e.code === 'not_paired' && !bgAsked.has(dev.id)) {   // ADB debugging on but this phone not trusted yet: offer the key once (TV shows its Allow prompt)
          bgAsked.add(dev.id); adb.pairStart(dev, store).then((r) => dlog(`fire: background ADB pairing: ${r.status}`)).catch((e2) => dlog(`fire: background ADB pairing: ${e2.message}`));
        }
      });
      return;
    }
    return adb.warm(dev, store);
  },
  async volumeCaps(dev, store) {
    if (lightning.token(dev, store)) return 'yes';   // build 30: the official remote sends volume to the TV itself (HDMI-CEC); the Fire TV's own fixed-volume flag (ADB) must not hide the buttons
    return adb.volumeCaps(dev, store);
  },
  closeAll() { adb.closeAll(); lightning.closeAll(); },
  hasAck: adb.hasAck,
};
export { err };
