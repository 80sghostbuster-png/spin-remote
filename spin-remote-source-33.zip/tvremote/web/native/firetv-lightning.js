// Build 27: Amazon's own Fire TV remote protocol — what the official Fire TV phone app (com.amazon.storm.lightning.client.aosp) does.
// No ADB, no developer options. Original code; the sequence, ports, headers and timeouts follow (see THIRD_PARTY_NOTICES.md):
//   hms-firetv (MIT; README "Fire TV protocol" — recovered from the official app's own request log, LightningClient.cpp, DiscoveryService.cpp),
//   debloat-fire-stick-claude-code tools/firetv.py (MIT), SLC-Josh/FireTVRest + Home Assistant forum "Rest commands for Fire TV" (notes),
//   uc-intg-firetv client.py (MPL-2.0 — facts only, no code copied).
//
//   wake:    POST http://<tv>:8009/apps/FireTVRemote (DIAL; empty body; answers while asleep). The API on 8080 only listens while this
//            FireTVRemote app runs. If 8009 refuses: read the DIAL "Application-URL" from http://<tv>:60000/dd.xml (DIAL description,
//            answers while asleep) and POST <Application-URL>FireTVRemote.
//   ready:   poll https://<tv>:8080/ until it answers anything (waking takes ~1–4 s; we allow 10 s).
//   pair:    POST /v1/FireTV/pin/display {"friendlyName"} → TV shows a 4-digit PIN; POST /v1/FireTV/pin/verify {"pin"} → {"description": token}
//   keys:    POST /v1/FireTV?action=dpad_up|dpad_down|dpad_left|dpad_right|select|back|home|menu   — NO body (a body → HTTP 500)
//            POST /v1/media?action=play (play/pause)
//   headers: X-Api-Key: 0987654321 (fixed app key), X-Client-Token: <token> (after pairing), Content-Type: application/json,
//            User-Agent: okhttp/4.12.0 (the official app's HTTP stack). TLS with the TV's self-signed certificate (not verified).
import { Sock } from './sock.js';
import { err } from './bytes.js';
import { dlog } from './dbg.js';
import { fireVolume } from './firetv-volume.js';   // build 33: Fire TV volume/mute live in their own file

const API_KEY = '0987654321', UA = 'okhttp/4.12.0'   // build 33: the version inside the official app;
// Build 28: each button → the official app's requests, in the order to try (first 2xx wins; a rejected variant is not retried on that TV).
//  volume: /v1/FireTV?action=volume_up|volume_down|mute (uc-intg-firetv device.py nav list; hms CommandHandler.cpp volume_up/volume_down/volume_mute)
//  rewind/fast-forward: /v1/media?action=scan&direction=back|forward (hms LightningClient.cpp scanBackward/scanForward; uc client.py rewind/fast_forward)
/** Official scan body (one tap = 10 s at normal speed). */
export const SCAN = (direction) => ({ direction, durationInSeconds: '10', speed: '1' });
/** Random request id, as the official app sends with every request (x-amzn-request-id, UUID v4 form). */
export function reqId() {
  const b = new Uint8Array(16); if (globalThis.crypto && crypto.getRandomValues) crypto.getRandomValues(b); else for (let i = 0; i < 16; i++) b[i] = Math.floor(Math.random() * 256);
  b[6] = (b[6] & 0x0f) | 0x40; b[8] = (b[8] & 0x3f) | 0x80; const h = [...b].map((x) => x.toString(16).padStart(2, '0')).join('');
  return `${h.slice(0, 8)}-${h.slice(8, 12)}-${h.slice(12, 16)}-${h.slice(16, 20)}-${h.slice(20)}`;
}
export const OFFICIAL = {
  up: ['/v1/FireTV?action=dpad_up'], down: ['/v1/FireTV?action=dpad_down'], left: ['/v1/FireTV?action=dpad_left'], right: ['/v1/FireTV?action=dpad_right'],
  select: ['/v1/FireTV?action=select'], back: ['/v1/FireTV?action=back'], home: ['/v1/FireTV?action=home'], menu: ['/v1/FireTV?action=menu'], options: ['/v1/FireTV?action=menu'],
  // Build 30: the official app's own requests come FIRST (facts read from the official app for interoperability; see docs/FIRETV-PROTOCOL.md):
  //  play/pause tap = POST /v1/media?action=play, no body. rewind/ff tap = POST /v1/media?action=scan with
  //  {"direction":"back"|"forward","durationInSeconds":"10","speed":"1"}. volume/mute tap = POST /v1/FireTV?action=volume_up|volume_down|mute, no body.
  //  The older build 28/29 forms stay behind them as extra tries.
  play_pause: ['/v1/media?action=play', ['/v1/media?action=play', { keyAction: { keyActionType: 'keyDownUp' } }], '/v1/media?action=pause'],
  play: ['/v1/media?action=play', ['/v1/media?action=play', { keyAction: { keyActionType: 'keyDownUp' } }]],
  pause: ['/v1/media?action=play', '/v1/media?action=pause'],
  rew: [['/v1/media?action=scan', SCAN('back')], '/v1/media?action=scan&direction=back', ['/v1/media?action=scan', { direction: 'back', keyAction: { keyActionType: 'keyDownUp' } }]],
  ff: [['/v1/media?action=scan', SCAN('forward')], '/v1/media?action=scan&direction=forward', ['/v1/media?action=scan', { direction: 'forward', keyAction: { keyActionType: 'keyDownUp' } }]],
  // vol_up / vol_down / mute: see firetv-volume.js (build 33)
  backspace: ['/v1/FireTV?action=backspace'],
};
const works = new Map();        // dev.id -> { key: variant label } that this TV accepted (tried first next time)
const refused = new Map();      // dev.id -> Set of request paths this TV answered with an error (skip them next time, go straight to the next variant / ADB)
const tokKey = (dev) => `ftv.lightning.${dev.id}`;
const te = new TextEncoder(), td = new TextDecoder();
const T_WAKE = 5000, T_HEALTH = 2000, T_CMD = 10000, T_KEY = 3000, POLL_MS = 700, READY_MS = 10000, T_OPEN = 2000;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const alt = new Map();          // dev.id -> 8443 when 8080 refuses and 8443 answers (port some setups document)
const P = (dev) => ({ api: (dev.ports && dev.ports.lightning) || alt.get(dev.id) || 8080, dial: (dev.ports && dev.ports.dial) || 8009, dd: (dev.ports && dev.ports.dialdd) || 60000 });
const info = new Map();          // dev.id -> GET /v1/FireTV answer (build 32, for the log)
const live = new Map();          // dev.id -> { sock } kept-open HTTPS connection for button presses (okhttp keeps connections alive too)
const qs = new Map();            // dev.id -> request chain (one at a time per TV, in order)

/** One HTTP/1.1 response. `ended` = connection closed (a body without length runs to the end). */
function httpResp(b, ended = false) {
  const s = td.decode(b), h = s.indexOf('\r\n\r\n'); if (h < 0) return null;
  const head = s.slice(0, h), st = +(/^HTTP\/1\.\d (\d+)/.exec(head) || [])[1] || 0;
  const cl = /\r\ncontent-length:\s*(\d+)/i.exec(head), hb = te.encode(s.slice(0, h + 4)).length;
  if (cl) { const n = +cl[1]; if (b.length < hb + n) return null; return { n: hb + n, v: { status: st, body: td.decode(b.subarray(hb, hb + n)), raw: b.slice(hb, hb + n), head } }; }
  if (/\r\ntransfer-encoding:\s*chunked/i.test(head)) {
    let i = hb, out = '';
    for (;;) { const rest = td.decode(b.subarray(i)), e = rest.indexOf('\r\n'); if (e < 0) return null; const len = parseInt(rest.slice(0, e), 16); const start = i + te.encode(rest.slice(0, e + 2)).length; if (len === 0) return { n: b.length, v: { status: st, body: out, head } }; if (b.length < start + len + 2) return null; out += td.decode(b.subarray(start, start + len)); i = start + len + 2; }
  }
  if (/^HTTP\/1\.\d (1\d\d|204|304)/.test(head)) return { n: hb, v: { status: st, body: '', head } };
  return ended ? { n: b.length, v: { status: st, body: td.decode(b.subarray(hb)), head } } : null;
}
function reqBytes(dev, { tls, port, method, path, body, token, keep, ctype, gzip }) {
  // Build 32: okhttp's order and casing (what the official app's HTTP stack puts on the wire): the app's own headers, then
  // Content-Type/Content-Length (only when there is a request body: POST always has one, empty if nothing), Host, Connection, Accept-Encoding, User-Agent.
  const b = body == null ? '' : JSON.stringify(body), post = method !== 'GET';
  const h = [`${method} ${path} HTTP/1.1`];
  if (tls) { h.push(`x-amzn-request-id: ${reqId()}`, `x-api-key: ${API_KEY}`); if (token) h.push(`x-client-token: ${token}`); if (post) h.push('Content-Type: application/json; charset=utf-8'); }
  else if (ctype) h.push(`Content-Type: ${ctype}`);
  if (post || b) h.push(`Content-Length: ${te.encode(b).length}`);
  h.push(`Host: ${dev.host}:${port}`, `Connection: ${keep ? 'Keep-Alive' : 'close'}`, `Accept-Encoding: ${gzip ? 'gzip' : 'identity'}`, `User-Agent: ${UA}`);
  return te.encode(h.join('\r\n') + '\r\n\r\n' + b);
}
async function readResp(sock, ms) {
  let v;
  try { v = await sock.waitFor((x) => httpResp(x), ms); }
  catch (e) { const r = e.code === 'closed' ? httpResp(sock.buf, true) : null; if (!r) throw e; v = r.v; }
  return gunzip(v);
}
/** Build 33: we may say "Accept-Encoding: gzip" like OkHttp does, so unpack a gzip answer. */
async function gunzip(v) {
  if (!v || !/\r\ncontent-encoding:\s*gzip/i.test(v.head || '')) return v;
  if (!v.raw || typeof DecompressionStream === 'undefined') return { ...v, body: `(gzip, ${v.raw ? v.raw.length : '?'} bytes, not unpacked)` };
  try { const out = await new Response(new Blob([v.raw]).stream().pipeThrough(new DecompressionStream('gzip'))).arrayBuffer(); return { ...v, body: td.decode(new Uint8Array(out)) }; }
  catch (e) { return { ...v, body: `(gzip unpack failed: ${e.message})` }; }
}
/** One request on its own connection. Throws 'unreachable' when nothing listens. */
async function http(dev, o) {
  const sock = await Sock.open({ host: dev.host, port: o.port, tls: o.tls, timeoutMs: Math.min(T_OPEN, o.ms) });
  try { await sock.write(reqBytes(dev, o)); return await readResp(sock, o.ms); } finally { sock.close(); }
}
const statusLine = (r) => ((r.head || '').split('\r\n')[0] || `HTTP ${r.status}`);
const ok2xx = (r) => r.status >= 200 && r.status < 300;
/** Accepted = 2xx AND the body isn't an error message (some Fire OS builds answer 200 with an error description). */
export function accepted(r) {
  if (!ok2xx(r)) return false;
  let d = r.body || ''; try { const j = JSON.parse(r.body); d = typeof j === 'string' ? j : [j.description, j.error, j.message, j.status].filter((x) => typeof x === 'string').join(' '); } catch (e) { /* plain text */ }
  return !/(error|exception|fail|invalid|unsupported|not (supported|found|allowed|available|paired))/i.test(d);
}

/** DIAL wake. 8009 first (every source); if that port refuses, the Application-URL from the DIAL description on 60000. */
async function wake(dev) {
  const t0 = Date.now(), p = P(dev);
  try { const r = await http(dev, { tls: false, port: p.dial, method: 'POST', path: '/apps/FireTVRemote', ctype: 'text/plain; charset=utf-8', ms: T_WAKE }); dlog(`fire: wake :${p.dial} → HTTP ${r.status} (${Date.now() - t0} ms)`); return true; }
  catch (e) { dlog(`fire: wake :${p.dial} failed: ${e.message}`); }
  try {
    const d = await http(dev, { tls: false, port: p.dd, method: 'GET', path: '/dd.xml', ms: T_HEALTH });
    const m = /\r\napplication-url:\s*http:\/\/[^:/\s]+:(\d+)(\/[^\s]*)/i.exec(d.head);
    if (!m) { dlog(`fire: DIAL description on :${p.dd} has no Application-URL (HTTP ${d.status})`); return false; }
    const base = m[2].endsWith('/') ? m[2] : m[2] + '/';
    const r = await http(dev, { tls: false, port: +m[1], method: 'POST', path: base + 'FireTVRemote', ctype: 'text/plain; charset=utf-8', ms: T_WAKE });
    dlog(`fire: wake via DIAL Application-URL :${m[1]}${base} → HTTP ${r.status}`); return true;
  } catch (e) { dlog(`fire: DIAL description :${p.dd} failed: ${e.message}`); return false; }
}
async function apiUp(dev) {
  const tryPort = async (port) => { try { const r = await http(dev, { tls: true, port, method: 'GET', path: '/', ms: T_HEALTH }); return r.status > 0; } catch (e) { return false; } };
  if (await tryPort(P(dev).api)) return true;
  if (!(dev.ports && dev.ports.lightning) && !alt.has(dev.id) && dev.id && await tryPort(8443)) { alt.set(dev.id, 8443); dlog('fire: remote service answers on 8443'); return true; }
  return false;
}
/** Wake and wait until the API answers. false fast when this TV has no Fire TV remote service at all (nothing on 8009/60000/8080). */
async function wakeAndWait(dev) {
  const t0 = Date.now(), woke = await wake(dev);
  if (await apiUp(dev)) return true;
  if (!woke) return false;
  while (Date.now() - t0 < READY_MS) { await sleep(POLL_MS); if (await apiUp(dev)) { dlog(`fire: remote service up after ${Date.now() - t0} ms`); return true; } }
  dlog(`fire: remote service did not start within ${READY_MS} ms`); return false;
}
const api = (dev, path, body, token) => http(dev, { tls: true, port: P(dev).api, method: 'POST', path, body, token, ms: T_CMD });

/** A button press on the kept-open connection; reconnects once, and wakes the service once if it isn't listening. */
function press(dev, path, token, body = null, gzip = false) {
  const run = async () => {
    for (let attempt = 0; ; attempt++) {
      let c = live.get(dev.id);
      try {
        if (!c || c.sock.closed) { c = { sock: await Sock.open({ host: dev.host, port: P(dev).api, tls: true, timeoutMs: T_OPEN }) }; live.set(dev.id, c); }
        await c.sock.write(reqBytes(dev, { tls: true, port: P(dev).api, method: 'POST', path, body, token, keep: true, gzip }));
        const r = await readResp(c.sock, T_KEY);
        if (/\r\nconnection:\s*close/i.test(r.head)) { c.sock.close(); live.delete(dev.id); }
        return r;
      } catch (e) {
        if (c) { c.sock.close(); live.delete(dev.id); }
        if (attempt >= 1) throw e;
        if (e.code === 'unreachable' && !(await wakeAndWait(dev))) throw e;
      }
    }
  };
  const p = (qs.get(dev.id) || Promise.resolve()).then(run); qs.set(dev.id, p.catch(() => {})); return p;
}

const VOLUME_KEYS = new Set(['vol_up', 'vol_down', 'mute']);
/** What firetv-volume.js may use: OkHttp-shaped requests (keep-alive, gzip) on the button connection, plus GET reads. */
const wire = {
  send: (dev, path, token, body) => press(dev, path, token, body, true),
  get: (dev, path, token) => { const run = () => http(dev, { tls: true, port: P(dev).api, method: 'GET', path, token, ms: T_KEY, gzip: true }); const p = (qs.get(dev.id) || Promise.resolve()).then(run); qs.set(dev.id, p.catch(() => {})); return p; },
  token: (dev, store) => store.get(tokKey(dev)) || null,
  statusLine: (r) => statusLine(r), dlog: (m) => dlog(m), err: (m, c) => err(m, c),
};
export const lightning = {
  token: (dev, store) => store.get(tokKey(dev)) || null,
  /** Wake, wait for the service, ask the TV to show its 4-digit code. true = the code is on screen. Never throws. */
  async pinDisplay(dev) {
    try {
      if (!(await wakeAndWait(dev))) return false;
      const r = await api(dev, '/v1/FireTV/pin/display', { friendlyName: 'Spin Remote' });
      dlog(`fire: pin/display → HTTP ${r.status} ${r.body.slice(0, 80)}`); return ok2xx(r);
    } catch (e) { dlog('fire: pin/display failed: ' + e.message); return false; }
  },
  /** Throws 'bad_code' for a wrong code; other errors mean the service is unusable right now. */
  async pinVerify(dev, store, pin) {
    const send = () => api(dev, '/v1/FireTV/pin/verify', { pin: String(pin).trim() });
    let r; try { r = await send(); } catch (e) { if (e.code !== 'unreachable' || !(await wakeAndWait(dev))) throw e; r = await send(); }
    let tok = ''; try { tok = JSON.parse(r.body).description || ''; } catch (e) { /* */ }
    if (r.status >= 500) throw err(`Fire TV answered HTTP ${r.status}`, 'protocol');
    if (!ok2xx(r) || !tok || tok === 'OK') throw err('That code is not right — check the TV and try again.', 'bad_code');
    store.set(tokKey(dev), tok); dlog('fire: paired with the Fire TV remote service (token saved)'); return true;
  },
  /** The request paths for a key (official app order), or null when the official remote has no such button. */
  pathsFor(key) { return OFFICIAL[key] || (VOLUME_KEYS.has(key) ? ['firetv-volume.js'] : null); },
  pathFor(key) { return OFFICIAL[key] ? OFFICIAL[key][0] : null; },
  /** One press through the official API. Tries each documented variant; throws when none is accepted (the caller falls back to ADB). */
  async key(dev, store, key) {
    // Build 31: every button is ONE request, the official app's own form (OFFICIAL[key][0]) — exactly like the arrows. No variants, no
    // skip memory, no guards. Anything but an accepted answer throws, and the caller sends the press over ADB (build 21) instead.
    if (VOLUME_KEYS.has(key)) return fireVolume(wire, dev, store, key);   // build 33: volume/mute → firetv-volume.js
    const tok = lightning.token(dev, store), list = OFFICIAL[key]; if (!tok || !list) return null;
    const v = Array.isArray(list[0]) ? { path: list[0][0], body: list[0][1] } : { path: list[0], body: null };
    const t0 = Date.now(), r = await press(dev, v.path, tok, v.body);
    dlog(`fire: ${key} ${v.path}${v.body ? ' ' + JSON.stringify(v.body) : ''} → ${statusLine(r)} body: ${r.body || '(empty)'}`);   // build 32: the TV's full answer
    if (r.status === 401 || r.status === 403) { store.del(tokKey(dev)); throw err('The Fire TV no longer accepts this phone’s code', 'not_paired'); }
    if (r.status >= 200 && r.status < 300) return `Fire TV remote ${v.path}${v.body ? ' ' + JSON.stringify(v.body) : ''} (${Date.now() - t0} ms)`;
    throw err(`Fire TV did not accept "${key}" (HTTP ${r.status}${r.body ? ' ' + r.body.slice(0, 60) : ''})`, 'protocol');
  },
  /** Typing through the official API: POST /v1/FireTV/text {"text"} (uc-intg-firetv client.py send_text), then /v1/FireTV/keyboard {"text"} (hms LightningClient.cpp sendKeyboardInput). */
  async text(dev, store, text) {
    const tok = lightning.token(dev, store); if (!tok) return null;
    const bad = refused.get(dev.id) || new Set(); refused.set(dev.id, bad); let last = null;
    for (const path of ['/v1/FireTV/text', '/v1/FireTV/keyboard']) {
      if (bad.has(path)) continue;
      let r; try { r = await api(dev, path, { text }, tok); } catch (e) { if (e.code !== 'unreachable' || !(await wakeAndWait(dev))) throw e; r = await api(dev, path, { text }, tok); }
      if (r.status === 401 || r.status === 403) { store.del(tokKey(dev)); throw err('The Fire TV no longer accepts this phone’s code', 'not_paired'); }
      if (accepted(r)) return `Fire TV remote ${path}`;
      bad.add(path); last = r.status;
    }
    throw err(`Fire TV did not accept the typing${last ? ` (HTTP ${last})` : ''}`, 'protocol');
  },
  /** Open the TV's search screen through the official API: the installed-apps list (GET /v1/FireTV/appsV2) → the search app → POST /v1/FireTV/app/<package>. */
  async openSearch(dev, store) {
    const tok = lightning.token(dev, store); if (!tok) return null;
    const r = await http(dev, { tls: true, port: P(dev).api, method: 'GET', path: '/v1/FireTV/appsV2', token: tok, ms: T_CMD });
    if (!ok2xx(r)) throw err(`Fire TV app list: HTTP ${r.status}`, 'protocol');
    const pkgs = []; try { const walk = (v) => { if (Array.isArray(v)) v.forEach(walk); else if (v && typeof v === 'object') { const id = v.appId || v.packageName || v.package || v.id; const nm = String(v.name || v.appName || v.displayName || ''); if (typeof id === 'string') pkgs.push({ id, nm }); Object.values(v).forEach(walk); } }; walk(JSON.parse(r.body)); } catch (e) { /* */ }
    const hit = pkgs.find((a) => /search/i.test(a.id)) || pkgs.find((a) => /^search$/i.test(a.nm.trim()) || /\bsearch\b|^find$/i.test(a.nm));
    if (!hit) throw err('No search app in the Fire TV app list', 'no_search');
    const l = await api(dev, `/v1/FireTV/app/${hit.id}`, null, tok);
    if (!ok2xx(l)) throw err(`Fire TV search app: HTTP ${l.status}`, 'protocol');
    return hit.id;
  },
  async warm(dev, store) { if (lightning.token(dev, store)) { await wakeAndWait(dev); await lightning.info(dev, store).catch((e) => dlog('fire: device info failed: ' + e.message)); return true; } return false; },
  /** Build 32: what the official app reads first — GET /v1/FireTV (device info). Its isVolumeControlsSupported /
   *  volumeCapabilityLevelOfSupport say whether the TV can change volume (HDMI-CEC). Logged in full; never blocks a button. */
  async info(dev, store) {
    const tok = lightning.token(dev, store); if (!tok) return null;
    const r = await http(dev, { tls: true, port: P(dev).api, method: 'GET', path: '/v1/FireTV', token: tok, ms: T_CMD });
    dlog(`fire: GET /v1/FireTV → ${statusLine(r)} body: ${r.body || '(empty)'}`);
    let j = null; try { j = JSON.parse(r.body); } catch (e) { /* */ }
    if (j && typeof j === 'object') { info.set(dev.id, j); dlog(`fire: TV says volume supported = ${j.isVolumeControlsSupported}, volume level = ${j.volumeCapabilityLevelOfSupport}, power level = ${j.powerCapabilityLevelOfSupport}`); }
    for (const pth of ['/v1/FireTV/status', '/v1/FireTV/properties']) {   // the other two reads the official app makes on a connected TV (logged only)
      try { const x = await http(dev, { tls: true, port: P(dev).api, method: 'GET', path: pth, token: tok, ms: T_CMD }); dlog(`fire: GET ${pth} → ${statusLine(x)} body: ${(x.body || '(empty)').slice(0, 600)}`); } catch (e) { dlog(`fire: GET ${pth} failed: ${e.message}`); }
    }
    return j;
  },
  async reachable(dev) { try { await http(dev, { tls: false, port: P(dev).dial, method: 'GET', path: '/apps/FireTVRemote', ms: T_HEALTH }); return true; } catch (e) { return false; } },
  forget(dev, store) { store.del(tokKey(dev)); refused.delete(dev.id); works.delete(dev.id); const c = live.get(dev.id); if (c) c.sock.close(); live.delete(dev.id); },
  closeAll() { for (const c of live.values()) c.sock.close(); live.clear(); qs.clear(); },
};
