// Native backend: implements the same contract as the bridge's /api/* (see ../api.js) but talks to the TVs directly from the phone.
//   Roku ........ ECP over HTTP (fully implemented, no pairing)
//   Google TV ... Android TV remote v2 (TLS + protobuf, pairing code)         [tested against a self-written mock only]
//   Fire TV ..... ADB over network (needs ADB debugging on; Allow prompt)      [tested against a self-written mock only]
//   Apple TV .... not implemented (demo mode only)
import { T, setTransport } from './transport.js';
import { ecp, rokuCloseAll } from './roku.js';
import { gtv } from './googletv.js';
import { fire as adb } from './firetv-official.js';   // build 27: official Fire TV remote first, build 21 ADB as fallback
import { atvx } from './appletv.js';
import { err } from './bytes.js';
import { dlog, getLog } from './dbg.js';
import { perfNew } from './perf.js';

export const NATIVE_PLATFORMS = ['roku', 'googletv', 'firetv', 'appletv'];
const HOST_RE = /^[A-Za-z0-9]([A-Za-z0-9.-]{0,251}[A-Za-z0-9])?$/;

export function makeStore(ls) {
  const mem = new Map();
  const g = (k) => { try { const v = ls ? ls.getItem('spin.' + k) : mem.get(k); return v == null ? null : JSON.parse(v); } catch { return null; } };
  const s = (k, v) => { const j = JSON.stringify(v); if (ls) ls.setItem('spin.' + k, j); else mem.set(k, j); };
  return { get: g, set: s, del: (k) => { if (ls) ls.removeItem('spin.' + k); else mem.delete(k); } };
}

// _companion-link._tcp is also advertised by iPhones, Macs and HomePods; only Apple TVs (rpMd = "AppleTV…") are wanted.
const isAppleTv = (r) => /^AppleTV/i.test((r.txt && (r.txt.rpMd || r.txt.model)) || '') || (!(r.txt && r.txt.rpMd) && /apple ?tv/i.test(r.name || ''));

export function createBackend({ makeSim, store, transport, ports = {}, ssdpTarget }) {
  if (transport) setTransport(transport);
  let demo = !!store.get('demo'), simH = null;
  const sim = () => (simH || (simH = makeSim()));
  const devices = () => store.get('devices') || [];
  const saveDevices = (l) => store.set('devices', l);
  const pub = (d) => ({ id: d.id, platform: d.platform, name: d.name, host: d.host, paired: !!d.paired });
  const find = (id) => { const d = devices().find((x) => x.id === id); if (!d) throw err('Unknown device', 'not_found'); return d; };
  const upsert = (d) => { const l = devices(), i = l.findIndex((x) => x.id === d.id); if (i >= 0) { l[i] = { ...l[i], ...d, paired: l[i].paired || d.paired }; } else l.push(d); saveDevices(l); return l.find((x) => x.id === d.id); };
  const mk = (platform, host, name, paired, extra) => ({ id: `${platform}-${host}`, platform, host, name, paired, ...(ports[platform] ? { ports: ports[platform] } : {}), ...extra });
  const setPaired = (id, v) => saveDevices(devices().map((d) => (d.id === id ? { ...d, paired: v } : d)));

  // Only the platform being paired is searched (Android's NSD allows very few concurrent operations, and one platform's failure must not taint another's).
  // mDNS searches run one after another; a port sweep of the phone's /24 is the fallback that needs no multicast at all.
  async function prepare() {
    try { if (T().prepare) { const i = await T().prepare({ noPrompt: prompted }); prompted = true; globalThis.__netinfo = i; dlog('network: ' + JSON.stringify(i)); } }
    catch (e) { dlog('prepare failed: ' + ((e && e.message) || e)); }
  }
  let prompted = false;

  /** Which of these saved TVs answer on the network the phone is on right now (short parallel port check). Never throws. */
  async function reach(list, ms = 1200) {
    const portOf = (d) => { const p = { ...(ports[d.platform] || {}), ...(d.ports || {}) }; return d.platform === 'roku' ? (p.http || 8060) : d.platform === 'googletv' ? [p.remote || 6466, p.pair || 6467] : d.platform === 'firetv' ? [p.adb || 5555, p.dial || 8009] : (p.companion || 49153); };
    const live = [];
    await Promise.all(list.map(async (d) => { try { const rows = await T().probe({ host: d.host, ports: [].concat(portOf(d)), timeoutMs: ms }); if ((rows || []).some((r) => r.state === 'open')) live.push(d.id); } catch (e) { /* not reachable from here */ } }));
    return live;
  }
  async function reachable() {
    await prepare();
    const saved = devices(), live = await reach(saved);
    dlog(`reachable: ${live.length}/${saved.length} saved TV(s) answer on this network`);
    return { live };
  }

  // Build 23: everything runs at once and each TV is listed the moment it answers (the UI polls /api/discover/progress while a scan runs):
  //   saved TVs on this Wi-Fi (quick port check) · SSDP for Rokus (short rounds, re-sent) · mDNS for every type together · a quick /24 port sweep.
  let progress = { running: false, seen: new Set(), t0: 0, first: null };
  async function discover(body = {}) {
    const only = NATIVE_PLATFORMS.includes(body.platform) ? body.platform : null, want = (p) => !only || only === p;
    dlog(`discover: ${only || 'all platforms'}`);
    const t0 = Date.now(); const seenIds = new Set(); progress = { running: true, seen: seenIds, t0, first: null };
    const prep = prepare();
    let added = 0; const foundBy = new Set();
    const known = new Set(devices().map((d) => d.id));
    const note = (d) => {
      const fire = d.platform === 'googletv' && devices().some((x) => x.platform === 'firetv' && x.host === d.host); if (fire) return;   // a Fire TV also answers like an Android TV
      foundBy.add(d.platform); if (!seenIds.size) { progress.first = Date.now() - t0; dlog(`discover: first TV after ${progress.first} ms`); }
      seenIds.add(d.id); if (!known.has(d.id)) { added++; known.add(d.id); } upsert(d);
    };
    const diag = { mdns: [], sweep: '', platform: only };
    const nameFail = (what, e) => { const m = `${what}: ${(e && e.message) || e}`; diag.mdns.push(m); dlog('discover: ' + m); };
    const tasks = [];
    // 1. TVs we already know: listed as soon as they answer a quick port check on this network (a TV on another Wi-Fi never shows).
    const saved = devices().filter((d) => want(d.platform));
    tasks.push(reach(saved, 800).then((live) => { for (const id of live) { const d = devices().find((x) => x.id === id); if (d) { if (!seenIds.size) progress.first = Date.now() - t0; seenIds.add(id); } } }).catch(() => {}));
    await prep;
    // 2. Rokus: short SSDP rounds (the query is re-sent inside each round); every reply's name is fetched in parallel.
    if (want('roku')) tasks.push((async () => {
      const asked = new Set(), infos = [];
      for (const ms of [700, 1200, 1500]) {
        let hits = []; try { hits = await ecp.discover({ ssdpTarget, timeoutMs: ms }); } catch (e) { dlog('ssdp failed: ' + ((e && e.message) || e)); }
        for (const r of hits) if (!asked.has(r.host)) { asked.add(r.host); infos.push(ecp.deviceInfo(r.host, r.port).then((i) => note(mk('roku', r.host, i.name, true, r.port !== 8060 ? { ports: { ...(ports.roku || {}), http: r.port } } : {}))).catch(() => {})); }
      }
      await Promise.allSettled(infos);
    })());
    // 3. mDNS: all service types at once (the phone asks the network directly first, which needs no NSD slot).
    const mq = (type) => T().mdns({ type, timeoutMs: 1500 });
    if (want('firetv')) tasks.push(mq('_amzn-wplay._tcp.').then((rs) => { for (const r of rs) note(mk('firetv', r.host, (r.txt && r.txt.n) || r.name || 'Fire TV', false)); }).catch((e) => nameFail('Fire TV', e)));
    if (want('googletv')) tasks.push(mq('_androidtvremote2._tcp.').then((rs) => { for (const r of rs) note(mk('googletv', r.host, r.name || 'Android TV', false, r.port && r.port !== 6466 ? { ports: { ...(ports.googletv || {}), remote: r.port, pair: r.port + 1 } } : {})); }).catch((e) => nameFail('Google TV', e)));
    if (want('appletv')) tasks.push(mq('_companion-link._tcp.').then((svc) => { const ign = []; for (const r of svc) { if (!isAppleTv(r)) { ign.push(`${(r.name || r.host).replace(/\\032/g, ' ')} (${(r.txt && (r.txt.rpMd || r.txt.model)) || 'unknown model'})`); continue; } note(mk('appletv', r.host, (r.name || 'Apple TV').replace(/\\032/g, ' '), false, { ports: { ...(ports.appletv || {}), companion: r.port } })); } diag.mdns.push(`Apple TV (_companion-link._tcp): ${svc.length ? svc.length + ' service(s) seen' : 'no answer from any Apple TV'}${ign.length ? '; ignored (not an Apple TV): ' + ign.join(', ') : ''}${svc.length === 0 ? ' — wake the Apple TV, make sure it is on this Wi-Fi, or add it by IP' : ''}`); }).catch((e) => nameFail('Apple TV', e)));
    // 4. Quick sweep of the phone's /24 for Roku / Google TV ports, at the same time (works where multicast is blocked).
    if (want('roku') || want('googletv')) tasks.push((async () => {
      try {
        const rp = (ports.roku || {}).http || 8060, gp = (ports.googletv || {}).pair || 6467, gc = (ports.googletv || {}).remote || 6466;
        const scan = []; if (want('roku')) scan.push(rp); if (want('googletv')) scan.push(gp, gc);
        const open = await T().tcpScan({ ports: scan, timeoutMs: 300 });
        const pre = (open.prefixes || []).join(' '), done = new Set();
        const infos = [];
        for (const r of open) {
          if (done.has(r.host)) continue;
          if (r.port === rp && want('roku')) { done.add(r.host); if (!seenIds.has('roku-' + r.host)) infos.push(ecp.deviceInfo(r.host, rp).then((i) => note(mk('roku', r.host, i.name, true, rp !== 8060 ? { ports: { ...(ports.roku || {}), http: rp } } : {}))).catch(() => {})); }
          else if ((r.port === gp || r.port === gc) && want('googletv')) { done.add(r.host); const id = 'googletv-' + r.host, have = devices().find((x) => x.id === id); if (!seenIds.has(id)) note(mk('googletv', r.host, have ? have.name : 'Android TV', false)); }
        }
        await Promise.allSettled(infos);
        diag.sweep = `Scanned ${pre || 'this Wi-Fi network'} for ${scan.join('/')}: ${open.length ? open.map((r) => r.host + ':' + r.port).join(', ') : 'nothing answered'}`;
        dlog('discover: ' + diag.sweep);
      } catch (e) { diag.sweep = `Port scan failed: ${(e && e.message) || e}`; dlog('discover: ' + diag.sweep); }
    })());
    try { await Promise.allSettled(tasks); } finally { progress.running = false; }
    dlog(`discover: seen ${seenIds.size} device(s) in ${Date.now() - t0} ms (first after ${progress.first == null ? '—' : progress.first + ' ms'}); saved but not reachable here: ${saved.filter((d) => !seenIds.has(d.id)).map((d) => d.name).join(', ') || 'none'}`);
    return { found: added, devices: devices().map(pub), seen: [...seenIds], diag, firstMs: progress.first, totalMs: Date.now() - t0 };
  }
  const discoverProgress = () => ({ running: progress.running, devices: devices().map(pub), seen: [...progress.seen], firstMs: progress.first });

  async function addDevice({ platform, host, name }) {
    await prepare();
    host = String(host || '').trim().replace(/^https?:\/\//, '').replace(/[:/].*$/, '');
    if (!HOST_RE.test(host)) throw err('That doesn’t look like an IP address (try 192.168.1.50).', 'bad_host');
    if (platform === 'appletv') {
      let port = (ports.appletv || {}).companion, nm = name;
      if (!port) { try { const f = (await T().mdns({ type: '_companion-link._tcp.', timeoutMs: 2500 })).find((r) => r.host === host && isAppleTv(r)); if (f) { port = f.port; nm = nm || f.name; } } catch (e) { /* mDNS unavailable */ } }
      await atvx.probe(host, { companion: port || 49153 });
      return pub(upsert(mk('appletv', host, nm || 'Apple TV ' + host, false, { ports: { ...(ports.appletv || {}), companion: port || 49153 } })));
    }
    if (platform === 'roku') { const i = await ecp.deviceInfo(host, (ports.roku || {}).http || 8060); return pub(upsert(mk('roku', host, name || i.name, true))); }
    if (platform === 'googletv') { await gtv.probe(host, { pair: (ports.googletv || {}).pair || 6467 }); return pub(upsert(mk('googletv', host, name || 'Android TV ' + host, false))); }
    if (platform === 'firetv') { await adb.probe(host, { adb: (ports.firetv || {}).adb || 5555 }); return pub(upsert(mk('firetv', host, name || 'Fire TV ' + host, false))); }
    throw err('Unknown platform', 'bad_platform');
  }

  const lastTx = new Map();                                            // device id -> promise that settles when that TV's latest command has been transmitted
  async function send(b) {
    const d = find(b.device);
    if (d.platform !== 'roku' && !d.paired) throw err('Pair this device first', 'not_paired');
    const P = { roku: ecp, googletv: gtv, firetv: adb, appletv: atvx }[d.platform]; if (!P) throw err('Not supported', 'unsupported');
    const dev = d.platform === 'roku' && d.ports && d.ports.http ? { ...d, port: d.ports.http } : { ...d, port: (d.ports || {}).http };
    const tr = perfNew({ platform: d.platform, key: b.action === 'key' ? b.key : b.action, pressed: b.t_press }); tr.queued();
    // Ordering: a command is handed to its TV only after the previous command for that TV has been *transmitted* (not acknowledged), so presses never overtake each other but are not serialised behind slow acks.
    const prev = lastTx.get(d.id); lastTx.set(d.id, tr.txP);
    try {
      if (prev) { let to; await Promise.race([prev, new Promise((r) => { to = setTimeout(r, 300); })]); clearTimeout(to); }
      const o = { repeat: !!b.repeat, trace: tr };
      let wire;
      if (d.platform === 'googletv' && gtv.forgot(d.id)) { gtv.reset(d, store, true); setPaired(d.id, false); throw err('The TV dropped the connection right after connecting: it no longer accepts this phone’s pairing (not paired any more). Pair again.', 'not_paired'); }
      if (b.action === 'key') wire = await P.key(dev, b.key, store, o);
      else if (b.action === 'text') wire = await P.text(dev, b.text, store, o);
      else if (b.action === 'launch') wire = await P.launch(dev, b.app, store, o);
      else if (b.action === 'search') { if (!P.search) throw err('Search by voice isn’t available for this TV.', 'no_search'); wire = await P.search(dev, b.text, store, o); }
      else throw err('Unknown action', 'bad_action');
      tr.transmitted(); if (P.hasAck) tr.acked(); else tr.noAck();
      return { ok: true, wire, how: o.how };
    } catch (e) { tr.failed(e); if (e.code === 'not_paired') setPaired(d.id, false); throw e; }
  }

  /** What this TV can do, asked before the buttons are offered (never assumes a streaming box controls the physical TV's volume). */
  async function caps(b) {
    const d = devices().find((x) => x.id === b.device); if (!d) return { volume: 'maybe', mute: true, search: false };
    const dev = d.platform === 'roku' && d.ports && d.ports.http ? { ...d, port: d.ports.http } : { ...d, port: (d.ports || {}).http };
    if (d.platform === 'roku') { const v = await ecp.volume(dev); return { volume: v, mute: v !== 'no', search: true, searchHow: 'roku search' }; }
    if (d.platform === 'googletv') return { volume: 'yes', mute: true, search: true, searchHow: 'search key + text field' };
    if (d.platform === 'firetv') { const v = d.paired && adb.volumeCaps ? await adb.volumeCaps(dev, store) : 'yes'; return { volume: v, mute: v !== 'no', search: true, searchHow: 'search screen + typed text' }; }
    if (d.platform === 'appletv') return { volume: 'yes', mute: false, search: true, searchHow: 'text field' };
    return { volume: 'maybe', mute: true, search: false };
  }

  /** Open the control connection ahead of the first press (Fire TV ADB + persistent shell, Google TV TLS, Apple TV verified session, Roku volume capability). Best-effort. */
  async function warm(b) {
    const d = (devices().find((x) => x.id === b.device)); if (!d) return { ok: false };
    if (d.platform !== 'roku' && !d.paired) return { ok: false };
    const P = { roku: ecp, googletv: gtv, firetv: adb, appletv: atvx }[d.platform]; if (!P || !P.warm) return { ok: false };
    const dev = d.platform === 'roku' && d.ports && d.ports.http ? { ...d, port: d.ports.http } : { ...d, port: (d.ports || {}).http };
    const t0 = Date.now(); try { await P.warm(dev, store); dlog(`warm ${d.platform} ${d.host} ${Date.now() - t0} ms`); return { ok: true, ms: Date.now() - t0 }; } catch (e) { dlog(`warm ${d.platform} failed: ${e.message}`); return { ok: false, why: e.message }; }
  }

  async function handler(path, opts = {}) {
    if (demo) return sim()(path, opts);
    const body = opts.body ? JSON.parse(opts.body) : {}, m = opts.method || 'GET';
    if (path === '/api/devices' && m === 'GET') return { devices: devices().map(pub), demo: false };
    if (path === '/api/discover/progress') return discoverProgress();
    if (path === '/api/discover') return discover(body);
    if (path === '/api/reachable') return reachable();
    if (path === '/api/devices' && m === 'POST') return addDevice(body);
    if (path.startsWith('/api/devices/') && m === 'DELETE') { const id = path.split('/').pop(); saveDevices(devices().filter((d) => d.id !== id)); return { ok: true }; }
    if (path === '/api/check' && m === 'POST') {                        // build 21: a Google TV counts as ready only after the TV finished the real remote handshake (remote_start)
      const d = find(body.device); if (d.platform !== 'googletv') return { ok: true };
      try { await gtv.session(d, store); return { ok: true }; }
      catch (e) { if (e.code === 'not_paired') { gtv.reset(d, store, true); setPaired(d.id, false); } throw e; }
    }
    if (path === '/api/devices/reset' && m === 'POST') {             // hidden "reset this TV": forget every saved key for ONE TV, keep the TV in the list unpaired
      const d = find(body.device); if (d.platform === 'googletv') gtv.reset(d, store);
      setPaired(d.id, false); dlog(`reset ${d.platform} ${d.host}`); return { ok: true };
    }
    if (path === '/api/send') return send(body);
    if (path === '/api/warm') return warm(body);
    if (path === '/api/caps') return caps(body);
    if (path === '/api/pair/start') {
      const d = find(body.device); await prepare(); dlog(`pair/start ${d.platform} ${d.host}`);
      if (d.platform === 'roku') return { status: 'paired' };
      if (d.platform === 'googletv') { const r = await gtv.pairStart(d, store); if (r.status === 'paired') setPaired(d.id, true); return r; }
      if (d.platform === 'appletv') return atvx.pairStart(d, store);
      if (d.platform === 'firetv') { const r = await adb.pairStart(d, store); if (r.status === 'paired') setPaired(d.id, true); return r; }
      throw err('Not supported', 'unsupported');
    }
    if (path === '/api/pair/finish') {
      const d = find(body.device); let r;
      if (d.platform === 'googletv') r = await gtv.pairFinish(d, body.code, store);
      else if (d.platform === 'appletv') r = await atvx.pairFinish(d, body.code, store);
      else if (d.platform === 'firetv') r = await adb.pairFinish(d, store, body.code);
      else r = { status: 'paired' };
      if (r.status === 'paired') setPaired(d.id, true);
      return r;
    }
    throw err('native: ' + path, 'not_found');
  }

  return {
    handler,
    info: () => ({ demo, native: true, version: 'native', platforms: demo ? ['roku', 'firetv', 'googletv', 'appletv'] : NATIVE_PLATFORMS }),
    setDemo(on) { demo = !!on; store.set('demo', demo); return demo; },
    debugLog: () => getLog(),
    closeAll() { rokuCloseAll(); gtv.closeAll(); adb.closeAll(); atvx.closeAll(); },
  };
}
