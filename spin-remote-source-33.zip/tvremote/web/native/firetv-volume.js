// Spin Remote — Fire TV volume and mute (build 33). Everything the app does for Fire TV volume is in this one file.
//
// What the official Fire TV app sends (read from its decompiled bundle for interoperability only; no code copied):
//   * A short tap on volume up/down/mute: POST https://<tv>:8080/v1/FireTV?action=volume_up|volume_down|mute, empty body,
//     headers x-amzn-request-id (random), x-api-key, x-client-token (from pairing), Content-Type: application/json; charset=utf-8.
//   * Holding the button (300 ms or more): the same POST with body {"keyActionType":"keyDown"}, then on release {"keyActionType":"keyUp"}.
//   * The app also defines a third key action, "keyDownUp", but its buttons never send it.
//   * Its HTTP library (OkHttp 4.12.0) adds Content-Length: 0, Host, Connection: Keep-Alive, Accept-Encoding: gzip, User-Agent: okhttp/4.12.0.
//
// Why this file exists: a Fire TV answered our tap with 200 {"description":"OK"} but the volume did not move. A 200 is not proof.
// So each press here:
//   1. reads the TV's own reported volume first (GET /v1/FireTV/status, /v1/FireTV/properties, /v1/FireTV), if the TV reports one;
//   2. sends the press in one form (see FORMS) and reads the volume again;
//   3. if the number did not move, silently tries the next form, at most once each, for this one press;
//   4. remembers the form that really moved the volume and uses only that from then on;
//   5. tells the screen "done" only when the reported volume changed, or when the TV does not report volume at all
//      (then we cannot check, and the official form is sent once, exactly as the official app does).
// Every request and every TV answer is written to the debug log.

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const ACTION = { vol_up: 'volume_up', vol_down: 'volume_down', mute: 'mute' };
const SETTLE_MS = 350;                 // give the TV a moment to apply the change before reading it back
const memKey = (dev) => `ftv.volume.form.${dev.id}`;

/** The press forms, most likely first. Each one is something the official app itself sends (or defines). */
export const FORMS = [
  { id: 'tap', why: 'official short tap (empty body)', steps: [null] },
  { id: 'hold', why: 'official hold: keyDown, then keyUp', steps: [{ keyActionType: 'keyDown' }, { keyActionType: 'keyUp' }], gapMs: 120 },
  { id: 'downup', why: 'official key action "keyDownUp" (defined by the app, unused by its buttons)', steps: [{ keyActionType: 'keyDownUp' }] },
];

/** Find a volume number / mute flag anywhere in a JSON answer. null when the TV does not report it. */
export function readVolumeFields(json) {
  let level = null, muted = null;
  const walk = (v, k = '') => {
    if (v && typeof v === 'object') { for (const [kk, vv] of Object.entries(v)) walk(vv, kk); return; }
    if (/capab|support|troubleshoot|url/i.test(k)) return;
    if (level === null && /volume/i.test(k) && v !== '' && v !== null && !isNaN(Number(v)) && typeof v !== 'boolean') level = Number(v);
    if (muted === null && /mute/i.test(k) && (typeof v === 'boolean' || v === 'true' || v === 'false')) muted = v === true || v === 'true';
  };
  walk(json);
  return level === null && muted === null ? null : { level, muted };
}

/**
 * wire = { send(dev, path, token, body) → {status, body, head}, get(dev, path, token) → same, token(dev, store), statusLine(r), dlog, err }
 * Returns a text for the debug log on success. Throws err(..., 'not_paired' | 'protocol' | 'volume_unchanged').
 */
export async function fireVolume(wire, dev, store, key) {
  const action = ACTION[key]; const tok = wire.token(dev, store); if (!action || !tok) return null;
  const path = `/v1/FireTV?action=${action}`;

  const snapshot = async (label) => {
    for (const p of ['/v1/FireTV/status', '/v1/FireTV/properties', '/v1/FireTV']) {
      try {
        const r = await wire.get(dev, p, tok);
        wire.dlog(`fire volume: ${label} GET ${p} → ${wire.statusLine(r)} body: ${(r.body || '(empty)').slice(0, 400)}`);
        if (r.status < 200 || r.status >= 300) continue;
        let j = null; try { j = JSON.parse(r.body); } catch (e) { continue; }
        const v = readVolumeFields(j); if (v) return { ...v, from: p };
      } catch (e) { wire.dlog(`fire volume: ${label} GET ${p} failed: ${e.message}`); }
    }
    return null;
  };
  const changed = (a, b) => !!(a && b) && ((key === 'mute') ? (a.muted !== null && b.muted !== null ? a.muted !== b.muted : a.level !== b.level) : a.level !== null && b.level !== null && a.level !== b.level);
  const sendForm = async (f) => {
    for (let i = 0; i < f.steps.length; i++) {
      if (i && f.gapMs) await sleep(f.gapMs);
      const body = f.steps[i], r = await wire.send(dev, path, tok, body);
      wire.dlog(`fire volume: [${f.id}] POST ${path}${body ? ' ' + JSON.stringify(body) : ' (empty body)'} → ${wire.statusLine(r)} body: ${r.body || '(empty)'}`);
      if (r.status === 401 || r.status === 403) { store.del('ftv.lightning.' + dev.id); throw wire.err('The Fire TV no longer accepts this phone’s code', 'not_paired'); }
      if (r.status < 200 || r.status >= 300) return false;
    }
    return true;
  };

  const before = await snapshot('before');
  const known = FORMS.find((f) => f.id === store.get(memKey(dev)));
  if (!before) {
    // The TV does not say what its volume is: nothing to check against. Send the remembered form, else the official tap, once.
    const f = known || FORMS[0];
    if (!(await sendForm(f))) throw wire.err(`Fire TV did not accept ${action}`, 'protocol');
    return `Fire TV volume: ${f.id} sent (this TV does not report its volume, so the change can't be checked)`;
  }
  wire.dlog(`fire volume: TV reports volume ${before.level ?? '?'}${before.muted !== null ? `, muted ${before.muted}` : ''} (${before.from})`);
  const order = known ? [known, ...FORMS.filter((f) => f !== known)] : FORMS;
  let last = before;
  for (const f of order) {
    if (!(await sendForm(f))) continue;
    await sleep(SETTLE_MS);
    const after = await snapshot(`after ${f.id}`);
    if (changed(last, after)) {
      if (store.get(memKey(dev)) !== f.id) { store.set(memKey(dev), f.id); wire.dlog(`fire volume: "${f.id}" really changed the volume on this TV — remembered`); }
      const show = (v) => (key === 'mute' && v.muted !== null ? `muted ${v.muted}` : `${v.level}`);
      return `Fire TV volume: ${f.id} changed ${show(last)} → ${show(after)} (checked on the TV)`;
    }
    if (after) last = after;
    wire.dlog(`fire volume: [${f.id}] TV said OK but its volume did not change`);
  }
  if (known) store.del(memKey(dev));
  throw wire.err('The Fire TV accepted the volume press but its volume did not change', 'protocol');
}
