// In-app debug log: kept in memory (and mirrored to localStorage so it survives a crash/restart) so the user can copy it from the pairing sheet.
// Never logs keys, certificates, codes or typed text.
const KEY = 'spin.dbglog', MAX = 400;
export const BUILD = 'spin-remote-test33 · 2026-11-01';
let lines = [], mem = null, timer = null;
const ls = () => { try { return typeof localStorage !== 'undefined' ? localStorage : null; } catch { return null; } };
try { const s = ls(); lines = JSON.parse((s && s.getItem(KEY)) || '[]'); } catch { lines = []; }
const stamp = () => { const t = new Date(); return t.toTimeString().slice(0, 8) + '.' + String(t.getMilliseconds()).padStart(3, '0'); };
const fmt = (x) => { if (typeof x === 'string') return x; try { return JSON.stringify(x); } catch { return String(x); } };
function save() { if (timer) return; timer = setTimeout(() => { timer = null; try { const s = ls(); if (s) s.setItem(KEY, JSON.stringify(lines)); } catch { /* storage full: keep memory copy */ } }, 400); }
export function dlog(...a) {
  const l = `${stamp()} ${a.map(fmt).join(' ')}`.slice(0, 700);
  lines.push(l); if (lines.length > MAX) lines = lines.slice(-MAX); save();
  if (globalThis.__DLOG_ECHO) console.log('[dlog]', l);
}
export const clearLog = () => { lines = []; save(); };
export function getLog() {
  const ni = globalThis.__netinfo || {};
  const head = [`Spin Remote debug log — ${BUILD}`, `now: ${new Date().toString()}`, `webview: ${(globalThis.navigator && navigator.userAgent) || '?'}`,
    `phone: ${ni.device || '?'} · Android ${ni.android || '?'} · Wi-Fi IP ${ni.phoneIp || '?'}`, `network: ${ni.network || '?'}`,
    `permissions: nearby-devices ${ni.nearbyPermission || '?'} · local-network ${ni.localNetworkPermission || '?'}`, '-----'];
  return head.concat(lines).join('\n');
}
dlog('--- app started ---', BUILD);
