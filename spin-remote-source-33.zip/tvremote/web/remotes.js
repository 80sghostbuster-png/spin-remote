// Original generic remote designs (no vendor artwork). Text labels only.
const S = (inner, extra = '') => `<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" ${extra}>${inner}</svg>`;
const F = (inner) => `<svg viewBox="0 0 24 24" width="22" height="22" fill="currentColor">${inner}</svg>`;
export const I = {
  power: S('<path d="M12 3v8"/><path d="M6.3 6.8a8 8 0 1 0 11.4 0"/>'),
  back: S('<path d="M9 4 4 9l5 5M4 9h9a6 6 0 0 1 0 12h-1"/>'),
  home: S('<path d="M3 11.5 12 4l9 7.5"/><path d="M5.5 10v9.5h13V10"/>'),
  menu: S('<path d="M4 7h16M4 12h16M4 17h16"/>'),
  options: S('<path d="M12 4v16M5 7.5l14 9M19 7.5l-14 9"/>'),
  replay: S('<path d="M4 4v5h5M4 9A8.5 8.5 0 1 1 4.6 15"/>'),
  rew: F('<path d="M11 6.5v11L3 12zM21 6.5v11L13 12z"/>'),
  ff: F('<path d="M13 6.5v11l8-5.5zM3 6.5v11L11 12z"/>'),
  play_pause: F('<path d="M3 5.5v13L11.5 12z"/><rect x="14" y="5.5" width="3" height="13" rx="1"/><rect x="19" y="5.5" width="3" height="13" rx="1"/>'),
  play: F('<path d="M7 4.5v15l13-7.5z"/>'),
  mute: S('<path d="M4 9.5v5h3.5L12 18.5v-13L7.5 9.5z" fill="currentColor"/><path d="m16 9.5 5 5M21 9.5l-5 5"/>'),
  volup: S('<path d="M3 9.5v5h3.5L11 18.5v-13L6.5 9.5z" fill="currentColor"/><path d="M15 12h6M18 9v6"/>'),
  voldown: S('<path d="M3 9.5v5h3.5L11 18.5v-13L6.5 9.5z" fill="currentColor"/><path d="M15 12h6"/>'),
  plus: S('<path d="M12 5v14M5 12h14"/>'),
  minus: S('<path d="M5 12h14"/>'),
  mic: S('<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/>'),
  backspace: S('<path d="M21 5H9l-6 7 6 7h12z"/><path d="m12 9 5 6M17 9l-5 6"/>'),
  enter: S('<path d="M20 5v7a3 3 0 0 1-3 3H5"/><path d="m9 11-4 4 4 4"/>'),
  kbd: S('<rect x="2.5" y="6" width="19" height="12" rx="2.5"/><path d="M6 10h.01M10 10h.01M14 10h.01M18 10h.01M7 14h10"/>'),
  tv: S('<rect x="3" y="5" width="18" height="12" rx="2"/><path d="M8 21h8"/>'),
  up: S('<path d="m6 15 6-6 6 6"/>'), down: S('<path d="m6 9 6 6 6-6"/>'),
  left: S('<path d="m15 6-6 6 6 6"/>'), right: S('<path d="m9 6 6 6-6 6"/>'),
  assistant: `<svg viewBox="0 0 28 14" width="28" height="14"><circle cx="4" cy="7" r="3" fill="#4d9bff"/><circle cx="11" cy="7" r="3" fill="#ff5d5d"/><circle cx="18" cy="7" r="3" fill="#ffc83d"/><circle cx="25" cy="7" r="3" fill="#35d07f"/></svg>`,
  reel: S('<rect x="9" y="4" width="6" height="16" rx="1.5"/><path d="M5 7v10M19 7v10M2 9.5v5M22 9.5v5"/>'),
  ring: S('<ellipse cx="12" cy="12" rx="9.5" ry="4.5" transform="rotate(-18 12 12)"/><circle cx="19.2" cy="7.4" r="1.6" fill="currentColor"/><circle cx="4.8" cy="16.6" r="1.6" fill="currentColor"/>'),
  sound: S('<path d="M4 9.5v5h3.5L12 18.5v-13L7.5 9.5z" fill="currentColor"/><path d="M16 9a4.5 4.5 0 0 1 0 6M18.5 6.5a8 8 0 0 1 0 11"/>'),
  soundoff: S('<path d="M4 9.5v5h3.5L12 18.5v-13L7.5 9.5z" fill="currentColor"/><path d="m16 9.5 5 5M21 9.5l-5 5"/>'),
  cast: S('<path d="M3 8V6a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-6"/><path d="M3 12a8 8 0 0 1 8 8M3 16a4 4 0 0 1 4 4M3 20h.01"/>'),
  close: S('<path d="M6 6l12 12M18 6 6 18"/>'),
};

const b = (key, icon, cls = '', label = '', extra = '') =>
  `<button class="btn ${cls}" data-key="${key}" aria-label="${label || key}" ${extra}>${icon}</button>`;
const t = (key, text, cls = '', label = '', extra = '') =>
  `<button class="btn ${cls}" data-key="${key}" aria-label="${label || text}" ${extra}><span>${text}</span></button>`;
const dpad = (cls = '') => `
  <div class="dpad ${cls}" data-nospin-x>
    <button class="dp dp-up" data-key="up" data-repeat aria-label="Up">${I.up}</button>
    <button class="dp dp-right" data-key="right" data-repeat aria-label="Right">${I.right}</button>
    <button class="dp dp-down" data-key="down" data-repeat aria-label="Down">${I.down}</button>
    <button class="dp dp-left" data-key="left" data-repeat aria-label="Left">${I.left}</button>
    <button class="btn dp-ok" data-key="select" aria-label="OK"><span>OK</span></button>
  </div>`;
const app = (id, label, cls) => `<button class="btn app ${cls}" data-launch="${id}" aria-label="Launch ${label}"><span>${label}</span></button>`;

export const REMOTES = {
  roku: {
    id: 'roku', name: 'Roku', short: 'ROKU', accent: '#b45cff', textEntry: true,
    html: () => `
    <div class="remote roku">
      <div class="r-top">
        ${b('kbd', I.kbd, 'round sm', 'Keyboard', 'data-kbd')}
        <div class="wordmark">roku<i>remote</i></div>
        ${b('power', I.power, 'round sm power', 'Power')}
      </div>
      ${dpad()}
      <div class="grid2">
        ${b('back', I.back, 'pill', 'Back')}${b('home', I.home, 'pill', 'Home')}
        ${b('replay', I.replay, 'pill', 'Replay')}${b('options', I.options, 'pill', 'Options')}
      </div>
      <div class="row3">${b('rew', I.rew, 'round', 'Rewind')}${b('play_pause', I.play_pause, 'round big', 'Play/Pause')}${b('ff', I.ff, 'round', 'Fast forward')}</div>
      <div class="row3 vol">${b('vol_down', I.voldown, 'pill', 'Volume down', 'data-repeat')}${b('mute', I.mute, 'pill', 'Mute')}${b('vol_up', I.volup, 'pill', 'Volume up', 'data-repeat')}</div>
      <div class="apps4">${app('netflix', 'NETFLIX', 'a-red')}${app('youtube', 'YOUTUBE', 'a-ytred')}${app('prime', 'PRIME', 'a-blue')}${app('disney', 'DISNEY+', 'a-navy')}</div>
    </div>`,
  },
  firetv: {
    id: 'firetv', name: 'Fire TV', short: 'FIRE', accent: '#ff9a1f', textEntry: true,
    html: () => `
    <div class="remote firetv">
      <div class="r-top">
        ${b('kbd', I.kbd, 'round sm', 'Keyboard', 'data-kbd')}
        <div class="wordmark">fire<i>tv</i></div>
        ${b('power', I.power, 'round sm power', 'Power')}
      </div>
      ${dpad()}
      <div class="row3">${b('back', I.back, 'round', 'Back')}${b('home', I.home, 'round', 'Home')}${b('menu', I.menu, 'round', 'Menu')}</div>
      <div class="row3">${b('rew', I.rew, 'round', 'Rewind')}${b('play_pause', I.play_pause, 'round big', 'Play/Pause')}${b('ff', I.ff, 'round', 'Fast forward')}</div>
      <div class="row3 vol">${b('vol_down', I.voldown, 'pill', 'Volume down', 'data-repeat')}${b('mute', I.mute, 'pill', 'Mute')}${b('vol_up', I.volup, 'pill', 'Volume up', 'data-repeat')}</div>
    </div>`,
  },
  googletv: {
    id: 'googletv', name: 'Google TV', short: 'GOOGLE', accent: '#4d9bff', textEntry: true,
    html: () => `
    <div class="remote googletv">
      <div class="r-top">
        ${b('kbd', I.kbd, 'round sm', 'Keyboard', 'data-kbd')}
        ${b('assistant', I.assistant, 'pill assist', 'Assistant')}
        ${b('power', I.power, 'round sm power', 'Power')}
      </div>
      ${dpad('light')}
      <div class="row2">${b('back', I.back, 'round', 'Back')}${b('home', I.home, 'round', 'Home')}${b('tv', I.tv, 'round', 'Live TV')}</div>
      <div class="gt-mid">
        <div class="row3 tight">${b('rew', I.rew, 'round', 'Rewind')}${b('play_pause', I.play_pause, 'round big', 'Play/Pause')}${b('ff', I.ff, 'round', 'Fast forward')}</div>
      </div>
      <div class="gt-vol">
        <div class="rocker">${b('vol_up', I.plus, 'rk', 'Volume up', 'data-repeat')}<span class="rk-l">VOL</span>${b('vol_down', I.minus, 'rk', 'Volume down', 'data-repeat')}</div>
        ${b('mute', I.mute, 'round', 'Mute')}
        <div class="rocker">${b('next', I.plus, 'rk', 'Channel up')}<span class="rk-l">CH</span>${b('prev', I.minus, 'rk', 'Channel down')}</div>
      </div>
      <div class="apps2">${app('youtube', 'YouTube', 'a-ytred')}${app('netflix', 'NETFLIX', 'a-red')}</div>
    </div>`,
  },
  appletv: {
    id: 'appletv', name: 'Apple TV', short: 'APPLE', accent: '#e6ebf5', textEntry: true,
    html: () => `
    <div class="remote appletv">
      <div class="r-top">
        ${b('kbd', I.kbd, 'round sm', 'Keyboard', 'data-kbd')}
        <div class="wordmark">tv<i>remote</i></div>
        <span class="spacer-sm"></span>
      </div>
      <div class="clickpad" data-nospin data-clickpad aria-label="Clickpad: swipe, tap edge to click, tap center to select">
        <div class="cp-ring"></div>
        <i class="cp-hint up">${I.up}</i><i class="cp-hint down">${I.down}</i><i class="cp-hint left">${I.left}</i><i class="cp-hint right">${I.right}</i>
        <div class="cp-dot"></div>
        <div class="cp-label">swipe · click</div>
      </div>
      <div class="atv-grid">
        <div class="atv-btns">
          ${b('back', I.back, 'round', 'Menu / Back')}${b('tv', `<span class="tvtxt">${I.tv}</span>`, 'round', 'TV / Home')}
          ${b('play_pause', I.play_pause, 'round', 'Play/Pause')}${b('mute', I.mute, 'round', 'Mute')}
        </div>
        <div class="atv-side">
          ${b('siri', '<i class="siri-orb"></i>', 'round siri', 'Siri')}
          <div class="rocker tall">${b('vol_up', I.plus, 'rk', 'Volume up', 'data-repeat')}<span class="rk-l">VOL</span>${b('vol_down', I.minus, 'rk', 'Volume down', 'data-repeat')}</div>
        </div>
      </div>
    </div>`,
  },
};
export const ORDER = ['roku', 'firetv', 'googletv', 'appletv'];
